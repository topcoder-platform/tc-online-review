package com.topcoder.management.resource;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

public class Resource implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setResourceRole(ResourceRole resourceRole) {
	}
	public ResourceRole getResourceRole() {
		return null;
	}
	public void setProject(Long project) {
	}
	public Long getProject() {
		return null;
	}
	public void setPhase(Long phase) {
	}
	public Long getPhase() {
		return null;
	}
	public void setSubmission(Long submission) {
	}
	public Long getSubmission() {
		return null;
	}
	public void setProperty(String name, Object value) {
	}
	public Object getProperty(String name) {
		return null;
	}
	public Map getAllProperties() {
		return null;
	}
	public void setCreationUser(String creationUser) {
	}
	public String getCreationUser() {
		return null;
	}
	public void setCreationTimestamp(Date creationTimestamp) {
	}
	public Date getCreationTimestamp() {
		return null;
	}
	public void setModificationUser(String modificationUser) {
	}
	public String getModificationUser() {
		return null;
	}
	public void setModificationTimestamp(Date modificationTimestamp) {
	}
	public Date getModificationTimestamp() {
		return null;
	}
}
