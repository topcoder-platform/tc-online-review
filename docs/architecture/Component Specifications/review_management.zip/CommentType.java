package com.topcoder.management.review;

import java.io.Serializable;

public class CommentType implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setName(String name) {
	}
	public String getName() {
		return null;
	}
}
