package com.topcoder.management.review;

import java.io.Serializable;

public class Item implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setAnswer(Object answer) {
	}
	public Object getAnswer() {
		return null;
	}
	public void setQuestion(long question) {
	}
	public long getQuestion() {
		return 0;
	}
	public void setDocument(Long document) {
	}
	public Long getDocument() {
		return null;
	}
	public void addCommnet(Comment comment) {
	}
	public void removeComment(Comment comment) {
	}
	public Comment[] getAllComments() {
		return null;
	}
}
