package com.topcoder.management.review;

import com.topcoder.search.builder.filter.Filter;

public interface ReviewManager {
	void createReview(Review review, String operator);
	void updateReview(Review review, String operator);
	Review getReview(long id);
	Review[] searchReviews(Filter filter, boolean complete);
	CommentType[] getAllCommentTypes();
	void addReviewComment(long review, Comment comment, String operator);
	void addItemComment(long item, Comment comment, String operator);
}
