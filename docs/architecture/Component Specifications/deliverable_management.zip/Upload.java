package com.topcoder.management.deliverable;

import java.io.Serializable;
import java.util.Date;

public class Upload implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setUploadType(UploadType uploadType) {
	}
	public UploadType getUploadType() {
		return null;
	}
	public void setOwner(long owner) {
	}
	public long getOwner() {
		return 0;
	}
	public void setProject(long project) {
	}
	public long getProject() {
		return 0;
	}
	public void setParameter(String parameter) {
	}
	public String getParameter() {
		return null;
	}
	public String getCreationUser() {
		return null;
	}
	public Date getCreationTimestamp() {
		return null;
	}
	public String getModificationUser() {
		return null;
	}
	public Date getModificationTimestamp() {
		return null;
	}
}
