package com.topcoder.management.deliverable;

import java.io.Serializable;

public class SubmissionStatus implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setName(String name) {
	}
	public String getName() {
		return null;
	}
}
