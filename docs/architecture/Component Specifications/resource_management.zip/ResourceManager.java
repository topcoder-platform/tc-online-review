package com.topcoder.management.resource;

import com.topcoder.search.builder.filter.Filter;

public interface ResourceManager {
	void updateResource(Resource resource, String operator);
	void updateResources(Resource[] resources, long project, String operator);
	Resource getResource(long id);
	Resource[] searchResource(Filter filter);
	ResourceRole[] getAllResourceRoles();
	void addNotifications(long[] users, long project, long notificationType, String operator);
	void removeNotifications(long[] users, long project, long notificationType, String opertator);
	long[] getNotifications(long project, long notificationType);
	NotificationType[] getAllNotificationTypes();
}
