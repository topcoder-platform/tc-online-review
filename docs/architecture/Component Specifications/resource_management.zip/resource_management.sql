CREATE TABLE project (
  project_id                    INTEGER                     NOT NULL,
  PRIMARY KEY(project_id)
);
CREATE TABLE phase_type_lu (
  phase_type_id                 INTEGER                     NOT NULL,
  PRIMARY KEY(phase_type_id)
);
CREATE TABLE phase (
  phase_id                      INTEGER                     NOT NULL,
  project_id                    INTEGER                     NOT NULL,
  phase_type_id                 INTEGER                     NOT NULL,
  PRIMARY KEY(phase_id),
  FOREIGN KEY(phase_type_id)
    REFERENCES phase_type_lu(phase_type_id),
  FOREIGN KEY(project_id)
    REFERENCES project(project_id)
);
CREATE TABLE submission (
  submission_id                 INTEGER                     NOT NULL,
  PRIMARY KEY(submission_id)
);
CREATE TABLE resource_role_lu (
  resource_role_id              INTEGER                     NOT NULL,
  phase_type_id                 INTEGER,
  name                          VARCHAR(64)                 NOT NULL,
  description                   VARCHAR(255)                NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(resource_role_id),
  FOREIGN KEY(phase_type_id)
    REFERENCES phase_type_lu(phase_type_id)
);
CREATE TABLE resource (
  resource_id                   INTEGER                     NOT NULL,
  resource_role_id              INTEGER                     NOT NULL,
  project_id                    INTEGER,
  phase_id                      INTEGER,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(resource_id),
  FOREIGN KEY(project_id)
    REFERENCES project(project_id),
  FOREIGN KEY(resource_role_id)
    REFERENCES resource_role_lu(resource_role_id),
  FOREIGN KEY(phase_id)
    REFERENCES phase(phase_id)
);
CREATE TABLE resource_info_type_lu (
  resource_info_type_id         INTEGER                     NOT NULL,
  name                          VARCHAR(64)                 NOT NULL,
  description                   VARCHAR(255)                NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(resource_info_type_id)
);
CREATE TABLE resource_info (
  resource_id                   INTEGER                     NOT NULL,
  resource_info_type_id         INTEGER                     NOT NULL,
  value                         LVARCHAR(4096)              NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(resource_id, resource_info_type_id),
  FOREIGN KEY(resource_info_type_id)
    REFERENCES resource_info_type_lu(resource_info_type_id),
  FOREIGN KEY(resource_id)
    REFERENCES resource(resource_id)
);
CREATE TABLE resource_submission (
  resource_id                   INTEGER                     NOT NULL,
  submission_id                 INTEGER                     NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(resource_id, submission_id),
  FOREIGN KEY(submission_id)
    REFERENCES submission(submission_id),
  FOREIGN KEY(resource_id)
    REFERENCES resource(resource_id)
);
CREATE TABLE notification_type_lu (
  notification_type_id          INTEGER                     NOT NULL,
  name                          VARCHAR(64)                 NOT NULL,
  description                   VARCHAR(255)                NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(notification_type_id)
);
CREATE TABLE notification (
  project_id                    INTEGER                     NOT NULL,
  external_ref_id               INTEGER                     NOT NULL,
  notification_type_id          INTEGER                     NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(project_id, external_ref_id, notification_type_id),
  FOREIGN KEY(project_id)
    REFERENCES project(project_id),
  FOREIGN KEY(notification_type_id)
    REFERENCES notification_type_lu(notification_type_id)
);

CREATE TABLE id_sequences (
  name                  VARCHAR(255)    NOT NULL,
  next_block_start      INTEGER         NOT NULL,
  block_size            INTEGER         NOT NULL,
  exhausted             INTEGER         NOT NULL,
  PRIMARY KEY (name)
);


INSERT INTO id_sequences(name, next_block_start, block_size, exhausted)
  VALUES('resource_id_seq', 1, 20, 0);