using System;
using NUnit.Framework;
using System.IO;
using System.Diagnostics;

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// Unit Test the emailaddresst class.
    /// </summary>
    [TestFixture]
    public class UnitTestEmailAddress
    {
        /// <summary>
        /// creates an object from 3 arg constructor
        /// </summary>
        public const string ADDRESS = "development@topcodersoftware.com";
        public const string TEST_USER = "Test User";
        public const string COMPANY = "Chrisco Inc.";
        
        [Test]
        public void EmailAddressConstructor3()
        {
            EmailAddress ea = new EmailAddress(ADDRESS, TEST_USER, COMPANY);

            Assertion.Assert (ea.Email == ADDRESS);
            Assertion.Assert (ea.Name == TEST_USER);
            Assertion.Assert (ea.Company == COMPANY);

            ea = null;
        }

        /// <summary>
        /// creates an object from 2 arg constructor
        /// </summary>
        [Test]
        public void EmailAddressConstructor2()
        {
            EmailAddress ea = new EmailAddress(ADDRESS, TEST_USER);

            Assertion.Assert (ea.Email == ADDRESS);
            Assertion.Assert (ea.Name == TEST_USER);

            ea = null;
        }

        /// <summary>
        /// test parsing
        /// </summary>
        [Test]
        public void EmailAddressParse()
        {
            EmailAddress ea = new EmailAddress();

            ea.Parse("\"" + TEST_USER + "\" <"+ADDRESS+"> ("+ COMPANY + ")");
            Assertion.Assert (ea.Email == ADDRESS);
            Assertion.Assert (ea.Name == TEST_USER);
            Assertion.Assert (ea.Company == COMPANY);

            ea.Parse("\"" + TEST_USER + "\" <"+ADDRESS+">");
            Assertion.Assert (ea.Email == ADDRESS);
            Assertion.Assert (ea.Name == TEST_USER);
            Assertion.Assert (ea.Company == null);

            ea.Parse("<"+ADDRESS+">");
            Assertion.Assert (ea.Email == ADDRESS);
            Assertion.Assert (ea.Name == null);
            Assertion.Assert (ea.Company == null);
            
            ea.Parse(ADDRESS);
            Assertion.Assert (ea.Email == ADDRESS);
            Assertion.Assert (ea.Name == null);
            Assertion.Assert (ea.Company == null);

            ea = null;
        }

        /// <summary>
        /// creates an object from 3 arg constructor
        /// </summary>
        [Test]
        public void EmailAddressToString()
        {
            EmailAddress ea = new EmailAddress(ADDRESS, TEST_USER, COMPANY);

            Assertion.Assert (ea.ToString() == "\"" + TEST_USER + "\" <" + ADDRESS + "> (" + COMPANY + ")");

            ea = null;
        }

    }
}
