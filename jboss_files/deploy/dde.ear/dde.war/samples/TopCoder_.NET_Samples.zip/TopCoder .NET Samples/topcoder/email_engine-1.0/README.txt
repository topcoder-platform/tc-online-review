
  Installation Requirements
  -------------------------
  .NET Framework 1.0  <http://msdn.microsoft.com/netframework/productinfo>
  NAnt 0.7.9+  <http://nant.sourceforge.net>
  NUnit 2.0+  <http://nunit.org>
    Note: The nunit bin and nant bin directories should be added to your path. 
          Also you will want to change the Nunit property to point to the 
          directory where your NUnit dll resides
          <property name="Nunit" value="C:\Program Files\NUnit V2.0\bin\nunit.framework.dll"/>
  
  
  TopCoder Software Environment Configuration
  -------------------------------------------
  TopCoder Software has defined a directory structure to promote component reuse
  and facilitate Component Based Development.
  
  Steps to setting up your environment:
  1- Designate a directory on your file system to be used as your TCS_HOME.
     (i.e. c:\tcs or /etc/home/user/tcs)        
  2- All TopCoder Software components are distributed with NAnt (http://nant.sourceforge.net) 
     based build scripts and Nunit (http://nunit.org) based test cases.  Please 
     properly install and configure these tools before working with TopCoder 
     Software components.
     Note: Be sure to change your Nunit reference (see requirements above)
  
  
  Thanks for using TopCoder Software components!
  
  The TopCoder Software Team
  service@topcodersoftware.com
  

 