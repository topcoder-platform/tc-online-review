using System;
using System.Collections;
using System.Text;

// @author CLoris
// @copyright 2003 (c) TopCoder Software

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// Provides properties and methods for constructing an list of recepients.
    /// Provides additional functionality (duplicates removing, sorting, etc)
    /// 
    /// </summary>
    public class EmailAddressList 
    {
        // constants
        private const string ERR_NULL_EMAIL = "Can not add a null EmailAddress to EmailAddressList";

        private const string TEXT_COMMA = ",";
        // end constants
        
        private ArrayList list = new ArrayList();

        /// <summary>
        /// property from EmailAddress objects retrieving from the list
        /// </summary>
        /// <returns>
        /// EmailAddress object referred to by the provided index.
        /// </returns>
        public EmailAddress this[int index] 
        {
            get 
            {
                return (EmailAddress)list[index];
            }
        }

        /// <summary>
        /// Gets the number of elements contained in the list
        /// </summary>
        /// <returns>
        /// Returns the count of objects pressent in the list.
        /// </returns>
        public int Count 
        {
            get 
            {
                return list.Count;
            }
        }
        /// <summary>
        /// Constructor of EmailAddressList class
        /// </summary>
        public EmailAddressList()
        {
        }

        //  Please read ( as <, and ) as > because "<" and ">" is part of special documentation tags
        /// <summary>
        /// Parses email address contained in <c>emails</c> and adds it to <c>list</c>, for example
        /// <c>Parse("ivan@domain.com, test@domain.com, \"Ivan Ivanov\" (ivan@domain2.com)")</c> should do following:
        /// <code>
        /// list.Add(new EmailAddress("ivan@domain.com"));
        /// list.Add(new EmailAddress("ivan@domain2.com","Ivan Ivanov"));
        /// </code>
        /// </summary>
        /// <param name="emails">email list</param>
        public void Parse(string emails)
        {
            EmailAddress emailAddress;
            int nextToken = 0;
            bool inQuote = false;
            bool inParen = false;

            for(int loop = 0; loop < emails.Length; loop++)
            {
                // check if we are in a quoted string
                if( (emails[loop] == '"') && (inParen == false) )
                {
                    inQuote = !inQuote;
                }
                // check if we are in a parenthesied string
                if( (emails[loop] == '(') && (inQuote == false) )
                {
                    inParen = true;
                }
                if( (emails[loop] == ')') && (inQuote == false) )
                {
                    inParen = false;
                }
                // check if we found a break
                if( (inQuote == false) && (inParen == false) && (emails[loop] == ',') )
                {
                    // add email address to our collection
                    emailAddress = new EmailAddress();
                    emailAddress.Parse(emails.Substring(nextToken, (loop - nextToken)).Trim());
                    this.Add(emailAddress);
                    nextToken = loop + 1;
                }
                else if( loop == (emails.Length - 1) )
                {
                    // handle last email address
                    emailAddress = new EmailAddress();
                    emailAddress.Parse(emails.Substring(nextToken, (loop - nextToken + 1)).Trim());
                    this.Add(emailAddress);
                }
            }

        }

        /// <summary>
        /// Adds EmailAddress object to <c>list</c>
        /// </summary>
        /// <param name="email">EmailAddress object</param>
        public void Add(EmailAddress email)
        {
            if(email == null)
            {
                throw new MessageErrorException(ERR_NULL_EMAIL);
            }
            else
            {
                list.Add(email);
            }
        }

        /// <summary>
        /// Removes EmailAddress object with specific email from <c>list</c>
        /// </summary>
        /// <param name="email">email</param>
        public void Remove(string email)
        {
            // Remove all objects with the specified email
            // Loop backwards to avoid bounds errors are remove all instances
            for(int loop = (list.Count - 1); loop >= 0; loop--)
            {
                if(String.Compare(((EmailAddress)list[loop]).Email, email, true) == 0)
                {
                    list.RemoveAt(loop);
                }
            }
           }

        /// <summary>
        /// Removes EmailAddress object with specific index from <c>list</c>
        /// </summary>
        /// <param name="index">index</param>
        public void Remove(int index)
        {
            list.RemoveAt(index);
        }

        /// <summary>
        /// Removes duplicate emails from the list.  Calling this method
        /// will cause the array to be sorted.
        /// </summary>
        public void RemoveDuplicates() 
        {
            // sort so we can easily find duplicates
            this.Sort();

            // loop through and remove the duplicates
            for(int loop = (list.Count - 1); loop > 0; loop--)
            {
                if(((EmailAddress)list[loop]).Email == ((EmailAddress)list[loop - 1]).Email)
                {
                    // we have to delete one of the duplicates
                    list.RemoveAt(loop - 1);
                }
            }
        }

        /// <summary>
        /// Sorts the email list
        /// </summary>
        public void Sort()
        {
            // sort the array list using the provided IComparer in EmailAddress
            list.Sort(new EmailAddress.EmailAddressComparerAlphabetical());
        }

        /// <summary>
        /// Clears the list
        /// </summary>
        public void Clear()
        {
            // release all members of list
            list.Clear();
        }

        /// <summary>
        /// Converts <c>list</c> to a string with "," delimiter (example: <code>"Submitter 18" (sub@domain.com), "Submitter 18" (sub_18@domain.com) </code>)
        /// </summary>
        /// <returns>well-formed string contains email list</returns>
        public override string ToString()
        {
            StringBuilder result = new StringBuilder();

            // loop through email addresses to build the string
            for(int loop = 0; loop < list.Count; loop++)
            {
                // add a comma seperator
                if(loop > 0)
                {
                    result.Append(TEXT_COMMA);
                }
                // add the email address
                result.Append( ((EmailAddress)list[loop]).ToString());
            }
            
            return result.ToString();
        }
    
    }
}
