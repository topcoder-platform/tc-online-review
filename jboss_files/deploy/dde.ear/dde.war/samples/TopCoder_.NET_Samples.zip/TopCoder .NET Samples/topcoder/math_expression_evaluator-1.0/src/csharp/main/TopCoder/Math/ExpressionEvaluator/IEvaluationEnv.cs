/* IEvaluationEnv.cs; 
 * @author kyky
 * Copyright @ 2003, TopCoder, Inc. All rights reserved
 * */
using System;

namespace TopCoder.Math.ExpressionEvaluator {
    /// <summary>
    /// Marker interface for Expression.Evaluate.
    /// Custom variables use instances of IEvaluationEnv to get
    /// the values that correspond to their names.
    /// Custom evaluation environments must implement this interface
    /// to be used in Expression.Evaluate.
    /// </summary>
    public interface IEvaluationEnv {
    }
}
