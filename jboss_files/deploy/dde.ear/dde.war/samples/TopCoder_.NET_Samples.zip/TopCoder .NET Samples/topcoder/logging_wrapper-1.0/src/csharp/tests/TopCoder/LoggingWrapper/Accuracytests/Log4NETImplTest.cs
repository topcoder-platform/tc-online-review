using System;
using System.IO;
using NUnit.Framework;
using log4net.Config;
using log4net;

namespace TopCoder.LoggingWrapper.AccuracyTests
{
    /// <summary>
    /// Accuracy test cases for Log4NET implementation
    /// @author aksonov
    /// </summary>
    [TestFixture]
    public class Log4NETImpl
    {
        private const string logfile = @"..\..\test_files\error-log.txt";
        private static string LOG_MESSAGE = "Hello world!";
        private static string FORMAT_LOG_MESSAGE = "Hello {0} world! {1}";
        private static int FORMAT_PARAM1 = 10;
        private static string FORMAT_PARAM2 = "Good bye!";
        
        [SetUp]
        public void StartUp()
        {
            LogManager.Configuration = new System.Collections.Specialized.NameValueCollection();        
            LogManager.Configuration.Add(LogManager.CLASS_PARAMETER, "TopCoder.LoggingWrapper.Log4NETImpl");            
            LogManager.Configuration.Add("Log4NetConfiguration", @"..\..\conf\log4net.config");
            LogManager.Configuration.Add("LogName", "Test Log");
            LogManager.LoadConfiguration();
        }
        /// <summary>
        /// Test if a log is of expected type.
        /// </summary>
        [Test]
        public void LogInitializedCorectly()
        {
            Assertion.AssertEquals("TopCoder.LoggingWrapper.Log4NETImpl",LogManager.GetLogger().GetType().FullName);

        }
        /// <summary>
        /// Tests if log entry is actualy writen to the system event log.
        /// </summary>
        [Test]
        public void TestSimpleLog()
        {
            LogManager.GetLogger().Level = Level.DEBUG;
            LogManager.Log(LOG_MESSAGE); 
            LogManager.GetLogger().Dispose();
            this.LogContains(LOG_MESSAGE, Level.DEBUG.ToString());
        }

        /// <summary>
        /// Tests if formatted log entry is actualy writen to the system event log.
        /// </summary>
        [Test]
        public void TestFormattedLog()
        {                    
            LogManager.Log(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), null);
        }
        /// <summary>
        /// Tests logging levels - DEBUG
        /// </summary>
        [Test]
        public void TestLogLevelDebug()
        {                    
            LogManager.Log(Level.DEBUG, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.DEBUG.ToString());
        }
        /// <summary>
        /// Tests logging levels - ERROR
        /// </summary>
        [Test]
        public void TestLogLevelError()
        {                    
            LogManager.Log(Level.ERROR, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.ERROR.ToString());
        }
        /// <summary>
        /// Tests logging levels - FAILUREAUDIT
        /// </summary>
        [Test]
        public void TestLogLevelFailureAudit()
        {                    
            LogManager.Log(Level.FAILUREAUDIT, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.DEBUG.ToString());
        }
        /// <summary>
        /// Tests logging levels - SUCCESSAUDIT
        /// </summary>
        [Test]
        public void TestLogLevelSuccessAudit()
        {                    
            LogManager.Log(Level.SUCCESSAUDIT, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.DEBUG.ToString());
        }
        /// <summary>
        /// Tests logging levels - WARN
        /// </summary>
        [Test]
        public void TestLogLevelWarn()
        {                    
            LogManager.Log(Level.WARN, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.WARN.ToString());
        }
        /// <summary>
        /// Tests logging levels - INFO
        /// </summary>
        [Test]
        public void TestLogLevelInfo()
        {                    
            LogManager.Log(Level.INFO, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.INFO.ToString());
        }
        /// <summary>
        /// Tests logging levels - FATAL
        /// </summary>
        [Test]
        public void TestLogLevelFatal()
        {                    
            LogManager.Log(Level.FATAL, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.FATAL.ToString());
        }
        /// <summary>
        /// Tests logging levels - OFF
        /// </summary>
        [Test]
        public void TestLogLevelOff()
        {                    
            LogManager.Log(Level.OFF, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogNotContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.OFF.ToString());
        }

        /// <summary>
        /// Tests IsLevelEnabled method
        /// </summary>
        [Test]
        public void TestLevelEnabled(){
            Assertion.Assert(LogManager.IsLevelEnabled(Level.DEBUG));
            Assertion.Assert(LogManager.IsLevelEnabled(Level.ERROR));
            Assertion.Assert(LogManager.IsLevelEnabled(Level.INFO));
            Assertion.Assert(LogManager.IsLevelEnabled(Level.WARN));
            Assertion.Assert(LogManager.IsLevelEnabled(Level.OFF));
            Assertion.Assert(LogManager.IsLevelEnabled(Level.SUCCESSAUDIT));
            Assertion.Assert(LogManager.IsLevelEnabled(Level.FAILUREAUDIT));
            Assertion.Assert(LogManager.IsLevelEnabled(Level.FATAL));
        }

        [TearDown]
        public void Down()
        {    
            LogManager.GetLogger().Dispose();
            File.Delete(logfile);
        }

        private void LogContains(string message, string level){
            StreamReader reader = new StreamReader(logfile);
            string log = reader.ReadToEnd();
            reader.Close();
            Assertion.Assert("Log should contain log string", log.IndexOf(message)>=0);
            if (level!=null)
                Assertion.Assert("Log should contain log level", log.IndexOf(level)>=0);
        }

        private void LogNotContains(string message, string level){
            StreamReader reader = new StreamReader(logfile);
            string log = reader.ReadToEnd();
            reader.Close();
            Assertion.Assert("Log should not contain log string", log.IndexOf(message)==-1);
            if (level!=null)
                Assertion.Assert("Log should not contain log level", log.IndexOf(level)==-1);
        }
    }
}
