using System;
using System.IO;
using NUnit.Framework;
using log4net.Config;
using log4net;
using System.Diagnostics;

namespace TopCoder.LoggingWrapper.AccuracyTests
{
    /// <summary>
    /// Accuracy test cases for DiagnosticImpl implementation
    /// @author aksonov
    /// </summary>
    [TestFixture]
    public class DiagnosticImpl
    {
        private static string LOG_MESSAGE = "Hello world!";
        private static string FORMAT_LOG_MESSAGE = "Hello {0} world! {1}";
        private static int FORMAT_PARAM1 = 10;
        private static string FORMAT_PARAM2 = "Good bye!";
        private static string LOG_NAME = "Test Log";
        
        [SetUp]
        public void StartUp()
        {
            if(EventLog.Exists(LOG_NAME))
                EventLog.Delete(LOG_NAME);

            LogManager.Configuration = new System.Collections.Specialized.NameValueCollection();        
            LogManager.Configuration.Add(LogManager.CLASS_PARAMETER, "TopCoder.LoggingWrapper.DiagnosticImpl");
            LogManager.Configuration.Add("Source", LOG_NAME);
            LogManager.Configuration.Add("LogName", LOG_NAME);
            LogManager.LoadConfiguration();
        }
        /// <summary>
        /// Test if a log is of expected type.
        /// </summary>
        [Test]
        public void LogInitializedCorectly()
        {
            Assertion.AssertEquals("TopCoder.LoggingWrapper.DiagnosticImpl",LogManager.GetLogger().GetType().FullName);            
        }
        /// <summary>
        /// Tests if log entry is actualy writen to the system event log.
        /// </summary>
        [Test]
        public void TestSimpleLog()
        {                    
            LogManager.Log(LOG_MESSAGE); 
            LogManager.GetLogger().Dispose();
            this.LogContains(LOG_MESSAGE, null);
        }

        /// <summary>
        /// Tests if formatted log entry is actualy writen to the system event log.
        /// </summary>
        [Test]
        public void TestFormattedLog()
        {                    
            LogManager.Log(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), null);
        }
        /// <summary>
        /// Tests logging levels - DEBUG
        /// </summary>
        [Test]
        public void TestLogLevelDebug()
        {                    
            LogManager.Log(Level.DEBUG, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.DEBUG.ToString());
        }
        /// <summary>
        /// Tests logging levels - ERROR
        /// </summary>
        [Test]
        public void TestLogLevelError()
        {                    
            LogManager.Log(Level.ERROR, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.ERROR.ToString());
        }
        /// <summary>
        /// Tests logging levels - FAILUREAUDIT
        /// </summary>
        [Test]
        public void TestLogLevelFailureAudit()
        {                    
            LogManager.Log(Level.FAILUREAUDIT, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.DEBUG.ToString());
        }
        /// <summary>
        /// Tests logging levels - SUCCESSAUDIT
        /// </summary>
        [Test]
        public void TestLogLevelSuccessAudit()
        {                    
            LogManager.Log(Level.SUCCESSAUDIT, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.DEBUG.ToString());
        }
        /// <summary>
        /// Tests logging levels - WARN
        /// </summary>
        [Test]
        public void TestLogLevelWarn()
        {                    
            LogManager.Log(Level.WARN, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.WARN.ToString());
        }
        /// <summary>
        /// Tests logging levels - INFO
        /// </summary>
        [Test]
        public void TestLogLevelInfo()
        {                    
            LogManager.Log(Level.INFO, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.INFO.ToString());
        }
        /// <summary>
        /// Tests logging levels - FATAL
        /// </summary>
        [Test]
        public void TestLogLevelFatal()
        {                    
            LogManager.Log(Level.FATAL, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.FATAL.ToString());
        }
        /// <summary>
        /// Tests logging levels - OFF
        /// </summary>
        [Test]
        public void TestLogLevelOff()
        {                    
            LogManager.Log(Level.OFF, FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2); 
            LogManager.GetLogger().Dispose();
            this.LogNotContains(String.Format(FORMAT_LOG_MESSAGE, FORMAT_PARAM1, FORMAT_PARAM2), Level.OFF.ToString());
        }
        /// <summary>
        /// Tests IsLevelEnabled method
        /// </summary>
        [Test]
        public void TestLevelEnabled(){
            Assertion.Assert("Level should be enabled",LogManager.IsLevelEnabled(Level.DEBUG));
            Assertion.Assert("Level should be enabled",LogManager.IsLevelEnabled(Level.ERROR));
            Assertion.Assert("Level should be enabled",LogManager.IsLevelEnabled(Level.INFO));
            Assertion.Assert("Level should be enabled",LogManager.IsLevelEnabled(Level.WARN));
            Assertion.Assert("Level should be enabled",LogManager.IsLevelEnabled(Level.OFF));
            Assertion.Assert("Level should be enabled",LogManager.IsLevelEnabled(Level.SUCCESSAUDIT));
            Assertion.Assert("Level should be enabled",LogManager.IsLevelEnabled(Level.FAILUREAUDIT));
            Assertion.Assert("Level should be enabled",LogManager.IsLevelEnabled(Level.FATAL));
        }

        [TearDown]
        public void Down()
        {    
            LogManager.GetLogger().Dispose();
            if(EventLog.Exists(LOG_NAME))
                EventLog.Delete(LOG_NAME);
        }

        private void LogContains(string message, string level){
            EventLog ea=new EventLog(LOG_NAME,".",LOG_NAME);            
            EventLogEntry[] entries=new EventLogEntry[ea.Entries.Count];
            ea.Entries.CopyTo(entries,0);
            Assertion.AssertEquals(message, entries[0].Message);
        }

        private void LogNotContains(string message, string level){
            if(!EventLog.Exists(LOG_NAME))
                return;
            EventLog ea=new EventLog(LOG_NAME,".",LOG_NAME);            
            EventLogEntry[] entries=new EventLogEntry[ea.Entries.Count];
            ea.Entries.CopyTo(entries,0);
            Assertion.Assert(entries[0].Message.IndexOf(message)==-1);
        }
    }
}
