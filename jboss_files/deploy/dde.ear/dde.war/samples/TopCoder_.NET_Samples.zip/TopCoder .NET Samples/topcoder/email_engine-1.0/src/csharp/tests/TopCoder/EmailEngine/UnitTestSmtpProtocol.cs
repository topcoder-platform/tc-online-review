using System;
using NUnit.Framework;
using System.IO;
using System.Diagnostics;

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// Unit Test the emailaddresst class.
    /// </summary>
    [TestFixture]
    public class UnitTestSmtpProtocol
    {
        /// <summary>
        /// test SMTPProtocol error messages
        /// </summary>
        private const string FROM_ADDRESS = "development@topcodersoftware.com";
        private const string TO_ADDRESS =  "development@topcodersoftware.com";
        [Test]
        [ExpectedException(typeof(SendException))]
        public void SmtpProtocolError1()
        {
            SmtpProtocol sp = new SmtpProtocol("192.168.10.51:25");

            sp.SendEmail(new Message("From: " + FROM_ADDRESS + "\nTo:" + TO_ADDRESS + "\nSubject:subj\n\nHello!\n\nThis is the message!"));
        }

        /// <summary>
        /// test SMTPProtocol error messages
        /// </summary>
        [Test]
        [ExpectedException(typeof(SendException))]
        public void SmtpProtocolError2()
        {
            SmtpProtocol sp = new SmtpProtocol();

            sp.SendEmail(new Message("From: " + FROM_ADDRESS + "\nTo:" + TO_ADDRESS + "\nSubject:subj\n\nHello!\n\nThis is the message!"));
        }

        /// <summary>
        /// test SMTPProtocol error messages
        /// </summary>
        [Test]
        [ExpectedException(typeof(SendException))]
        public void SmtpProtocolError3()
        {
            // somewhere we can't open a connection
            SmtpProtocol sp = new SmtpProtocol("smtp.yahoo.com:555");

            sp.SendEmail(new Message("From: " + FROM_ADDRESS + "\nTo:" + TO_ADDRESS + "\nSubject:subj\n\nHello!\n\nThis is the message!"));
        }

        /// <summary>
        /// test constructor
        /// </summary>
        [Test]
        public void SmtpProtocolConstructor()
        {
            SmtpProtocol sp = new SmtpProtocol("192.168.10.51:333");

            Assertion.Assert ( sp.Server == "192.168.10.51" );
            Assertion.Assert ( sp.Port == 333 );

            sp = new SmtpProtocol("192.168.10.51");

            Assertion.Assert ( sp.Server == "192.168.10.51" );
            Assertion.Assert ( sp.Port == 25 );
        }
    }
}
