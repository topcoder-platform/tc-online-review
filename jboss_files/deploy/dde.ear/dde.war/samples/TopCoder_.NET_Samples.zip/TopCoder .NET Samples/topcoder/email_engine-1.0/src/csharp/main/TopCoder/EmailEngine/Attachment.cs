using System;
using System.IO;
using System.Text;
    
// @author CLoris
// @copyright 2003 (c) TopCoder Software

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// Provides properties and methods for constructing an e-mail attachment.
    /// </summary>
    public class Attachment
    {
        // constants
        private const string ATTACH_MIME_HEAD = "\r\n" +
                                                "\r\n--NextMimePart" +
                                                "\r\nContent-Type: application/octet-stream; name=\"{0}\"" + 
                                                "\r\nContent-Transfer-Encoding: base64" +
                                                "\r\nContent-Disposition: attachment; filename=\"{0}\"" +
                                                "\r\n\r\n";
        private const string ATTACH_NEW_LINE = "\r\n";
        private const string ATTACH_DEFAULT_NAME = "unknown.unk";

        private const string ERR_NULL_FILESTREAM = "Null FileStream specified for attachment";
        // end constants
        
        private byte[] memoryBuffer;
        private string attachFileName;
        
        /// <summary>
        /// Creates Attachment from given filename
        /// </summary>
        /// <param name="filename">specify the full path to the file.  If supplying
        /// just a filename, the local path is assumed.
        /// </param>
        /// <exception cref="AttachmentErrorException">Thrown when there is a file access error or memory error.</exception>
        public Attachment(string filename)
        {
            FileStream fileStream;

            // set the file name
            attachFileName = Path.GetFileName(filename);
            
            try
            {
                // open up the requested file
                fileStream = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read);
            }
            catch (Exception e) 
            {
                throw new AttachmentErrorException(e.ToString());
            }

            try
            {
                // stream the file into memory
                memoryBuffer = new Byte[(fileStream.Length)];
                fileStream.Read(memoryBuffer,0,(int)fileStream.Length);
            }
            catch (Exception e) 
            {
                throw new AttachmentErrorException(e.ToString());
            }
 
            // close the stream
            fileStream.Close();
        }

        /// <summary>
        /// Creates Attachment from given filestream
        /// </summary>
        /// <param name="fileStream">
        /// file stream to the file to be attached.  The constructor will not close this file stream. 
        /// </param>
        /// <exception cref="AttachmentErrorException">Thrown when there is a file access error.</exception>
        public Attachment(FileStream fileStream)
        {
            if(fileStream == null)
            {
                throw new AttachmentErrorException(ERR_NULL_FILESTREAM);
            }

            // set the file name
            attachFileName = Path.GetFileName(fileStream.Name);

            try
            {
                // stream the file into memory
                memoryBuffer = new Byte[(fileStream.Length)];
                fileStream.Read(memoryBuffer,0,(int)fileStream.Length);
            }
            catch (Exception e) 
            {
                throw new AttachmentErrorException(e.ToString());
            }

        }

        /// <summary>
        /// Creates Attachment from given stream
        /// </summary>
        /// <param name="stream"></param>
        /// <exception cref="AttachmentErrorException">Thrown when there is a stream access error.</exception>
        public Attachment(Stream stream)
        {
            if(stream == null)
            {
                throw new AttachmentErrorException(ERR_NULL_FILESTREAM);
            }

            // set the file name
            attachFileName = ATTACH_DEFAULT_NAME;

            try
            {
                // stream the file into memory
                memoryBuffer = new Byte[(stream.Length)];
                stream.Read(memoryBuffer,0,(int)stream.Length);
            }
            catch (Exception e) 
            {
                throw new AttachmentErrorException(e.ToString());
            }
        
        }
        
        /// <summary>
        /// Encodes attachment to string
        /// </summary>
        /// <returns>
        /// Base64 encoded string representation of the file
        /// </returns>
        /// <exception cref="AttachmentErrorException">Thrown when there is a stream access error.</exception>
        public override string ToString()
        {
            StringBuilder attachString = new StringBuilder();
            
            // fill the byte array - accessing the file stream might produce an unexpected error
            // return full mime encoded attachment
            attachString.Append(String.Format(ATTACH_MIME_HEAD, attachFileName));
            attachString.Append(System.Convert.ToBase64String(memoryBuffer));
            attachString.Append(ATTACH_NEW_LINE);
            return attachString.ToString(); 
        }

    }
}
