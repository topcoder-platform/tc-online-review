/*
Copyright c 2003, TopCoder, Inc. All rights reserved.
Author opi
*/

using System;
using System.Text;
using System.Collections;

namespace TopCoder.Util.Collection.Queue
{
	using System;
	using NUnit.Framework;
	/// <summary>
	/// Test the functionality of the PriorityQueue class.
	/// </summary>
	/// 
	[TestFixture]
	public class PriorityQueueFunctionalTests
	{
		/// <summary>
		/// Test PriorityQueue created but left empty.
		/// </summary>
		public PriorityQueue pq;
		/// <summary>
		/// Test PriorityQueue created and filled with 1000 objects
		/// </summary>
		public PriorityQueue pqBig;

		/// <summary>
		/// Comparer class used to test the PriorityQueue methods
		/// </summary>
        public class myReverserClass : IComparer  
        {
            // Calls CaseInsensitiveComparer.Compare with the parameters reversed.
            int IComparer.Compare( Object x, Object y )  
            {
                String aa = (String) x;
                String bb = (String) y;
                return( (new CaseInsensitiveComparer()).Compare( bb, aa ) );
            }
        };
        /// <summary>
		/// Create two queues, one empty and one filled with 1000 strings - "0" to "999"
		/// with corresponding integer priorities.
		/// </summary>
		/// 
		[SetUp]
		protected void SetUp() 
		{
			pq = new PriorityQueue();
			pqBig = new PriorityQueue();
			Assertion.AssertNotNull(pqBig);
			for (int index=0; index<1000; index++)
			{
				pqBig.Enqueue(index.ToString(), index);
			}

		}

		/// <summary>
		/// IsSynchronized test on an unsynchronized PriorityQueue
		/// </summary>
		[Test]
		public void IsSynchronizedTest()
		{
			Assertion.AssertEquals(pq.IsSynchronized, false);
		}

        /// <summary>
        /// Test all of the PriorityQueue constructors
        /// </summary>
        [Test]
		public void PriorityQueueConstructorTest()
		{
            IComparer myComparer = new myReverserClass();
			String [] strCollection = {"N", "B", "Z", "M", "W", "A"};

            PriorityQueue pqCon = new PriorityQueue();
            Assertion.AssertEquals(0, pqCon.Count);
            
            pqCon = new PriorityQueue(1000);
            Assertion.AssertEquals(0, pqCon.Count);
            
            pqCon = new PriorityQueue(1000, myComparer);
            Assertion.AssertEquals(0, pqCon.Count);
            
            pqCon = new PriorityQueue(1000, 1.000001F);
            Assertion.AssertEquals(0, pqCon.Count);
            
            pqCon = new PriorityQueue(1000, 9.9F, myComparer);
            Assertion.AssertEquals(0, pqCon.Count);
            
            pqCon = new PriorityQueue(strCollection);
            Assertion.AssertEquals(6, pqCon.Count);
            
            pqCon = new PriorityQueue(myComparer);
            Assertion.AssertEquals(0, pqCon.Count);
            
            pqCon = new PriorityQueue(strCollection, myComparer);
            Assertion.AssertEquals(6, pqCon.Count);
		}
		
        /// <summary>
        /// Fill and Clear a PriorityQueue
        /// </summary>
        [Test]
		public void ClearTest()
		{
            pq.Enqueue(10);
            pq.Enqueue(20);
            pq.Enqueue(30);
            pq.Enqueue(-1000);
            Assertion.AssertEquals(30, pq.Peek());
            Assertion.AssertEquals(4, pq.Count);
                
			pq.Clear();
			Assertion.AssertEquals(pq.Count, 0);
		}

        /// <summary>
        /// Create a clone of a PriorityQueue and make sure it is the same
        /// </summary>
        [Test]
		public void CloneTest()
		{
			PriorityQueue pqClone = (PriorityQueue) pqBig.Clone();
			Assertion.AssertEquals(pqBig.Count, pqClone.Count);
			Assertion.AssertEquals(pqBig.Peek(), pqClone.Peek());
		}

		/// <summary>
		/// Look for an element that should be in the PriorityQueue and for
		/// one that should not be in the PriorityQueue.
		/// </summary>
		[Test]
		public void ContainsTest()
		{
			Assertion.AssertEquals(true, pqBig.Contains("435"));
            Assertion.AssertEquals(false, pqBig.Contains("Hello World"));
		}

        /// <summary>
        /// Dequeue a PriorityQueue into an existing array.
        /// </summary>
		[Test]
		public void CopyToTest()
		{
			Object [] arTest = new Object[2000];
			pqBig.CopyTo(arTest, 10);
			Assertion.AssertEquals("574", arTest[435]);

			object[] strArray2 = new String[10];
			strArray2[0] = "Array too short";
			strArray2 = pqBig.ToArray();
			Assertion.AssertNotNull(strArray2[2]);
		}

        /// <summary>
        /// Remove the top three priority objects from the PriorityQueue
        /// </summary>
		[Test]
		public void DequeueTest()
		{
            Assertion.AssertEquals("999", pqBig.Dequeue());
            Assertion.AssertEquals("998", pqBig.Dequeue());
            Assertion.AssertEquals("997", pqBig.Dequeue());
		}

		/// <summary>
		/// Enqueue some objects to a non-empty PriorityQueue and make sure the right
		/// one (top priority) is on top.
		/// </summary>
		[Test]
		public void EnqueueTest()
		{
            pqBig.Enqueue("2000", 2000);
            pqBig.Enqueue("-2000", -2000);
            Assertion.AssertEquals("2000", pqBig.Peek());
		}

        /// <summary>
        /// Test the ability to enumerate through a PriorityQueue
        /// </summary>
		[Test]
		public void GetEnumeratorTest()
		{
            int dec = 999;
            int inc = 0;
            foreach(String currobject in pqBig)
            {
                if(currobject != dec.ToString())
                    Assertion.Fail("Objects enumerating properly.");
                dec--; inc++;
            }

            Assertion.AssertEquals("Not enough objects enumerated",
                1000, inc);
        }

        /// <summary>
        /// Test the Peek interface
        /// </summary>
		[Test]
		public void PeekTest()
		{
            Assertion.AssertEquals("999", pqBig.Peek());
		}

        /// <summary>
        /// Create a synchronized PriorityQueue and test the Synchronized interfaces
        /// </summary>
		[Test]
		public void SynchronizedTest()
		{
            PriorityQueue pqSync = PriorityQueue.Synchronized(pqBig);
            Assertion.AssertEquals(1000, pqSync.Count);
            pqSync.Enqueue("2000", 2000);
            pqSync.Enqueue("-2000", -2000);
            Assertion.AssertEquals(1002, pqSync.Count);
            Assertion.AssertEquals("2000", pqSync.Peek());
            Assertion.AssertEquals(pqSync.IsSynchronized, true);
            Assertion.AssertEquals(true, pqSync.Contains("435"));
            Assertion.AssertEquals(false, pqSync.Contains("Hello World"));
            Object [] arTest = new Object[2000];
            pqSync.CopyTo(arTest, 10);
            Assertion.AssertEquals("575", arTest[435]);
            Assertion.AssertEquals("2000", pqSync.Dequeue());
            Assertion.AssertEquals("999", pqSync.Dequeue());
            Assertion.AssertEquals("998", pqSync.Dequeue());
            int count=0;
            foreach(string s in pqSync)
            {
                int l = s.Length;
                count++;
            }
            Assertion.AssertEquals(999, count);
            pqSync.TrimToSize();
            Assertion.AssertEquals(999, pqSync.Count);
        }

        /// <summary>
        /// Copy PriorityQueue contents to an array
        /// </summary>
		[Test]
		public void ToArrayTest()
		{
			object [] objArray = pqBig.ToArray();
            Assertion.AssertEquals("999", objArray[0].ToString());
            Assertion.AssertEquals("0", objArray[999].ToString());
		}

        /// <summary>
        /// Test the TrimToSize interface
        /// </summary>
		[Test]
		public void TrimToSizeTest()
		{
		    pq.Enqueue("Test", 5);
		    pq.Enqueue("String", 3);
            pq.TrimToSize();
            Assertion.AssertEquals(2, pq.Count);
        }
	}
}
