/*
Copyright c 2003, TopCoder, Inc. All rights reserved.
Author opi
*/

using System;
using System.Collections;
using System.Threading;

using TopCoder.Util.Collection.Queue;

using NUnit.Framework;

namespace TopCoder.Util.Collection.Queue
{
    /// <summary>
    /// Test the sync functionality of the PriorityQueue class.
    /// </summary>
    /// 
    [TestFixture]
    public class PriorityQueueSynchronizedTest
    {
        /// <summary>
        /// Test the Enqueue and Dequeue methods
        /// </summary>
        [Test]
        public void TestConcurrency()
        {
            int tests = 50;

            SynchronizedPriorityQueueThreadEnqueue[] pqse =
                new SynchronizedPriorityQueueThreadEnqueue[tests];
            SynchronizedPriorityQueueThreadDequeue[] pqsd = 
                new SynchronizedPriorityQueueThreadDequeue[tests];

            Thread[] threads = new Thread[tests*2];
            PriorityQueue pq = new PriorityQueue();
            PriorityQueue spq = PriorityQueue.Synchronized(pq);
            int i;

            // Start with 5000 numbers which will be dequeued 5000 to 1.
            for (i=0; i<5000; i++)
            {
                spq.Enqueue(i);
            }

            // Start x threads each Enqueueing 1000 elements
            // Start x threads each Dequeueing 1000 elements (retrying if Dequeue throws Exception)
            int tc=0;
            for (i = 0; i < tests; i++) 
            {
                pqse[i] = new SynchronizedPriorityQueueThreadEnqueue(spq, i);
                threads[tc] = new Thread(new ThreadStart(pqse[i].Run));
                threads[tc].Start();
                tc++;

                pqsd[i] = new SynchronizedPriorityQueueThreadDequeue(spq, i);
                threads[tc] = new Thread(new ThreadStart(pqsd[i].Run));
                threads[tc].Start();
                tc++;
            }

            for (i = 0; i < tc; i++) 
            {
                threads[i].Join();
            }

            // Then after all this - make sure PQ dequeues everyone in order
            int prev = int.MaxValue;
            int val = 0;
            for (i=0; i<spq.Count; i++)
            {
                val = (int)spq.Dequeue();
                Assertion.Assert("Previous value is less than new value", val<=prev);
                prev = val;
            }
        }

        class SynchronizedPriorityQueueThreadEnqueue
        {
            private PriorityQueue spq;
            private int idx;
            private bool success;

            /// <summary>
            /// Whether the test is successful
            /// </summary>
            public bool Success
            {
                get
                {
                    return success;
                }
            }

            /// <summary>
            /// Initialize the variables
            /// </summary>
            public SynchronizedPriorityQueueThreadEnqueue(PriorityQueue spq, int idx)
            {
                this.spq = spq;
                this.idx = idx;
            }

            /// <summary>
            /// Main loop of threads
            /// </summary>
            public void Run()
            {
                int i;

                success = true;
                for (i = 0; i < 1000; i++)
                {
                    try
                    {
                        spq.Enqueue(i);
                    }
                    catch (Exception) 
                    {
                        success = false;
                    }
                }
            }
        }
        
        class SynchronizedPriorityQueueThreadDequeue
        {
            private PriorityQueue spq;
            private int idx;
            private bool success;

            /// <summary>
            /// Whether the test is successful
            /// </summary>
            public bool Success
            {
                get
                {
                    return success;
                }
            }

            /// <summary>
            /// Initialize the variables
            /// </summary>
            public SynchronizedPriorityQueueThreadDequeue(PriorityQueue spq, int idx)
            {
                this.spq = spq;
                this.idx = idx;
            }

            /// <summary>
            /// Main loop of threads
            /// </summary>
            public void Run()
            {
                int i;

                success = true;
                for (i = 0; i < 1000; i++)
                {
                    try 
                    {
                        spq.Dequeue();
                    }
                    // The PQ may be empty depending on how the threads run - this is okay
                    // because this is how it will behave in the real world.
                    catch (InvalidOperationException ioe)
                    {
                        String error = ioe.ToString();
                        i--;
                    }
                    catch (Exception) 
                    {
                        success = false;
                    }
                }
            }
        }
    }
}
