/*
Copyright c 2003, TopCoder, Inc. All rights reserved.
Author opi
*/

using System;
using System.Text;
using System.Collections;

namespace TopCoder.Util.Collection.Queue
{
	using System;
	using NUnit.Framework;
	/// <summary>
	/// Test the functionality of the PriorityQueue class.
	/// </summary>
	/// 
	[TestFixture]
	public class PriorityQueueFailureTests
	{
		/// <summary>
		/// Test PriorityQueue created but left empty.
		/// </summary>
		public PriorityQueue pq;
		/// <summary>
		/// Test PriorityQueue created and filled with 1000 objects
		/// </summary>
		public PriorityQueue pqBig;

		/// <summary>
		/// Comparer class used to test the PriorityQueue methods
		/// </summary>
		public class myReverserClass : IComparer  
        {
            // Calls CaseInsensitiveComparer.Compare with the parameters reversed.
            int IComparer.Compare( Object x, Object y )  
            {
                String aa = (String) x;
                String bb = (String) y;
                return( (new CaseInsensitiveComparer()).Compare( bb, aa ) );
            }
        };
        /// <summary>
		/// Create two queues, one empty and one filled with 1000 strings - "0" to "999"
		/// with corresponding integer priorities.
		/// </summary>
		/// 
		[SetUp]
		protected void SetUp() 
		{
			pq = new PriorityQueue();
			pqBig = new PriorityQueue();
			Assertion.AssertNotNull(pqBig);
			for (int index=0; index<1000; index++)
			{
				pqBig.Enqueue(index.ToString(), index);
			}

		}

        /// <summary>
        /// Cannot create a PriorityQueue with a negative capacity
        /// </summary>
		[Test]
		[ExpectedException(typeof(ArgumentOutOfRangeException))]
		public void PQConstructorWithNegCapacity()
		{
			PriorityQueue pq1 = new PriorityQueue(-100);
		}

        /// <summary>
        /// Cannot Enqueue an object whose priority cannot be compared to existing priorities
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void EnqueueFail1()
        {
            pqBig.Enqueue("3000", "3000");
        }

        /// <summary>
        /// Cannot Enqueue an object whose priority cannot be compared to existing priorities
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void EnqueueFail2()
        {
            pqBig.Enqueue("4000");
        }
        
        /// <summary>
        /// Cannot use an enumerator (Current operation) after a Dequeue()
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void EnumerationFail1()
        {
            object obj;
            IEnumerator en = pqBig.GetEnumerator();
            en.Reset();
            en.MoveNext();
            obj = en.Current;
            obj = pqBig.Dequeue();
            obj = en.Current;
        }
        
        /// <summary>
        /// Cannot use an enumerator (MoveNext operation) after a Dequeue()
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void EnumerationFail2()
        {
            object obj;
            IEnumerator en = pqBig.GetEnumerator();
            en.Reset();
            en.MoveNext();
            obj = en.Current;
            obj = pqBig.Dequeue();
            obj = en.MoveNext();
        }
        
        /// <summary>
        /// Cannot add an object to the PriorityQueue that does not Implement the
        /// IComparable interface.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConFail1()
        {
            IComparer myComparer = new myReverserClass();
            PriorityQueue pqTest = new PriorityQueue(null, myComparer);
        }
        
        /// <summary>
        /// Cannot add objects to a PriorityQueue with a mismatched Comparer
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidCastException))]
        public void ConFail2()
        {
            IComparer myComparer = new myReverserClass();
            int [] iArray = {5, 3, 8, 6, 4, 9, 7};
            PriorityQueue pqTest = new PriorityQueue(iArray, myComparer);
        }
        
        /// <summary>
        /// Cannot add an object to a PriorityQueue with a mismatched Comparer.
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidCastException))]
        public void ConFail3()
        {
            IComparer myComparer = new myReverserClass();
            object [] iArray = {"5", "3", "8", "6", "4", new object(), "7"};
            PriorityQueue pqTest = new PriorityQueue(iArray, myComparer);
        }
        /// <summary>
        /// Cannot create a PriorityQueue with a negative capacity.
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ConFail4()
        {
            IComparer myComparer = new myReverserClass();
            PriorityQueue pqTest = new PriorityQueue(-40, 5.0F, myComparer);
        }
        
        /// <summary>
        /// Cannot create a PriorityQueue with a GrowFactor less than 1.0 or
        /// greater than 10.0
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ConFail5()
        {
            IComparer myComparer = new myReverserClass();
            PriorityQueue pqTest = new PriorityQueue(40, 50.0F, myComparer);
        }
        
        /// <summary>
        /// Cannot Dequeue() from an empty PriorityQueue
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void DequeueFail()
        {
            PriorityQueue pqTest = new PriorityQueue();
            object obj = pqTest.Dequeue();
        }
	}
}
