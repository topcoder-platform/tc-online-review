// @author kyky
// @copyright (c) TopCoder Software
using System;
using System.Collections;
using NUnit.Framework;

namespace TopCoder.Math.ExpressionEvaluator {

    [TestFixture]
    public class FailureTests {

        /// <summary>
        /// Verifies that parsing really invalid expressions throws exceptions.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.ExpressionFormatException))]
        public void TestInvalidParse1() {
            Expression.Parse("(()()))))((()()()(()(*)(*)(*)(&*&^*&YTIJUH(*^&(*HKJY(*&^(IUJHKJH(*IJHKJH(*YKJHKJHKJ(*&)(*");
        }

        /// <summary>
        /// Verifies that parsing partially parenthesized expressions throws exceptions.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.ExpressionFormatException))]
        public void TestInvalidParse2() {
            Expression.Parse("(((((1+2)+(3+4))+(5+6))");
        }

        /// <summary>
        /// Verifies that parsing expressions with invalid numeric constants throws exceptions.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.ExpressionFormatException))]
        public void TestInvalidParse3() {
            Expression.Parse("123E5E6");
        }

        /// <summary>
        /// Verifies that parsing expressions with extra parentheses throws exceptions.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.ExpressionFormatException))]
        public void TestInvalidParse4() {
            Expression.Parse("((((1+2)+3)+4)+5))");
        }

        /// <summary>
        /// Verifies that parsing incomplete expressions throws exceptions.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.ExpressionFormatException))]
        public void TestInvalidParse5() {
            Expression.Parse("(1+2)*3+");
        }

        /// <summary>
        /// Verifies that parsing invalid numeric constants throws exceptions.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.ExpressionFormatException))]
        public void TestInvalidParse6() {
            Expression.Parse("++3");
        }

        /// <summary>
        /// Verifies that parsing incomplete numeric constants throws exceptions.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.ExpressionFormatException))]
        public void TestInvalidParse7() {
            Expression.Parse("123E-");
        }

        /// <summary>
        /// Verifies that calling parse with DefaultResolver works, but throw exceptions at
        /// the attempt to evaluate the resulting expression.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.UnresolvedVariableException))]
        public void TestDefaultNameResolver1() {
            Expression exp = Expression.Parse("A", new DefaultNameResolver());
            Assertion.Assert("Expression must parse", exp != null);
            exp.Evaluate();
        }        

        /// <summary>
        /// Verifies that calling parse with DefaultResolver works, but throw exceptions at
        /// the attempt to evaluate the resulting expression.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.UnresolvedVariableException))]
        public void TestDefaultNameResolver2() {
            Expression exp = Expression.Parse("A+B", new DefaultNameResolver());
            Assertion.Assert("Expression must parse", exp != null);
            exp.Evaluate();
        }        
    }
}

