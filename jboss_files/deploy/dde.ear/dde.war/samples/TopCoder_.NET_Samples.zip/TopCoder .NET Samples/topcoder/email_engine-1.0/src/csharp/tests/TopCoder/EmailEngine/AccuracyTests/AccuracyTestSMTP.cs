using System;
using NUnit.Framework;
using System.IO;

namespace TopCoder.EmailEngine.AccuracyTests
{
    /// <summary>
    /// Accuracy Tests for SmtpProtocol class
    /// @author aksonov
    /// </summary>

    [TestFixture]
    public class AccuracyTestSMTP
    {
        /// test SmtpProtocol constructor
        /// </summary>
        [Test]
        public void TestSmtpProtocol()
        {
            SmtpProtocol sp = new SmtpProtocol("smtp.test.com:333");

            Assertion.AssertEquals ("smtp.test.com", sp.Server);
            Assertion.AssertEquals (333, sp.Port);

            sp = new SmtpProtocol("smtp2.test.com");

            Assertion.AssertEquals("smtp2.test.com", sp.Server);
            Assertion.AssertEquals( 25, sp.Port);
        }
    }
}
