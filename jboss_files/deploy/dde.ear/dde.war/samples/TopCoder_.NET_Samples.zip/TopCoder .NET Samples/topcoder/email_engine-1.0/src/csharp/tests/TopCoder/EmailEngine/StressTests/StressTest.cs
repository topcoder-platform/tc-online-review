using System;
using NUnit.Framework;

// Author: mathgodleo

namespace TopCoder.EmailEngine.StressTests
{
	/// <summary>
	/// StressTests the EmailEngine.
	/// </summary>
	[TestFixture]
	public class StressTest
	{
		private EmailEngine ee;

        private const string FROM_ADDRESS = "development@topcodersoftware.com";
        private const string TO_ADDRESS = "development@topcodersoftware.com";
        private const string SMTP = "192.168.10.51";
		/// <summary>
		/// Sets up the test.
		/// </summary>
		[SetUp]
		public void SetUp()
		{
			ee = new EmailEngine();
			ee.EmailSender = new SmtpProtocol(SMTP);
		}

		/// <summary>
		/// Test sending 100 messages (no attachment). Should take at most 30s.
		/// </summary>
		[Test]
		public void SendNoAttachments()
		{
			Message message = new Message();
			message.From.Parse(FROM_ADDRESS);
			message.To.Parse(TO_ADDRESS);
			message.Body = "Hello world!";
			message.Subject = "subj";

			long time = DateTime.Now.Ticks;
			for (int i = 0; i<100; i++)
			{
				ee.SendMessage(message);
			}
			System.Console.WriteLine("\nSending 100 emails (no attachments) time = " + 
								     (DateTime.Now.Ticks - time)/10000000.0 + 
									 " seconds");
			Assertion.Assert("Took too long", DateTime.Now.Ticks - time < 300000000);
		}

		/// <summary>
		/// Test sending 100 messages (w/attachment). Should take at most 60s.
		/// </summary>
		[Test]
		public void SendWithAttachments()
		{
			Message message = new Message();
			Attachment attachment = 
				new Attachment(@"..\..\docs\Email_Engine_Sequence_Diagram_1.gif");
			message.From.Parse(FROM_ADDRESS);
			message.To.Parse(TO_ADDRESS);
			message.Body = "Hello world!";
			message.Subject = "subj";
			message.Attachments.Add(attachment);

			long time = DateTime.Now.Ticks;
			for (int i = 0; i<100; i++)
			{
				ee.SendMessage(message);
			}
			System.Console.WriteLine("\nSending 100 emails (w/attachments) time = " + 
				(DateTime.Now.Ticks - time)/10000000.0 + 
				" seconds");
			Assertion.Assert("Took too long", DateTime.Now.Ticks - time < 600000000);
		}
	}
}