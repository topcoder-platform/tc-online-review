using System;
using NUnit.Framework;

namespace TopCoder.EmailEngine.FunctionalTests
{
	/// <summary>
	/// Summary description for EmailEngine.
	/// </summary>
	[TestFixture]
	public class EmailEngineTest
	{
		private EmailEngine ee;
        private const string SMTP = "192.168.10.51";

    	/// <summary>
    	/// Sets up the test
    	/// </summary>
		[SetUp]
		public void SetUp()
		{
			ee = new EmailEngine();
			ee.EmailSender = new SmtpProtocol(SMTP);
		}

    	/// <summary>
    	/// tests creating the message
    	/// </summary>
		[Test]
		public void SendCreateMessage()
		{
			Message message = new Message();
			message.From.Parse("development@topcodersoftware.com");
			message.To.Parse("development@topcodersoftware.com");
			message.Body = "Hello world!";
			message.Subject = "subj";

			ee.SendMessage(message);
		}

    	/// <summary>
    	/// tests sending a complex message
    	/// </summary>
		[Test]
		public void SendComplexMessage()
		{
			Message m = MessageTest.GetComplexMessage();
			ee.SendMessage(m);
		}

    	/// <summary>
    	/// tests sending an attachment
    	/// </summary>
		[Test]
		public void SendAttachmentMessage()
		{
			Message m = MessageTest.GetAttachmentMessage();
			ee.SendMessage(m);
		}

    	/// <summary>
    	/// tests parsing and sending a message
    	/// </summary>
		[Test]
		public void SendParseMessage()
		{
			Message m = MessageTest.GetParseMessage();
			ee.SendMessage(m);
		}
		
    	/// <summary>
    	/// tests attachments
    	/// </summary>
		[Test]
		public void SendAttachmentDelMessage()
		{
			Message m = MessageTest.GetAttachmentDelMessage();
			ee.SendMessage(m);
		}
	}
}
