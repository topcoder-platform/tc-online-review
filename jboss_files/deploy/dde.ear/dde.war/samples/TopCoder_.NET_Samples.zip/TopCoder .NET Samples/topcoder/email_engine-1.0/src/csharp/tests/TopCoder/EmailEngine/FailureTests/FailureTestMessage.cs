using System;
using NUnit.Framework;

namespace TopCoder.EmailEngine.FailureTests {

    /// <summary>
    /// This tests Message.
    /// </summary>
    [TestFixture]
    public class FailureTestMessage {

        /// <summary>
        /// This tests whether fields are reset on Parse
        /// </summary>
        [Test]
        public void MessageParseReset() {
            Message m = new Message("a@a.a", "a", "a");
            m.Parse("To: a@a.a");
            Assertion.Assert(m.Subject == "");
            Assertion.Assert(m.Body == "");
        }

        /// <summary>
        /// This tests exception thrown with no from addr
        /// </summary>
        [Test]
        [ExpectedException(typeof(MessageErrorException))]
        public void MessageNoFromAddress() {
            Message m = new Message();
            m.To.Add(new EmailAddress("a@a.a"));
            m.ToString();
        }

        /// <summary>
        /// This tests exception thrown with no to addr
        /// </summary>
        [Test]
        [ExpectedException(typeof(MessageErrorException))]
        public void MessageNoToAddress() {
            Message m = new Message();
            m.From = new EmailAddress("a@a.a");
            m.ToString();
        }

    }

}
