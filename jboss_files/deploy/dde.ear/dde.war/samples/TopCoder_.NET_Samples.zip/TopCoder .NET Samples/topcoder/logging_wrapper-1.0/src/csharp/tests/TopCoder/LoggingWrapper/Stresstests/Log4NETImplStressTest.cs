// @author TCSDESIGNER
// @copyright (c) TopCoder Software

using System;
using System.IO;
using System.Text;
using NUnit.Framework;
using log4net.Config;
using log4net;

namespace TopCoder.LoggingWrapper.StressTests
{
    /// <summary>
    /// Stress tests for Log4NETImpl
    /// </summary>
    [TestFixture]
    public class Log4NETImplStrssTest {

        /// <summary>
        /// Set up method
        /// </summary>
        [SetUp]
        public void SetUp() {
            LogManager.Configuration = new System.Collections.Specialized.NameValueCollection();
            LogManager.Configuration.Add("PluginClassName", "TopCoder.LoggingWrapper.Log4NETImpl");
            LogManager.Configuration.Add("Log4NetConfiguration", @"..\..\conf\log4net.config");
            LogManager.Configuration.Add("LogName", "Test Log");
            LogManager.LoadConfiguration();
        }

        /// <summary>
        /// Tear down method
        /// </summary>
        [TearDown]
        public void TearDown() {
            LogManager.GetLogger().Dispose();
        }

        /// <summary>
        /// Test logging long message
        /// </summary>
        [Test]
        public void LogLongMessage() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 1000; ++i) {
                sb.Append("0123456789");
            }
            DateTime dt = DateTime.Now;
            LogManager.Log(sb.ToString());
            System.Console.Write("Logging 10k-length message took ");
            System.Console.Write((DateTime.Now.Ticks - dt.Ticks) / 10000);
            System.Console.WriteLine(" ms with Log4NETImpl");
        }

        /// <summary>
        /// Test logging multiple messages
        /// </summary>
        [Test]
        public void LogMultipleMessage() {
            DateTime dt = DateTime.Now;
            for (int i = 0; i < 1000; ++i) {
                LogManager.Log("0123456789");
            }
            System.Console.Write("Logging 1k messages took ");
            System.Console.Write((DateTime.Now.Ticks - dt.Ticks) / 10000);
            System.Console.WriteLine(" ms with Log4NETImpl");
        }

    }

}
