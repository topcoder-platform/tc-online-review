/* DefaultNameResolver.cs
 * Copyright @ 2003, TopCoder, Inc. All rights reserved
 * */
// @author kyky, mishagam
using System;

namespace TopCoder.Math.ExpressionEvaluator {
    /// <summary>
    /// Default implementation of INameResolver interface. When possible,
    /// applications using the component should inherit from this class instead of
    /// implementing the INameResolver directly. This allows for drop-in
    /// version upgrades without having to modify the code in case we decide to
    /// extend INameResolver to handle resolution of User-Defined Functions.
    /// </summary>
    public class DefaultNameResolver : INameResolver {

        /// <summary>
        /// Defualt Resolve if all extending classes didn't ovewrite this.
        /// Returns InvalidVariable that throws Exception on the attempt to 
        /// Evaluate it
        /// </summary>
        /// <param name="name">string name of variable. Here ignored</param>
        /// <returns></returns>
        public virtual Expression Resolve( string name ) {

            return new InvalidVariable();
        }

        /// <summary>
        /// class extending Expession. Used to throw UnresolvedVariableException
        /// on attempt to evaluate it.
        /// </summary>
        private class InvalidVariable: Expression {
            public override double Evaluate( IEvaluationEnv env ) {
                throw new UnresolvedVariableException("Tried to Evaluate InvalidVariable class");
            }
        }
    }


}
