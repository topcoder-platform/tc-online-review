// @author Mikhail_T
// @copyright (c) TopCoder Software 2003

using System;
using System.Collections;
using System.IO;

namespace TopCoder.LoggingWrapper
{
    /// <summary>
    ///  logging implementation based on log4net logging solution. Implements Facade pattern.
    /// </summary>
    public class Log4NETImpl : Logger
    {
        /// <summary>
        /// logging implementation object. should be initialized at constructor.
        /// </summary>
        private log4net.ILog log = null;

        /// <summary>
        /// file name for logging
        /// </summary>
        private string logfile = ".NET Logging Wrapper";

        /// <summary>
        /// filename of logfile
        /// </summary>
        internal string Logname 
        {
            get 
            {
                return logfile;
            }
            set 
            {
                if(value==null) throw new ArgumentNullException("Logname");                
                logfile = value;
            }
        }
        /// <summary>
        /// logging levels in the implementation
        /// </summary>
        public enum Log4NETLevel
        {
            OFF,
            DEBUG,
            INFO,
            WARN,
            ERROR,
            FATAL
        }

        /// <summary>
        /// Initializes a new instance of the Log4NETImpl class
        /// </summary>
        internal Log4NETImpl() : base() 
        {
        }

        /// <summary>
        /// Initializes a new instance of the Log4NETImpl class with the specified logging level
        /// </summary>        
        /// <param name="level">Level of logging.</param>
        internal Log4NETImpl(Level level) : base(level) 
        {
        }

        ~Log4NETImpl()
        {
            log4net.LogManager.Shutdown();
        }
		
		override public void Dispose()
		{
			log4net.LogManager.Shutdown();
		}
        /// <summary>
        /// Is used to load/reload configuration for logging implementation. <c>log</c> object should be initialized here
        /// </summary>
        /// <param name="config">configuration</param>
        internal override void LoadConfiguration(System.Collections.Specialized.NameValueCollection config)
        {            
            if(config==null) throw new ArgumentNullException("config");                        
            try
            {
                if(config["LogName"]!=null)
                    Logname=config["LogName"];                
                string fileName = config["Log4NetConfiguration"];                
                log4net.Config.DOMConfigurator.Configure(new FileInfo(fileName));
                log=log4net.LogManager.GetLogger(Logname);                
            }
			catch(Exception e)
			{            
				throw new ConfigException("Error encountered in the process of logger configuration. "+e.Message);                                    
			}
        }
    
        /// <summary>
        /// Maps the level of logging in the implementation to the logging level of the wrapper.
        /// </summary>
        internal override void setMapping()
        {
            Map[Level.DEBUG] = Log4NETLevel.DEBUG;
            Map[Level.FAILUREAUDIT] = Log4NETLevel.DEBUG;
            Map[Level.SUCCESSAUDIT] = Log4NETLevel.DEBUG;
            Map[Level.ERROR] = Log4NETLevel.ERROR;
            Map[Level.OFF] = Log4NETLevel.OFF;
            Map[Level.FATAL] = Log4NETLevel.FATAL;
            Map[Level.WARN] = Log4NETLevel.WARN;
            Map[Level.INFO] = Log4NETLevel.INFO;
        }
        /// <summary>
        /// Is used to log a message using the specified logging level
        /// </summary>
        /// <param name="level">logging level</param>
        /// <param name="message">logging message</param>
            /// <param name="param">parameters for logging message</param>
        internal override void Log(Level level, string message, params object[] param)
        {            
            if (!Map.Contains(level)) return;
            switch ((Log4NETLevel)Map[level])
            {
                case Log4NETLevel.WARN: log.Warn(String.Format(message, param));break;
                case Log4NETLevel.DEBUG: log.Debug(String.Format(message, param));break;
                case Log4NETLevel.ERROR: log.Error(String.Format(message, param));break;
                case Log4NETLevel.FATAL: log.Fatal(String.Format(message, param));break;
                case Log4NETLevel.INFO: log.Info(String.Format(message, param));break;
            }

        }

    }
}
