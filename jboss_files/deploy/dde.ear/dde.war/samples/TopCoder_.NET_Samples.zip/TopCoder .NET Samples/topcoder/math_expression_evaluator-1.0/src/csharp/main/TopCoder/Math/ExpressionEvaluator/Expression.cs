/* Expression.cs; 
 * Copyright @ 2003, TopCoder, Inc. All rights reserved
 * @author kyky, mishagam
 * */
using System;
using System.Collections;

namespace TopCoder.Math.ExpressionEvaluator {
    /// <summary>
    /// This abstract class provides methods for evaluating itself.
    /// In addition, Expression provides static methods for parsing expression
    /// strings into instances of Expression.                                                                                                                                                                          .
    /// </summary>
    public abstract class Expression {
        /// <summary>
        /// This is the most general way of calling Evaluate. Applications requiring
        /// custom evaluation use this method.
        /// Descendent classes override this method to implement their functionality.
        /// </summary>
        /// <param name="env">The evaluation environment.</param>
        /// <returns>Evaluation result.</returns>
        /// <exception cref="UnresolvedVariableException"/>
        public abstract double Evaluate( IEvaluationEnv env );
        /// <summary>
        /// This method builds an evaluation environment from the supplied IDictionary.
        /// Applications that use only simple evaluation make an IDictionary 
        /// that maps variable names to variable values, and call this method.
        /// </summary>
        /// <param name="varValues">A dictionary that maps variable names to their values.</param>
        /// <returns>Evaluation result.</returns>
        /// <exception cref="UnresolvedVariableException"/>
        public double Evaluate( IDictionary varValues ) {
            return Evaluate( new SimpleEvaluationEnv( varValues ));
        }
        /// <summary>
        /// This method builds an evaluation environment from two arrays
        /// of the same length, containing variable names and values.
        /// This method allows for more compact uses when the number of variables
        /// is known at compile time, and is small.
        /// </summary>
        /// <param name="names">An array of variable names.</param>
        /// <param name="values">An array of variable values.</param>
        /// <returns>Evaluation result.</returns>
        /// <exception cref="UnresolvedVariableException"/>
        public double Evaluate( string[] names, double[] values ) {
            if (names == null && values == null) {
                names = new string[0];
                values = new double[0];
            }

            if (names == null || values == null) {
                throw new ArgumentNullException("names and values cannot have one null");
            }
            if (names.Length != values.Length ) {
                throw new ArgumentException("names and values must be of the same length");
            }
            Hashtable ht = new Hashtable();
            for ( int i = 0 ; i != names.Length ; i++ ) {
                ht[names[i]] = values[i];
            }
            return Evaluate( new SimpleEvaluationEnv( ht ));
        }
        /// <summary>
        /// This method is suitable only for constant expressions (i.e. expressions
        /// that do not reference variables). Calling this method on an expression
        /// which references a variable results in UnresolvedVariableException.
        /// </summary>
        /// <returns>Evaluation result.</returns>
        /// <exception cref="UnresolvedVariableException"/>
        public double Evaluate() {
            return Evaluate( new SimpleEvaluationEnv());;
        }
        /// <summary>
        /// Produces an evaluable expression from a string representing the expression.
        /// Uses the default name resolver to resolve variable names.
        /// </summary>
        /// <param name="expr">String representation of the expression.</param>
        /// <returns>An instance of Expression that corresponds to the string expr.</returns>
        /// <exception cref="ExpressionFormatException"/>
        public static Expression Parse( string expr ) {
            return Parse( expr, new SimpleNameResolver());
        }
        /// <summary>
        /// Produces an evaluable expression from a string representing the expression.
        /// Uses the supplied name resolver to resolve variable names.
        /// </summary>
        /// <param name="expr">String representation of the expression.</param>
        /// <param name="resolver">A facility for resolving variable names.</param>
        /// <returns>An instance of Expression that corresponds to the string expr.</returns>
        /// <exception cref="ExpressionFormatException"/>
        public static Expression Parse( string expr, INameResolver resolver ) {
            DefaultParser parser = new DefaultParser();

            Expression e = parser.Parse(expr, resolver);
            return e;
        }
    }
}
