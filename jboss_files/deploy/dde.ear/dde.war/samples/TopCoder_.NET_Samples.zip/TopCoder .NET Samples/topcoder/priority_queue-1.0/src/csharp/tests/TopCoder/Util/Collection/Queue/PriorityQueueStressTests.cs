/*
Copyright c 2003, TopCoder, Inc. All rights reserved.
Author opi
*/


using System;
using System.Text;
using System.Collections;

namespace TopCoder.Util.Collection.Queue
{
	using System;
	using NUnit.Framework;
	/// <summary>
	/// Test the functionality of the PriorityQueue class.
	/// </summary>
	/// 
	[TestFixture]
	public class PriorityQueueStressTests
	{
		/// <summary>
		/// Test PriorityQueue created but left empty.
		/// </summary>
		public PriorityQueue pq;
		/// <summary>
		/// Test PriorityQueue created and filled with 1000 objects
		/// </summary>
		public PriorityQueue pqBig;

        /// <summary>
		/// Create two queues, one empty and one filled with 1000 strings - "0" to "999"
		/// with corresponding integer priorities.
		/// </summary>
		/// 
		[SetUp]
		protected void SetUp() 
		{
			pq = new PriorityQueue();
			pqBig = new PriorityQueue();
			Assertion.AssertNotNull(pqBig);
			for (int index=0; index<1000; index++)
			{
				pqBig.Enqueue(index.ToString(), index);
			}

		}

		/// <summary>
        /// Create a large PriorityQueue, fill it, copy it to an array, enumerate
        /// through the PriorityQueue then Peek at every element as it is Dequeued.
        /// </summary>
        [Test]
        public void Stress()
        {
            int iStress = 10000;
            PriorityQueue pqStress = new PriorityQueue(1, 1);
            for (int index=0; index<iStress; index++)
            {
                pqStress.Enqueue(index.ToString(), index);
            }
            Assertion.AssertEquals("Count1",iStress, pqStress.Count);

            object [] iArray;
            iArray = pqStress.ToArray();
            Assertion.AssertEquals("Array",iStress, iArray.Length);

            pqStress.TrimToSize();

            int count=0;
            foreach(string s in pqStress)
            {
                int l = s.Length;
                count++;
            }
            Assertion.AssertEquals(iStress, count);

			int posneg = 1;
			// Alternatively enqueue an object at the bottom then the top of the heap.
			for (int index=0; index<iStress; index++)
			{
				pqStress.Dequeue();
				pqStress.Enqueue(index.ToString(), (index+iStress)*posneg);
				posneg *= (-1);
			}

			Assertion.AssertEquals(iStress, pqStress.Count);
			int mid = (iStress/2)-1; // Half of the new objects and half of the old objects have been Dequeue'd
			Assertion.AssertEquals(mid.ToString(), pqStress.Peek());

            count=0;
			int beginCount = pqStress.Count;
            while (pqStress.Count > 0)
            {
                pqStress.Peek();
                pqStress.Dequeue();
                count++;
            }
			// PriorityQueue should be empty
            Assertion.AssertEquals("Count2",0, pqStress.Count);
			// Should have Dequeue'd everything
			Assertion.AssertEquals(beginCount, count);
        }
	}
}
