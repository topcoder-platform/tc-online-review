using System;
using System.Text;
using System.Text.RegularExpressions;

// @author CLoris
// @copyright 2003 (c) TopCoder Software

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// Provides properties and methods for constructing an e-mail message.
    /// </summary>
    public class Message 
    {
        // constants
        private const string MSG_FROM = "From: {0}\r\n";
        private const string MSG_DATE = "Date: {0} {1}\r\n";
        private const string MSG_TO = "To: ";
        private const string MSG_CC = "CC: ";
        private const string MSG_BCC = "BCC: ";
        private const string MSG_SUBJECT = "Subject: {0}\r\n";
        private const string MSG_SUBJECT_BLANK = "Subject: \r\n";
        private const string MSG_CRLF = "\r\n";
        private const string MSG_COMMA = ", ";
        private const string MSG_MIME_HEAD = "MIME-Version: 1.0\r\n" +
                                             "Content-Type: multipart/mixed; boundary=\"NextMimePart\"\r\n" +
                                             "Content-Transfer-Encoding: 7bit\r\n" +
                                             "\r\nThis message is in MIME format. Since your mail reader does not understand\r\n" +
                                             "this format, some or all of this message may not be legible.\r\n";
        private const string MSG_MIME_BODY = "\r\n--NextMimePart\r\n" +
                                             "Content-Type: text/plain; charset=us-ascii\r\n\r\n";
        private const string MSG_DATE_FORMAT = "ddd, dd MMM yyyy hh:mm:ss";
        private const string MSG_OFFSET_FORMAT = "0000";
        
        private const string REGEX_HEADER = "^(?<header>(.+\n)+)\n(?<body>\n*(.+(\n)*)+)";
        private const string REGEX_HEADER_FIELDS = "\\s*(?<field>[^:]+):(?<value>.+)\n";

        private const string ERR_FROM_REQUIRED = "Message requires a From value before conversion ToString()";
        private const string ERR_TO_CC_REQUIRED = "Message requires a To and CC to contain at least one address before conversion ToString()";
        private const string ERR_TO_INVALID = "Invalid To address specified in message";
        private const string ERR_CC_INVALID = "Invalid CC address specified in message";
        private const string ERR_BCC_INVALID = "Invalid CCC address specified in message";
        // end constants

        private EmailAddressList to = new EmailAddressList();
        private EmailAddressList cc = new EmailAddressList();
        private EmailAddressList bcc = new EmailAddressList();
        private EmailAddress from = new EmailAddress();
        private string subject = "";
        private string body = "";
        private AttachmentList attachments = new AttachmentList();

        /// <summary>
        /// From field of the message
        /// </summary>
        public EmailAddress From 
        {
            get 
            {
                return from;
            }
            set 
            {
                from = value;
            }
        }
        /// <summary>
        /// Retrievs To: recipients list of the email message
        /// </summary>
        /// 
        public EmailAddressList To 
        {
            get 
            {
                return to;
            }
            set 
            {
                to = value;
            }
        }

        /// <summary>
        /// Retrievs CC: recipients list of the email message
        /// </summary>
        public EmailAddressList CC
        {
            get 
            {
                return cc;
            }
            set 
            {
                cc  = value;
            }
        }

        /// <summary>
        /// Retrievs BCC: recipients list of the email message
        /// </summary>
        public EmailAddressList BCC
        {
            get 
            {
                return bcc;
            }
            set 
            {
                bcc = value;
            }
        }

        /// <summary>
        /// Body of the email message
        /// </summary>
        public String Body 
        {
            get 
            {
                return body;
            }
            set 
            {
                body = value;
            }
        }

        /// <summary>
        /// Subject of the email message
        /// </summary>
        public String Subject 
        {
            get 
            {
                return subject;
            }
            set 
            {
                subject = value;
            }
        }

        /// <summary>
        /// Retrieves the list of attachments
        /// </summary>

        public AttachmentList Attachments
        {
            get 
            {
                return attachments;
            }
            set 
            {
                attachments = value;
            }
        }
    
        /// <summary>
        /// Empty Message constructor
        /// </summary>
        public Message()
        {
        }

        //  Please read ( as <, and ) as > because "<" and ">" is part of special documentation tags
        /// <summary>
        /// Constructs Message from email in standard format, like:
        /// <code>
        /// From: "Ivan Ivanov" (ivan@ya.ru)
        /// To: "John Smith" (john@domain.com)
        /// CC: al@domain.com, forever@domain.com
        /// Subject: Hello!
        /// 
        /// Hello, How are you!
        /// Bye!
        /// </code>
        /// </summary>
        /// <param name="message"></param>
        public Message(string message)
        {
            // parse out the provided message
            this.Parse(message);
        }

        /// <summary>
        /// Parse <c>message</c> (email in standard format) to own private objects
        /// Used for sending existing email messages (not new)
        /// </summary>
        /// <param name="message">email message</param>
        public void Parse(string message)
        {
            Regex regex;
            Match match;
            String header;

            // clear existing values
            EmailAddressList to = new EmailAddressList();
            EmailAddressList cc = new EmailAddressList();
            EmailAddressList bcc = new EmailAddressList();
            EmailAddress from = new EmailAddress();
            subject = "";
            body = "";
            AttachmentList attachments = new AttachmentList();

            // split the message into the header and the body
            regex = new Regex(REGEX_HEADER);
            match = regex.Match(message);
            header = match.Groups["header"].Value;
            this.Body = match.Groups["body"].Value;

            // parse out the header fields
            regex = new Regex(REGEX_HEADER_FIELDS, RegexOptions.Multiline);
            match = regex.Match(header);
            
            // visit each header field and work it into the messgae
            while(match.Success == true)
            {
                switch(match.Groups["field"].Value.ToLower())
                {
                    case "to":
                        this.to.Parse(match.Groups["value"].Value);
                        break;
                    case "from":
                        this.from.Parse(match.Groups["value"].Value);
                        break;
                    case "cc":
                        this.cc.Parse(match.Groups["value"].Value);
                        break;
                    case "bcc":
                        this.bcc.Parse(match.Groups["value"].Value);
                        break;
                    case "subject":
                        this.subject = match.Groups["value"].Value;
                        break;
                }

                        // next match
                        match = match.NextMatch();
            }

        }

        /// <summary>
        /// Simple Message constructor
        /// </summary>
        /// <param name="email">Recipient's email</param>
        /// <param name="subject">subject</param>
        /// <param name="body">body</param>
        public Message(string email, string subject, string body)
        {
            this.Body = body;
            this.Subject = subject;
            this.To.Add(new EmailAddress(email));
        }

        /// <summary>
        /// Simple Message constructor
        /// </summary>
        /// <param name="email">Recipient's email (EmailAddress object)</param>
        /// <param name="subject">subject</param>
        /// <param name="body">body</param>
        public Message(EmailAddress email, string subject, string body)
        {
            this.Body = body;
            this.Subject = subject;
            this.To.Add(email);
        }

        /// <summary>
        /// Converts Message object to well-formed string for further sending email via SmtpProtocol
        /// throws MessageErrorException if Message if not well-formed (From:. To: or Body: missed, etc.)
        /// </summary>
        /// <returns></returns>
        /// <exception cref="MessageErrorException">Thrown if an email message lacks a from address.</exception>
        /// <exception cref="MessageErrorException">Thrown if an email message lacks atleast one To or CC address.</exception>
        /// <exception cref="MessageErrorException">Thrown if an email message has a bad CC, To or BCC address.</exception>
        public override string ToString()
        {
            StringBuilder result = new StringBuilder();

            // validate and build message
            // --------------------------
            
            // from (RFC822 C.3.2)
            if( (this.from.ToString() == "") || (this.from.ToString() == null) )
            {
                throw new MessageErrorException(ERR_FROM_REQUIRED);
            }
            else
            {
                result.Append(String.Format(MSG_FROM, this.from.ToString()));
            }

            // date
            DateTime myTime = DateTime.Now;
            TimeZone tz = TimeZone.CurrentTimeZone;
            result.Append(String.Format(MSG_DATE, myTime.ToString(MSG_DATE_FORMAT),((int)(tz.GetUtcOffset(myTime).Hours * 100)).ToString(MSG_OFFSET_FORMAT)));

            // "To" and "CC" are required to contain at least one address. (RFC822 C.3.4)
            if( (this.to.Count == 0) && (this.cc.Count == 0) )
            {
                throw new MessageErrorException(ERR_TO_CC_REQUIRED);
            }

            // to
            if(this.to.Count > 0)
            {
                result.Append(MSG_TO);
            }
            for(int loop = 0; loop < this.to.Count; loop++)
            {
                if( (this.to[loop].ToString() == "") || (this.to[loop].ToString() == null) )
                {
                    throw new MessageErrorException(ERR_TO_INVALID);
                }
                else
                {
                    if(loop > 0)
                    {
                        result.Append(MSG_COMMA);
                    }
                    result.Append(this.to[loop].ToString());
                }
            }
            if(this.to.Count > 0)
            {
                result.Append(MSG_CRLF);
            }

            // cc
            if(this.cc.Count > 0)
            {
                result.Append(MSG_CC);
            }
                for(int loop = 0; loop < this.cc.Count; loop++)
            {
                if( (this.cc[loop].ToString() == "") || (this.cc[loop].ToString() == null) )
                {
                    throw new MessageErrorException(ERR_CC_INVALID);
                }
                else
                {
                    if(loop > 0)
                    {
                        result.Append(MSG_COMMA);
                    }
                    result.Append(this.cc[loop].ToString());
                }
            }
            if(this.cc.Count > 0)
            {
                result.Append(MSG_CRLF);
            }

            // bcc
            if(this.bcc.Count > 0)
            {
                result.Append(MSG_BCC);
            }
            for(int loop = 0; loop < this.bcc.Count; loop++)
            {
                if( (this.bcc[loop].ToString() == "") || (this.bcc[loop].ToString() == null) )
                {
                    throw new MessageErrorException(ERR_BCC_INVALID);
                }
                else
                {
                    if(loop > 0)
                    {
                        result.Append(MSG_COMMA);
                    }
                    result.Append(this.bcc[loop].ToString());
                }
            }
            if(this.bcc.Count > 0)
            {
                result.Append(MSG_CRLF);
            }

            // subject
            if(this.subject == null)
            {
                result.Append(MSG_SUBJECT_BLANK);
            }
            else
            {
                result.Append(String.Format(MSG_SUBJECT, this.subject.ToString()));
            }

            // message
            result.Append(MSG_MIME_HEAD);
            // message body
            result.Append(MSG_MIME_BODY);
            result.Append(this.body);

            // attachments
            if(this.attachments.Count > 0)
            {
                result.Append(this.attachments.ToString());
            }

            return result.ToString();
        }
    }


}
