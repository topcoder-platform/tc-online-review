using System;
using NUnit.Framework;
using System.IO;
using System.Diagnostics;

namespace TopCoder.EmailEngine.AccuracyTests
{
    /// <summary>
    /// Accuracy Tests for EmailEngine class
    /// @author aksonov
    /// </summary>
    [TestFixture]
    public class AccuracyTestEmailEngine
    {
        /// <summary>
        /// test sending message
        /// </summary>
        private const string SMTP = "192.168.10.51";
        //private const string FROM_ADDRESS = "development@topcodersoftware.com";
        //private const string TO_ADDRESS =  "development@topcodersoftware.com";
        private const string FROM_ADDRESS = "development@topcodersofware.com";
        private const string TO_ADDRESS =  "development@topcodersofware.com";
        [Test]
        public void TestEmailEngine()
        {
            EmailEngine ee = new EmailEngine(new SmtpProtocol(SMTP));
            Message m = new Message();
            m.From.Parse(FROM_ADDRESS);
			m.To.Parse(TO_ADDRESS);
			m.Body = "Hello world!";
			m.Subject = "subj2";
			
            AttachmentList list = new AttachmentList();
            list.Add(new Attachment(new FileStream(@"..\..\test_files\attachment1.txt", FileMode.Open, FileAccess.Read, FileShare.Read)));
            list.Add(new Attachment(new FileStream(@"..\..\test_files\attachment2.txt", FileMode.Open, FileAccess.Read, FileShare.Read)));
            list.Add(new Attachment(new FileStream(@"..\..\test_files\attachment3.msg", FileMode.Open, FileAccess.Read, FileShare.Read)));

            m.Attachments = list;
            ee.SendMessage(m);
        }

    }
}
