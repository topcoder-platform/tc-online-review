// @author mathgodleo
// @copyright (c) TopCoder Software

using System;
using System.Diagnostics;
using System.IO;
using NUnit.Framework;

namespace TopCoder.LoggingWrapper.FailureTests
{
	/// <summary>
	/// Test cases for Log4NET implementation.
	/// </summary>
	[TestFixture]
	//[Ignore("")]
	public class Log4NETImplFailureTests
	{

		private const string logfile = @"../../test_files/error-log.txt";

		/// <summary>
		/// Set ups configuration of the LogManager
		/// </summary>
		[SetUp]
		public void setup()
		{
		    LogManager.GetLogger().Dispose();
			LogManager.Configuration = new System.Collections.Specialized.NameValueCollection();        
			LogManager.Configuration.Add(LogManager.CLASS_PARAMETER, "TopCoder.LoggingWrapper.Log4NETImpl");            
			LogManager.Configuration.Add("Log4NetConfiguration", @"..\..\conf\log4net.config");
			LogManager.Configuration.Add("LogName", "Failure Log");
			LogManager.LoadConfiguration();
		}

		/// <summary>
		/// Tests a null 1st parameter to Log().
		/// </summary>
		[Test]
		[ExpectedException(typeof(System.ArgumentNullException))]
		public void testLogNull()
		{
			LogManager.Log(null);
		}

		/// <summary>
		/// Tests a null 3rd parameter to Log().
		/// </summary>
		[Test]
		[ExpectedException(typeof(System.ArgumentNullException))]
		public void testLogNull2()
		{
			LogManager.Log(Level.DEBUG, "Hello World {0}", null);
		}

		/// <summary>
		/// Tests a null 1st parameter to Log().
		/// </summary>
		[Test]
		[ExpectedException(typeof(System.ArgumentNullException))]
		public void testLogNull3()
		{
			LogManager.Log(null, "Hello World {0}", "!");
		}

		/// <summary>
		/// Tests that every logging level works.
		/// </summary>
		[Test]
		public void testAllLevels()
		{
			LogManager.Log(Level.DEBUG, "DEBUG");
			LogManager.Log(Level.ERROR, "ERROR");
			LogManager.Log(Level.FAILUREAUDIT, "FAILURE");
			LogManager.Log(Level.FATAL, "FATAL");
			LogManager.Log(Level.INFO, "INFO");
			LogManager.Log(Level.OFF, "OFF");
			LogManager.Log(Level.SUCCESSAUDIT, "SUCCESS");
			LogManager.Log(Level.WARN, "WARN");
			
			LogManager.GetLogger().Dispose();

			FileStream fs = File.OpenRead(logfile);
			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			StreamReader sr = new StreamReader(fs);
			string str;
			while ((str = sr.ReadLine()) != null)
			{
				sb.Append(str);
			}
			String f = sb.ToString();
			fs.Close();		
			

			Assertion.Assert(f.IndexOf("DEBUG") >= 0);
			Assertion.Assert(f.IndexOf("ERROR") >= 0);
			Assertion.Assert(f.IndexOf("FAILURE") >= 0);
			Assertion.Assert(f.IndexOf("FATAL") >= 0);
			Assertion.Assert(f.IndexOf("INFO") >= 0);
			Assertion.Assert(f.IndexOf("OFF") < 0);
			Assertion.Assert(f.IndexOf("SUCCESS") >= 0);
			Assertion.Assert(f.IndexOf("WARN") >= 0);
		}

		[TearDown]
		public void Down()
		{
		    LogManager.GetLogger().Dispose();
		}
	}
}
