// @author Mikhail_T
// @copyright (c) TopCoder Software 2003


using System;
using System.Diagnostics;
using System.Configuration;

namespace TopCoder.LoggingWrapper
{
    /// <summary>
    /// logging implementation based on System.Diagnostic namespace
    /// </summary>
    public class DiagnosticImpl : Logger
    {
        /// <summary>
        /// logging implementation object. Should be initialized at LoadConfiguration.
        /// </summary>
        private static EventLog log = null;
        /// <summary>
        /// Name of log file
        /// </summary>
        private string logname = ".NET Logging Wrapper";
        /// <summary>
        /// Name of source needed for the EventLog.WriteEntry function
        /// </summary>
        private string source = ".NET Logging Wrapper";
        /// <summary>
        /// Name of log file
        /// </summary>
        internal string Logname 
        {
            get 
            {                
                return logname;
            }
            set 
            {
                if(logname==null) throw new ArgumentNullException("logname");                
                logname = value;
            }
        }

        /// <summary>
        /// Initializes a new instance of the DiagnosticImpl class
        /// </summary>
        internal DiagnosticImpl() : base()
        {            
            log=new EventLog(logname,".",source);            
        }

        /// <summary>
        /// Initializes a new instance of the DiagnosticImpl class with the specified logging level
        /// </summary>
        internal DiagnosticImpl(Level level) : base(level) 
        {        
            log=new EventLog(logname,".",source);            
        }

        /// <summary>
        /// Is used to load/reload configuration for logging implementation
        /// </summary>
        /// <param name="config">configuration</param>
        internal override void LoadConfiguration(System.Collections.Specialized.NameValueCollection config)
        {            
            if(config==null) throw new ArgumentNullException("config");            
            try{
                if(config["Source"]!=null)
                    source=config["Source"];            
                if(config["LogName"]!=null)
                    Logname=config["LogName"];    
                log=new EventLog(logname,".",source);    
            }
            catch(Exception e)
			{            
               throw new ConfigException("Error encountered in the process of logger configuration. "+e.Message);                                    
            }
        }
		override public void Dispose()
		{
		}
        /// <summary>
        /// Maps the level of logging in the implementation to the logging level of the wrapper.
        /// </summary>
        internal override void setMapping()
        {
            Map[Level.DEBUG] = EventLogEntryType.Information;
            Map[Level.FAILUREAUDIT] = EventLogEntryType.FailureAudit;
            Map[Level.SUCCESSAUDIT] = EventLogEntryType.SuccessAudit;
            Map[Level.ERROR] = EventLogEntryType.Error;
            Map[Level.FATAL] = EventLogEntryType.Error;
            Map[Level.WARN] = EventLogEntryType.Warning;
            Map[Level.INFO] = EventLogEntryType.Information;			
			Map[Level.OFF]=Level.OFF;
        }

        /// <summary>
        /// Is used to log a message using the underlying implementation
        /// </summary>
        /// <param name="level">logging level</param>
        /// <param name="message">logging message</param>
        /// <param name="param">parameters for logging message</param>
        internal override void Log(Level level, string message, params object[] param)
        {
            if (!Map.Contains(level)||level==Level.OFF) return;
            log.WriteEntry(String.Format(message,param),(EventLogEntryType)Map[level]);
        }		
		
    }
}
