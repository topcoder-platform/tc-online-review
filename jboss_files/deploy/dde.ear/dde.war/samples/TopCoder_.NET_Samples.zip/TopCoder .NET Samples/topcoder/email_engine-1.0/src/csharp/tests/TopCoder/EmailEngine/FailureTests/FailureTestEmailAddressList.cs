using System;
using NUnit.Framework;

namespace TopCoder.EmailEngine.FailureTests {

    /// <summary>
    /// This tests EmailAddressList.
    /// </summary>
    [TestFixture]
    public class FailureTestEmailAddressList {

        /// <summary>
        /// This tests whether it parses email list correctly
        /// </summary>
        [Test]
        public void EmailAddressListParse() {
            EmailAddressList eal = new EmailAddressList();
            eal.Parse("\"a,a\" <a@a.a> (a,a)");
            Assertion.Assert(eal.Count == 1);
        }

        /// <summary>
        /// This tests whether duplicates are identified with addr
        /// </summary>
        [Test]
        public void EmailAddressListRemoveDuplicates() {
            EmailAddressList eal = new EmailAddressList();
            eal.Parse("\"a\" <a@a.a>, \"b\" <a@a.a>, \"a\" <b@b.b>, <b@b.b> (c)");
            Assertion.Assert(eal.Count == 4);
            eal.RemoveDuplicates();
            Assertion.Assert(eal.Count == 2);
        }

    }

}
