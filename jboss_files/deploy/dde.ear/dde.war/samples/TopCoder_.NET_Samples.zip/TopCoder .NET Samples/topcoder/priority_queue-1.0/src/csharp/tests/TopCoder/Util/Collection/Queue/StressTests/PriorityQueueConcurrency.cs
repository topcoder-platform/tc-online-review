/*
Copyright c 2003, TopCoder, Inc. All rights reservedusing System;
Author pzhao
*/

using System;
using System.Collections;
using System.Threading;

using TopCoder.Util.Collection.Queue;

using NUnit.Framework;

namespace TopCoder.Util.Collection.Queue.StressTests
{
    /// <summary>
    /// Test the PriorityQueue class using a number of threads
    /// </summary>
    [TestFixture]
    public class PriorityQueueConcurrency
    {
        /// <summary>
        /// Test the Enqueue and Dequeue methods
        /// </summary>
        [Test]
        public void TestConcurrency()
        {
            PriorityQueueThread[] pqs = new PriorityQueueThread[10];
            Thread[] threads = new Thread[10];
            int i;

            for (i = 0; i < 10; i++) 
            {
                pqs[i] = new PriorityQueueThread();
                threads[i] = new Thread(new ThreadStart(pqs[i].Run));
                threads[i].Start();
            }

            for (i = 0; i < 10; i++) 
            {
                threads[i].Join();
                Assertion.Assert(pqs[i].Success);
            }
        }
    }
    
    /// <summary>
    /// Single thread that test the PriorityQueue class
    /// </summary>
    class PriorityQueueThread
    {
        private AbstractBenchmark test;
        private bool success;

        /// <summary>
        /// Whether the test is successful
        /// </summary>
        public bool Success
        {
            get
            {
                return success;
            }
        }

        /// <summary>
        /// Main loop of threads
        /// </summary>
        public void Run()
        {
            success = true;
            try {
                test = new TestEnqueueDequeue();
                test.RunOnce();
                test = new TestConstructor();
                test.RunOnce();
                test = new TestContains();
                test.RunOnce();
                test = new TestCopyToArray();
                test.RunOnce();
                test = new TestClone();
                test.RunOnce();
                test = new TestEnumerate();
                test.RunOnce();
            } catch (Exception) {
                success = false;
            }
        }
    }
}
