/* ExpressionFormatException.cs; 
 * Copyright @ 2003, TopCoder, Inc. All rights reserved
 * 
 * @authors kyky, mishagam
 * */
using System;

namespace TopCoder.Math.ExpressionEvaluator {
    /// <summary>
    /// Expression.Parse throws this exception when an expression passed for parsing
    /// does not conform to the syntax supported by the parser.
    /// </summary>
    public class ExpressionFormatException : Exception {
        /// <summary>
        /// Creates an instance of ExpressionFormatException.
        /// </summary>
        /// <param name="description">Descriptive message explaining why the expression cannot be parsed.</param>
        public ExpressionFormatException( string description ) : base( description ) {
        }
    }
}
