/*
    Copyright c 2003, TopCoder, Inc. All rights reserved
    Author TCSDEVELOPER
*/

using System;

using TopCoder.Math.ExpressionEvaluator;

using NUnit.Framework;

namespace TopCoder.Math.ExpressionEvaluator.AccuracyTests {

    /// <summary>
    /// Test cases for the various format constants.
    /// </summary>
    [TestFixture]
    public class ConstantsAccuracyTests {
        /// <summary>
        /// Expression instance for tests.
        /// </summary>
        Expression exp;

        /// <summary>
        /// Verifies that the parser can process positive integer constants.
        /// (Including Zero)
        /// </summary>
        [Test]
        public void TestPositiveIntConstant() {
            // Zero
            exp = Expression.Parse("0");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   0, Double.Parse(exp.ToString()));

            exp = Expression.Parse("0000");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   0, Double.Parse(exp.ToString()));

            // Small positive integer
            exp = Expression.Parse("2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 2", 
                                   2, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   2, Double.Parse(exp.ToString()));

            // Large positive integer
            exp = Expression.Parse("1234567");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1234567", 
                                   1234567, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   1234567, Double.Parse(exp.ToString()));

            // Heading by "+"
            exp = Expression.Parse("+12345");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 12345", 
                                   12345, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   12345, Double.Parse(exp.ToString()));

            // Heading by "0"
            exp = Expression.Parse("000123");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 123", 
                                   123, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   123, Double.Parse(exp.ToString()));

            // Heading by "+" and "0"
            exp = Expression.Parse("+001234");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1234", 
                                   1234, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   1234, Double.Parse(exp.ToString()));
        }

        /// <summary>
        /// Verifies that the parser can process negative integer constants.
        /// (Including Zero)
        /// </summary>
        [Test]
        public void TestNegativeIntConstant() {
            // Zero
            exp = Expression.Parse("-0");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   0, Double.Parse(exp.ToString()));

            exp = Expression.Parse("-0000");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   0, Double.Parse(exp.ToString()));

            // Small negative integer
            exp = Expression.Parse("-2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -2", 
                                   -2, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -2, Double.Parse(exp.ToString()));

            // Large negative integer
            exp = Expression.Parse("-1234567");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -1234567", 
                                   -1234567, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -1234567, Double.Parse(exp.ToString()));

            // Heading by "0"
            exp = Expression.Parse("-000123");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -123", 
                                   -123, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -123, Double.Parse(exp.ToString()));
        }

        /// <summary>
        /// Verifies that the parser can process positive real value constants.
        /// (Including Zero)
        /// </summary>
        [Test]
        public void TestPositiveDoubleConstant() {
            // Zero
            exp = Expression.Parse("0.0");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   0, Double.Parse(exp.ToString()));

            exp = Expression.Parse("0000.0");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   0, Double.Parse(exp.ToString()));

            exp = Expression.Parse(".000");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   0, Double.Parse(exp.ToString()));

            // Small positive double
            exp = Expression.Parse("1.2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1.2", 
                                   1.2, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   1.2, Double.Parse(exp.ToString()));

            // Large positive double
            exp = Expression.Parse("1234.567");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1234.567", 
                                   1234.567, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   1234.567, Double.Parse(exp.ToString()));

            // Heading by "+"
            exp = Expression.Parse("+123.45");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 123.45", 
                                   123.45, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   123.45, Double.Parse(exp.ToString()));

            // Heading by "0"
            exp = Expression.Parse("0001.23");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1.23", 
                                   1.23, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   1.23, Double.Parse(exp.ToString()));

            // Heading by "+" and "0"
            exp = Expression.Parse("+001.234");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1.234", 
                                   1.234, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   1.234, Double.Parse(exp.ToString()));

            // Heading by "."
            exp = Expression.Parse(".23");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to .23", 
                                   .23, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   .23, Double.Parse(exp.ToString()));

            // Heading by "+" and "."
            exp = Expression.Parse("+.234");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to .234", 
                                   .234, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   .234, Double.Parse(exp.ToString()));
            
            // Tailing by "0"
            exp = Expression.Parse(".2345000");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to .2345", 
                                   .2345, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   .2345, Double.Parse(exp.ToString()));
            
            // Tailing by "."
            exp = Expression.Parse("23456.");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 23456", 
                                   23456, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   23456, Double.Parse(exp.ToString()));
        }

        /// <summary>
        /// Verifies that the parser can process negative real value constants.
        /// (Including Zero)
        /// </summary>
        [Test]
        public void TestNegativeDoubleConstant() {
            // Zero
            exp = Expression.Parse("-0.0");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   0, Double.Parse(exp.ToString()));

            exp = Expression.Parse("-0000.0");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   0, Double.Parse(exp.ToString()));

            exp = Expression.Parse("-.000");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   0, Double.Parse(exp.ToString()));

            // Small positive double
            exp = Expression.Parse("-1.2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -1.2", 
                                   -1.2, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -1.2, Double.Parse(exp.ToString()));

            // Large positive double
            exp = Expression.Parse("-1234.567");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -1234.567", 
                                   -1234.567, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -1234.567, Double.Parse(exp.ToString()));

            // Heading by "0"
            exp = Expression.Parse("-0001.23");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -1.23", 
                                   -1.23, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -1.23, Double.Parse(exp.ToString()));

            // Heading by "."
            exp = Expression.Parse("-.23");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -.23", 
                                   -.23, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -.23, Double.Parse(exp.ToString()));

            // Tailing by "0"
            exp = Expression.Parse("-.2345000");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -.2345", 
                                   -.2345, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -.2345, Double.Parse(exp.ToString()));
            
            // Tailing by "."
            exp = Expression.Parse("-23456.");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -23456", 
                                   -23456, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -23456, Double.Parse(exp.ToString()));
        }

        /// <summary>
        /// Verifies that the parser can process positive constants with real 
        /// values specified using the "scientific" notation.
        /// </summary>
        [Test]
        public void TestPositiveScientificConstant() {
            // Zero power
            exp = Expression.Parse("1.2E0");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1.2", 
                                   1.2, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   1.2, Double.Parse(exp.ToString()));

            exp = Expression.Parse("1.2E+0");
            Assertion.AssertEquals("Expression must evaluate to 1.2", 
                                   1.2, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   1.2, Double.Parse(exp.ToString()));

            exp = Expression.Parse("1.2E-0");
            Assertion.AssertEquals("Expression must evaluate to 1.2", 
                                   1.2, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   1.2, Double.Parse(exp.ToString()));

            // Positive power
            exp = Expression.Parse("3.4E12");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 3.4E12", 
                                   3.4E12, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   3.4E12, Double.Parse(exp.ToString()));

            // Heading with "+"
            exp = Expression.Parse("3.4E+12");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 3.4E12", 
                                   3.4E12, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   3.4E12, Double.Parse(exp.ToString()));

            // Heading with "0"
            exp = Expression.Parse("3.4E0012");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 3.4E12", 
                                   3.4E12, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   3.4E12, Double.Parse(exp.ToString()));
            
            // Heading with "0" and "+"
            exp = Expression.Parse("3.4E+0012");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 3.4E12", 
                                   3.4E12, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   3.4E12, Double.Parse(exp.ToString()));

            // Negative power
            exp = Expression.Parse("3.4E-12");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 3.4E-12", 
                                   3.4E-12, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   3.4E-12, Double.Parse(exp.ToString()));

            // Heading with "0"
            exp = Expression.Parse("3.4E-0012");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 3.4E-12", 
                                   3.4E-12, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   3.4E-12, Double.Parse(exp.ToString()));
        }

        /// <summary>
        /// Verifies that the parser can process negative constants with real 
        /// values specified using the "scientific" notation.
        /// </summary>
        [Test]
        public void TestNegativeScientificConstant() {
            // Zero power
            exp = Expression.Parse("-1.2E0");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -1.2", 
                                   -1.2, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -1.2, Double.Parse(exp.ToString()));

            exp = Expression.Parse("-1.2E+0");
            Assertion.AssertEquals("Expression must evaluate to -1.2", 
                                   -1.2, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -1.2, Double.Parse(exp.ToString()));

            exp = Expression.Parse("-1.2E-0");
            Assertion.AssertEquals("Expression must evaluate to -1.2", 
                                   -1.2, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -1.2, Double.Parse(exp.ToString()));

            // Positive power
            exp = Expression.Parse("-3.4E12");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -3.4E12", 
                                   -3.4E12, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -3.4E12, Double.Parse(exp.ToString()));

            // Heading with "+"
            exp = Expression.Parse("-3.4E+12");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -3.4E12", 
                                   -3.4E12, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -3.4E12, Double.Parse(exp.ToString()));

            // Heading with "0"
            exp = Expression.Parse("-3.4E0012");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -3.4E12", 
                                   -3.4E12, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -3.4E12, Double.Parse(exp.ToString()));
            
            // Heading with "0" and "+"
            exp = Expression.Parse("-3.4E+0012");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -3.4E12", 
                                   -3.4E12, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -3.4E12, Double.Parse(exp.ToString()));

            // Negative power
            exp = Expression.Parse("-3.4E-12");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -3.4E-12", 
                                   -3.4E-12, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -3.4E-12, Double.Parse(exp.ToString()));

            // Heading with "0"
            exp = Expression.Parse("-3.4E-0012");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -3.4E-12", 
                                   -3.4E-12, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   -3.4E-12, Double.Parse(exp.ToString()));
        }

        /// <summary>
        /// Verifies that the parser can process the built-in constant for 'PI'
        /// </summary>
        [Test]
        public void TestConstantPI() {
            Expression exp = Expression.Parse("Math.PI");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to PI", 
                                   System.Math.PI, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   System.Math.PI, Double.Parse(exp.ToString()));
        }

        /// <summary>
        /// Verifies that the parser can process the built-in constant for 'E'
        /// </summary>
        [Test]
        public void TestConstantE() {
            Expression exp = Expression.Parse("Math.E");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to E", 
                                   System.Math.E, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", 
                             exp is Literal);
            Assertion.AssertEquals("Test ToString() method",
                                   System.Math.E, Double.Parse(exp.ToString()));
        }
    }
}