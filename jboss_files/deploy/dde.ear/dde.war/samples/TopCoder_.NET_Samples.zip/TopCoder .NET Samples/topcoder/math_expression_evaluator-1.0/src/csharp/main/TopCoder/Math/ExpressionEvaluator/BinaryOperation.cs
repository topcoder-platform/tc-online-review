/* BinaryOperation.cs
 * Copyright @ 2003, TopCoder, Inc. All rights reserved
 * */
using System;

namespace TopCoder.Math.ExpressionEvaluator {
    /// <summary>
    /// Representation of a Binary Operation.
    /// Authors - kyky, mishagam
    /// Version - 1.0
    /// </summary>
    class BinaryOperation : Expression {
        /// <summary>
        /// Defines the signature of a binary operator.
        /// </summary>
        public delegate double Operator( double lhs, double rhs );
        /// <summary>
        /// Creates a binary operation on the two arguments
        /// (the left-hand side and the right-hand side) with the given operator.
        /// </summary>
        /// <param name="lhs">left-hand side operand</param>
        /// <param name="rhs">right-hand side operand</param>
        /// <param name="op">The operator for this operation</param>
        public BinaryOperation( Expression lhs, Expression rhs, Operator op) {
            this.lhs = lhs;
            this.rhs = rhs;
            this.op = op;
        }
        /// <summary>
        /// Evaluates both operands, performs the operation, and returns the result.
        /// </summary>
        /// <param name="env">Evaluation environment - passed to both sides of the operation.</param>
        /// <returns>Evaluation result.</returns>
        public override double Evaluate( IEvaluationEnv env ) {
            return op( lhs.Evaluate( env ), rhs.Evaluate( env ) );
        }
        /// <summary>
        /// Converts this expression to a string representation.
        /// </summary>
        /// <returns>String representation of this expression.</returns>
        public override string ToString() {
            if ( op == OPERATOR_ADD ) {
                return "(" + lhs.ToString() + "+" + rhs.ToString() + ")";
            } else if ( op == OPERATOR_SUBTRACT ) {
                return "(" + lhs.ToString() + "-" + rhs.ToString() + ")";
            }else if ( op == OPERATOR_MULTIPLY ) {
                return "(" + lhs.ToString() + "*" + rhs.ToString() + ")";
            }else if ( op == OPERATOR_DIVIDE ) {
                return "(" + lhs.ToString() + "/" + rhs.ToString() + ")";
            }else if ( op == OPERATOR_POWER ) {
                return "(" + lhs.ToString() + "^" + rhs.ToString() + ")";
            }else if ( op == OPERATOR_LT ) {
                return "(" + lhs.ToString() + "<" + rhs.ToString() + ")";
            }else if ( op == OPERATOR_GT ) {
                return "(" + lhs.ToString() + ">" + rhs.ToString() + ")";
            }else if ( op == OPERATOR_LE ) {
                return "(" + lhs.ToString() + "<=" + rhs.ToString() + ")";
            }else if ( op == OPERATOR_GE ) {
                return "(" + lhs.ToString() + ">=" + rhs.ToString() + ")";
            }else if ( op == OPERATOR_EQ ) {
                return "(" + lhs.ToString() + "==" + rhs.ToString() + ")";
            }else if ( op == OPERATOR_NE ) {
                return "(" + lhs.ToString() + "!=" + rhs.ToString() + ")";
            }else if ( op == OPERATOR_MIN ) {
                return "Min(" + lhs.ToString() + ", " + rhs.ToString() + ")";
            }else if ( op == OPERATOR_MAX ) {
                return "Max(" + lhs.ToString() + ", " + rhs.ToString() + ")";
            } else { // TODO: Add more checks here
                return "(" + lhs.ToString() + " <unknown_binary> " + rhs.ToString() + ")";
            }
        }
        /// <summary>
        /// Left-hand side operand of this operation.
        /// </summary>
        private Expression lhs;
        /// <summary>
        /// Right-hand side operand of this operation.
        /// </summary>
        private Expression rhs;
        /// <summary>
        /// Operator of this operation.
        /// </summary>
        private Operator op;
        /// <summary>
        /// The Addition Operator.
        /// </summary>
        public readonly static Operator OPERATOR_ADD      = new Operator(Add);
        /// <summary>
        /// The Subtraction Operator
        /// </summary>
        public readonly static Operator OPERATOR_SUBTRACT = new Operator(Subtract);
        /// <summary>
        /// The Multiplication Operator
        /// </summary>
        public readonly static Operator OPERATOR_MULTIPLY = new Operator(Multiply);
        /// <summary>
        /// The Division Operator
        /// </summary>
        public readonly static Operator OPERATOR_DIVIDE   = new Operator(Divide);
        /// <summary>
        /// The Power Operator
        /// </summary>
        public readonly static Operator OPERATOR_POWER    = new Operator(System.Math.Pow);
        /// <summary>
        /// The Equality Operator
        /// </summary>
        public readonly static Operator OPERATOR_EQ       = new Operator(IsEqual);
        /// <summary>
        /// The Inequality Operator
        /// </summary>
        public readonly static Operator OPERATOR_NE       = new Operator(IsNotEqual);
        /// <summary>
        /// The Greater Than Operator
        /// </summary>
        public readonly static Operator OPERATOR_GT       = new Operator(IsGreater);
        /// <summary>
        /// The Greater Than Or Equal Operator
        /// </summary>
        public readonly static Operator OPERATOR_GE       = new Operator(IsGreaterEqual);
        /// <summary>
        /// The Less Than Operator
        /// </summary>
        public readonly static Operator OPERATOR_LT       = new Operator(IsLess);
        /// <summary>
        /// The Less Than Or Equals Operator
        /// </summary>
        public readonly static Operator OPERATOR_LE       = new Operator(IsLessEqual);
        /// <summary>
        /// The Minimum Operator
        /// </summary>
        public readonly static Operator OPERATOR_MIN      = new Operator(System.Math.Min);
        /// <summary>
        /// The Maximum Operator
        /// </summary>
        public readonly static Operator OPERATOR_MAX      = new Operator(System.Math.Max);

        /// <summary>
        /// Following functions are used to create operators.
        /// They are more or less self evident.
        /// This is add function to create OPERATOR_ADD
        /// </summary>
        /// <param name="lhs">Expression to the left of operator</param>
        /// <param name="rhs">Expression to the right of operator</param>
        /// <returns>double sum of lhs and rhs</returns>
        private static double Add( double lhs, double rhs ) {
            return lhs + rhs;
        }

        /// <summary>
        /// This is Substract  function to create OPERATOR_SUBSTRACT
        /// </summary>
        /// <param name="lhs">Expression to the left of operator</param>
        /// <param name="rhs">Expression to the right of operator</param>
        /// <returns>double lhs - rhs</returns>
        private static double Subtract( double lhs, double rhs ) {
            return lhs - rhs;
        }
        /// <summary>
        /// This is Multiply  function to create OPERATOR_MULTIPLY
        /// </summary>
        /// <param name="lhs">Expression to the left of operator</param>
        /// <param name="rhs">Expression to the right of operator</param>
        /// <returns>double lhs * rhs</returns>
        private static double Multiply( double lhs, double rhs ) {
            return lhs * rhs;
        }
        /// <summary>
        /// This is Divide  function to create OPERATOR_DIVIDE
        /// </summary>
        /// <param name="lhs">Expression to the left of operator</param>
        /// <param name="rhs">Expression to the right of operator</param>
        /// <returns>double lhs / rhs</returns>
        private static double Divide( double lhs, double rhs ) {
            return lhs / rhs;
        }
        /// <summary>
        /// This is IsEqual  function to create OPERATOR_EQ
        /// </summary>
        /// <param name="lhs">Expression to the left of operator</param>
        /// <param name="rhs">Expression to the right of operator</param>
        /// <returns>double 1 if lhs == rhs, 0 otherwise </returns>
        private static double IsEqual( double lhs, double rhs ) {
            return lhs==rhs ? 1 : 0;
        }
        /// <summary>
        /// This is IsNotEqual  function to create OPERATOR_NE
        /// </summary>
        /// <param name="lhs">Expression to the left of operator</param>
        /// <param name="rhs">Expression to the right of operator</param>
        /// <returns>double 1 if lhs != rhs, 0 otherwise </returns>
        private static double IsNotEqual( double lhs, double rhs ) {
            return lhs!=rhs ? 1 : 0;
        }
        /// <summary>
        /// This is IsGreater  function to create OPERATOR_GT
        /// </summary>
        /// <param name="lhs">Expression to the left of operator</param>
        /// <param name="rhs">Expression to the right of operator</param>
        /// <returns>double 1 if lhs larger rhs, 0 otherwise </returns>
        private static double IsGreater( double lhs, double rhs ) {
            return lhs>rhs ? 1 : 0;
        }
        /// <summary>
        /// This is IsGreaterEqual  function to create OPERATOR_GE
        /// </summary>
        /// <param name="lhs">Expression to the left of operator</param>
        /// <param name="rhs">Expression to the right of operator</param>
        /// <returns>double 1 if lhs larger or equal rhs, 0 otherwise </returns>
        private static double IsGreaterEqual( double lhs, double rhs ) {
            return lhs>=rhs ? 1 : 0;
        }
        /// <summary>
        /// This is IsLess  function to create OPERATOR_LT
        /// </summary>
        /// <param name="lhs">Expression to the left of operator</param>
        /// <param name="rhs">Expression to the right of operator</param>
        /// <returns>double 1 if lhs is less than rhs, 0 otherwise </returns>
        private static double IsLess( double lhs, double rhs ) {
            return lhs<rhs ? 1 : 0;
        }

        /// <summary>
        /// This is IsLessEqual  function to create OPERATOR_LE
        /// </summary>
        /// <param name="lhs">Expression to the left of operator</param>
        /// <param name="rhs">Expression to the right of operator</param>
        /// <returns>double 1 if lhs less or equal rhs, 0 otherwise </returns>
        private static double IsLessEqual( double lhs, double rhs ) {
            return lhs<=rhs ? 1 : 0;
        }
    }
}
