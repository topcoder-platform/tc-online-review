// @author Mikhail_T
// @copyright (c) TopCoder Software 2003


using System;
using System.Configuration;
using System.Reflection;
using System.Collections.Specialized;

namespace TopCoder.LoggingWrapper
{

    /// <summary>
    /// .NET LoggingWrapper Component
    /// author: aksonov
    /// copyright: Copyright (c) 2003, TopCoder, Inc. All rights reserved
    /// 
    /// static class <c>LogManager</c> contains methods <c>Log</c> and <c>IsLevelEnabled</c> 
    /// to provide access to the pluggable logging solution and method <c>GetLogger</c> to 
    /// retrive the logging solution currently in use
    /// </summary>
    /// 
    public class LogManager 
    {
        /// <summary>
        /// String constant used while configuration reading
        /// </summary>
        public static readonly string CLASS_PARAMETER = "PluginClassName";
        /// <summary>
        /// full class name of current logging solution
        /// </summary>
        private static string name = null;
        /// <summary>
        /// current logging implementation
        /// </summary>
        private static Logger log = null;
        /// <summary>
        /// Tells if Logging is in progress.
        /// </summary>
        private static bool isLogging=false;
        /// <summary>
        /// Tells if Loading Configuration is in progress.
        /// </summary>        
        private static bool isLoadingConfiguration=false;

        private static NameValueCollection nameValue=null;
        /// <summary>
        /// configuration
        /// </summary>
        public static System.Collections.Specialized.NameValueCollection Configuration 
        {
            get 
            {
                return nameValue;
            }
            set 
            {
                nameValue=value;
            }
        }

        /// <summary>
        /// Static constructor for configuration loading before application starts
        /// </summary>
        static LogManager()
        {
            LoadConfiguration();
        }
        /// <summary>
        /// Loads/reloads configuration file and loads pluggable logging solution
        /// </summary>
        public static void LoadConfiguration() 
        {
            if(!isLogging){                
                lock(typeof(LogManager))
                {        
                    isLoadingConfiguration=true;
                    if(Configuration!=null)
                        if(Configuration.HasKeys())
                        {
                            name = Configuration[CLASS_PARAMETER];
                            if (name==null) throw new ConfigException("No name is given for the implementation.");            
                            LoadPlugin(name);
                        }
                    isLoadingConfiguration=false;
                }                
            }
        }

		/// <summary>
		/// Loads pluggable logging solution with defined classname
		/// </summary>
		/// <param name="classname">Name of implementation to load.</param>
        public static void LoadPlugin(string classname)
        {
            if(classname==null) throw new ArgumentNullException(classname);            
            try 
            {
                name = classname;
                Type type=Type.GetType(name);
				if(type == null)
					throw new TopCoder.LoggingWrapper.ConfigException(classname+" do not present.");
				ConstructorInfo csi;				
				csi=type.GetConstructor(BindingFlags.Instance|BindingFlags.NonPublic,null,Type.EmptyTypes,null);                
				if(csi==null)
					throw new TopCoder.LoggingWrapper.InvalidPluginException();                                				
                log = (Logger)csi.Invoke(null);                            
                log.LoadConfiguration(Configuration);
            }             
            catch (TopCoder.LoggingWrapper.InvalidPluginException)
            {
                throw new TopCoder.LoggingWrapper.InvalidPluginException();
            }
            catch (Exception e)
            {
                throw new TopCoder.LoggingWrapper.ConfigException(e.Message);
            }
            if (log==null) throw new TopCoder.LoggingWrapper.ConfigException("Incorrect name of logging implementation");
        }

        /// <summary>
        /// Retrieves the logging solution currently in use
        /// </summary>
        /// <returns>solution currently in use</returns>
        public static Logger GetLogger()
        {
            return log;
        }

        /// <summary>
        /// Retrieves the full class name of logging solution currently in use
        /// </summary>
        /// <returns>full class name of logging solution currently in use</returns>
        public static string GetLoggerClassName()
        {
            return name;
        }

        /// <summary>
        /// Loads and retrieve the logging solution with class name <c>classname</c>
        /// </summary>
        /// <param name="classname">Full name of class of pluggable logging solution</param>
        /// <returns>logging solution</returns>
        public static Logger GetLogger(string classname)
        {
            if(classname==null) throw new ArgumentNullException("classname");            
            LoadPlugin(classname);
            return log;
        }

        /// <summary>
        /// Provides access to current pluggable logging solution
        /// </summary>
        /// <param name="level">logging level</param>
        /// <param name="message">logging message (can be contains {0},{1} for parameter inserting)</param>
        /// <param name="param">parameters for logging message (if needed)</param>
        public static void Log(Level level, string message, params object[] param)
        {
            if(message==null) throw new ArgumentNullException("message");
            if(param==null) throw new ArgumentNullException("param");            
            if (log==null) throw new TopCoder.LoggingWrapper.ConfigException("Incorrect name of logging implementation");
            try 
            {
                if(!isLoadingConfiguration)
                {
                    lock(typeof(LogManager))
                    {
                        isLogging=true;                        
                        log.Log(level,message,param);        
                        isLogging=false;
                    }
                }
            
            } 
            catch (Exception e) 
            {
                throw new PluginException(String.Format("Error in class {0} : {1}",name,e.Message));
            }
        }

        /// <summary>
        /// Provides access to current pluggable logging solution with its default logging level
        /// </summary>
        /// <param name="message">logging message (can be contains {0},{1} for parameter inserting)</param>
        /// <param name="param">parameters for logging message (if needed)</param>
        public static void Log(string message, params object[] param)
        {            
            if(message==null) throw new ArgumentNullException("message");
            if(param==null) throw new ArgumentNullException("param");
            if (log==null) throw new TopCoder.LoggingWrapper.ConfigException("Incorrect name of logging implementation");
            try 
            {
                if(!isLoadingConfiguration)
                {    
                    lock(typeof(LogManager))
                    {    
                        isLogging=true;
                        log.Log(message,param);
                        isLogging=false;
                    }
                }
            } 
            catch (Exception e) 
            {
                throw new PluginException(String.Format("Error in logging implementation class {0} : {1}",name,e.Message));
            }
        }
        /// <summary>
        /// Is used to determine if a specific logging level is enabled for current logging solution
        /// </summary>
        /// <param name="level">logging level</param>
        /// <returns>is enabled or not enabled</returns>
        public static bool IsLevelEnabled(Level level)
        {            
            if (log==null) throw new TopCoder.LoggingWrapper.ConfigException("Incorrect name of logging implementation");
            try 
            {
                return log.IsLevelEnabled(level);
            }
            catch (Exception e)
            {
                throw new PluginException(e.Message);
            }
        }
    }
}
