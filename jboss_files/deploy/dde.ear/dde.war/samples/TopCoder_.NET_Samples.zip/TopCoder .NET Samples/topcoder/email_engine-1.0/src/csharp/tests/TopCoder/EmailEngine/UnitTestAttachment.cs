using System;
using NUnit.Framework;
using System.IO;
using System.Diagnostics;

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// Unit Test the Attachment class.
    /// </summary>
    [TestFixture]
    public class UnitTestAttachment
    {
        /// <summary>
        /// creates an object from a file and exercises functionality
        /// </summary>
        [Test]
        public void FileNameConstructor()
        {
            Attachment aa;
            String result;
            
            aa = new Attachment(@"..\..\test_files\test.pdf");
            result = aa.ToString();
            Debug.Assert (result.Length > 0);
            aa = null;
        }

        /// <summary>
        /// creates an object from a filestream
        /// </summary>
        [Test]
        public void FileStreamConstructor()
        {
            FileStream fs = new FileStream(@"..\..\test_files\test1.gif", FileMode.Open);
            Attachment aa;
            String result;

            aa = new Attachment(fs);
            fs.Close();
            result = aa.ToString();
            Debug.Assert (result.Length > 0);
            aa = null;
        }

        /// <summary>
        /// creates an object from a null filestream
        /// </summary>
        [Test]
        [ExpectedException(typeof(AttachmentErrorException))]
        public void FileStreamConstructorWithNull()
        {
            FileStream fs = null;
            Attachment aa;
            String result;

            aa = new Attachment(fs);
            result = aa.ToString();
            aa = null;
        }

        /// <summary>
        /// creates an object from a non-existent file
        /// </summary>
        [Test]
        [ExpectedException(typeof(AttachmentErrorException))]
        public void FileStreamConstructorWithBadFile()
        {
            Attachment aa;
            String result;

            aa = new Attachment(@"c:\bogus\doesnotexist.doc");
            result = aa.ToString();
            aa = null;
        }
    }
}
