using System;
using NUnit.Framework;
using System.IO;

namespace TopCoder.EmailEngine.AccuracyTests
{
    /// <summary>
    /// Accuracy Tests
    /// @author aksonov
    /// </summary>
    [TestFixture]
    public class AccuracyTestEmail
    {
        /// <summary>
        /// test parsing a email
        /// </summary>
        [Test]
        public void EmailParse()
        {
            EmailAddress email = new EmailAddress();
            email.Parse("a@a.a");

            Assertion.AssertEquals ( "a@a.a", email.Email);
        }

        /// <summary>
        /// test parsing a email
        /// </summary>
        [Test]
        public void EmailParse2()
        {
            EmailAddress email = new EmailAddress();
            email.Parse("\"Pavel Aksonov\" <a@a.a>");

            Assertion.AssertEquals ( "a@a.a", email.Email);
            Assertion.AssertEquals ( "Pavel Aksonov", email.Name);
        }

        /// <summary>
        /// test parsing a email
        /// </summary>
        [Test]
        public void EmailParse3()
        {
            EmailAddress email = new EmailAddress();
            email.Parse("\"Pavel, Aksonov\" <a@a.a>");

            Assertion.AssertEquals ( "a@a.a", email.Email);
            Assertion.AssertEquals ( "Pavel, Aksonov", email.Name);
        }

    }
}
