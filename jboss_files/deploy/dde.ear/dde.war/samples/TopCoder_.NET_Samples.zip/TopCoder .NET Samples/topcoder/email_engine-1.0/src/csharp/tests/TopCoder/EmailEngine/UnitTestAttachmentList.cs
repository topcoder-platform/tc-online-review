using System;
using NUnit.Framework;
using System.IO;
using System.Diagnostics;

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// Unit Test the Attachment class.
    /// </summary>
    [TestFixture]
    public class UnitTestAttachmentList
    {
        /// <summary>
        /// creates an object and exercises add remove  functionality
        /// </summary>
        [Test]
        public void AttachmentListAddRemove()
        {
            AttachmentList al = new AttachmentList();
            Attachment a;

            FileStream fs = new FileStream(@"..\..\test_files\test1.gif", FileMode.Open);

            Assertion.Assert (al.Count == 0);
            al.Add(new Attachment(fs));
            fs.Close();
            Assertion.Assert (al.Count == 1);
            al.Add(new Attachment(@"..\..\test_files\test2.gif"));
            Assertion.Assert (al.Count == 2);

            for(int loop = 0; loop < al.Count; loop++)
            {
                a = al[loop];
            }

            Assertion.Assert (al.Count == 2);
            al.Remove(0);
            Assertion.Assert (al.Count == 1);
            al.Remove(0);
            Assertion.Assert (al.Count == 0);
            
        }

        /// <summary>
        /// creates an object and exercises add clear functionality
        /// </summary>
        [Test]
        public void AttachmentListAddClear()
        {
            AttachmentList al = new AttachmentList();

            FileStream fs = new FileStream(@"..\..\test_files\test1.gif", FileMode.Open);

            Assertion.Assert (al.Count == 0);
            al.Add(new Attachment(fs));
            fs.Close();
            Assertion.Assert (al.Count == 1);
            al.Add(new Attachment(@"..\..\test_files\test2.gif"));
            Assertion.Assert (al.Count == 2);

            al.Clear();
            Assertion.Assert (al.Count == 0);
            
        }
 
        /// <summary>
        /// creates an object and exercises ToString functionality
        /// </summary>
        [Test]
        public void AttachmentListAddToString()
        {
            AttachmentList al = new AttachmentList();
            String result;

            FileStream fs = new FileStream(@"..\..\test_files\test1.gif", FileMode.Open);

            Assertion.Assert (al.Count == 0);
            al.Add(new Attachment(fs));
            fs.Close();
            Assertion.Assert (al.Count == 1);
            al.Add(new Attachment(@"..\..\test_files\test2.gif"));
            Assertion.Assert (al.Count == 2);

            result = al.ToString();
            al.Clear();
            Assertion.Assert (result.Length > 0);
            
        }
 
        /// <summary>
        /// creates an object and exercises index error
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void AttachmentListIndexError()
        {
            AttachmentList al = new AttachmentList();
            Attachment a;

            FileStream fs = new FileStream(@"..\..\test_files\test1.gif", FileMode.Open);

            Assertion.Assert (al.Count == 0);
            al.Add(new Attachment(fs));
            fs.Close();
            Assertion.Assert (al.Count == 1);

            a = al[345];
            al.Clear();
            
        }

        /// <summary>
        /// creates an object and exercises remove index error
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void AttachmentListRemoveIndexError()
        {
            AttachmentList al = new AttachmentList();

            FileStream fs = new FileStream(@"..\..\test_files\test2.gif", FileMode.Open);

            Assertion.Assert (al.Count == 0);
            al.Add(new Attachment(fs));
            fs.Close();
            Assertion.Assert (al.Count == 1);

            al.Remove(345);
            al.Clear();
            
        }

        /// <summary>
        /// creates an object that is null and exercises error
        /// </summary>
        [Test]
        [ExpectedException(typeof(AttachmentErrorException))]
        public void AttachmentListAddNullError()
        {
            AttachmentList al = new AttachmentList();
            al.Add(null);
            
        }
    }
}