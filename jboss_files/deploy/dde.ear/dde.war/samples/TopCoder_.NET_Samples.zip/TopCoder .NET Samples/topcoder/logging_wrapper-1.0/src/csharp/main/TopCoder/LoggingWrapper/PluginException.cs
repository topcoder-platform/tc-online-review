// @author Mikhail_T
// @copyright (c) TopCoder Software 2003

using System;

namespace TopCoder.LoggingWrapper
{
    /// <summary>
    /// Exception class for all pluggable implementation exceptions
    /// </summary>
    public class PluginException : System.Exception
    {
        /// <summary>
        /// Initializes a new instance of the PluginException class
        /// </summary>
        public PluginException() : base()
        {
        }

        /// <summary>
        /// Initializes a new instance of the PluginException class with defined message
        /// </summary>
        public PluginException(string message ) : base(message)
        {
        }
    }
}
