// @author mathgodleo
// @copyright (c) TopCoder Software

using System;
using System.Diagnostics;
using NUnit.Framework;

namespace TopCoder.LoggingWrapper.FailureTests
{
	/// <summary>
	/// Test cases for LogManager.
	/// </summary>
	[TestFixture]
	//[Ignore("")]
	public class LogManagerFailureTests
	{
		/// <summary>
		/// Set ups configuration of the LogManager
		/// </summary>
		[SetUp]
		public void StartUp()
		{
		}

		/// <summary>
		/// Tests that an exception is thrown when the class of the Logging 
		/// implementation is unspecified.
		/// </summary>
		[Test]
		[ExpectedException(typeof(ConfigException))]
		public void testNoClassSpecified()
		{
			LogManager.Configuration = new System.Collections.Specialized.NameValueCollection();        
			LogManager.Configuration.Add("Source", "LoggerFailureTests");
			LogManager.Configuration.Add("LogName", "LoggerFailureTests");
			LogManager.LoadConfiguration();
		}

		/// <summary>
		/// Tests the LogManager with a bad configuration.
		/// </summary>
		[Test]
		[ExpectedException(typeof(ConfigException))]
		public void testBadConfig()
		{
			LogManager.Configuration = new System.Collections.Specialized.NameValueCollection();        
			LogManager.Configuration.Add(LogManager.CLASS_PARAMETER, "NOT A CLASS");
			LogManager.Configuration.Add("Source", "LoggerFailureTests");
			LogManager.Configuration.Add("LogName", "LoggerFailureTests");
			LogManager.LoadConfiguration();
		}

		/// <summary>
		/// Tests the LogManager with a bad plugin.
		/// </summary>
		[Test]
		[ExpectedException(typeof(ConfigException))]
		public void testBadConfig2()
		{
			LogManager.LoadPlugin("not a plugin");
		}

		/// <summary>
		/// Tests the LogManager with a bad plugin.
		/// </summary>
		[Test]
		[ExpectedException(typeof(TopCoder.LoggingWrapper.InvalidPluginException))]
		public void testBadConfig3()
		{
			LogManager.LoadPlugin("System.String");
		}

		/// <summary>
		/// Tests the LogManager with a bad plugin.
		/// </summary>
		[Test]
		[ExpectedException(typeof(ArgumentNullException))]
		public void testBadConfig4()
		{
			LogManager.LoadPlugin(null);
		}
	}
}
