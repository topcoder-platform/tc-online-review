/*
    Copyright c 2003, TopCoder, Inc. All rights reserved
    Author TCSDEVELOPER
*/

using System;
using System.Collections;

using TopCoder.Math.ExpressionEvaluator;

using NUnit.Framework;

namespace TopCoder.Math.ExpressionEvaluator.AccuracyTests {

    /// <summary>
    /// Test cases for the complex expressions.
    /// </summary>
    [TestFixture]
    public class ExpressionAccuracyTests {
        /// <summary>
        /// Expression instance for tests.
        /// </summary>
        Expression exp;

        /// <summary>
        /// Verifies the priorities of arithmetic operations
        /// </summary>
        [Test]
        public void TestArithmeticPriority() {
            exp = Expression.Parse("2*(4+5)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 18", 
                                   18, exp.Evaluate());

            exp = Expression.Parse("2+3.4/5.6");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 2+3.4/5.6", 
                                   2+3.4/5.6, exp.Evaluate());

            exp = Expression.Parse("-3-5");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -3-5", 
                                   -3-5, exp.Evaluate());

            exp = Expression.Parse("-3*-5");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -3*-5", 
                                   -3*-5, exp.Evaluate());

            exp = Expression.Parse("-3-5.0^-1*9");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -3-5^-1*9", 
                                   -3-1/5.0*9, exp.Evaluate());

            exp = Expression.Parse("-3-5.0^-(1*2)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -3-5^-(1*2)", 
                                   -3-1/25.0, exp.Evaluate());

            exp = Expression.Parse("SIN(1.23*2.15)+COS(7.89)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression == SIN(1.23*2.15)+COS(7.89)", 
                                   System.Math.Sin(1.23*2.15) 
                                       + System.Math.Cos(7.89), 
                                   exp.Evaluate());
        }

        /// <summary>
        /// Verifies the priorities of logic operations
        /// </summary>
        [Test]
        public void TestLogicPriority() {
            exp = Expression.Parse("1==1&&2!=2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());

            exp = Expression.Parse("3<2||2>=1&&!(2!=2)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 
                                   1, exp.Evaluate());

            exp = Expression.Parse("3<2||2>=1&&!(2!=2)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 
                                   1, exp.Evaluate());
        }

    }
}