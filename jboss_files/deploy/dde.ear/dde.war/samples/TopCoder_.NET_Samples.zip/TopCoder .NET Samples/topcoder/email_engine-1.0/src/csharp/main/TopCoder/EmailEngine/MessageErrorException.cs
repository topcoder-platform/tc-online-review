using System;

// @author CLoris
// @copyright 2003 (c) TopCoder Software

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// This exception is for any error during messages creating/manipulation
    /// </summary>
    public class MessageErrorException : Exception
    {
        /// <summary>
        /// Exception constructor
        /// </summary>
        public MessageErrorException() : base() {}

        /// <summary>
        /// Exception constructor with message
        /// </summary>
        /// <param name="message"></param>
        public MessageErrorException(string message) : base(message) {}
    }
}
