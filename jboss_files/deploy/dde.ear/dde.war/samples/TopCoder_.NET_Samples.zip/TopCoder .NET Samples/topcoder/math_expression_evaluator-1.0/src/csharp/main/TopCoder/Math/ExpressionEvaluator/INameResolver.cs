/* INameResolver.cs; 
 * @author kyky
 * Copyright @ 2003, TopCoder, Inc. All rights reserved
 * */
using System;

namespace TopCoder.Math.ExpressionEvaluator {
    /// <summary>
    /// Interface for parse-time resolution of variable names
    /// to the representations of custom variables.
    /// </summary>
    public interface INameResolver {
        /// <summary>
        /// Resolves a variable name to the representations as Expression.
        /// </summary>
        /// <param name="name">Name of the variable to resolve.</param>
        /// <returns>An instance of Expression representing variable identified by name.</returns>
        Expression Resolve( string name );
    }
}
