using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.Net.Sockets;

// @author CLoris
// @copyright 2003 (c) TopCoder Software

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// Simple Mail Transfer Protocol Client
    /// This class implements a client interface to the SMTP protocol.
    /// Throws SendException if any errors happens
    /// </summary>
    public class SmtpProtocol : IEmailSender
    {
        // constants
        private const int DEFAULT_SMTP_PORT = 25; // port 25 is the default smtp port
        private const string SMTP_CMD_HELO = "HELO {0}\r\n";
        private const string SMTP_CMD_FROM = "MAIL FROM: {0}\r\n";
        private const string SMTP_CMD_RCPT_TO = "RCPT TO: {0}\r\n";
        private const string SMTP_CMD_BEGIN_DATA = "DATA\r\n";
        private const string SMTP_CMD_END_DATA = "\r\n.\r\n";
        private const string SMTP_CMD_QUIT = "QUIT\r\n";

        private const int SMTP_RESULT_SERVICE_READY = 220;
        private const int SMTP_RESULT_SERVICE_CLOSING_CHANNEL = 221;
        private const int SMTP_RESULT_REQUESTED_MAIL_ACTION_OK = 250;
        private const int SMTP_RESULT_USER_NOT_LOCAL_WILL_FORWARD = 251;
        private const int SMTP_RESULT_START_MAIL_INPUT = 354;

        private const string REGEX_SERVER_PORT = "(?<server>.+)\\:(?<port>[0-9]+)$";

        private const string ERR_NO_SMTP_SERVER = "No SMPT server specified prior to SendEmail request";
        private const string ERR_BAD_RESPONSE = "Bad response from server: {0}"; 
        // end constants

        private string server;
        private int port = DEFAULT_SMTP_PORT; 

        /// <summary>
        /// The DNS name of the SMTP server.  Can be in format smtp.dom.com or smtp.dom.com:port.
        /// </summary>
        public string Server
        {
            get 
            {
                return server;
            }
            set 
            {
                Match match;
                Regex portregex = new Regex(REGEX_SERVER_PORT);
    
                // see if we have aport specified
                match = portregex.Match(value);
                if(match.Success)
                {
                    // use the specified server and port
                    this.server = match.Groups["server"].Value;
                    this.port = int.Parse(match.Groups["port"].Value);
                }
                else
                {
                    // use the specified server and the default port
                    this.server = value;
                    this.port = DEFAULT_SMTP_PORT;
                }
            }
        }

        /// <summary>
        /// The Port of the SMTP server.  Can be in format smtp.dom.com or smtp.dom.com:port.
        /// </summary>
        public int Port
        {
            get 
            {
                return port;
            }
        }
        
        /// <summary>
        /// Emtpy SmtpProtocol contructor
        /// </summary>
        public SmtpProtocol()
        {
        }

        /// <summary>
        /// Constructs SmtpProtocol object from given server address.
        /// </summary>
        /// <param name="server">Server URL</param>
        public SmtpProtocol(string server)
        {
            // set the server variable using property so we can check for a port
            this.Server = server; 
        }

        /// <summary>
        /// Sends well-formed email formated by Message class
        /// throws MessageErrorException if text is not well-formed email
        /// </summary>
        /// <param name="message">
        /// Should contain a populated Message object that is to be transmitted.
        /// </param>
        /// <exception cref="SendException">Thrown if No SMPT server specified prior to SendEmail request.</exception>
        /// <exception cref="SendException">Thrown if an error is received form the SMTP Server during send.</exception>
        public void SendEmail(Message message)
        {
            TcpClient tcpSock = new TcpClient();
            NetworkStream stream;
            StreamReader streamReader;
            SendException sendException = null;
            
            // ensure smtp server has been set
            if(server == null)
            {
                throw new SendException(ERR_NO_SMTP_SERVER);
            }

            // Verify that the server exists and we can connect
            try
            {
                // try to resolve the dns name
                Dns.GetHostByName(server);

                // open the socket to the SMTP server.
                tcpSock.Connect(server, port);
            }
            catch (Exception e)
            {
                throw new SendException(e.ToString());
            }

            
            // once the connection is open we will send the message
            // if an error occurs raise it up but always close the connection
            try
            {
                // attach some streams
                stream = tcpSock.GetStream();
                streamReader = new StreamReader(tcpSock.GetStream());

                // verify we have a hello
                CheckResponse(streamReader, new int[1] {SMTP_RESULT_SERVICE_READY});

                // say hello ourselves
                IPHostEntry myHost = Dns.GetHostByName(Dns.GetHostName());
                Write(stream, String.Format( SMTP_CMD_HELO, myHost.AddressList[0].ToString() ));
                //Write(stream, "HELO " + myHost.AddressList[0].ToString() + "\r\n");
                CheckResponse(streamReader, new int[1] {SMTP_RESULT_REQUESTED_MAIL_ACTION_OK});

                // send MAIL FROM
                Write(stream, String.Format( SMTP_CMD_FROM, message.From.Email ));
                CheckResponse(streamReader, new int[2] {SMTP_RESULT_REQUESTED_MAIL_ACTION_OK, 
                                                        SMTP_RESULT_USER_NOT_LOCAL_WILL_FORWARD});

                // send RCPT commands
                for(int loop = 0; loop < message.To.Count; loop++)
                {
                    Write(stream, String.Format( SMTP_CMD_RCPT_TO, message.To[loop].Email ));
                    CheckResponse(streamReader, new int[2] {SMTP_RESULT_REQUESTED_MAIL_ACTION_OK, 
                                                            SMTP_RESULT_USER_NOT_LOCAL_WILL_FORWARD});
                }
                for(int loop = 0; loop < message.CC.Count; loop++)
                {
                    Write(stream, String.Format( SMTP_CMD_RCPT_TO, message.CC[loop].Email ));
                    CheckResponse(streamReader, new int[2] {SMTP_RESULT_REQUESTED_MAIL_ACTION_OK, 
                                                            SMTP_RESULT_USER_NOT_LOCAL_WILL_FORWARD});
                }
                for(int loop = 0; loop < message.BCC.Count; loop++)
                {
                    Write(stream, String.Format( SMTP_CMD_RCPT_TO, message.BCC[loop].Email ));
                    CheckResponse(streamReader, new int[2] {SMTP_RESULT_REQUESTED_MAIL_ACTION_OK, 
                                                            SMTP_RESULT_USER_NOT_LOCAL_WILL_FORWARD});
                }

                // send DATA
                Write(stream, SMTP_CMD_BEGIN_DATA);
                CheckResponse(streamReader, new int[1] {SMTP_RESULT_START_MAIL_INPUT});
                
                // send message
                Write(stream, message.ToString());
                Write(stream, SMTP_CMD_END_DATA);
                CheckResponse(streamReader, new int[1] {SMTP_RESULT_REQUESTED_MAIL_ACTION_OK});

                // send QUIT
                Write(stream, SMTP_CMD_QUIT);
                CheckResponse(streamReader, new int[1] {SMTP_RESULT_SERVICE_CLOSING_CHANNEL});

            }
            catch (Exception ee)
            {
                // keep a handle to this exception so we can throw it in finally
                sendException = new SendException(ee.ToString());
            }
            finally
            {
                // make sure we close the socket while ignoring any errors
                try
                {
                    tcpSock.Close();
                }
                finally {}

                // throw any previous error
                if(sendException != null)
                {
                    throw sendException;
                }
            }

        }

        /// <summary>
        /// Checks the response from the tcpclient socket after a request has
        /// been passed.  
        /// </summary>
        /// <param name="streamReader">
        /// A StreamReader from the socket we are checking on the response from.
        /// </param>
        /// <param name="successCodes">
        /// int array of success codes for the response.
        /// </param>
        /// <exception cref="SendException">Thrown if SMPT server response does not have the provded success code.</exception>
        private void CheckResponse(StreamReader streamReader, int[] successCodes)
        {
            String result;
            bool found = false;

            result = streamReader.ReadLine();

            // check the string for the success code
            for(int loop = 0; loop < successCodes.Length; loop++)
            {
                // there is a bug in IndexOf - it will not find a number string
                // at the beginning of string.  Add a blank space to get around it
                if((" " + result.ToString()).IndexOf(successCodes[loop].ToString()) > 0)
                {
                    found = true;
                    break;
                }
            }

            // if we didn't find a success code - throw an error
            if(found == false)
            {
                throw new SendException(String.Format(ERR_BAD_RESPONSE, result));
            }
        }

        /// <summary>
        /// Sends the provided message out of the the socket for the provided stream.  
        /// </summary>
        /// <param name="stream">
        /// A Stream from the socket we are writing to.
        /// </param>
        /// <param name="message">
        /// message to be written to the stream.
        /// </param>
        private void Write(Stream stream, string message)
        {
            byte[] dataMessage;
            
            // convert to byte array to send
            dataMessage = System.Text.Encoding.ASCII.GetBytes(message.ToCharArray());
            stream.Write(dataMessage,0,dataMessage.Length);
        }
    }
}
