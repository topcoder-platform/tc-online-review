/* SimpleVariable.cs; 
 * @author kyky
 * Copyright @ 2003, TopCoder, Inc. All rights reserved
 * */
using System;

namespace TopCoder.Math.ExpressionEvaluator {
    /// <summary>
    /// Private class for dealing with built-in version of variables.
    /// </summary>
    class  SimpleVariable : Expression {
        /// <summary>
        /// Constructs a variable with a given name.
        /// </summary>
        /// <param name="name">Name of the variable.</param>
        public SimpleVariable( string name) {
            this.name = name;
        }
        /// <summary>
        /// Uses the evaluation environment to resolve the value of this variable.
        /// </summary>
        /// <param name="env">The value of the variable, as specified in the environment.</param>
        /// <returns></returns>
        public override double Evaluate( IEvaluationEnv env ) {
            try {
                return ((SimpleEvaluationEnv)env).GetValueForName( name );
            } catch (InvalidCastException) {
                throw new ArgumentException( "Unexpected environment in SimpleVariable.Evaluate");
            }
        }
        /// <summary>
        /// Converts this variable to a string representation.
        /// </summary>
        /// <returns>Variable name.</returns>
        public override string ToString() {
            return name;
        }
        /// <summary>
        /// Variable name.
        /// </summary>
        private string name;
    }
}
