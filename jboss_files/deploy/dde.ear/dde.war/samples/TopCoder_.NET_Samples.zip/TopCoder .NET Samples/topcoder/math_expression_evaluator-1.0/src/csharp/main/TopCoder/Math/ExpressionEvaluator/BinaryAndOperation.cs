/* AssemplyInfo.cs
 * Copyright @ 2003, TopCoder, Inc. All rights reserved
 * 
 * authors - kyky, mishagam
 * */
using System;

namespace TopCoder.Math.ExpressionEvaluator {
    /// <summary>
    /// Representation of a Binary Operation "AND".
    /// </summary>
    class BinaryAndOperation : Expression {
        /// <summary>
        /// Creates a binary AND operation on the two arguments
        /// (the left-hand side and the right-hand side).
        /// </summary>
        /// <param name="lhs">left-hand side operand</param>
        /// <param name="rhs">right-hand side operand</param>
        public BinaryAndOperation( Expression lhs, Expression rhs ) {
            this.lhs = lhs;
            this.rhs = rhs;
        }
        /// <summary>
        /// Evaluates the AND operation using short-circuit evaluation.
        /// </summary>
        /// <param name="env">Evaluation environment - passed to both sides of the operation.</param>
        /// <returns>Evaluation result.</returns>
        public override double Evaluate( IEvaluationEnv env ) {
            return ((lhs.Evaluate( env ) != 0) && (rhs.Evaluate( env ) != 0)) ? 1 : 0;
        }
        /// <summary>
        /// Converts this expression to a string representation.
        /// </summary>
        /// <returns>String representation of this expression.</returns>
        public override string ToString() {
            return "(" + lhs.ToString() + " && " + rhs.ToString() + ")";
        }
        /// <summary>
        /// Left-hand side operand of this operation.
        /// </summary>
        private Expression lhs;
        /// <summary>
        /// Right-hand side operand of this operation.
        /// </summary>
        private Expression rhs;
    }
}
