/*
    Copyright c 2003, TopCoder, Inc. All rights reserved
    Author TCSDEVELOPER
*/

using System;
using System.Collections;

using TopCoder.Math.ExpressionEvaluator;

using NUnit.Framework;

namespace TopCoder.Math.ExpressionEvaluator.AccuracyTests {

    /// <summary>
    /// Test cases for the binary operations.
    /// </summary>
    [TestFixture]
    public class BinaryOpAccuracyTests {
        /// <summary>
        /// Expression instance for tests.
        /// </summary>
        Expression exp;

        /// <summary>
        /// Verifies that the system deals with addition
        /// </summary>
        [Test]
        public void TestADD() {
            Hashtable ht = new Hashtable();
            exp = Expression.Parse("12+_XxX");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 100", 
                                   100, 
                                   exp.Evaluate(new string[]{"_XxX"},
                                                new double[] {88}));
            ht["_XxX"] = -22;
            Assertion.AssertEquals("Expression must evaluate to -10", 
                                   -10, exp.Evaluate(ht));
        }

        /// <summary>
        /// Verifies that the system deals with subtraction
        /// </summary>
        [Test]
        public void TestSUBTRACT() {
            Hashtable ht = new Hashtable();
            exp = Expression.Parse("Y12-_XxX");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 100", 
                                   100, 
                                   exp.Evaluate(new string[]{"Y12", "_XxX"},
                                                new double[] {88, -12}));
            ht["Y12"] = 12.334;
            ht["_XxX"] = -22;
            Assertion.AssertEquals("Expression must evaluate to 34.334", 
                                   34.334, exp.Evaluate(ht));
        }

        /// <summary>
        /// Verifies that the system deals with multiplication.
        /// </summary>
        [Test]
        public void TestMULTIPLY() {
            exp = Expression.Parse("2.4*8.3");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 2.4*8.3", 
                                   2.4*8.3, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with division
        /// </summary>
        [Test]
        public void TestDIVIDE() {
            exp = Expression.Parse("1.2/3.4");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1.2/3.4", 
                                   1.2/3.4, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with power operation.
        /// </summary>
        [Test]
        public void TestPOWER() {
            exp = Expression.Parse("4^3");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 64", 
                                   64, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "=="
        /// </summary>
        [Test]
        public void TestEQ() {
            exp = Expression.Parse("2.3==2.3");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 
                                   1, exp.Evaluate());
            exp = Expression.Parse("2.3==3.2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "!="
        /// </summary>
        [Test]
        public void TestNE() {
            exp = Expression.Parse("1.2!=8.9");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 
                                   1, exp.Evaluate());

            exp = Expression.Parse("1.2!=1.20");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation ">"
        /// </summary>
        [Test]
        public void TestGT() {
            exp = Expression.Parse("1E2>2E1");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 
                                   1, exp.Evaluate());
            exp = Expression.Parse("1E2>1E2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation ">="
        /// </summary>
        [Test]
        public void TestGE() {
            exp = Expression.Parse("2E3>=2E3");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 
                                   1, exp.Evaluate());
            exp = Expression.Parse("2E3>=3E3");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "less than"
        /// </summary>
        [Test]
        public void TestLT() {
            exp = Expression.Parse("-2.3<-1.8");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 
                                   1, exp.Evaluate());
            exp = Expression.Parse("2.3<1.8");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation 
        /// "less or equal".
        /// </summary>
        [Test]
        public void TestLE() {
            exp = Expression.Parse("-22<=22");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 
                                   1, exp.Evaluate());
            exp = Expression.Parse("22<=-22");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
        }

        /// <summary>
        /// Tests operation MIN
        /// </summary>
        [Test]
        public void TestMIN() {
            exp = Expression.Parse("MIN(2.51,3.0)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to Min(2.51,3.0)", 
                                   System.Math.Min(2.51, 3.0), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation MAX
        /// </summary>
        [Test]
        public void TestMAX() {
            exp = Expression.Parse("MAX(2.51,3.0)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to MAX(2.51,3.0)", 
                                   System.Math.Max(2.51, 3.0), exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "and"
        /// </summary>
        [Test]
        public void TestAND() {
            exp = Expression.Parse("1&&1");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 
                                   1, exp.Evaluate());
            exp = Expression.Parse("1&&0");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
            exp = Expression.Parse("0&&1");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
            exp = Expression.Parse("0&&0");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
            // short circuit
            exp = Expression.Parse("0&&X");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "||"
        /// </summary>
        [Test]
        public void TestOR() {
            exp = Expression.Parse("1||1");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 
                                   1, exp.Evaluate());
            exp = Expression.Parse("1||0");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 
                                   1, exp.Evaluate());
            exp = Expression.Parse("0||1");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 
                                   1, exp.Evaluate());
            exp = Expression.Parse("0||0");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, exp.Evaluate());
            // short circuit
            exp = Expression.Parse("1||X");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 
                                   1, exp.Evaluate());
        }
    }
}