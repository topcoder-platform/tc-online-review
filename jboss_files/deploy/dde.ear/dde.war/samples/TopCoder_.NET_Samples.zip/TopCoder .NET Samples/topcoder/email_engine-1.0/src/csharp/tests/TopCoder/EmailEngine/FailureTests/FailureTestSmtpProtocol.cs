using System;
using NUnit.Framework;

namespace TopCoder.EmailEngine.FailureTests {

    /// <summary>
    /// This tests SmtpProtocol.
    /// </summary>
    [TestFixture]
    public class FailureTestSmtpProtocol {

        /// <summary>
        /// This tests whether server is parsed correctly
        /// </summary>
        [Test]
        public void SmtpProtocolParseServer() {
            SmtpProtocol sp = new SmtpProtocol("a.a:26");
            sp.Server = "a.a";
            Assertion.Assert(sp.Port == 25);
        }

    }

}
