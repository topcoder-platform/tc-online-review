using System;
using System.Collections;

namespace TopCoder.Util.Collection.Queue
{
    /// <summary>
    /// The Priority Queue component supports standard queue functionality, except that it does not
    /// follow the first-in-first-out (FIFO) paradigm. Items added to a priority queue implementation
    /// require assigning a priority level to the item. Items then can be added in arbitrary order to the
    /// queue, but are removed based on the priority.
    /// </summary>
    /// <author>TCSDESIGNER</author>
    public class PriorityQueue : ICloneable, IEnumerable, ICollection
    {
        /// <summary>
        /// The SynchronizedPriorityQueue is derived from a PriorityQueue and behaves as a
        /// thread-safe version. It must be created through the Synchronized static method.
        /// All method calls are referred through to the unsynchronized queue after using
        /// the lock command to invoke a critical section.
        /// </summary>
        private class SynchronizedPriorityQueue : PriorityQueue
        {
            private PriorityQueue queueUnsynchronized = null;

            public SynchronizedPriorityQueue(PriorityQueue queue)
            {
                queueUnsynchronized = queue;
            }

            /// <summary>
            /// The number of elements contained in the PriorityQueue.
            /// </summary>
            public override int Count { get { return 0; } }

            /// <summary>
            /// true if access to the PriorityQueue is synchronized (thread-safe);
            /// otherwise, false.
            /// </summary>
            public override bool IsSynchronized { get { return true; } }

            /// <summary>
            /// An object that can be used to synchronize access to the PriorityQueue.
            /// </summary>
            public override object SyncRoot { get { return queueUnsynchronized; } }

            /// <summary>
            /// Determines whether the enumerator is valid. An enumerator is invalidated when
            /// the contents of the queue are changed.
            /// </summary>
            /// <param name="enumerator">Enumerator to check status of</param>
            /// <returns>true if the enumerator is valid; otherwise false</returns>
            protected override bool IsEnumeratorValid(PriorityQueueEnumerator enumerator)
            {
                return false;
            }

			/// <summary>
			/// Retrieves the object for the enumerator corresponding to the provided
			/// enumeration index.
			/// </summary>
			/// <param name="index">Index to retrieve object from</param>
			/// <param name="pqe">Enumerator which is enumerating</param>
			/// <exception cref="InvalidOperationException">Enumerator is invalid</exception>
			/// <returns>The object in the priority queue at the specified index</returns>
			protected override object EnumCurrent(int index, PriorityQueueEnumerator pqe)
			{
				return null;
			}

            /// <summary>
            /// Removes all objects from the PriorityQueue
            /// </summary>
            public override void Clear()
            {
            }

            /// <summary>
            /// Creates a shallow copy of the PriorityQueue
            /// </summary>
            /// <returns>A shallow copy of the PriorityQueue</returns>
            public override object Clone()
            {
                return null;
            }

            /// <summary>
            /// Determines whether an element is in the PriorityQueue
            /// </summary>
            /// <param name="obj">The Object to locate in the PriorityQueue. The value can
            /// be a null reference (Nothing in Visual Basic).</param>
            /// <returns>true if obj is found in the PriorityQueue; otherwise, false.</returns>
            public override bool Contains(object obj)
            {
                return false;
            }

            /// <summary>
            /// Copies the PriorityQueue elements to an existing one-dimensional Array, starting at the
            /// specified array index.
            /// </summary>
            /// <param name="array">The one-dimensional Array that is the destination of the
            /// elements copied from PriorityQueue. The Array must have zero-based indexing.</param>
            /// <param name="index">The zero-based index in array at which copying begins.</param>
            public override void CopyTo(Array array, int index)
            {
            }

            /// <summary>
            /// Removes and returns the object at the beginning of the Queue. This will be the
            /// object with the highest priority.
            /// </summary>
            /// <returns>The object that is removed from the beginning of the Queue.</returns>
            /// <exception cref="InvalidOperationException">The PriorityQueue is empty.</exception>
            public override object Dequeue()
            {
                return 0;
            }

            /// <summary>
            /// Adds an object to the PriorityQueue. Its position is based on its priority. A
            /// higher priority is placed towards the front.
            /// </summary>
            /// <param name="obj">The object to add to the PriorityQueue. The value can be a null
            /// reference (Nothing in Visual Basic).</param>
            /// <param name="priority">The priority of the object being added to the
            /// PriorityQueue.</param>
            /// <exception cref="ArgumentException">The PriorityQueue is set to use the IComparable
            /// interface, and priority does not implement the IComparable interface.</exception>
            /// <exception cref="InvalidOperationException">The comparer throws an exception.</exception>
            public override void Enqueue(object obj, object priority)
            {
            }

            /// <summary>
            /// Adds an object to the PriorityQueue. Its position is based on the value of the
            /// object. A higher value is placed towards the front.
            /// </summary>
            /// <param name="obj">The object to add to the PriorityQueue. The value can be a null
            /// reference (Nothing in Visual Basic).</param>
            /// <exception cref="ArgumentException">The PriorityQueue is set to use the IComparable
            /// interface, and object does not implement the IComparable interface.</exception>
            /// <exception cref="InvalidOperationException">The comparer throws an exception.</exception>
            /// <remarks>In terms of priority, the object's priority is its value.</remarks>
            public override void Enqueue(object obj)
            {
                Enqueue(obj, obj);
            }

            /// <summary>
            /// Returns an enumerator that can iterate through the PriorityQueue.
            /// </summary>
            /// <returns>An IEnumerator for the PriorityQueue.</returns>
            public override IEnumerator GetEnumerator()
            {
                return null;
            }

            /// <summary>
            /// Returns the object at the beginning of the PriorityQueue without removing it.
            /// </summary>
            /// <returns>The object at the beginning of the PriorityQueue.</returns>
            /// <exception cref="InvalidOperationException">The PriorityQueue is empty.</exception>
            public override object Peek()
            {
                return null;
            }

            /// <summary>
            /// Copies the PriorityQueue elements to a new array.
            /// </summary>
            /// <returns>A new array containing elements copied from the PriorityQueue.</returns>
            public override object[] ToArray()
            {
                return null;
            }

            /// <summary>
            /// Sets the capacity to the actual number of elements in the PriorityQueue.
            /// </summary>
            public override void TrimToSize()
            {
            }
        }

        /// <summary>
        /// An enumerator implementation for the PriorityQueue class
        /// </summary>
        protected class PriorityQueueEnumerator : IEnumerator
        {
            private PriorityQueue queue;
            private int index = -1;

            public PriorityQueueEnumerator(PriorityQueue priqueue)
            {
                queue = priqueue;
            }

            /// <summary>
            /// The current element in the collection.
            /// </summary>
			/// <exception cref="InvalidOperationException">Enumerator is invalid</exception>
			public object Current
            {
                get
                {
                    return null;
                }
            }

            /// <summary>
            /// Sets the enumerator to its initial position, which is before the first
            /// element in the collection.
            /// </summary>
			/// <exception cref="InvalidOperationException">Enumerator is invalid</exception>
			public void Reset()
            {
            }

            /// <summary>
            /// Advances the enumerator to the next element of the collection.
            /// </summary>
			/// <exception cref="InvalidOperationException">Enumerator is invalid</exception>
			/// <returns>true if the enumerator was successfully advanced to the next
            /// element; false if the enumerator has passed the end of the collection.
            /// </returns>
            public bool MoveNext()
            {
                return false;
            }
        }

        /// <summary>
        /// A Comparison object that compares priority values.
        /// Can be null in which case the priority object must implement the IComparable
        /// interface.
        /// </summary>
        IComparer priorityComparer = null;

        /// <summary>
        /// An array which is created when an enumeration is requested. The
        /// object is removed whenever an operation occurs.
        /// </summary>
        object [] enumArray = null;

        /// <summary>
        /// An ArrayList which is created when an enumeration is requested. The
        /// object is removed whenever an operation occurs, invalidating enumerators upon
        /// calls to IsEnumeratorValid.
        /// </summary>
        ArrayList enumerators = null;

        /// <summary>
        /// An internal object which stores an object and its associated priority
        /// </summary>
        private struct PriorityObject
        {
            public object obj;
            public object priority;
        }

        /// <summary>
        /// The heap, being the core of the priority queue with data stored in it
        /// </summary>
        PriorityObject [] heap;

        /// <summary>
        /// Size of the heap
        /// </summary>
        int heapSize = 0;

       
        /// <summary>
        /// Pops the object off the top of the heap by manipulating the heap and
        /// decreasing the heap size.
        /// </summary>
        /// <returns>The object that was on top of the heap</returns>
        private PriorityObject PopHeap()
        {
            PriorityObject priobj;
            priobj.obj = priobj.priority = null;
            return priobj;
        }

        /// <summary>
        /// Peeks at the object on top of the heap
        /// </summary>
        /// <returns>The object that is on top of the heap</returns>
        private PriorityObject PeekHeap()
        {
            PriorityObject priobj;
            priobj.obj = priobj.priority = null;
            return priobj;
        }

        /// <summary>
        /// Pushes an object into the heap by manipulating the heap and increasing the
        /// heap size.
        /// </summary>
        /// <param name="priobj">The object to be placed in the heap</param>
        private void PushHeap(PriorityObject priobj)
        {
        }

        /// <summary>
        /// Determines whether the enumerator is valid. An enumerator is invalidated when
        /// the contents of the queue are changed.
        /// </summary>
        /// <param name="enumerator">Enumerator to check status of</param>
        /// <returns>true if the enumerator is valid; otherwise false</returns>
        protected virtual bool IsEnumeratorValid(PriorityQueueEnumerator enumerator)
        {
            return false;
        }

        /// <summary>
        /// Retrieves the object for the enumerator corresponding to the provided
        /// enumeration index.
        /// </summary>
        /// <param name="index">Index to retrieve object from</param>
        /// <param name="pqe">Enumerator which is enumerating</param>
        /// <exception cref="InvalidOperationException">Enumerator is invalid</exception>
        /// <returns>The object in the priority queue at the specified index</returns>
        protected virtual object EnumCurrent(int index, PriorityQueueEnumerator pqe)
        {
            return null;
        }


        /// <summary>
        /// The number of elements contained in the PriorityQueue.
        /// </summary>
        public virtual int Count { get { return heapSize; } }

        /// <summary>
        /// true if access to the PriorityQueue is synchronized (thread-safe);
        /// otherwise, false.
        /// </summary>
        public virtual bool IsSynchronized { get { return false; } }

        /// <summary>
        /// An object that can be used to synchronize access to the PriorityQueue.
        /// </summary>
        public virtual object SyncRoot { get { return this; } }


        /// <summary>
        /// Initializes a new instance of the PriorityQueue class that is empty, has the
        /// default initial capacity and uses the default growth factor.
        /// </summary>
        /// <remarks>The default initial capacity is 32 and the default growth factor is 2.0</remarks>
        public PriorityQueue()
        {
        }

        /// <summary>
        /// Initializes a new instance of the PriorityQueue class that contains elements copied
        /// from the specified collection, has the same initial capacity as the number of
        /// elements copied and uses the default growth factor.
        /// </summary>
        /// <param name="col">The ICollection to copy elements from.</param>
        /// <exception cref="ArgumentNullException">col is a null reference
        /// (Nothing in Visual Basic).</exception>
        /// <exception cref="InvalidCastException">One or more elements in col do not
        /// implement the IComparable interface.</exception>
        /// <remarks>If the collection is of type PriorityQueue, the priorities are copied.
        /// The default growth factor is 2.0</remarks>
		public PriorityQueue(ICollection col)
        {
        }

        /// <summary>
        /// Initializes a new instance of the PriorityQueue class that is empty, has the
        /// default initial capacity, uses the default growth factor, and is ordered
        /// according to the specified IComparer interface.
        /// </summary>
        /// <param name="comparer">The IComparer implementation to use when comparing priorities
        /// -or-
        /// A null reference (Nothing in Visual Basic) to use the IComparable implementation
        /// of each key.</param>
		/// <remarks>The default initial capacity is 32 and the default growth factor is 2.0</remarks>
		public PriorityQueue(IComparer comparer)
        {
            priorityComparer = comparer;
        }

        /// <summary>
        /// Initializes a new instance of the PriorityQueue class that contains elements copied
        /// from the specified collection, has the same initial capacity as the number of
        /// elements copied and uses the default growth factor.
        /// </summary>
        /// <param name="col">The ICollection to copy elements from.</param>
        /// <param name="comparer">The IComparer implementation to use when comparing priorities
        /// -or-
        /// A null reference (Nothing in Visual Basic) to use the IComparable implementation
        /// of each key.</param>
        /// <exception cref="ArgumentNullException">col is a null reference
        /// (Nothing in Visual Basic).</exception>
        /// <exception cref="InvalidOperationException">The comparer throws an exception.</exception>
        /// <remarks>If the collection is of type PriorityQueue, the priorities are copied.
		/// The default growth factor is 2.0</remarks>
		public PriorityQueue(ICollection col, IComparer comparer)
        {
            priorityComparer = comparer;
        }

        /// <summary>
        /// Initializes a new instance of the Queue class that is empty, has the specified
        /// initial capacity and uses the default growth factor.
        /// </summary>
        /// <param name="capacity">The initial number of elements that the Queue can contain.</param>
        /// <exception cref="ArgumentOutOfRangeException">capacity is less than zero.</exception>
		/// <remarks>The default growth factor is 2.0</remarks>
		public PriorityQueue(int capacity)
        {
        }

        /// <summary>
        /// Initializes a new instance of the Queue class that is empty, has the specified
        /// initial capacity and uses the default growth factor. Priority is ordered
        /// according to the specified IComparer interface.
        /// </summary>
        /// <param name="capacity">The initial number of elements that the Queue can contain.</param>
        /// <param name="comparer">The IComparer implementation to use when comparing priorities
        /// -or-
        /// A null reference (Nothing in Visual Basic) to use the IComparable implementation
        /// of each key.</param>
        /// <exception cref="ArgumentOutOfRangeException">capacity is less than zero.</exception>
		/// <remarks>The default growth factor is 2.0</remarks>
		public PriorityQueue(int capacity, IComparer comparer)
        {
            priorityComparer = comparer;
        }

        /// <summary>
        /// Initializes a new instance of the Queue class that is empty, has the specified
        /// initial capacity and uses the specified growth factor.
        /// </summary>
        /// <param name="capacity">The initial number of elements that the Queue can contain.</param>
        /// <param name="growFactor">The factor by which the capacity of the Queue is expanded.</param>
        /// <exception cref="ArgumentOutOfRangeException">capacity is less than zero.
        /// -or-
        /// growFactor is less than 1.0 or greater than 10.0.</exception>
        public PriorityQueue(int capacity, float growFactor)
        {
        }

        /// <summary>
        /// Initializes a new instance of the Queue class that is empty, has the specified
        /// initial capacity and uses the specified growth factor. Priority is ordered
        /// according to the specified IComparer interface.
        /// </summary>
        /// <param name="capacity">The initial number of elements that the Queue can contain.</param>
        /// <param name="growFactor">The factor by which the capacity of the Queue is expanded.</param>
        /// <param name="comparer">The IComparer implementation to use when comparing priorities
        /// -or-
        /// A null reference (Nothing in Visual Basic) to use the IComparable implementation
        /// of each key.</param>
        /// <exception cref="ArgumentOutOfRangeException">capacity is less than zero.
        /// -or-
        /// growFactor is less than 1.0 or greater than 10.0.</exception>
        public PriorityQueue(int capacity, float growFactor, IComparer comparer)
        {
        }

        /// <summary>
        /// Removes all objects from the PriorityQueue
        /// </summary>
        public virtual void Clear()
        {
        }

        /// <summary>
        /// Creates a shallow copy of the PriorityQueue
        /// </summary>
        /// <returns>A shallow copy of the PriorityQueue</returns>
        public virtual object Clone()
        {
            return null;
        }

        /// <summary>
        /// Determines whether an element is in the PriorityQueue
        /// </summary>
        /// <param name="obj">The Object to locate in the PriorityQueue. The value can
        /// be a null reference (Nothing in Visual Basic).</param>
        /// <returns>true if obj is found in the PriorityQueue; otherwise, false.</returns>
        public virtual bool Contains(object obj)
        {
            return false;
        }

        /// <summary>
        /// Copies the PriorityQueue elements to an existing one-dimensional Array, starting at the
        /// specified array index.
        /// </summary>
        /// <param name="array">The one-dimensional Array that is the destination of the
        /// elements copied from PriorityQueue. The Array must have zero-based indexing.</param>
        /// <param name="index">The zero-based index in array at which copying begins.</param>
        public virtual void CopyTo(Array array, int index)
        {
        }

        /// <summary>
        /// Removes and returns the object at the beginning of the Queue. This will be the
        /// object with the highest priority.
        /// </summary>
        /// <returns>The object that is removed from the beginning of the Queue.</returns>
        /// <exception cref="InvalidOperationException">The PriorityQueue is empty.</exception>
        public virtual object Dequeue()
        {
            return 0;
        }

        /// <summary>
        /// Adds an object to the PriorityQueue. Its position is based on its priority. A
        /// higher priority is placed towards the front.
        /// </summary>
        /// <param name="obj">The object to add to the PriorityQueue. The value can be a null
        /// reference (Nothing in Visual Basic).</param>
        /// <param name="priority">The priority of the object being added to the
        /// PriorityQueue.</param>
        /// <exception cref="ArgumentException">The PriorityQueue is set to use the IComparable
        /// interface, and priority does not implement the IComparable interface.</exception>
        /// <exception cref="InvalidOperationException">The comparer throws an exception.</exception>
        public virtual void Enqueue(object obj, object priority)
        {
        }

        /// <summary>
        /// Adds an object to the PriorityQueue. Its position is based on the value of the
        /// object. A higher value is placed towards the front.
        /// </summary>
        /// <param name="obj">The object to add to the PriorityQueue. The value can be a null
        /// reference (Nothing in Visual Basic).</param>
        /// <exception cref="ArgumentException">The PriorityQueue is set to use the IComparable
        /// interface, and object does not implement the IComparable interface.</exception>
        /// <exception cref="InvalidOperationException">The comparer throws an exception.</exception>
		/// <remarks>In terms of priority, the object's priority is its value.</remarks>
		public virtual void Enqueue(object obj)
        {
            Enqueue(obj, obj);
        }

        /// <summary>
        /// Returns an enumerator that can iterate through the PriorityQueue.
        /// </summary>
        /// <returns>An IEnumerator for the PriorityQueue.</returns>
        public virtual IEnumerator GetEnumerator()
        {
            return null;
        }

        /// <summary>
        /// Returns the object at the beginning of the PriorityQueue without removing it.
        /// </summary>
        /// <returns>The object at the beginning of the PriorityQueue.</returns>
        /// <exception cref="InvalidOperationException">The PriorityQueue is empty.</exception>
        public virtual object Peek()
        {
            return null;
        }

        /// <summary>
        /// Returns a PriorityQueue wrapper that is synchronized (thread-safe).
        /// </summary>
        /// <param name="queue">The PriorityQueue to synchronize.</param>
        /// <returns>A PriorityQueue wrapper that is synchronized (thread-safe).</returns>
        /// <exception cref="ArgumentNullException">queue is a null reference (Nothing in Visual Basic).</exception>
        public static PriorityQueue Synchronized(PriorityQueue queue)
        {
            return new SynchronizedPriorityQueue(queue);
        }

        /// <summary>
        /// Copies the PriorityQueue elements to a new array.
        /// </summary>
        /// <returns>A new array containing elements copied from the PriorityQueue.</returns>
        public virtual object[] ToArray()
        {
            return null;
        }

        /// <summary>
        /// Sets the capacity to the actual number of elements in the PriorityQueue.
        /// </summary>
        public virtual void TrimToSize()
        {
        }
    }
}
