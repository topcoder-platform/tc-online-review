using System;

// @author CLoris
// @copyright 2003 (c) TopCoder Software

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// Exception for any errors during sending of email
    /// </summary>
    public class SendException : Exception
    {
        /// <summary>
        /// Exception constructor
        /// </summary>
        public SendException() : base() {}

        /// <summary>
        /// Exception constructor with message
        /// </summary>
        /// <param name="message"></param>
        public SendException(string message) : base(message) {}
    }
}
