using System;
using System.Collections;
using NUnit.Framework;
using TopCoder.Util.Collection.Queue;

namespace TopCoder.Util.Collection.Queue.FailureTests
{
    /// <summary>
    /// tests incorrect working with PriorityQueue methods
    /// @author aksonov
    /// @copyright TopCoder Software (c) 2003
    /// </summary>
    [TestFixture]
    public class QueueTests 
    {
        /// <summary>
        /// priority queue object
        /// </summary>
        private PriorityQueue queue = null;

        /// <summary>
        /// set up 
        /// </summary>
        [SetUp]
        protected void SetUp()
        {
            queue = new PriorityQueue();
        }

        /// <summary>
        /// tests trying dequeue empty collection
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void TestDequeue()
        {
            queue.Dequeue();
        }
        /// <summary>
        /// tests trying enqueue item with other type
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void TestEnqueue()
        {
            queue.Enqueue(4);
            Assertion.AssertEquals(1, queue.Count);
            queue.Enqueue("4");
        }
        /// <summary>
        /// tests trying enqueue item that is not implements IComparable interface - 
        /// 
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestEnqueue2()
        {
            queue.Enqueue(4);
            Assertion.AssertEquals(1, queue.Count);
            queue.Enqueue(new PriorityQueue());
        }
        /// <summary>
        /// tests trying enqueue item with priority of other type
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void TestEnqueueIncorrectPriority()
        {
            queue.Enqueue(4,1);
            Assertion.AssertEquals(1, queue.Count);
            queue.Enqueue(5,"1");
        }

        /// <summary>
        /// tests trying enqueue item with priority that is not implements IComparable 
        /// interface
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void TestEnqueue3()
        {
            queue.Enqueue(4);
            Assertion.AssertEquals(1, queue.Count);
            queue.Enqueue(5, new PriorityQueue());
        }

        /// <summary>
        /// test calls Peek method when queue is empty
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void TestPeek()
        {
            queue.Peek();
        }

        /// <summary>
        /// test calls Synchronized method with null queue
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestSynchronized()
        {
            PriorityQueue queue = PriorityQueue.Synchronized(null);
        }

        /// <summary>
        /// test calls MoveNext() for empty queue
        /// </summary>
        [Test]
        public void TestEnumerator()
        {
            IEnumerator enumerator = queue.GetEnumerator();
            Assertion.AssertEquals(false,enumerator.MoveNext());
        }

    }
}
