/* UnresolvedVariableException.cs; 
 * Copyright @ 2003, TopCoder, Inc. All rights reserved
 * 
 * @author kyky
 * */
using System;

namespace TopCoder.Math.ExpressionEvaluator {
    /// <summary>
    /// Expression.Evaluate throws this exception when a variable name
    /// is found that cannot be resolved in the evaluation environment.
    /// </summary>
    public class UnresolvedVariableException : Exception {
        /// <summary>
        /// Creates an instance of UnresolvedVariableException.
        /// </summary>
        /// <param name="varName">Name of the unresolved variable.</param>
        public UnresolvedVariableException( string varName) : base( varName ) {
        }
    }
}
