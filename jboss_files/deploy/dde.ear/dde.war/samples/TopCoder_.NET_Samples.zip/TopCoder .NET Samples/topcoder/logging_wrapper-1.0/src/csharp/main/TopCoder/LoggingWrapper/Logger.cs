// @author Mikhail_T
// @copyright (c) TopCoder Software 2003

using System;
using System.Collections;

namespace TopCoder.LoggingWrapper
{
	/// <summary>
	/// Logger abstract class should be extended by classes that wish to provide a custom 
	/// logging implementation. The <c>Log</c> method is used to log a message using the 
	/// underlying implementation, and the <c>IsLevelEnabled</c> method is used to determine 
	/// if a specific logging level is supported by underlying implementation
	/// </summary>
	public abstract class Logger : IDisposable
    {
        private Level level = Level.DEBUG;
        private IDictionary map = new Hashtable();
        private string configfile = null;

        /// <summary>
        /// Default logging level
        /// </summary>
        public Level Level 
        {
            get 
            {
                return level;
            }
            set 
            {                
                level = value;
            }
        }

        /// <summary>
        /// name of config file for logging implementation (if necessary)
        /// </summary>
        public string ConfigFile 
        {
            get 
            {
                return configfile;
            }
            set 
            {
                if(ConfigFile==null) throw new ArgumentNullException("ConfigFile");                
                configfile = value;
            }
        }

        /// <summary>
        ///  mapping of logging levels in the implementation to the logging level of wrapper
        /// </summary>
        internal IDictionary Map 
        {
            get 
            {
                return map;
            }
            set 
            {
                if(Map==null) throw new ArgumentNullException("Map");                
                map = value;
            }
        }

        /// <summary>
        /// Initializes a new instance of the Logger class
        /// </summary>
        public Logger()
        {
            this.setMapping();
        }

		/// <summary>
		/// Initializes a new instance of the Logger class with the specified logging level 
		/// </summary>
		/// <param name="level">Logging level </param>
        public Logger(Level level)
        {            
            this.Level = level;
            this.setMapping();
        }

        /// <summary>
        /// Is used by logging implementation to load/reload configuration
        /// </summary>
        internal abstract void LoadConfiguration(System.Collections.Specialized.NameValueCollection config);
        /// <summary>
        /// Is used to log a message using the underlying implementation with the default logging level
        /// </summary>
        /// <param name="message">parameterized logging message (it can contain {0}, {1}.. for inserting parameters) </param>
        /// <param name="param">parameters for logging message (if needed)</param>
        internal void Log(string message, params object[] param)
        {
            this.Log(this.Level, message, param);
        }

        /// <summary>
        /// Is used to log a message using the underlying implementation with the specified logging level
        /// </summary>
        /// <param name="level">logging level</param>
        /// <param name="message">logging message</param>
        /// <param name="param">parameters for logging message</param>
        internal abstract void Log(Level level, string message, params object[] param);

        /// <summary>
        /// Is used to determine if a specific logging level is supported by underlying implementation
        /// </summary>
        /// <param name="level">logging level</param>
        /// <returns>result</returns>
        internal bool IsLevelEnabled(Level level)
        {            
            return this.Map.Contains(level);
        }

        /// <summary>
        /// Maps the level of logging in the implementation to the logging level of the wrapper.
        /// </summary>
        internal abstract void setMapping();
		
		/// <summary>
		/// Performs application-defined tasks associated with freeing, releasing, 
		/// or resetting unmanaged resources.
		/// </summary>
		public abstract void Dispose();
    }
}
