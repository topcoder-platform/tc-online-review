/*
Copyright c 2003, TopCoder, Inc. All rights reserved.
Author opi
*/

using System;
using System.Text;
using System.Collections;

namespace TopCoder.Util.Collection.Queue
{
	using System;
	using NUnit.Framework;
	/// <summary>
	/// Test the functionality of the PriorityQueue class.
	/// </summary>
	/// 
	[TestFixture]
	public class PriorityQueueAccuracyTests
	{
		/// <summary>
		/// Test PriorityQueue created but left empty.
		/// </summary>
		public PriorityQueue pq;
		/// <summary>
		/// Test PriorityQueue created and filled with 1000 objects
		/// </summary>
		public PriorityQueue pqBig;

		/// <summary>
		/// Create two queues, one empty and one filled with 1000 strings - "0" to "999"
		/// with corresponding integer priorities.
		/// </summary>
		/// 
		[SetUp]
		protected void SetUp() 
		{
			pq = new PriorityQueue();
			pqBig = new PriorityQueue();
			Assertion.AssertNotNull(pqBig);
			for (int index=0; index<1000; index++)
			{
				pqBig.Enqueue(index.ToString(), index);
			}

		}

		/// <summary>
		/// This test replicates the Demo code in section 4.2 of the .NET Priority Queue Collection Component Specification
		/// </summary>
		/// 
		[Test]
		public void ComponentSpecTest()
		{
			pq.Enqueue("Low priority", 1);
			pq.Enqueue("High priority", 3);
			pq.Enqueue("Medium priority", 2);
			Assertion.AssertEquals(3, pq.Count);

			// Enumerate through the items in the queue and
			// output them to the screen
			StringBuilder test = new StringBuilder();
			foreach(string s in pq)
			{
				test.Append(s);
			}
			Assertion.AssertEquals("High priorityMedium priorityLow priority", test.ToString());

			// Take a look at the item on top of the queue and output
			// it to the screen
			String strPeek = pq.Peek().ToString();
			Assertion.AssertEquals("High priority", strPeek);

			// Take the items off the queue in order of priority
			// and output them to the screen
			StringBuilder test2 = new StringBuilder();
			while(pq.Count != 0)
			{
				test2.Append(pq.Dequeue().ToString());
			}
			Assertion.AssertEquals("High priorityMedium priorityLow priority", test.ToString());

		}
		/// <summary>
		/// Count test - fill the PriorityQueue and make sure it contains the right number
		/// of objects.
		/// </summary>
		[Test]
		public void CountTest()
		{
			int count;
			pqBig = new PriorityQueue();
			Assertion.AssertNotNull(pqBig);
			for (int index=0; index<100000; index++)
			{
				pqBig.Enqueue(index.ToString(), index);
			}
			count = pqBig.Count;
			Assertion.AssertEquals(count, 100000);
		}
	}
}
