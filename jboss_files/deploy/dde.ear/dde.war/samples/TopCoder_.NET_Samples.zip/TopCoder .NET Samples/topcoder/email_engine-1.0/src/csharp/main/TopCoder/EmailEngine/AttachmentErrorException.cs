using System;

// @author CLoris
// @copyright 2003 (c) TopCoder Software

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// This exception is for any error during attachment creating/manipulation
    /// </summary>
    public class AttachmentErrorException : Exception
    {
        /// <summary>
        /// Exception constructor
        /// </summary>
        public AttachmentErrorException() : base() {}

        /// <summary>
        /// Exception constructor with message
        /// </summary>
        /// <param name="message"></param>
        public AttachmentErrorException(string message) : base(message) {}
    }
}
