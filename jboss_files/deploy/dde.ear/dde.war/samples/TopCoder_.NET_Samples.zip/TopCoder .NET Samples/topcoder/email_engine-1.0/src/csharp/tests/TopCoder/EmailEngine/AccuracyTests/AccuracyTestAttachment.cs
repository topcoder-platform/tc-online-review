using System;
using NUnit.Framework;
using System.IO;
using System.Web.Mail;

namespace TopCoder.EmailEngine.AccuracyTests
{
    /// <summary>
    /// Accuracy Tests for Attachment class
    /// @author aksonov
    /// </summary>
    [TestFixture]
    public class AccuracyTestAttachment
    {
        private static string FRAGMENT1 = "SGVsbG8gZmlyc3Qgd29ybGQhDQo";

        /// <summary>
        /// Test creation attachment from given filename
        /// </summary>
        [Test]
        public void TestFileName()
        {
            Attachment att = new Attachment(@"..\..\test_files\attachment1.txt");
            Assertion.Assert("Attachment should contain encoded fragment",att.ToString().IndexOf(FRAGMENT1)!=-1);
        }

        /// <summary>
        /// Test creation attachment from given file stream
        /// </summary>
        [Test]
        public void TestFileStream()
        {
            FileStream fs = new FileStream(@"..\..\test_files\attachment1.txt", FileMode.Open, FileAccess.Read, FileShare.Read);
            Attachment att = new Attachment(fs);
            Assertion.Assert("Attachment should contain encoded fragment",att.ToString().IndexOf(FRAGMENT1)!=-1);
        }

        /// <summary>
        /// Test creation attachment from given stream
        /// </summary>
        [Test]
        public void TestStream()
        {
            FileStream fs = new FileStream(@"..\..\test_files\attachment1.txt", FileMode.Open, FileAccess.Read, FileShare.Read);
            byte[] buf = new byte[1000];
            fs.Read(buf,0,1000);
            fs.Close();
            Attachment att = new Attachment(new MemoryStream(buf));
            Assertion.Assert("Attachment should contain encoded fragment",att.ToString().IndexOf(FRAGMENT1)!=-1);
        }

    }
}
