// @author TCSDESIGNER
// @copyright (c) TopCoder Software

using System;
using System.IO;
using System.Text;
using System.Diagnostics;
using NUnit.Framework;

namespace TopCoder.LoggingWrapper.StressTests
{
    /// <summary>
    /// Stress tests for DiagnoticImpl
    /// </summary>
    [TestFixture]
    public class DiagnoticImplStrssTest {

        /// <summary>
        /// Set up method
        /// </summary>
        [SetUp]
        public void SetUp() {
            if(EventLog.Exists("TestLog"))
                EventLog.Delete("TestLog");
            LogManager.Configuration = new System.Collections.Specialized.NameValueCollection();        
            LogManager.Configuration.Add("PluginClassName", "TopCoder.LoggingWrapper.DiagnosticImpl");
            LogManager.Configuration.Add("Source", "TestLog");
            LogManager.Configuration.Add("LogName", "TestLog");
            LogManager.LoadConfiguration();
        }

        /// <summary>
        /// Tear down method
        /// </summary>
        [TearDown]
        public void TearDown() {
            if(EventLog.Exists("TestLog"))
                EventLog.Delete("TestLog");
        }

        /// <summary>
        /// Test logging long message
        /// </summary>
        [Test]
        public void LogLongMessage() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 1000; ++i) {
                sb.Append("0123456789");
            }
            DateTime dt = DateTime.Now;
            LogManager.Log(sb.ToString());
            System.Console.Write("Logging 10k-length message took ");
            System.Console.Write((DateTime.Now.Ticks - dt.Ticks) / 10000);
            System.Console.WriteLine(" ms with DiagnoticImpl");
        }

        /// <summary>
        /// Test logging multiple messages
        /// </summary>
        [Test]
        public void LogMultipleMessage() {
            DateTime dt = DateTime.Now;
            for (int i = 0; i < 1000; ++i) {
                LogManager.Log("0123456789");
            }
            System.Console.Write("Logging 1k messages took ");
            System.Console.Write((DateTime.Now.Ticks - dt.Ticks) / 10000);
            System.Console.WriteLine(" ms with DiagnoticImpl");
        }

    }

}
