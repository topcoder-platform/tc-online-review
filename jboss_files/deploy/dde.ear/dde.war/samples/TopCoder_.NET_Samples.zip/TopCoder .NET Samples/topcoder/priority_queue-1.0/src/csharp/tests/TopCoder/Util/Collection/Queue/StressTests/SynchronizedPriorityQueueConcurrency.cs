/*
Copyright c 2003, TopCoder, Inc. All rights reservedusing System;
Author pzhao
*/

using System;
using System.Collections;
using System.Threading;

using TopCoder.Util.Collection.Queue;

using NUnit.Framework;

namespace TopCoder.Util.Collection.Queue.StressTests
{
    /// <summary>
    /// Test the SynchronizedPriorityQueue class using a number of threads
    /// </summary>
    [TestFixture]
    public class SynchronizedPriorityQueueConcurrency
    {
        /// <summary>
        /// Test the Enqueue and Dequeue methods
        /// </summary>
        [Test]
        public void TestConcurrency()
        {
            SynchronizedPriorityQueueThread[] pqs = new SynchronizedPriorityQueueThread[50];
            Thread[] threads = new Thread[50];
            PriorityQueue pq = new PriorityQueue();
            PriorityQueue spq = PriorityQueue.Synchronized(pq);
            int i;

            for (i = 0; i < 50; i++) 
            {
                pqs[i] = new SynchronizedPriorityQueueThread(spq, i);
                threads[i] = new Thread(new ThreadStart(pqs[i].Run));
                threads[i].Start();
            }

            for (i = 0; i < 50; i++) 
            {
                threads[i].Join();
                Assertion.Assert(pqs[i].Success);
            }
        }
    }
    
    /// <summary>
    /// Single thread that test the SynchronizedPriorityQueue class
    /// </summary>
    class SynchronizedPriorityQueueThread
    {
        private PriorityQueue spq;
        private int idx;
        private bool success;

        /// <summary>
        /// Whether the test is successful
        /// </summary>
        public bool Success
        {
            get
            {
                return success;
            }
        }

        /// <summary>
        /// Initialize the variables
        /// </summary>
        public SynchronizedPriorityQueueThread(PriorityQueue spq, int idx)
        {
            this.spq = spq;
            this.idx = idx;
        }

        /// <summary>
        /// Main loop of threads
        /// </summary>
        public void Run()
        {
            int i;

            success = true;
            for (i = 0; i < 50; i++)
            {
                spq.Enqueue(idx*100+i);
                success = success && (spq.Count >= i + 1);
                success = success && (spq.Contains(idx*100+i));
                success = success && ((int) spq.Peek() >= idx*100+i);

                try {
                    spq.ToArray();
                    spq.Clone();
                    spq.TrimToSize();
                } catch (Exception) {
                    success = false;
                }
            }
        }
    }
}
