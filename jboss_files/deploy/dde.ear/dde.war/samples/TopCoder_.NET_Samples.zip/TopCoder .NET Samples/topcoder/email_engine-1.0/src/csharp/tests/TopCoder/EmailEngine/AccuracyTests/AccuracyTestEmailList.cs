using System;
using NUnit.Framework;
using System.IO;


namespace TopCoder.EmailEngine.AccuracyTests
{
    /// <summary>
    /// Accuracy Tests for EmailAddressList class
    /// @author aksonov
    /// </summary>
    [TestFixture]
    public class AccuracyTestEmailList
    {
        /// <summary>
        /// test parsing a email list
        /// </summary>
        [Test]
        public void ListParse()
        {
            EmailAddressList list = new EmailAddressList();
            list.Parse("a@a.a, c@c.c, a@a.a, <b@b.b>");

            Assertion.AssertEquals ( "a@a.a", list[0].Email);
            Assertion.AssertEquals ( "c@c.c", list[1].Email);
            Assertion.AssertEquals ( "a@a.a", list[2].Email);
            Assertion.AssertEquals ( "b@b.b", list[3].Email);
        }

        /// <summary>
        /// test parsing a email list
        /// </summary>
        [Test]
        public void ListParse2()
        {
            EmailAddressList list = new EmailAddressList();
            list.Parse("a@a.a, \"Pavel Aksonov\" <c@c.c>, a@a.a, <b@b.b>");

            Assertion.AssertEquals ( "a@a.a", list[0].Email);
            Assertion.AssertEquals ( "c@c.c", list[1].Email);
            Assertion.AssertEquals ( "Pavel Aksonov", list[1].Name);
            Assertion.AssertEquals ( "a@a.a", list[2].Email);
            Assertion.AssertEquals ( "b@b.b", list[3].Email);
        }

        /// <summary>
        /// test parsing a email list
        /// </summary>
        [Test]
        public void ListParse3()
        {
            EmailAddressList list = new EmailAddressList();
            list.Parse("a@a.a, \"Pavel, Aksonov\" <c@c.c>, a@a.a, <b@b.b>");

            Assertion.AssertEquals ( "a@a.a", list[0].Email);
            Assertion.AssertEquals ( "c@c.c", list[1].Email);
            Assertion.AssertEquals ( "Pavel, Aksonov", list[1].Name);
            Assertion.AssertEquals ( "a@a.a", list[2].Email);
            Assertion.AssertEquals ( "b@b.b", list[3].Email);
        }

        /// <summary>
        /// test adding to email list
        /// </summary>
        [Test]
        public void ListAdding()
        {
            EmailAddressList list = new EmailAddressList();
            list.Parse("a@a.a, c@c.c, a@a.a, <b@b.b>");

            Assertion.AssertEquals ( "a@a.a", list[0].Email);
            Assertion.AssertEquals ( "c@c.c", list[1].Email);
            Assertion.AssertEquals ( "a@a.a", list[2].Email);
            Assertion.AssertEquals ( "b@b.b", list[3].Email);
            list.Add(new EmailAddress("bb@b.b","Test T"));
            Assertion.AssertEquals ( "bb@b.b", list[4].Email);
            Assertion.AssertEquals ( "Test T", list[4].Name);
        }

        /// <summary>
        /// test adding to email list
        /// </summary>
        [Test]
        public void ListRemoving()
        {
            EmailAddressList list = new EmailAddressList();
            list.Parse("a@a.a, c@c.c, a@a.a, <b@b.b>");

            Assertion.AssertEquals ( "a@a.a", list[0].Email);
            Assertion.AssertEquals ( "c@c.c", list[1].Email);
            Assertion.AssertEquals ( "a@a.a", list[2].Email);
            Assertion.AssertEquals ( "b@b.b", list[3].Email);
            EmailAddress email = new EmailAddress();
            email.Parse("\"Test T\" <bb@b.b>");
            list.Add(email);
            Assertion.AssertEquals ( "bb@b.b", list[4].Email);
            Assertion.AssertEquals ( "Test T", list[4].Name);
            Assertion.AssertEquals ( 5, list.Count);
            list.Remove(3);
            Assertion.AssertEquals ( "bb@b.b", list[3].Email);
            Assertion.AssertEquals ( "Test T", list[3].Name);
            Assertion.AssertEquals ( 4, list.Count);
        }

        /// <summary>
        /// test sorting email list
        /// </summary>
        [Test]
        public void ListSorting()
        {
            EmailAddressList list = new EmailAddressList();
            list.Parse("a@a.a, c@c.c, a@a.a, <b@b.b>");

            Assertion.AssertEquals ( "a@a.a", list[0].Email);
            Assertion.AssertEquals ( "c@c.c", list[1].Email);
            Assertion.AssertEquals ( "a@a.a", list[2].Email);
            Assertion.AssertEquals ( "b@b.b", list[3].Email);
            EmailAddress email = new EmailAddress();
            email.Parse("\"Test T\" <bb@b.b>");
            list.Add(email);
            Assertion.AssertEquals ( "bb@b.b", list[4].Email);
            Assertion.AssertEquals ( "Test T", list[4].Name);
            list.Remove(3);
            Assertion.AssertEquals ( "bb@b.b", list[3].Email);
            Assertion.AssertEquals ( "Test T", list[3].Name);

            list.Sort();
            Assertion.AssertEquals ( "bb@b.b", list[2].Email);
            Assertion.AssertEquals ( "Test T", list[2].Name);
            Assertion.AssertEquals ( 4, list.Count);
        }

        /// <summary>
        /// test removing duplicates
        /// </summary>
        [Test]
        public void ListRemoveDuplicates()
        {
            EmailAddressList list = new EmailAddressList();
            list.Parse("a@a.a, c@c.c, \"Pavel\" <a@a.a>, <b@b.b>, b@b.b, cc@c.c");
            list.RemoveDuplicates();
            Assertion.AssertEquals ( "cc@c.c", list[3].Email);
            Assertion.AssertEquals ( 4, list.Count);
        }
    }
}
