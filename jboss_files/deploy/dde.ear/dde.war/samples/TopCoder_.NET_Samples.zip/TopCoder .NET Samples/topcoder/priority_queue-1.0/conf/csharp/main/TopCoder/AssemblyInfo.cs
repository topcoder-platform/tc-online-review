

using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle(".NET Priority Queue")]
[assembly: AssemblyDescription(".NET Priority Queue Data Structure")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("http://www.topcoder.com")]
[assembly: AssemblyProduct(".NET Email Engine")]
[assembly: AssemblyCopyright("Copyright � 2003, TopCoder, Inc. All rights reserved")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0")]

// This will not compile with Visual Studio.  If you want to build a signed
// executable use the NAnt build file.  To build under Visual Studio just
// exclude this file from the build.
[assembly: AssemblyDelaySign(false)]
//[assembly: AssemblyKeyFile(@"..\NAnt.key")]
[assembly: AssemblyKeyName("")]