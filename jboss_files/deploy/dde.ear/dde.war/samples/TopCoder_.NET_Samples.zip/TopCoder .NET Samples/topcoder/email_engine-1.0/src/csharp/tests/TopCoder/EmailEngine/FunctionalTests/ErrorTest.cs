using System;
using NUnit.Framework;
using TopCoder.EmailEngine;

namespace TopCoder.EmailEngine.FunctionalTests
{
            /// <summary>
        /// Error testing
        /// </summary>
    [TestFixture]
    public class ErrorTest 
    {
        /// <summary>
        /// creates incorrect message
        /// </summary>

        [Test]
        [ExpectedException(typeof(MessageErrorException))]
        public void CreateIncorrectMessage()
        {
            Message message = new Message();
            message.From.Parse("me@");
            message.To.Parse("friend@domain.com");
            message.Body = "Hello world!";
            message.Subject = "subj";
        }

        /// <summary>
        /// creates an incorrect attachment
        /// </summary>
        [Test]
        [ExpectedException(typeof(AttachmentErrorException))]
        public void CreateIncorrectAttachment()
        {
            Message message = new Message();
            message.From.Parse("me@me.com");
            message.To.Parse("friend@domain.com");
            message.Body = "Hello world!";
            message.Subject = "subj";
            message.Attachments.Add(null);
        }


        /// <summary>
        /// sends to an invalid smtp
        /// </summary>

        [Test]
        [ExpectedException(typeof(SendException))]
        public void SendToInvalidSMTP()
        {
            Message message = new Message();
            message.From.Parse("me@me.com");
            message.To.Parse("friend@domain.com");
            message.Body = "Hello world!";
            message.Subject = "subj";
            //message.Attachments.Add(null);

            EmailEngine ee = new EmailEngine();
            ee.EmailSender = new SmtpProtocol("invalidsmtp.com");
            ee.SendMessage(message);
        }



        /// <summary>
        /// creates an empty SMTP name
        /// </summary>
        [Test]
        [ExpectedException(typeof(SendException))]
        public void SendToEmptySMTP()
        {
            Message message = new Message();
            message.From.Parse("me@me.com");
            message.To.Parse("friend@domain.com");
            message.Body = "Hello world!";
            message.Subject = "subj";
            //message.Attachments.Add(null);

            EmailEngine ee = new EmailEngine();
            ee.SendMessage(message);
        }


        /// <summary>
        /// gets the message
        /// </summary>

        public static Message GetParseMessage()
        {
            Message m = new Message();
            m.Parse("From: ivan@domain.com\nTo:john@domain.com\nSubject:subj\n\nHello!");
            return m;
        }

        /// <summary>
        /// gets the message
        /// </summary>

        [Test]
        public void ParseMessage()
        {
            Message m = GetParseMessage();
        }


    }
} 
