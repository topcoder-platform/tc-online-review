using System;
using NUnit.Framework;
using TopCoder.Math.ExpressionEvaluator;
using System.Threading;
using System.Collections;

namespace TopCoder.Math.ExpressionEvaluator.stresstests
{
    /// <summary>
    /// Stress tests for expression parsing and evaluation at every thread 
    /// 
    /// @author aksonov
    /// @copyright (c) TopCoder Software Inc. 2003
    /// </summary>
    [TestFixture]
    public class ParseAndEvaluateTests
    {
        /// <summary>
        /// the number of concurrent threads
        /// </summary>
        private const int NUM_TESTS = 100;

        /// <summary>
        /// the number of variables in complex expression
        /// </summary>
        private const int NUM_VAR = 300;

        /// <summary>
        /// test simple expression (without variables)
        /// </summary>
        [Test]
        public void TestSimpleExpression1()
        {
            DoStress(NUM_TESTS, "2+2", null, null, 4);
        }

        /// <summary>
        /// test simple expression (without variables)
        /// </summary>
        [Test]
        public void TestSimpleExpression2()
        {
            DoStress(NUM_TESTS, "2E2", new string[]{}, new double[]{}, 200);
        }

        /// <summary>
        /// test the perfomance for constant expression 
        /// </summary>
        [Test]
        public void TestSimpleExpression3()
        {
            DoStress(NUM_TESTS, "Math.PI", new string[]{}, new double[]{}, System.Math.PI);
        }

        /// <summary>
        /// test the expression with variables x and y
        /// </summary>
        [Test]
        public void TestExpressionWithVariables1()
        {
            DoStress(NUM_TESTS, "300*x+2*(y+Math.PI)", new string[]{"x","y"}, new double[]{5.1, 4.2}, 300*5.1+2*(4.2+System.Math.PI));
        }

        /// <summary>
        /// test the expression with variable x 
        /// </summary>
        [Test]
        public void TestExpressionWithVariables2()
        {
            DoStress(NUM_TESTS, "2*x+3*x+4/x", new string[]{"x"}, new double[]{2}, 12);
        }

        /// <summary>
        /// test the expression with variables x1 and y2
        /// </summary>
        [Test]
        public void TestExpressionWithVariables3()
        {
            DoStress(NUM_TESTS, "210*(x1/(3*y2))", new string[]{"x1","y2"}, new double[]{10,10}, 70);
        }
        /// <summary>
        /// text the complex (long) expression
        /// </summary>
        [Test]
        public void TestComplexExpression()
        {
            string expression = "-x0+3*2-(";
            for (int i=1;i<NUM_VAR;i++)
            {
                if ((i%2)==0)
                {
                    expression+=i.ToString()+"-(";
                } 
                else 
                {
                    expression+=i.ToString()+"+(";
                }
            }
            expression+="123";
            for (int i=1;i<NUM_VAR+1;i++)
            {
                expression+=")";
            }
            DoStress(NUM_TESTS, expression, new string[]{"x0"}, new double[]{10}, 119);
        }

        /// <summary>
        /// Method parses expression, creates count concurrent threads and run expression 
        /// evaluation in every thread and compares actual and expected result.
        /// Also this method calculates running time.
        /// </summary>
        /// <param name="count">the num of threads</param>
        /// <param name="expression">expression</param>
        /// <param name="names">names of variables</param>
        /// <param name="values">values of variables</param>
        /// <param name="answer">expected answer for expression</param>
        static private void DoStress(int count, string expression, string[] names, double[] values, double answer)
        {
            DateTime now = DateTime.Now;
            Thread[] threads = new Thread[count];
            ParseAndEvaluate[] tests = new ParseAndEvaluate[count];
            for (int i=0;i<count;i++)
            {
                tests[i] = new ParseAndEvaluate(expression, names, values);
                threads[i] = new Thread(new ThreadStart(tests[i].HandleThread));
                threads[i].Start();
            }

            for (int i=0;i<count;i++)
            {
                threads[i].Join();
                if (tests[i].Error==null)
                {
                    Assertion.AssertEquals(answer, tests[i].Answer);
                } 
                else 
                {
                    Assertion.Fail("No exception should be:"+tests[i].Error);
                }
            }
            Console.WriteLine("Parse & Evaluate Test. Expression: {0}, Time:{1}", 
                expression, DateTime.Now-now);
        }

        /// <summary>
        /// helpful class for thread running
        /// </summary>
        private class ParseAndEvaluate 
        {
            /// <summary>
            /// expression
            /// </summary>
            private string expression = null;
            /// <summary>
            /// names of variables
            /// </summary>
            private string[] names = null;
            /// <summary>
            /// names of values
            /// </summary>
            private double[] values = null;
            /// <summary>
            /// exception error during execution
            /// </summary>
            private string error = null;
            /// <summary>
            /// actual answer of evaluation
            /// </summary>
            private double answer;

            /// <summary>
            /// constructor
            /// </summary>
            /// <param name="expression">expression</param>
            /// <param name="names">the names of variables</param>
            /// <param name="values">the values of variables</param>
            public ParseAndEvaluate(string expression, string[] names, 
                double[] values)
            {
                this.expression = expression;
                this.values = values;
                this.names = names;
            }

            /// <summary>
            /// property returns the actual result of evaluation
            /// </summary>
            public double Answer 
            {
                get 
                {
                    return this.answer;
                }
            }

            /// <summary>
            /// property return exception thrown during evaluation (if any)
            /// </summary>
            public string Error 
            {
                get 
                {
                    return this.error;
                }
            }
            /// <summary>
            /// runs evaluation of the expression
            /// </summary>
            public void HandleThread()
            {
                try 
                {
                    this.answer = Expression.Parse(expression).Evaluate(names, values);
                } 
                catch (Exception e)
                {
                    this.error = e.Message;
                }
            }

        }

    }
}
