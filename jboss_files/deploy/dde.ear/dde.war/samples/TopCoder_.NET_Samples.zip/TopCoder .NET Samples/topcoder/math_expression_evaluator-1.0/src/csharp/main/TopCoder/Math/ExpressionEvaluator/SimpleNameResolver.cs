/* SimpleNameResolver.cs; 
 * @author kyky
 * Copyright @ 2003, TopCoder, Inc. All rights reserved
 * */
using System;

namespace TopCoder.Math.ExpressionEvaluator {
    /// <summary>
    /// Creates instances of SimpleVariable referencing names passed as a parameter.
    /// </summary>
    class SimpleNameResolver : DefaultNameResolver {
        /// <summary>
        /// Creates an instance of SimpleVariable that references the name
        /// passed as a parameter.
        /// </summary>
        /// <param name="name">Name of the variable.</param>
        /// <returns>An instance of SimpleVariable referencing the name.</returns>
        public override Expression Resolve( string name ) {
            return new SimpleVariable( name );
        }
    }
}
