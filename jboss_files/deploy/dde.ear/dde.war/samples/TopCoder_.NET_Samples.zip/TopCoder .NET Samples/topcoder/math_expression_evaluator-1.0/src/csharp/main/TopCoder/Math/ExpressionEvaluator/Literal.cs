/* Literal.cs; 
 * Copyright @ 2003, TopCoder, Inc. All rights reserved
 * 
 * @authors kyky, mishagam
 * */
using System;

namespace TopCoder.Math.ExpressionEvaluator {
    /// <summary>
    /// An expression that always evaluates to a static value.
    /// </summary>
    public class Literal : Expression {
        /// <summary>
        /// Makes a literal value for use in expressions.
        /// </summary>
        /// <param name="val">An object to be converted to double.</param>
        public Literal( object val ) {
            try {
                this.val = Convert.ToDouble( val );
            } catch ( Exception ) {
                this.val = Double.NaN;
            }
        }
        /// <summary>
        /// Returns the value of this literal.
        /// </summary>
        /// <param name="env">Ignored</param>
        /// <returns>The value of this literal.</returns>
        public override double Evaluate( IEvaluationEnv env) {
            return val;
        }

        /// <summary>
        /// string representation of val number
        /// </summary>
        /// <returns>string representing double val</returns>
        public override string ToString() {
            return "" + val;
        }
        /// <summary>
        /// Value of this literal.
        /// </summary>
        private double val;
    }
}
