using System;
using System.IO;
using NUnit.Framework;
using log4net.Config;
using log4net;
using System.Diagnostics;

namespace TopCoder.LoggingWrapper.AccuracyTests
{
    /// <summary>
    /// Accuracy test cases for both Log4NET and Diagnostic implementation
    /// @author aksonov
    /// </summary>
    [TestFixture]
    public class ComplexImpl
    {
        private static string LOG_NAME = "TestLog";
        
        [SetUp]
        public void StartUp()
        {
            if(EventLog.Exists(LOG_NAME))
                EventLog.Delete(LOG_NAME);

        }
        /// <summary>
        /// Test if a log is of expected type.
        /// </summary>
        [Test]
        public void LogInitializedCorectly()
        {
            LogManager.Configuration = new System.Collections.Specialized.NameValueCollection();        
    //        LogManager.Configuration.Add(LogManager.CLASS_PARAMETER, "TopCoder.LoggingWrapper.DiagnosticImpl");
    //        LogManager.Configuration.Add("Source", LOG_NAME);
    //        LogManager.Configuration.Add("LogName", LOG_NAME);
    //        LogManager.LoadConfiguration();
  //          Assertion.AssertEquals("TopCoder.LoggingWrapper.DiagnosticImpl",LogManager.GetLogger().GetType().FullName);
/****
            LogManager.Configuration = new System.Collections.Specialized.NameValueCollection();        
            LogManager.Configuration.Add(LogManager.CLASS_PARAMETER, "TopCoder.LoggingWrapper.Log4NETImpl");            
            LogManager.Configuration.Add("Log4NetConfiguration", @"conf\log4net.config");
            LogManager.Configuration.Add("LogName", "Test Log");
            Assertion.AssertEquals("TopCoder.LoggingWrapper.Log4NETImpl",LogManager.GetLogger().GetType().FullName);
*/
        }
    }
}


