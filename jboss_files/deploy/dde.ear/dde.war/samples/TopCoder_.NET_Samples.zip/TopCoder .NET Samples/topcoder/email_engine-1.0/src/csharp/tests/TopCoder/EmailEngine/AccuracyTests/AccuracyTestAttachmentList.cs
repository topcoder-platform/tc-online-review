using System;
using NUnit.Framework;
using System.IO;
using System.Diagnostics;


namespace TopCoder.EmailEngine.AccuracyTests
{
    /// <summary>
    /// Accuracy Tests for AttachmentList
    /// @author aksonov
    /// </summary>
    [TestFixture]
    public class AccuracyTestAttachmentList
    {
        /// <summary>
        /// tests adding and removing from list
        /// </summary>
        [Test]
        public void AttachmentListAddRemove()
        {
            AttachmentList list = new AttachmentList();
            Assertion.AssertEquals(0, list.Count);
            list.Add(new Attachment(new FileStream(@"..\..\test_files\attachment1.txt", FileMode.Open, FileAccess.Read, FileShare.Read)));
            Assertion.AssertEquals(1, list.Count);
            list.Add(new Attachment(new FileStream(@"..\..\test_files\attachment2.txt", FileMode.Open, FileAccess.Read, FileShare.Read)));
            Assertion.AssertEquals(2, list.Count);
            list.Clear();
            Assertion.AssertEquals(0, list.Count);
            list.Add(new Attachment(new FileStream(@"..\..\test_files\attachment1.txt", FileMode.Open, FileAccess.Read, FileShare.Read)));
            Assertion.AssertEquals(1, list.Count);
            list.Remove(0);
            Assertion.AssertEquals(0, list.Count);


        }
    }
}