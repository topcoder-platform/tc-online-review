// @author TCSDEVELOPER
// @copyright (c) TopCoder Software
using System;
using System.Collections;
using NUnit.Framework;

namespace TopCoder.Math.ExpressionEvaluator {

    /// <summary>
    /// Additional tests of matheval component - testing difficult 
    /// problems for parser that were not tested in functional tests
    /// author - TCSDEVELOPER
    /// </summary>
    [TestFixture]
    public class UnitTests {

        /// <summary>
        /// Verifies that the parser can process positive integer constants.
        /// </summary>
        [Test]
        public void TestDifficultDoubleLiterals() {
            Expression exp = Expression.Parse("+12.13E1");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 12.13E1", 12.13E1, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", exp is Literal );
            exp = Expression.Parse("+12E1");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 12E1", 12E1, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", exp is Literal );
            exp = Expression.Parse("+.12E1");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to .12E1", .12E1, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", exp is Literal );
            exp = Expression.Parse("-3.12E-1");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -3.12E-1", -3.12E-1, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", exp is Literal );
        }

        /// <summary>
        /// Verifies that parser correctly intepretes variable names like 
        /// _name12.234.i12E
        /// </summary>
        [Test]
        public void TestVariableNames() {
            Expression exp = Expression.Parse("_x.X52.13A");
            Assertion.Assert("Expression must parse", exp != null);
            double dret = exp.Evaluate(new String[]{"_x.X52.13A"}, new Double[]{25.0});
            Assertion.AssertEquals("Expression must evaluate to -2", 25.0, dret);
        }

        /// <summary>
        /// Tests more complex expressions to verify that parser works
        /// </summary>
        [Test]
        public void TestComplexExpression() {
            Expression exp = Expression.Parse("((99+x)*(101-x))/1000");
            Assertion.Assert("Expression must parse", exp != null);
            double dret = exp.Evaluate(new String[]{"x"}, new Double[]{1.0});
            Assertion.AssertEquals("Expression must evaluate to 10", 10.0, dret);
        }

        /// <summary>
        /// Verifies that parser correctly intepretes variable names like 
        /// _name12.234.i12E
        /// </summary>
        [Test]
        public void TestIncorrectVariableNames() {
            try {
                Expression exp = Expression.Parse("1x.X52.13A");
                Assertion.Fail("Should be ExpressionFormatException");
            } catch (ExpressionFormatException efe) {
                Assertion.AssertEquals("Incorrect Exception Message", "Unexpected end of Expression: error at or around x.X52.13A",  efe.Message);
            } catch (Exception e) {
                Assertion.Fail("Should be ExpressionFormaException:" + e);
            }
        }
        /// <summary>
        /// Verifies that the parser can process positive integer constants.
        /// </summary>
        [Test]
        public void TestPositiveIntConstant() {
            Expression exp = Expression.Parse("2222");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 2222", 2222, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", exp is Literal );
        }

        /// <summary>
        /// Verifies that the parser can process negative integer constants.
        /// Checks that the result of the parse is a literal (as opposed to
        /// a Unary Minus operation with a positive literal operand).
        /// </summary>
        [Test]
        public void TestNegativeIntConstant() {
            Expression exp = Expression.Parse("-2312");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -2312", -2312, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", exp is Literal );
        }

        /// <summary>
        /// Verifies that the parser can process positive integer constants with a '+' sign
        /// </summary>
        [Test]
        public void TestForcedPositiveIntConstant() {
            Expression exp = Expression.Parse("+2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 2", 2, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", exp is Literal );
        }

        /// <summary>
        /// Verifies that the parser can process positive constants with real values.
        /// </summary>
        [Test]
        public void TestPositiveDoubleConstant() {
            Expression exp = Expression.Parse("2.3456");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 2.3456", 2.3456, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", exp is Literal );
        }

        /// <summary>
        /// Verifies that the parser can process negative constants with real values.
        /// Checks that the result of the parse is a literal (as opposed to
        /// a Unary Minus operation with a positive literal operand).
        /// </summary>
        [Test]
        public void TestNegativeDoubleConstant() {
            Expression exp = Expression.Parse("-2.3456E-1");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -2.3456E-1", -2.3456E-1, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", exp is Literal );
        }

        /// <summary>
        /// Verifies that the parser can process positive constants
        /// with real values and a '+' sign
        /// </summary>
        [Test]
        public void TestForcedPositiveDoubleConstant() {
            Expression exp = Expression.Parse("+2.3456E2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 2.3456E2", 2.3456E2, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", exp is Literal );
        }

        /// <summary>
        /// Verifies that the parser can process positive constants with real values
        /// specified using the "scientific" notation.
        /// </summary>
        [Test]
        public void TestPositiveScientificConstant() {
            Expression exp = Expression.Parse(".23456E1");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to .23456E1", .23456E1, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", exp is Literal );
        }

        /// <summary>
        /// Verifies that the parser can process the built-in constant for 'PI'
        /// </summary>
        [Test]
        public void TestConstantPI() {
            Expression exp = Expression.Parse("Math.PI");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to PI", System.Math.PI, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", exp is Literal );
        }

        /// <summary>
        /// Verifies that the parser can process the built-in constant for 'E'
        /// </summary>
        [Test]
        public void TestConstantE() {
            Expression exp = Expression.Parse("Math.E");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to E", System.Math.E, exp.Evaluate());
            Assertion.Assert("Expression must parse to a literal", exp is Literal );
        }

        /// <summary>
        /// Verifies that the system deals with unary negation correctly.
        /// </summary>
        [Test]
        public void TestUnaryMinus() {
            Expression exp = Expression.Parse("-X");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -5.4321", -5.4321, exp.Evaluate(new string[] {"X"}, new double[] {5.4321}));
        }

        /// <summary>
        /// Verifies that the system deals with logical unary negation correctly.
        /// </summary>
        [Test]
        public void TestUnaryNotForTrue() {
            Expression exp = Expression.Parse("!X");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 0, exp.Evaluate(new string[] {"X"}, new double[] {1}));
        }

        /// <summary>
        /// Verifies that the system deals with logical unary negation correctly.
        /// </summary>
        [Test]
        public void TestUnaryNotForFalse() {
            Expression exp = Expression.Parse("!X");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 1, exp.Evaluate(new string[] {"X"}, new double[] {0}));
        }

        /// <summary>
        /// Verifies that the system deals with power operation.
        /// </summary>
        [Test]
        public void TestBinaryPower() {
            Expression exp = Expression.Parse("2^8");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 2^8", 256, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with multiplication.
        /// </summary>
        [Test]
        public void TestBinaryMultiply() {
            Expression exp = Expression.Parse("2*8");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 2*8", 16, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with division
        /// </summary>
        [Test]
        public void TestBinaryDivide() {
            Expression exp = Expression.Parse("2/8");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 2/8", 0.25, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with addition
        /// </summary>
        [Test]
        public void TestBinaryAdd() {
            Expression exp = Expression.Parse("2+8");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 2+8", 10, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with subtraction
        /// </summary>
        [Test]
        public void TestBinarySubtract() {
            Expression exp = Expression.Parse("2-8");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 2-8", -6, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "=="
        /// </summary>
        [Test]
        public void TestBinaryEQTrue() {
            Expression exp = Expression.Parse("2==2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 1, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "=="
        /// </summary>
        [Test]
        public void TestBinaryEQFalse() {
            Expression exp = Expression.Parse("2==8");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 0, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "!="
        /// </summary>
        [Test]
        public void TestBinaryNETrue() {
            Expression exp = Expression.Parse("2!=8");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 1, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "!="
        /// </summary>
        [Test]
        public void TestBinaryNEFalse() {
            Expression exp = Expression.Parse("2!=2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 0, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation ">"
        /// </summary>
        [Test]
        public void TestBinaryGTTrue() {
            Expression exp = Expression.Parse("8>2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 1, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation ">"
        /// </summary>
        [Test]
        public void TestBinaryGTFalse() {
            Expression exp = Expression.Parse("2>2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 0, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation ">="
        /// </summary>
        [Test]
        public void TestBinaryGETrue() {
            Expression exp = Expression.Parse("2>=2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 1, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation ">="
        /// </summary>
        [Test]
        public void TestBinaryGEFalse() {
            Expression exp = Expression.Parse("2>=3");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 0, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "<"
        /// </summary>
        [Test]
        public void TestBinaryLTTrue() {
            Expression exp = Expression.Parse("2<8");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 1, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "<"
        /// </summary>
        [Test]
        public void TestBinaryLTFalse() {
            Expression exp = Expression.Parse("2<2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 0, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "<="
        /// </summary>
        [Test]
        public void TestBinaryLETrue() {
            Expression exp = Expression.Parse("2<=2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 1, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "<="
        /// </summary>
        [Test]
        public void TestBinaryLEFalse() {
            Expression exp = Expression.Parse("3<=2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 0, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "&&"
        /// </summary>
        [Test]
        public void TestBinaryAndTrue() {
            Expression exp = Expression.Parse("2!=3&&3!=2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 1, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "&&"
        /// </summary>
        [Test]
        public void TestBinaryAndFalse() {
            Expression exp = Expression.Parse("2!=3&&3!=3");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 0, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the logical operation "&&" stops evaluation when
        /// it discovers a "false" in the chain.
        /// </summary>
        [Test]
        public void TestBinaryAndShortCircuit() {
            // Note that short-circuiting implementation would never hit the "X!=3" part
            // and therefore would not trigger an exception.
            Expression exp = Expression.Parse("2!=3&&2!=2&&X!=3");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 0, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "||"
        /// </summary>
        [Test]
        public void TestBinaryOrTrue() {
            Expression exp = Expression.Parse("3!=3||3!=2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 1, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with logical operation "||"
        /// </summary>
        [Test]
        public void TestBinaryOrFalse() {
            Expression exp = Expression.Parse("3!=3||2!=2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 0, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system stops evaluation of logical operation "||"
        /// when it discovers a "true" in the chain
        /// </summary>
        [Test]
        public void TestBinaryOrShortCircuit() {
            // Note that short-circuiting implementation would never hit the "X!=3" part
            // and therefore would not trigger an exception.
            Expression exp = Expression.Parse("3!=3||3!=4||X!=2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1", 1, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that "*" evaluates before "+"
        /// </summary>
        [Test]
        public void TestPriority1() {
            Expression exp = Expression.Parse("1+2*3");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1+2*3", 7, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that parentheses force evaluation order.
        /// </summary>
        [Test]
        public void TestPriority2() {
            Expression exp = Expression.Parse("(1+2)*3");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to (1+2)*3", 9, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that "^" evaluates before "/"
        /// </summary>
        [Test]
        public void TestPriority3() {
            Expression exp = Expression.Parse("2^8/4");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 2^8/4", 64, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that parentheses force evaluation order.
        /// </summary>
        [Test]
        public void TestPriority4() {
            Expression exp = Expression.Parse("2^(8/4)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 2^(8/4)", 4, exp.Evaluate());
        }

        /// <summary>
        /// Verifies that parentheses force evaluation order.
        /// </summary>
        [Test]
        public void TestPriority5() {
            Expression exp = Expression.Parse("(((2+3)*4)+5)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to (((2+3)*4)+5)", (((2+3)*4)+5), exp.Evaluate());
        }

        /// <summary>
        /// Verifies that parentheses force evaluation order.
        /// </summary>
        [Test]
        public void TestPriority6() {
            Expression exp = Expression.Parse("(((5+3)/4)+5)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to (((5+3)/4)+5)", (((5+3)/4)+5), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation MIN
        /// </summary>
        [Test]
        public void TestMIN() {
            Expression exp = Expression.Parse("MIN ( 2.5 ,3.0)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to Math.Min(2.5, 3.0)", System.Math.Min(2.5, 3.0), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation MAX
        /// </summary>
        [Test]
        public void TestMAX() {
            Expression exp = Expression.Parse("MAX(2.5, 3.0 )");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate Math.Max(2.5, 3.0)", System.Math.Max(2.5, 3.0), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation SIN
        /// </summary>
        [Test]
        public void TestSIN() {
            Expression exp = Expression.Parse("SIN(PI)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to (((5+3)/4)+5)", System.Math.Sin(System.Math.PI), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation COS
        /// </summary>
        [Test]
        public void TestCOS() {
            Expression exp = Expression.Parse("COS(PI)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to Math.Cos(Math.PI)", System.Math.Cos(System.Math.PI), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation TAN
        /// </summary>
        [Test]
        public void TestTAN() {
            Expression exp = Expression.Parse("TAN(PI/4)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to Math.Tan(Math.PI/4)", System.Math.Tan(System.Math.PI/4), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation ASIN
        /// </summary>
        [Test]
        public void TestASIN() {
            Expression exp = Expression.Parse("ASIN(1)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to Math.Asin(1)", System.Math.Asin(1), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation ACOS
        /// </summary>
        [Test]
        public void TestACOS() {
            Expression exp = Expression.Parse("ACOS(1)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to Math.Acos(1)", System.Math.Acos(1), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation ATAN
        /// </summary>
        [Test]
        public void TestATAN() {
            Expression exp = Expression.Parse("ATAN(1)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to Math.Atan(1)", System.Math.Atan(1), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation EXP
        /// </summary>
        [Test]
        public void TestEXP() {
            Expression exp = Expression.Parse("EXP(2)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to Math.Exp(2)", System.Math.Exp(2), exp.Evaluate());
        }
        /// <summary>
        /// Tests operation EXP
        /// </summary>
        [Test]
        public void TestSQRT() {
            Expression exp = Expression.Parse("SQRT(25)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 5.0", 5.0, exp.Evaluate());
        }

        /// <summary>
        /// Tests operation LOG
        /// </summary>
        [Test]
        public void TestLOG() {
            Expression exp = Expression.Parse("LOG(10)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to Math.Log(10)", System.Math.Log(10), exp.Evaluate());
        }

        /// <summary>
        /// Verifies that the system deals with simple variables correctly
        /// </summary>
        [Test]
        public void TestSimpleVar1() {
            Expression exp = Expression.Parse("A");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1.234", 1.234, exp.Evaluate(new string[]{"A"}, new double[] {1.234}));
        }

        /// <summary>
        /// Verifies that the system deals with simple variables correctly
        /// </summary>
        [Test]
        public void TestSimpleVar2() {
            Expression exp = Expression.Parse("A");
            Assertion.Assert("Expression must parse", exp != null);
            Hashtable ht = new Hashtable();
            ht["A"] = 1.234;
            Assertion.AssertEquals("Expression must evaluate to 1.234", 1.234, exp.Evaluate(ht));
        }

        /// <summary>
        /// Checks the ToString operator
        /// </summary>
        [Test]
        public void TestToString1() {
            Expression exp = Expression.Parse("1+2");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must convert to string \"(1+2)\"", "(1+2)", exp.ToString());
        }

        /// <summary>
        /// Checks the ToString operator
        /// </summary>
        [Test]
        public void TestToString2() {
            Expression exp = Expression.Parse("1+2+3");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must convert to string \"((1+2)+3)\"", "((1+2)+3)", exp.ToString());
        }

        /// <summary>
        /// Checks the ToString operator
        /// </summary>
        [Test]
        public void TestToString3() {
            Expression exp = Expression.Parse("(((5+3)/4)+5)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must convert to string \"(((5+3)/4)+5)\"", "(((5+3)/4)+5)", exp.ToString());
        }

        /// <summary>
        /// Verifies that parsing invalid expressions throws exceptions.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.ExpressionFormatException))]
        public void TestInvalidParse1() {
            Expression.Parse("(");
        }

        /// <summary>
        /// Verifies that parsing invalid expressions throws exceptions.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.ExpressionFormatException))]
        public void TestInvalidParse2() {
            Expression.Parse(")");
        }

        /// <summary>
        /// Verifies that parsing invalid expressions throws exceptions.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.ExpressionFormatException))]
        public void TestInvalidParse3() {
            Expression.Parse("()");
        }

        /// <summary>
        /// Verifies that parsing invalid expressions throws exceptions.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.ExpressionFormatException))]
        public void TestInvalidParse4() {
            Expression.Parse("(2+3");
        }

        /// <summary>
        /// Verifies that parsing invalid expressions throws exceptions.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.ExpressionFormatException))]
        public void TestInvalidParse5() {
            Expression.Parse("+");
        }

        /// <summary>
        /// Verifies that parsing invalid expressions throws exceptions.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.ExpressionFormatException))]
        public void TestInvalidParse6() {
            Expression.Parse("(2+3+4+5)*(1+2+3+4))");
        }

        /// <summary>
        /// Verifies that parsing invalid expressions throws exceptions.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.ExpressionFormatException))]
        public void TestInvalidParse7() {
            Expression.Parse("2E3+3E");
        }

        /// <summary>
        /// Verifies that parsing invalid expressions throws exceptions.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.ExpressionFormatException))]
        public void TestInvalidParse8() {
            Expression.Parse("123X + &^!%&@#^%@&^#@%&#^%@!#&!^@%#");
        }

        /// <summary>
        /// Verifies that expressions with unresolved variables parse, but throw exceptions at
        /// the attempt to evaluate them.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.UnresolvedVariableException))]
        public void TestUndefinedVar1() {
            Expression exp = Expression.Parse("A");
            Assertion.Assert("Expression must parse", exp != null);
            exp.Evaluate();
        }

        /// <summary>
        /// Verifies that expressions with unresolved variables parse, but throw exceptions at
        /// the attempt to evaluate them.
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.UnresolvedVariableException))]
        public void TestUndefinedVar2() {
            Expression exp = Expression.Parse("A+B+C");
            Assertion.Assert("Expression must parse", exp != null);
            exp.Evaluate(new string[] {"A","B"}, new double[] {1,2});
        }

        /// <summary>
        /// Verifies that variable names are case-sensitive
        /// </summary>
        [Test]
        [ExpectedException(typeof(TopCoder.Math.ExpressionEvaluator.UnresolvedVariableException))]
        public void TestUndefinedVar3() {
            // Variable names are case-sensitive
            Expression exp = Expression.Parse("A");
            Assertion.Assert("Expression must parse", exp != null);
            exp.Evaluate(new string[] {"a"}, new double[] {1});
        }

        /// <summary>
        /// Verifies that lower-case variable names are allowed
        /// </summary>
        [Test]
        [ExpectedException(typeof(System.ArgumentException))]
        public void TestInvalidCall1() {
            Expression exp = Expression.Parse("a");
            Assertion.Assert("Expression must parse", exp != null);
            exp.Evaluate(new string[] {"a"}, new double[] {1,2,3});
        }

        /// <summary>
        /// Verifies that Expression's Evaluate checks its arguments for null
        /// </summary>
        [Test]
        [ExpectedException(typeof(System.ArgumentNullException))]
        public void TestInvalidCall2() {
            Expression exp = Expression.Parse("a");
            Assertion.Assert("Expression must parse", exp != null);
            exp.Evaluate(new string[] {"a"}, null);
        }

        /// <summary>
        /// Verifies that Expression's Evaluate checks its arguments for null
        /// </summary>
        [Test]
        [ExpectedException(typeof(System.ArgumentNullException))]
        public void TestInvalidCall3() {
            Expression exp = Expression.Parse("a");
            Assertion.Assert("Expression must parse", exp != null);
            exp.Evaluate(null, new double[0]);
        }

        /// <summary>
        /// Tests that Parser issues correct Exceptions in the case of 
        /// malformed Expression
        /// </summary>
        [Test]
        public void testExpressionFormatExceptions() {
            Expression exp = null;
            // testing bracket after function1
            try {
                exp = Expression.Parse("log 0");
                Assertion.Fail("There should be ExpressionFormatException");
            } catch (ExpressionFormatException efe) {
                Assertion.AssertEquals("Incorrect Expression message",
                    "Function LOG must be followed by an open parenthesis",
                    efe.Message);
            } catch (Exception e) {
                Assertion.Fail("There should be ExpressionFormatException:" + e.Message);
            }
            // testing bracket after function2
            try {
                exp = Expression.Parse("max 0,1)");
                Assertion.Fail("There should be ExpressionFormatException");
            } catch (ExpressionFormatException efe) {
                Assertion.AssertEquals("Incorrect Expression message",
                    "Function MAX must be followed by an open parenthesis",
                    efe.Message);
            } catch (Exception e) {
                Assertion.Fail("There should be ExpressionFormatException: " + e.Message);
            }
            // testing closing bracket after function1
            try {
                exp = Expression.Parse("log(0 0");
                Assertion.Fail("There should be ExpressionFormatException");
            } catch (ExpressionFormatException efe) {
                Assertion.AssertEquals("Incorrect Expression message",
                    "The last argument of the function LOG must be followed by a closing parenthesis",
                    efe.Message);
            } catch (Exception e) {
                Assertion.Fail("There should be ExpressionFormatException: " + e.Message);
            }
            // testing closing bracket after function2
            try {
                exp = Expression.Parse("max(0,1");
                Assertion.Fail("There should be ExpressionFormatException");
            } catch (ExpressionFormatException efe) {
                Assertion.AssertEquals("Incorrect Expression message",
                    "The last argument of the function MAX must be followed by a closing parenthesis",
                    efe.Message);
            } catch (Exception e) {
                Assertion.Fail("There should be ExpressionFormatException, but was: " + e.Message);
            }
            // testing comma between argumnents in  function2
            try {
                exp = Expression.Parse("max(0 1)");
                Assertion.Fail("There should be ExpressionFormatException");
            } catch (ExpressionFormatException efe) {
                Assertion.AssertEquals("Incorrect Expression message",
                    "Arguments of function MAX must be separated with commas",
                    efe.Message);
            } catch (Exception e) {
                Assertion.Fail("There should be ExpressionFormatException, but was: " + e.Message);
            }
            // testing missing right parenthesis
            try {
                exp = Expression.Parse("3*(a + b");
                Assertion.Fail("There should be ExpressionFormatException");
            } catch (ExpressionFormatException efe) {
                Assertion.AssertEquals("Incorrect Expression message",
                    "Malformed expression: missing right parenthesis",
                    efe.Message);
            } catch (Exception e) {
                Assertion.Fail("There should be ExpressionFormatException, but was: " + e.Message);
            }
        }
    }
}
