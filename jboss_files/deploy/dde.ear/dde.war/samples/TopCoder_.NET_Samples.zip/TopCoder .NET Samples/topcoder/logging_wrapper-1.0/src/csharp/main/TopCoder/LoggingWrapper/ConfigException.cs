// @author Mikhail_T
// @copyright (c) TopCoder Software 2003


using System;

namespace TopCoder.LoggingWrapper
{
    /// <summary>
    /// Exception class for all errors in configuration    
    /// </summary>
    public class ConfigException : System.Exception
    {
        /// <summary>
        /// Initializes a new instance of the ConfigException class
        /// </summary>
        public ConfigException() : base()
        {
        }

        /// <summary>
        /// Initializes a new instance of the ConfigException class with defined message
        /// </summary>
		/// <param name="message">Error message for the user.</param>
        public ConfigException(string message) : base(message)
        {
        }
    }
}
