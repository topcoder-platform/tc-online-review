using System;
using System.Text;
using System.Collections;

// @author CLoris
// @copyright 2003 (c) TopCoder Software

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// Provides properties and methods for constructing an attachment.
    /// </summary>
    public class AttachmentList 
    {
        // constants
        private const string ATTACH_MIME_NEXT_PART = "--NextMimePart--";

        private const string ERR_NULL_ATTACH = "Can not add a null attachment to the AttachmentList.";
        // end constants
        
        private ArrayList list = new ArrayList();
        
        /// <summary>
        /// property from Attachment objects retrieving from the list
        /// </summary>
        /// <returns>
        /// Attachment object referred to by the provided index.
        /// </returns>
        /// <exception cref="ArgumentOutOfRangeException">Thrown if invalid index provided.</exception>
        public Attachment this[int index] 
        {
            get 
            {
                return (Attachment)list[index];
            }
        }

        /// <summary>
        /// Gets the number of elements contained in the list
        /// </summary>
        /// <returns>
        /// Returns the count of objects pressent in the list.
        /// </returns>
        public int Count 
        {
            get 
            {
                return list.Count;
            }
        }
        /// <summary>
        /// Constructor of AttachmentList class
        /// </summary>
        public AttachmentList()
        {
        }

        /// <summary>
        /// Adds Attachment object into the list
        /// </summary>
        /// <param name="att">Attachment object</param>
        /// <exception cref="AttachmentErrorException">Thrown if null Attachment provided.</exception>
        public void Add(Attachment att)
        {
            if(att == null)
            {
                throw new AttachmentErrorException(ERR_NULL_ATTACH);
            }
            else
            {
                list.Add(att);
            }
        }

        /// <summary>
        /// Removes Attachment object with specific index from the list
        /// throws ArgumentOutOfRangeException if error happens.
        /// </summary>
        /// <param name="index">index</param>
        /// <exception cref="ArgumentOutOfRangeException">Thrown if invalid index provided.</exception>
        public void Remove(int index)
        {
            list.RemoveAt(index);
        }

        /// <summary>
        /// Clears the list
        /// </summary>
        public void Clear()
        {
            list.Clear();
        }

        /// <summary>
        /// Encodes the list of attachments into string
        /// </summary>
        /// <returns>result string</returns>
        public override string ToString()
        {
            StringBuilder data = new StringBuilder();

            // visit each attachment and get its encoded string
            for(int loop = 0; loop < list.Count; loop++)
            {
                data.Append( ((Attachment)list[loop]).ToString() );
            }
            if(list.Count > 0)
            {
                data.Append(ATTACH_MIME_NEXT_PART);
            }
            return data.ToString();
        }
    }
}
