using System;

// @author CLoris
// @copyright 2003 (c) TopCoder Software

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// The main class of the component, allows to send emails directly from application code
    /// </summary>
    public class EmailEngine 
    {
        // constants
        private const string ERR_REQUIRE_EMAILSENDER = "EmailEngine requires an EmailSender to be specified prior to calling SendMessage.";
            private const string ERR_REQUIRE_MESSAGE = "EmailEngine requires a Message to be specified prior to calling SendMessage.";
                // end constants
        
        private IEmailSender sender;

        /// <summary>
        /// Class that send emails, should implement IEmailSender interface
        /// </summary>
        public IEmailSender EmailSender
        {
            get 
            {
                return sender;
            }

            set 
            {
                sender = value;
            }
        }

        /// <summary>
        /// Emtpy EmailEngine constructor
        /// </summary>
        public EmailEngine()
        {
            // assign SmtpProtocol by default
            this.sender = new SmtpProtocol();
        }

        /// <summary>
        /// EmailEngine Constructor with defined sender
        /// </summary>
        /// <param name="emailsender">object of class which implement IEmailSender interface</param>
        public EmailEngine(IEmailSender emailsender)
        {
            this.EmailSender = emailsender;
        }

        /// <summary>
        /// Sends email (the Message object) to defined EmailSender object
        /// throws SendException if EmailSender is not defined is not correct
        /// throws MessageErrorException if Message is not defined or is not correct
        /// </summary>
        /// <param name="message">Email (Message object)</param>
        /// <exception cref="MessageErrorException">Thrown if null message provided.</exception>
        /// <exception cref="SendException">Thrown if null emailsender provided.</exception>
        public void SendMessage(Message message)
        {
            // ensure we have an EmailSender
            if (this.EmailSender == null)
            {
                throw new SendException(ERR_REQUIRE_EMAILSENDER);
            }

            // ensure a message object is specified
            if (message==null)
            {
                throw new MessageErrorException(ERR_REQUIRE_MESSAGE);
            }

            // everything looks good - let's send the message
            this.EmailSender.SendEmail(message);
        
        }

    }
}
