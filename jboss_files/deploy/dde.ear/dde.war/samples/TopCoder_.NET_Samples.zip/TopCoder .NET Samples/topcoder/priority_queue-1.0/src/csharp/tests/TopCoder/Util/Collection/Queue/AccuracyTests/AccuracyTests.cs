// Author mathgodleo

using System;
using TopCoder.Util.Collection.Queue;
using System.Collections;
using System.Threading;

namespace TopCoder.Util.Collection.Queue.AccuracyTests
{
    using NUnit.Framework;

    /// <summary>
    /// AccuracyTests for the Priority Queue implementation
    /// </summary>
    [TestFixture]
    public class AccuracyTests
    {
        private PriorityQueue pq;

        /// <summary>
        /// Sets up priority queue.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            pq = new PriorityQueue();
        }
        
        /// <summary>
        /// test that enqueue, dequeue and peek work
        /// </summary>
        [Test]
        public void testEnqueueDequeuePeek(){
            pq.Clear();
            
            pq.Enqueue(1);
            pq.Enqueue(17);
            pq.Enqueue(-10);
            pq.Enqueue(-1111);
            pq.Enqueue(5);

            Assertion.AssertEquals(5, pq.Count);

            Assertion.AssertEquals(17, pq.Peek());
            Assertion.AssertEquals(17, pq.Dequeue());
            Assertion.AssertEquals(5, pq.Peek());
            Assertion.AssertEquals(5, pq.Dequeue());
            Assertion.AssertEquals(1, pq.Peek());
            Assertion.AssertEquals(1, pq.Dequeue());
            Assertion.AssertEquals(-10, pq.Peek());
            Assertion.AssertEquals(-10, pq.Dequeue());
            Assertion.AssertEquals(-1111, pq.Peek());
            Assertion.AssertEquals(-1111, pq.Dequeue());

            Assertion.AssertEquals(0, pq.Count);
        }

        /// <summary>
        /// test that enqueue with a specified priority works
        /// </summary>
        [Test]
        public void testEnqueueWithPriority(){
            pq.Clear();

            pq.Enqueue("World", 1);
            pq.Enqueue("Hello", 2);
            pq.Enqueue("!!!", 0);

            Assertion.AssertEquals("Hello", pq.Dequeue());
            Assertion.AssertEquals("World", pq.Dequeue());
            Assertion.AssertEquals("!!!", pq.Dequeue());
            
            Assertion.AssertEquals(0, pq.Count);
        }

        /// <summary>
        /// test that ToArray works
        /// </summary>
        [Test]
        public void testToArray(){
            pq.Clear();
            pq.Enqueue(5);
            pq.Enqueue(3);
            pq.Enqueue(1);
            pq.Enqueue(4);
            pq.Enqueue(2);
            
            Assertion.AssertEquals(5, pq.Count);

            object[] array = pq.ToArray();

            Assertion.AssertEquals(array[0], pq.Dequeue());
            Assertion.AssertEquals(array[1], pq.Dequeue());
            Assertion.AssertEquals(array[2], pq.Dequeue());
            Assertion.AssertEquals(array[3], pq.Dequeue());
            Assertion.AssertEquals(array[4], pq.Dequeue());

            Assertion.AssertEquals(0, pq.Count);
        }
    
        /// <summary>
        /// test that CopyTo works
        /// </summary>
        [Test]
        public void testCopyTo(){
            pq.Clear();
            pq.Enqueue(5);
            pq.Enqueue(3);
            pq.Enqueue(1);
            pq.Enqueue(4);
            pq.Enqueue(2);
            
            Assertion.AssertEquals(5, pq.Count);

            object[] array = new object[5];
            pq.CopyTo(array, 0);

            Assertion.AssertEquals(array[0], pq.Dequeue());
            Assertion.AssertEquals(array[1], pq.Dequeue());
            Assertion.AssertEquals(array[2], pq.Dequeue());
            Assertion.AssertEquals(array[3], pq.Dequeue());
            Assertion.AssertEquals(array[4], pq.Dequeue());

            Assertion.AssertEquals(0, pq.Count);
        }

        /// <summary>
        /// test that Contains works
        /// </summary>
        [Test]
        public void testContains(){
            pq.Clear();

            pq.Enqueue("World", 1);
            pq.Enqueue("Hello", 2);
            pq.Enqueue("!!!", 0);

            Assertion.Assert(pq.Contains("Hello"));
            Assertion.Assert(pq.Contains("World"));
            Assertion.Assert(pq.Contains("!!!"));
            Assertion.Assert(!pq.Contains("!!"));
            Assertion.Assert(!pq.Contains(""));
            Assertion.Assert(!pq.Contains(null));

            Assertion.AssertEquals(3, pq.Count);
        }

        /// <summary>
        /// test that Clone works
        /// </summary>
        [Test]
        public void testClone(){
            pq.Clear();
            
            pq.Enqueue(5);
            pq.Enqueue(3);
            pq.Enqueue(1);
            pq.Enqueue(4);
            pq.Enqueue(2);

            PriorityQueue pq2 = (PriorityQueue) pq.Clone();

            Assertion.AssertEquals(5, pq2.Count);
            Assertion.AssertEquals(5, pq.Count);

            Assertion.AssertEquals(pq2.Dequeue(), pq.Dequeue());
            Assertion.AssertEquals(pq2.Dequeue(), pq.Dequeue());
            Assertion.AssertEquals(pq2.Dequeue(), pq.Dequeue());
            Assertion.AssertEquals(pq2.Dequeue(), pq.Dequeue());
            Assertion.AssertEquals(pq2.Dequeue(), pq.Dequeue());

            Assertion.AssertEquals(0, pq2.Count);
            Assertion.AssertEquals(0, pq.Count);
        }
    
        /// <summary>
        /// test that Enumerators work
        /// </summary>
        [Test]
        public void testEnumerator(){
            pq.Clear();
            
            pq.Enqueue(5);
            pq.Enqueue(3);
            pq.Enqueue(1);
            pq.Enqueue(4);
            pq.Enqueue(2);

            int expected = 5;
            foreach(int num in pq)
            {
                Assertion.AssertEquals(expected--, num);
            }            

            Assertion.AssertEquals(5, pq.Count);
        }
    
        /// <summary>
        /// test that Enumerators work
        /// </summary>
        [Test]
        public void testEnumerator2(){
            pq.Clear();
            
            pq.Enqueue(5);
            pq.Enqueue(3);
            pq.Enqueue(1);
            pq.Enqueue(4);
            pq.Enqueue(2);

            IEnumerator enumerator = pq.GetEnumerator();
            for (int i = 5; i >= 1; i--) {
                enumerator.MoveNext();
                Assertion.AssertEquals(i, enumerator.Current);
            }
        }


        // number of operations each thread executes
        private int NUM_THREAD_OPS = 50000;

        // number of threads executing
        private int NUM_THREADS = 10;

        /// <summary>
        /// Enqueues NUM_THREAD_OPS items into the priority queue.
        /// </summary>
        private void Enqueue(){
            for (int i = 0; i < NUM_THREAD_OPS; i++) {
                pq.Enqueue(i);
            }
        }

        /// <summary>
        /// Enqueues NUM_THREAD_OPS items into the priority queue.
        /// </summary>
        private void Dequeue(){
            for (int i = 0; i < NUM_THREAD_OPS; i++) {
                pq.Dequeue();
            }
        }

        /// <summary>
        /// Tests the priority queue with synchronization
        /// </summary>
        [Test]
        public void testThreading1(){
            pq.Clear();
            pq = PriorityQueue.Synchronized(pq);
            
            Thread[] threads = new Thread[NUM_THREADS];
            
            for (int i = 0; i < NUM_THREADS; i++)
                threads[i] = new Thread(new ThreadStart(Enqueue));
            
            for (int i = 0; i < NUM_THREADS; i++) {
                threads[i].Start();
            }

            for (int i = 0; i < NUM_THREADS; i++) {
                threads[i].Join();
            }

            Assertion.AssertEquals(NUM_THREAD_OPS * NUM_THREADS, pq.Count);

            for (int i = NUM_THREAD_OPS - 1; i >= 0; i--) {
                for (int j = 0; j < NUM_THREADS; j++) {
                    Assertion.AssertEquals(i, pq.Dequeue());
                }
            }

            pq = (PriorityQueue) pq.SyncRoot;
        }

        /// <summary>
        /// Tests the priority queue with synchronization
        /// </summary>
        [Test]
        public void testThreading2(){
            pq.Clear();
            pq = PriorityQueue.Synchronized(pq);
            
            Thread[] threads = new Thread[NUM_THREADS];
            
            for (int i = 0; i < NUM_THREADS; i++)
                threads[i] = new Thread(new ThreadStart(Enqueue));
            
            for (int i = 0; i < NUM_THREADS; i++) {
                threads[i].Start();
            }

            for (int i = 0; i < NUM_THREADS; i++) {
                threads[i].Join();
            }

            Assertion.AssertEquals(NUM_THREAD_OPS * NUM_THREADS, pq.Count);

            for (int i = 0; i < NUM_THREADS; i++)
                threads[i] = new Thread(new ThreadStart(Dequeue));
            
            for (int i = 0; i < NUM_THREADS; i++) {
                threads[i].Start();
            }

            for (int i = 0; i < NUM_THREADS; i++) {
                threads[i].Join();
            }

            Assertion.AssertEquals(0, pq.Count);

            pq = (PriorityQueue) pq.SyncRoot;
        }

        /// <summary>
        /// Used to sort elements in reverse order.
        /// </summary>
        private class Reverse : IComparer
        {
            /// <summary>
            /// Compares o1 to o2 and returns the negation of the result.
            /// </summary>
            /// <param name="o1">1st object to compare</param>
            /// <param name="o2">2nd object to compare</param>
            /// <returns>the opposite of o1.CompareTo(o2)</returns>
            public int Compare(object o1, object o2)
            {
                return ((IComparable)o2).CompareTo(o1);
            }
        }


        /// <summary>
        /// Test that constructors work as expected.
        /// </summary>
        [Test]
        public void testConstructors(){
            PriorityQueue pq1 = new PriorityQueue();
            Assertion.AssertEquals(pq1.Count, 0);
            
            ArrayList list = new ArrayList();
            list.Add(5);
            list.Add(3);
            list.Add(4);
            list.Add(6);
            PriorityQueue pq2 = new PriorityQueue(list);
            Assertion.AssertEquals(6, pq2.Dequeue());
            Assertion.AssertEquals(5, pq2.Dequeue());
            Assertion.AssertEquals(4, pq2.Dequeue());
            Assertion.AssertEquals(3, pq2.Dequeue());

            PriorityQueue pq3 = new PriorityQueue(new Reverse());
            pq3.Enqueue(5);
            pq3.Enqueue(3);
            pq3.Enqueue(4);
            pq3.Enqueue(6);

            Assertion.AssertEquals(3, pq3.Dequeue());
            Assertion.AssertEquals(4, pq3.Dequeue());
            Assertion.AssertEquals(5, pq3.Dequeue());
            Assertion.AssertEquals(6, pq3.Dequeue());

            PriorityQueue pq4 = new PriorityQueue(list, new Reverse());
        
            Assertion.AssertEquals(3, pq4.Dequeue());
            Assertion.AssertEquals(4, pq4.Dequeue());
            Assertion.AssertEquals(5, pq4.Dequeue());
            Assertion.AssertEquals(6, pq4.Dequeue());      
        }

        /// <summary>
        /// Tests that a poorly chosen growth factor is well handled.
        /// </summary>
        [Test]
        public void testConstructorError(){
            PriorityQueue tmp = new PriorityQueue(10, (float)1.000001);

            // shouldn't throw an exception
            for (int i = 0; i < 15; i++) {
                tmp.Enqueue(1);
            }

        }
    }
}
