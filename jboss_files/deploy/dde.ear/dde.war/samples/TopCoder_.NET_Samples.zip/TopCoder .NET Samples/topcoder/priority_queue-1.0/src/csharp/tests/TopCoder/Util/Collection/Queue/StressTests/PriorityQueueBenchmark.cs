/*
Copyright c 2003, TopCoder, Inc. All rights reservedusing System;
Author pzhao
*/

using System;
using System.Collections;

using TopCoder.Util.Collection.Queue;

using NUnit.Framework;

namespace TopCoder.Util.Collection.Queue.StressTests
{
    /// <summary>
    /// Test the benchmark of PriorityQueue class
    /// </summary>
    [TestFixture]
    public class PriorityQueueBenchmark
    {
        private AbstractBenchmark test1;
        private AbstractBenchmark test2;
        private AbstractBenchmark test3;
        private AbstractBenchmark test4;
        private AbstractBenchmark test5;
        private AbstractBenchmark test6;

        /// <summary>
        /// Test the Enqueue and Dequeue methods
        /// </summary>
        [Test]
        public void EnqueueDequeueBenchmark()
        {
            test1 = new TestEnqueueDequeue();
            test1.RunOnce();
            test1.RunBenchmark(10);
        }

        /// <summary>
        /// Test the Constructor
        /// </summary>
        [Test]
        public void ConstructorBenchmark()
        {
            test2 = new TestConstructor();
            test2.RunOnce();
            test2.RunBenchmark(10);
        }

        /// <summary>
        /// Test the Contains method
        /// </summary>
        [Test]
        public void ContainsBenchmark()
        {
            test3 = new TestContains();
            test3.RunOnce();
            test3.RunBenchmark(10);
        }

        /// <summary>
        /// Test the ToArray and CopyTo methods
        /// </summary>
        [Test]
        public void CopyToArrayBenchmark()
        {
            test4 = new TestCopyToArray();
            test4.RunOnce();
            test4.RunBenchmark(10);
        }

        /// <summary>
        /// Test the Clone method
        /// </summary>
        [Test]
        public void CloneBenchmark()
        {
            test5 = new TestClone();
            test5.RunOnce();
            test5.RunBenchmark(10);
        }
        
        /// <summary>
        /// Test the Enumerate method
        /// </summary>
        [Test]
        public void EnumerateBenchmark()
        {
            test6 = new TestEnumerate();
            test6.RunOnce();
            test6.RunBenchmark(10);
            
        }

        /// <summary>
        /// Output the benchmark results
        /// </summary>
        ~PriorityQueueBenchmark()
        {
            test1.OutputResult();
            test2.OutputResult();
            test3.OutputResult();
            test4.OutputResult();
            test5.OutputResult();
            test6.OutputResult();
        }
    }
}
