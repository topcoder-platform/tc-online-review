// @author Mikhail_T
// @copyright (c) TopCoder Software 2003


using System;

namespace TopCoder.LoggingWrapper
{
    /// <summary>
    /// Exception for incorrect pluggable logging implementations  (without implementation of Logger class)
    /// </summary>
    public class InvalidPluginException : System.Exception
    {

        /// <summary>
        /// Initializes a new instance of the InvalidPluginException class
        /// </summary>
        public InvalidPluginException()
        {

        }
    }
}
