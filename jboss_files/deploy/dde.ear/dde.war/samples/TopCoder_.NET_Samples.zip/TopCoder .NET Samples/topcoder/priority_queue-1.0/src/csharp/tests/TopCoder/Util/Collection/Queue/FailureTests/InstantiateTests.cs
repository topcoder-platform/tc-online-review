using System;
using System.Collections;
using NUnit.Framework;
using TopCoder.Util.Collection.Queue;

namespace TopCoder.Util.Collection.Queue.FailureTests
{
    /// <summary>
    /// tests incorrect instantiation of PriorityQueue class
    /// @author aksonov
    /// @copyright TopCoder Software (c) 2003
    /// </summary>
    [TestFixture]
    public class InstantiateTests 
    {
        /// <summary>
        /// tests incorrect instantiation (pass null collection)
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void InstantiationNullCollection1()
        {
            PriorityQueue queue = new PriorityQueue((ICollection)null);
        }
        /// <summary>
        /// tests incorrect instantiation (pass null collection)
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void InstantiationNullCollection2()
        {
            PriorityQueue queue = new PriorityQueue((ICollection)null, Comparer.Default);
        }
        /// <summary>
        /// tests incorrect instantiation (pass incorrect collection)
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidCastException))]
        public void InstantiationWrongCollection1()
        {
            PriorityQueue queue = new PriorityQueue(new object[]{"a",new PriorityQueue()}, null);
        }
        /// <summary>
        /// tests incorrect instantiation (pass incorrect collection and defined comparer
        /// that throws exception because of invalid collection)
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void InstantiationWrongCollection2()
        {
            PriorityQueue queue = new PriorityQueue(new object[]{"3",4}, Comparer.Default);
        }

        /// <summary>
        /// tests incorrect instantiation (pass comparer that always throws exception)
        /// </summary>
        [Test]
        [ExpectedException(typeof(Exception))]
        public void InstantiationWrongCollection3()
        {
            PriorityQueue queue = new PriorityQueue(new object[]{3,4}, new InvalidComparer());
        }

        /// <summary>
        /// tests incorrect instantiation (invalid capacity)
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void InstantiationInvalidCapacity1()
        {
            PriorityQueue queue = new PriorityQueue(-1);
        }

        /// <summary>
        /// tests incorrect instantiation (invalid capacity)
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void InstantiationInvalidCapacity2()
        {
            PriorityQueue queue = new PriorityQueue(-1, null);
        }

        /// <summary>
        /// tests incorrect instantiation (invalid grow factor)
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void InstantiationInvalidGrowFactor1()
        {
            PriorityQueue queue = new PriorityQueue(1, 0.99f);
        }

        /// <summary>
        /// tests incorrect instantiation (invalid grow factor)
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void InstantiationInvalidGrowFactor2()
        {
            PriorityQueue queue = new PriorityQueue(1, 10.1f);
        }
        /// <summary>
        /// tests incorrect instantiation (invalid grow factor)
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void InstantiationInvalidGrowFactor3()
        {
            PriorityQueue queue = new PriorityQueue(1, 0.99f, Comparer.Default);
        }

        /// <summary>
        /// tests incorrect instantiation (invalid grow factor)
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void InstantiationInvalidGrowFactor4()
        {
            PriorityQueue queue = new PriorityQueue(1, 10.1f, null);
        }
    }
    /// <summary>
    /// invalid comparer
    /// </summary>
    public class InvalidComparer : IComparer 
    {
        /// <summary>
        /// compare method
        /// </summary>
        public int Compare(object a, object b)
        {
            throw new Exception();
        }
    }
}
