/*
Copyright c 2003, TopCoder, Inc. All rights reservedusing System;
Author pzhao
*/

using System;
using System.Collections;

using TopCoder.Util.Collection.Queue;

using NUnit.Framework;

namespace TopCoder.Util.Collection.Queue.StressTests
{
    /// <summary>
    /// Test the Enqueue and Dequeue methods using a large number of objects
    /// </summary>
    public class TestEnqueueDequeue : AbstractBenchmark
    {
        private PriorityQueue pq;

        /// <summary>
        /// Initialize the test
        /// </summary>
        public TestEnqueueDequeue() : base("Test Enqueue and Dequeue")
        {
            pq = new PriorityQueue();
        }

        /// <summary>
        /// Run once of the benchmark test.
        /// </summary>
        public override void RunOnce()
        {
            int i;

            // Enqueue without priority
            for (i = 0; i < 10000; i++)
            {
                pq.Enqueue(i);
                Assertion.AssertEquals("Count property after enqueue:", i+1, pq.Count);
                Assertion.AssertEquals("Peek result after enqueue:", i, pq.Peek());
            }
            
            // Dequeue
            for (i = 0; i < 10000; i++)
            {
                Assertion.AssertEquals("Dequeue result 1:", 10000-i-1, pq.Dequeue());
                Assertion.AssertEquals("Count property after dequeue:", 10000-i-1, pq.Count);
            }

            // Enqueue with priority
            for (i = 0; i < 10000; i++)
            {
                pq.Enqueue(i, 10000-i);
                Assertion.AssertEquals("Count property after enqueue:", i+1, pq.Count);
                Assertion.AssertEquals("Peek result after enqueue:", 0, pq.Peek());
            }
            
            // Dequeue
            for (i = 0; i < 10000; i++)
            {
                Assertion.AssertEquals("Dequeue result 2:", i, pq.Dequeue());
                Assertion.AssertEquals("Count property after dequeue:", 10000-i-1, pq.Count);
            }
        }
    }

    /// <summary>
    /// Test the constructor using a large loop and collection
    /// </summary>
    public class TestConstructor : AbstractBenchmark
    {
        private PriorityQueue pq;

        /// <summary>
        /// Initialize the test
        /// </summary>
        public TestConstructor() : base("Test Constructor")
        {
        }

        /// <summary>
        /// Run once of the benchmark test.
        /// </summary>
        public override void RunOnce()
        {
            int[] objs = null;
            int i;

            // Initial Count
            pq = new PriorityQueue();
            Assertion.AssertEquals("Count property 1:", 0, pq.Count);

            // Construct with large collection
            objs = new int[10000];
            for (i = 0; i < 10000; i++)
            {
                objs[i] = (i + 9999) % 10000;
            }
            pq = new PriorityQueue(objs);
            Assertion.AssertEquals("Count property 2:", 10000, pq.Count);
     
            // Dequeue
            for (i = 0; i < 10000; i++)
            {
                Assertion.AssertEquals("Dequeue result:", 10000-i-1, pq.Dequeue());
            }
        }
    }

    /// <summary>
    /// Test the Contains method using a large loop and collection
    /// </summary>
    public class TestContains : AbstractBenchmark
    {
        private PriorityQueue pq;

        /// <summary>
        /// Initialize the test
        /// </summary>
        public TestContains() : base("Test Contains")
        {
            string obj = null;

            pq = new PriorityQueue();

            // Enqueue a large number of strings 
            for (int i = 0; i < 1000; i++)
            {
                obj = (i*2).ToString();
                pq.Enqueue(obj);
            }
        }

        /// <summary>
        /// Run once of the benchmark test.
        /// </summary>
        public override void RunOnce()
        {
            string obj = null;
            
            // Check the Contains method
            for (int i = 0; i < 2000; i++)
            {
                obj = i.ToString();
                Assertion.AssertEquals("Contains result:", i % 2 == 0, pq.Contains(obj));
            }
        }
    }

    /// <summary>
    /// Test the ToArray and CopyTo method using a large loop and collection
    /// </summary>
    public class TestCopyToArray : AbstractBenchmark
    {
        private PriorityQueue pq;

        /// <summary>
        /// Initialize the test
        /// </summary>
        public TestCopyToArray() : base("Test ToArray and CopyTo")
        {
            pq = new PriorityQueue();

            // Enqueue a large number of numbers 
            for (int i = 0; i < 10000; i++)
            {
                pq.Enqueue((i % 3 == 0) ? 10000-i-1 : i);
            }
        }

        /// <summary>
        /// Run once of the benchmark test.
        /// </summary>
        public override void RunOnce()
        {
            object[] objs = null;
            int i;

            // ToArray method
            objs = pq.ToArray();

            // Check the Count
            Assertion.AssertEquals("Count:", 10000, objs.Length);
            
            // Check the elements
            for (i = 0; i < 10000; i++)
            {
                Assertion.AssertEquals("Elements:", 10000-i-1, (int)objs[i]);
            }

            // CopyTo method
            int[] ints = new int[10010];
            pq.CopyTo(ints, 5);

            // Check the elements
            for (i = 0; i < 10000; i++)
            {
                Assertion.AssertEquals("Elements:", 10000-i-1, ints[i+5]);
            }
        }
    }

    /// <summary>
    /// Test the Clone method using a large loop and collection
    /// </summary>
    public class TestClone : AbstractBenchmark
    {
        private PriorityQueue pq;

        /// <summary>
        /// Initialize the test
        /// </summary>
        public TestClone() : base("Test Clone")
        {
            pq = new PriorityQueue();

            // Enqueue a large number of strings 
            for (int i = 0; i < 10000; i++)
            {
                pq.Enqueue(i);
            }
        }

        /// <summary>
        /// Run once of the benchmark test.
        /// </summary>
        public override void RunOnce()
        {
            PriorityQueue clone = (PriorityQueue) pq.Clone();

            // Check Count
            Assertion.AssertEquals("Count:", 10000, clone.Count);

            // Check the elements
            for (int i = 0; i < 10000; i++)
            {
                Assertion.AssertEquals("Elements:", 10000-i-1, clone.Dequeue());
            }
        }
    }

    /// <summary>
    /// Test the Enumerate method using a large loop and collection
    /// </summary>
    public class TestEnumerate : AbstractBenchmark
    {
        private PriorityQueue pq;

        /// <summary>
        /// Initialize the test
        /// </summary>
        public TestEnumerate() : base("Test Enumerate")
        {
            pq = new PriorityQueue();

            // Enqueue a large number of strings 
            for (int i = 0; i < 10000; i++)
            {
                pq.Enqueue(i);
            }
        }

        /// <summary>
        /// Run once of the benchmark test.
        /// </summary>
        public override void RunOnce()
        {
            int idx = 0;

            // Check each element
            foreach (int obj in pq)
            {
                Assertion.AssertEquals("Elements:", 10000-idx-1, obj);
                idx++;
            }

            // Check the number of element
            Assertion.AssertEquals("Count:", 10000, idx);
        }
    }
}