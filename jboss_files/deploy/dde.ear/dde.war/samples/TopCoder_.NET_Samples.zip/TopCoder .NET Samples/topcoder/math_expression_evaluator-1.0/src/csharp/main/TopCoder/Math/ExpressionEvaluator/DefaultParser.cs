/* DefaultParser.cs
 * Copyright @ 2003, TopCoder, Inc. All rights reserved
 * 
 * Author - mishagam
 * */
using System;
using System.Collections;
using System.Text.RegularExpressions;

namespace TopCoder.Math.ExpressionEvaluator {
    /// types constants. Represent different types of symbols
    enum Type {
        LBRACKET = 1,
        RBRACKET,
        COMMA,
        LITERAL,
        FUNCTION1,
        FUNCTION2,
        OPERATOR1,
        OPERATOR2,
        VARIABLE,
        END
    };

    /// precedences of symbols. 
    /// mainly usual precedences of operations
    enum Prec {
        BRACKET = 0,
        OR, 
        AND,
        EQU,
        RELATION,
        ADDSUB,
        MULDIV,
        POWER,
        UNARY,
        FUNCTION,
        VARIABLE,
        LITERAL,
    };
    /// <summary>
    /// Class representing tokens in lexical analysis.
    /// author - TCSDEVELOPER
    /// version - 1.0
    /// </summary>
    class Symbol {
        /// <summary>
        /// Name - string representation of token
        /// </summary>
        public string name;

        /// <summary>
        /// Type of token
        /// </summary>
        public Type type;

        /// <summary>
        /// Precendence of token. especially makes sense for operations
        /// </summary>
        public Prec precedence;

        /// <summary>
        /// operator for unary and binary functions
        /// </summary>
        public Object oper;

        /// <summary>
        /// Self evident constructor
        /// </summary>
        /// <param name="_name">value of name for new symbol</param>
        /// <param name="_type">type of new symbol</param>
        /// <param name="_prec">precedence level for new symbol</param>
        internal Symbol(string _name, Type _type, Prec _prec, Object _oper) {
            name = _name;
            type = _type;
            precedence = _prec;
            oper = _oper;
        }

    }


    /// <summary>
    /// Summary description for DefaultParser. Class for parsing expressions
    /// implementing IParser interface. Used in MathematicalEvaluator
    /// Author - TCSDEVELOPER
    /// Vesion - 1.0
    /// </summary>
    class DefaultParser {
        /// <summary>
        /// Table of symbols hardcoded in parser
        /// </summary>
        static readonly Hashtable symbols = InitSymbols();

        /// <summary>
        /// Name resolver used for resolving variable names
        /// </summary>
        INameResolver currentResolver = null;

        /// <summary>
        /// list of tokens constructed after initial scanning of expression
        /// </summary>
        IList tokens = null;

        /// <summary>
        /// regular expression for double literals
        /// </summary>
        static readonly Regex doubleReg = new Regex(@"\A((\d*\.\d+)|(\d+\.?\d*))(E[\+\-]?[0-9]+)?");

        /// <summary>
        /// regular expression for variables of form like AA_A78.e3.67U
        /// </summary>
        static readonly Regex varReg = new Regex(@"\A[_a-zA-Z\$]+[_a-zA-Z\.\d\$]*");

        /// <summary>
        /// adding new symbol to symbols table
        /// </summary>
        /// <param name="name">name for new symbol</param>
        /// <param name="type">name for new symbol</param>
        /// <param name="prec">name for new symbol</param>
        static private void AddSymbol(Hashtable hash, string name, Type type, Prec prec, Object oper) {
            Symbol sym = new Symbol(name, type, prec, oper);
            hash.Add(name, sym);
        }

        /// <summary>
        /// Initializing symbols table and regular expressions
        /// </summary>
        static private Hashtable  InitSymbols() {
            Hashtable syms = new Hashtable();
            AddSymbol(syms, "(", Type.LBRACKET, Prec.BRACKET, null); 
            AddSymbol(syms, ")", Type.RBRACKET, Prec.BRACKET, null); 
            AddSymbol(syms, ",", Type.COMMA, Prec.BRACKET, null); 
            AddSymbol(syms, "+", Type.OPERATOR2, Prec.ADDSUB, BinaryOperation.OPERATOR_ADD); 
            AddSymbol(syms, "-", Type.OPERATOR2, Prec.ADDSUB, BinaryOperation.OPERATOR_SUBTRACT); 
            AddSymbol(syms, "*", Type.OPERATOR2, Prec.MULDIV, BinaryOperation.OPERATOR_MULTIPLY); 
            AddSymbol(syms, "/", Type.OPERATOR2, Prec.MULDIV, BinaryOperation.OPERATOR_DIVIDE); 
            AddSymbol(syms, "<", Type.OPERATOR2, Prec.RELATION, BinaryOperation.OPERATOR_LT); 
            AddSymbol(syms, "<=", Type.OPERATOR2, Prec.RELATION, BinaryOperation.OPERATOR_LE); 
            AddSymbol(syms, ">", Type.OPERATOR2, Prec.RELATION, BinaryOperation.OPERATOR_GT); 
            AddSymbol(syms, ">=", Type.OPERATOR2, Prec.RELATION, BinaryOperation.OPERATOR_GE); 
            AddSymbol(syms, "==", Type.OPERATOR2, Prec.EQU, BinaryOperation.OPERATOR_EQ); 
            AddSymbol(syms, "!=", Type.OPERATOR2, Prec.EQU, BinaryOperation.OPERATOR_NE); 
            AddSymbol(syms, "^", Type.OPERATOR2, Prec.POWER, BinaryOperation.OPERATOR_POWER); 
            AddSymbol(syms, "||", Type.OPERATOR2, Prec.OR, null); 
            AddSymbol(syms, "&&", Type.OPERATOR2, Prec.AND, null); 
            AddSymbol(syms, "!", Type.OPERATOR1, Prec.UNARY, UnaryOperation.OPERATOR_NOT); 
            AddSymbol(syms, "MIN", Type.FUNCTION2, Prec.FUNCTION, BinaryOperation.OPERATOR_MIN);
            AddSymbol(syms, "MAX", Type.FUNCTION2, Prec.FUNCTION, BinaryOperation.OPERATOR_MAX);
            AddSymbol(syms, "SIN", Type.FUNCTION1, Prec.FUNCTION, UnaryOperation.OPERATOR_SIN); 
            AddSymbol(syms, "COS", Type.FUNCTION1, Prec.FUNCTION, UnaryOperation.OPERATOR_COS);
            AddSymbol(syms, "TAN", Type.FUNCTION1, Prec.FUNCTION, UnaryOperation.OPERATOR_TAN);
            AddSymbol(syms, "ASIN", Type.FUNCTION1, Prec.FUNCTION, UnaryOperation.OPERATOR_ASIN);
            AddSymbol(syms, "ACOS", Type.FUNCTION1, Prec.FUNCTION, UnaryOperation.OPERATOR_ACOS);
            AddSymbol(syms, "ATAN", Type.FUNCTION1, Prec.FUNCTION, UnaryOperation.OPERATOR_ATAN);
            AddSymbol(syms, "SQRT", Type.FUNCTION1, Prec.FUNCTION, UnaryOperation.OPERATOR_SQRT);
            AddSymbol(syms, "EXP", Type.FUNCTION1, Prec.FUNCTION, UnaryOperation.OPERATOR_EXP);
            AddSymbol(syms, "LOG", Type.FUNCTION1, Prec.FUNCTION, UnaryOperation.OPERATOR_LOG);
            AddSymbol(syms, ";", Type.END, Prec.BRACKET, null);
            AddSymbol(syms, " ", 0, 0, null);
            AddSymbol(syms, "\t", 0, 0, null);

            return syms;
        }

        /// <summary>
        /// index of current token during lexical analysis
        /// </summary>
        int itok = 0;

        /// <summary>
        /// reading function (standard) with one argument
        /// </summary>
        /// <param name="func">Symbol with the name of function</param>
        /// <returns>parsed expression of function and argument</returns>
        private Expression ReadFunction1(Symbol func) {
            // reading bracket and next term, creating UnaryOperation
            Symbol sbr = (Symbol)tokens[itok++];
            if (sbr.type != Type.LBRACKET) {
                throw new ExpressionFormatException(String.Format(
                    "Function {0} must be followed by an open parenthesis", func.name));
            }
            Expression earg = ParseExpression((int)Prec.BRACKET +1);
            sbr = (Symbol)tokens[itok++];
            if (sbr.type != Type.RBRACKET) {
                throw new ExpressionFormatException(String.Format(
                    "The last argument of the function {0} must " +
                    "be followed by a closing parenthesis", func.name));
            }
            UnaryOperation.Operator op = null;
            Object oop = func.oper;
            op = (UnaryOperation.Operator)oop;
            
            return new UnaryOperation(earg, op);
        }
        /// <summary>
        /// reading function (standard) with two argument. (Min and Max)
        /// </summary>
        /// <param name="func">Symbol with the name of function</param>
        /// <returns>parsed expression of function and arguments</returns>
        private Expression ReadFunction2(Symbol func) {
            // reading bracket and next term, creating UnaryOperation
            Symbol sbr = (Symbol)tokens[itok++];
            if (sbr.type != Type.LBRACKET) {
                throw new ExpressionFormatException(String.Format(
                    "Function {0} must be followed by an open parenthesis", func.name));
            }

            // reading first argument
            Expression earg1 = ParseExpression((int)Prec.BRACKET+1);
            sbr = (Symbol)tokens[itok++];
            if (sbr.type != Type.COMMA) {
                throw new ExpressionFormatException(String.Format(
                    "Arguments of function {0} must be separated with commas", func.name));
            }

            // reading second argument
            Expression earg2 = ParseExpression((int)Prec.BRACKET+1);
            sbr = (Symbol)tokens[itok++];
            if (sbr.type != Type.RBRACKET) {
                throw new ExpressionFormatException(String.Format(
                    "The last argument of the function {0} must " +
                    "be followed by a closing parenthesis", func.name));
            }

            BinaryOperation.Operator op = null;
            if (func.name.ToUpper().Equals("MIN")) {
                op = BinaryOperation.OPERATOR_MIN;
            } else if (func.name.ToUpper().Equals("MAX")) {
                op = BinaryOperation.OPERATOR_MAX;
            } else {
                throw new ExpressionFormatException(
                    "Unrecognized function name: " + func.name);
            }

            return new BinaryOperation(earg1, earg2, op);
        }

        /// <summary>
        /// tests that name looks no worse than _$aaa454.ghg76
        /// </summary>
        /// <param name="name">string to ckeck if this is correct variable name</param>
        /// <returns></returns>
        bool IsCorrectVariableName(string name) {
            foreach (char c in name.ToUpper()) {
                if (    c != '_' && c != '$' && c!='.' && 
                    !Char.IsLetter(c) && !Char.IsDigit(c)) {
                    return false;
                }
            }
            if (name[0]=='.' || Char.IsDigit(name[0])) {
                return false;
            }

            return true;
        }

        /// <summary>
        /// resolves variables using , plus checks if they are really number litarals
        /// </summary>
        Expression Resolve(Symbol sym) {
            Expression e;
            double d; 
            string sname = sym.name;

            bool isNumber = Double.TryParse(sname, System.Globalization.NumberStyles.Float,
                System.Globalization.NumberFormatInfo.CurrentInfo, out d);
            if (! isNumber) {
                if (    sym.name.ToUpper().Equals("MATH.E") || 
                    sym.name.ToUpper().Equals("E")) {
                    e = new Literal(System.Math.E);
                } else if ( sym.name.ToUpper().Equals("MATH.PI") ||
                            sym.name.ToUpper().Equals("PI")) {
                    e = new Literal(System.Math.PI);
                } else {
                    if (!IsCorrectVariableName(sym.name)) {
                        throw new ExpressionFormatException(String.Format(
                            "Invalid variable name: [{0}] Variables must start " +
                            "with a letter or an underscore, and consist of " +
                            "letters, digits, underscores, and dots.", sym.name));
                    }
                    e = this.currentResolver.Resolve(sym.name);
                }
            } else {
                e = new Literal(d);
            }
            return e;
        }

        /// <summary>
        /// parseExpression - parces expreassion, already converted to tokens.
        /// Uses recursive calls to itself for estimating parts with higher 
        /// precedence. \
        /// For example, in estimating 2*3 + x*y 2*3 and x*y are parsed in 
        /// recursive calls to parseExpression with higher precedence
        /// </summary>
        /// <param name="prec">Precedence level for estimated part</param>
        /// <returns></returns>
        private Expression ParseExpression(int prec) {
            // checking for functions
            Expression returnExpression = null;
            Symbol currentSymbol = (Symbol)tokens[itok++];
            if (prec >= (int)Prec.FUNCTION) {
                // checking for functions, else ret var or literal or bracket
                if (currentSymbol.type == Type.FUNCTION1) {
                    returnExpression = ReadFunction1(currentSymbol);
                } else if (currentSymbol.type == Type.FUNCTION2) {
                    // reading function with 2 arguments - min and max
                    returnExpression = ReadFunction2(currentSymbol);
                } else if (currentSymbol.type == Type.LITERAL) {
                    if (currentSymbol.name.ToUpper().Equals("PI")) {
                        returnExpression = new Literal(System.Math.PI);
                    } else if (currentSymbol.name.ToUpper().Equals("E")) {
                        returnExpression = new Literal(System.Math.E);
                    } else {
                        returnExpression = new Literal(currentSymbol.name);
                    }
                } else if (currentSymbol.type == Type.VARIABLE) {
                    returnExpression = Resolve(currentSymbol);
                } else if (currentSymbol.type == Type.LBRACKET) {
                    // reading second argument
                    returnExpression = ParseExpression((int)Prec.BRACKET+1);
                    Symbol sbr = (Symbol)tokens[itok++];
                    if (sbr.type != Type.RBRACKET) {
                        throw new ExpressionFormatException(
                                "Malformed expression: missing right parenthesis");
                    }
                } else {
                    throw new ExpressionFormatException(String.Format(
                            "Malformed expression. Error at or around {0}", currentSymbol.name));
                }
            } else if (prec >= (int)Prec.UNARY) {
                // checking for unary operation
                UnaryOperation.Operator op = null;
                if (    currentSymbol.name.Equals("+") || currentSymbol.name.Equals("-") || 
                        currentSymbol.type == Type.OPERATOR1) {
                    // unary operator, - , !
                    if (currentSymbol.name.Equals("-")) {
                        op = UnaryOperation.OPERATOR_NEG;
                    } else if (currentSymbol.name.Equals("+")) {
                        op = null;
                    } else if (currentSymbol.name.Equals("!")) {
                        op = UnaryOperation.OPERATOR_NOT;
                    } else {
                        throw new ExpressionFormatException(
                            "Unrecognized unary operator: " + currentSymbol.name);
                    }
                } else {
                    // there is no unary operation
                    itok --; 
                }
                returnExpression = ParseExpression(prec + 1);
                if (op != null) {
                    if (    op == UnaryOperation.OPERATOR_NEG && 
                        (returnExpression is Literal)) {
                        returnExpression = new Literal(-returnExpression.Evaluate());
                    } else {
                        returnExpression = new UnaryOperation(returnExpression, op);
                    }
                }
            } else {
                // reading expression with binary operations till 
                // end of expr or operation with lower precedence
                itok --;
                Expression leftHand = ParseExpression(prec + 1);
                if (itok >= tokens.Count) {
                    throw new ExpressionFormatException(String.Format(
                            "Unexpected end of formula at or around {0}", ((Symbol)tokens[tokens.Count - 1]).name));
                }
                Symbol operationSymbol = (Symbol)tokens[itok++];
                while ( operationSymbol.type == Type.OPERATOR2 && 
                    (int)(operationSymbol.precedence) >= prec) {
                    Expression rightHand = ParseExpression(prec + 1);
                    if (operationSymbol.name.Equals("&&")) {
                        leftHand = new BinaryAndOperation(leftHand, rightHand);
                    } else if (operationSymbol.name.Equals("||")) {
                        leftHand = new BinaryOrOperation(leftHand, rightHand);
                    } else {
                        // Binary Operation
                        Object oop = operationSymbol.oper;
                        BinaryOperation.Operator op = (BinaryOperation.Operator)oop;
                        leftHand = new BinaryOperation(leftHand, rightHand, op);
                    }
                    operationSymbol = (Symbol)tokens[itok++];
                }
                returnExpression = leftHand;
                itok--;
            }
            return returnExpression;
        }

        /// <summary>
        /// parse from IParser interface. Parses expression using
        /// resolver for creating expressions from tokens.
        /// </summary>
        /// <param name="expr">expression in string form</param>
        /// <param name="resolver">INameResolver </param>
        /// <returns>parsed Expression</returns>
        public Expression Parse(string expr, INameResolver resolver) {
            currentResolver = resolver;
            tokens = SplitTokens(expr);
            itok = 0;
            Expression e = ParseExpression(1);
            if (itok >=0 && itok < tokens.Count - 1) {
                throw new ExpressionFormatException(String.Format(
                    "Unexpected end of Expression: error at or around {0}", ((Symbol)tokens[itok]).name));
            } else if (itok != tokens.Count - 1) {
                throw new ExpressionFormatException(String.Format(
                    "Unexpected end of Expression: error at or around {0}", ((Symbol)tokens[tokens.Count - 1]).name));
            }
            
            return e;
        }

        /// <summary>
        /// determines if part of input string from offset off has double literal
        /// and if it does, returns it, otherwise returns null
        /// Uses precalculated regular expression
        /// </summary>
        /// <param name="e">source string</param>
        /// <param name="off">offset to analysed position</param>
        /// <returns>found double literal or null</returns>
        string DoublePart(string e, int off) {
            string part = e.Substring(off);
            Match m = doubleReg.Match(part);
            if (!m.Success) {
                return null;
            }
            return m.ToString();            
        }
        /// <summary>
        /// determines if part of input string from offset off has variable 
        /// name and if it does, returns it, otherwise returns null
        /// Uses precalculated regular expression
        /// </summary>
        /// <param name="e">source string</param>
        /// <param name="off">offset to analysed position</param>
        /// <returns>found variable name or null</returns>
        string VarPart(string e, int off) {
            string part = e.Substring(off);
            Match m = varReg.Match(part);
            if (!m.Success) {
                return null;
            }
            return m.ToString();            
        }

        /// <summary>
        /// converts string expr to list of tokens like functions, operations,
        /// variables, literals, brackets, and so on.
        /// Result in this.tokens array
        /// <param name="expr">analysed expression string</param>
        /// </summary>
        IList SplitTokens(string expr) {
            ArrayList tokens = new ArrayList();

            expr = expr + ";";
            int lastTokenStart = 0;
            string part;
            for (int i = 0; i<expr.Length; i++) {
                // checking for start of double
                if ((part = DoublePart(expr, i))!=null) {
                    Symbol sym = new Symbol(part, Type.LITERAL, Prec.LITERAL, null);
                    tokens.Add(sym);
                    lastTokenStart = i + part.Length;
                    i = lastTokenStart - 1;
                    continue;
                } else if ((part = VarPart(expr, i))!=null) {
                    // checking that this symbol isn't name of function
                    if (symbols.ContainsKey(part.ToUpper())) {
                        if (i > lastTokenStart) {
                            throw new ExpressionFormatException(String.Format(
                                "Malformed expression. Error at or around {0}", part));
                        }
                        if (part[0] != ' ' && part[0] != '\t') {
                            tokens.Add(symbols[part.ToUpper()]);
                        }
                    } else {
                        Symbol sym = new Symbol(part, Type.VARIABLE, Prec.VARIABLE, null);
                        tokens.Add(sym);
                    }
                    lastTokenStart = i + part.Length;
                    i = lastTokenStart - 1;
                    continue;
                }
                for (int ln = 4; ln >= 1; ln--) {
                    if (ln > expr.Length - i) {
                        continue;
                    }
                    string sname = expr.Substring(i, ln);
                    if (symbols.ContainsKey(sname.ToUpper())) {
                        if (i > lastTokenStart) {
                            throw new ExpressionFormatException(String.Format(
                                "Malformed expression. Error at or around {0}", sname));
                        }
                        if (sname[0] != ' ' && sname[0] != '\t') {
                            tokens.Add(symbols[sname.ToUpper()]);
                        }
                    } else {
                        continue; // moving to next ln
                    }
                    i += ln - 1;
                    lastTokenStart = i + 1;
                    break;  // moving along expr
                }
            }

            return (IList)tokens;           
        }
    }
}
