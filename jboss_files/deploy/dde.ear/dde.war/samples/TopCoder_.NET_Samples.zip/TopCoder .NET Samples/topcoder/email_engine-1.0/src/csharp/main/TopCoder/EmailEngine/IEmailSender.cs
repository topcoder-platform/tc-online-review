using System;

// @author CLoris
// @copyright 2003 (c) TopCoder Software

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// General interface for class which enable to send emails
    /// </summary>
    public interface IEmailSender 
    {
        /// <summary>
        /// Send email
        /// throws MessageErrorException if a text is not well-formed email
        /// </summary>
        /// <param name="message">well-formed email message</param>
        void SendEmail(Message message);
    }
}
