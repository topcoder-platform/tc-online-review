// @author TCSDESIGNER
// @copyright (c) TopCoder Software

using System;

namespace TopCoder.LoggingWrapper
{
    /// <summary>
    /// This class for test purposes only
    /// </summary>
    public class InvalidImpl
    {
        /// <summary>
        /// constructor
        /// </summary>
        public InvalidImpl()
        {
        }
    }
}
