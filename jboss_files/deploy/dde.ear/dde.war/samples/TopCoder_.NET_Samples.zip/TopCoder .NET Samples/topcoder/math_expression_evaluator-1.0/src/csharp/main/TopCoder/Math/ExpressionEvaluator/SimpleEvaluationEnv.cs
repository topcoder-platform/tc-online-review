/* SimpleEvaluationEnv.cs; 
 * Copyright @ 2003, TopCoder, Inc. All rights reserved
 * 
 * @authors kyky, mishagam
 * */
using System;
using System.Collections;

namespace TopCoder.Math.ExpressionEvaluator {
    /// <summary>
    /// Private class for evaluating simple variables.
    /// Uses an IDictionary to store variable values,
    /// whree variable name is uased as the key.
    /// </summary>
    class SimpleEvaluationEnv : IEvaluationEnv {
        /// <summary>
        /// Default constructor - uses an empty hash table
        /// for the dictionary.
        /// </summary>
        public SimpleEvaluationEnv() {
            dictionary = new Hashtable();
        }
        /// <summary>
        /// Uses the supplied IDictionary to resolve variables.
        /// </summary>
        /// <param name="dictionary">A dictionary that maps variable names to variable values.</param>
        public SimpleEvaluationEnv( IDictionary dictionary ) {
            this.dictionary = dictionary;
        }
        /// <summary>
        /// Looks up a value in the dictionary, using name as the key.
        /// </summary>
        /// <param name="name">Name of the variable.</param>
        /// <returns>Value of the variable identified by name.</returns>
        public double GetValueForName( string name ) {
            if ( !dictionary.Contains( name ) ) {
                throw new UnresolvedVariableException( name );
            }
            try {
                return Convert.ToDouble( dictionary[name] );
            } catch (Exception) {
                return Double.NaN;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        private IDictionary dictionary;
    }
}
