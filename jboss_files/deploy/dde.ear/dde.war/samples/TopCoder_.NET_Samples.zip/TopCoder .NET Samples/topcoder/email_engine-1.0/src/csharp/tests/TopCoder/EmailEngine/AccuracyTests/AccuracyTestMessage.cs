using System;
using NUnit.Framework;
using System.IO;

namespace TopCoder.EmailEngine.AccuracyTests
{
    /// <summary>
    /// Accuracy Tests for Message class
    /// @author aksonov
    /// </summary>
    [TestFixture]
    public class AccuracyTestMessage
    {
        /// <summary>
        /// test parsing a message
        /// </summary>
        [Test]
        public void MessageParse()
        {
            String msg = "BCC:hidden@aksonov.kiev.ua\n To: \"Pavel Aksonov\" <test1@aksonov.kiev.ua>,    test2@aksonov.kiev.ua       \nFrom: tc@aksonov.kiev.ua\n\nThis is the message!\n\n";
            Message m = new Message(msg);

            Assertion.AssertEquals ( "tc@aksonov.kiev.ua", m.From.Email);
            Assertion.AssertEquals ( "test1@aksonov.kiev.ua", m.To[0].Email);
            Assertion.AssertEquals ( "Pavel Aksonov", m.To[0].Name );
            Assertion.AssertEquals ( "test2@aksonov.kiev.ua" , m.To[1].Email);
            Assertion.AssertEquals ( "hidden@aksonov.kiev.ua" , m.BCC[0].Email);
            Assertion.AssertEquals ( "", m.Subject);
            Assertion.AssertEquals ( "This is the message!\n\n" , m.Body);
        }

        /// <summary>
        /// test parsing a message with body having \n at the beginning
        /// </summary>
        [Test]
        public void MessageParse2()
        {
            String msg = "CC:\n To: \"Pavel Aksonov\" <test1@aksonov.kiev.ua>,    test2@aksonov.kiev.ua       \nSubject:Hello!    \nFrom: tc@aksonov.kiev.ua\n\n\nThis is the message!\n\n";
            Message m = new Message();
            m.Parse(msg);

            Assertion.AssertEquals ( "tc@aksonov.kiev.ua", m.From.Email);
            Assertion.AssertEquals ( "test1@aksonov.kiev.ua", m.To[0].Email);
            Assertion.AssertEquals ( "Pavel Aksonov", m.To[0].Name );
            Assertion.AssertEquals ( "test2@aksonov.kiev.ua" , m.To[1].Email);
            Assertion.AssertEquals ( 0, m.CC.Count);
            Assertion.AssertEquals ( "Hello!    ", m.Subject);
            Assertion.AssertEquals ( "\nThis is the message!\n\n" , m.Body);
        }

    }
}
