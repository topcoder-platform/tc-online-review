/*
    Copyright c 2003, TopCoder, Inc. All rights reserved
    Author TCSDEVELOPER
*/

using System;
using System.Collections;

using TopCoder.Math.ExpressionEvaluator;

using NUnit.Framework;

namespace TopCoder.Math.ExpressionEvaluator.AccuracyTests {

    /// <summary>
    /// Test cases for the unary operations.
    /// </summary>
    [TestFixture]
    public class UnaryOpAccuracyTests {
        /// <summary>
        /// Expression instance for tests.
        /// </summary>
        Expression exp;

        /// <summary>
        /// Verifies that the system deals with unary negation correctly.
        /// </summary>
        [Test]
        public void TestNEG() {
            Hashtable ht = new Hashtable();
            exp = Expression.Parse("-XyZ");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to -.4321", 
                                   -.4321, 
                                   exp.Evaluate(new string[] {"XyZ"}, 
                                                new double[] {.4321}));
            ht["XyZ"] = -.1234;
            Assertion.AssertEquals("Expression must evaluate to .1234", 
                                   .1234, exp.Evaluate(ht));
        }

        /// <summary>
        /// Verifies that the system deals with logical unary negation correctly.
        /// </summary>
        [Test]
        public void TestNOT() {
            Hashtable ht = new Hashtable();
            exp = Expression.Parse("!__X");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 0", 
                                   0, 
                                   exp.Evaluate(new string[] {"__X"}, 
                                                new double[] {1}));
            ht["__X"] = 0;
            Assertion.AssertEquals("Expression must evaluate to 1", 
                                   1, exp.Evaluate(ht));
        }

        /// <summary>
        /// Tests operation SIN
        /// </summary>
        [Test]
        public void TestSIN() {
            exp = Expression.Parse("SIN(1.2345)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to SIN(1.2345)", 
                                   System.Math.Sin(1.2345), exp.Evaluate());
                                   
        }

        /// <summary>
        /// Tests operation COS
        /// </summary>
        [Test]
        public void TestCOS() {
            exp = Expression.Parse("COS(-1.2345)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to COS(-1.2345)", 
                                   System.Math.Cos(-1.2345), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation TAN
        /// </summary>
        [Test]
        public void TestTAN() {
            exp = Expression.Parse("TAN(-1.2345E1)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to TAN(-1.2345)", 
                                   System.Math.Tan(-1.2345e1), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation ASIN
        /// </summary>
        [Test]
        public void TestASIN() {
            exp = Expression.Parse("ASIN(0.5)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to ASIN(0.5)", 
                                   System.Math.Asin(0.5), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation ACOS
        /// </summary>
        [Test]
        public void TestACOS() {
            exp = Expression.Parse("ACOS(-0.5)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to ACOS(-0.5)", 
                                   System.Math.Acos(-0.5), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation ATAN
        /// </summary>
        [Test]
        public void TestATAN() {
            exp = Expression.Parse("ATAN(-0.5E2)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to ATAN(-0.5E2)", 
                                   System.Math.Atan(-0.5e2), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation EXP
        /// </summary>
        [Test]
        public void TestEXP() {
            exp = Expression.Parse("EXP(2.34E-5)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to Exp(2.34E-5)", 
                                   System.Math.Exp(2.34E-5), exp.Evaluate());
        }

        /// <summary>
        /// Tests operation LOG
        /// </summary>
        [Test]
        public void TestLOG() {
            exp = Expression.Parse("LOG(10.000)");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to Math.Log(10)", 
                                   System.Math.Log(10), exp.Evaluate());
        }
    }
}