using System;
using System.Text;
using System.Collections;
using System.Text.RegularExpressions;

// @author CLoris
// @copyright 2003 (c) TopCoder Software

namespace TopCoder.EmailEngine
{
    //  Please read [ as <, and ] as > because "<" and ">" is part of special documentation tags
    /// <summary>
    /// Class for manipulation with email addresses and convertation it to a string.
    /// Email validation can be added here in the future.
    /// Used by Message class for creating of the list of recipients.
    /// It can be used by address books also.
    /// Example of usage:
    /// <code>Email ea = new EmailAddress("Submitter 18","sub_18@Domain.com","TopCoder software");
    /// string email = ea.ToString(); // email contains : "Submitter 18" [sub_18@domain.com] (TopCoder software)
    /// </code>
    /// </summary>
    public class EmailAddress 
    {
        // constants
        private const string TEXT_CRLF = "\r\n";
        private const string TEXT_BLANK = "";

        private const string ERR_NULL = "Null value not allowed";
        private const string ERR_INVALID_EMAIL = "Invalid email address specified during parse: {0}";
        
        private const string REGEX_NAME = "\\\"(?<name>.+)\\\"";
        private const string REGEX_EMAIL = @"(\W|\<){0,1}(?<email>\w+\@(\w+\.)+\w+)(\W|\>){0,1}";
        private const string REGEX_COMPANY = "\\((?<company>.+)\\)$";

        private const string TOSTRING_NAME = "\"{0}\" ";
        private const string TOSTRING_EMAIL = "<{0}>";
        private const string TOSTRING_COMPANY = " ({0})";
        // end constants

        private string name = null;
        private string email = null;
        private string company = null;

        /// <summary>
        /// email of the email address
        /// </summary>
        public string Email 
        {
            get 
            {
                return email;
            }
            set 
            {
                email = value;
            }
        }

        /// <summary>
        /// Name of the email address
        /// </summary>
        public string Name 
        {
            get 
            {
                return name;
            }
            set 
            {
                name = value;
            }
        }

        /// <summary>
        /// company field of the email address
        /// </summary>
        public string Company 
        {
            get 
            {
                return company;
            }
            set 
            {
                company = value;
            }
        }

        /// <summary>
        /// Empty EmailAddress constructor
        /// </summary>
        public EmailAddress()
        {
        }

        /// <summary>
        /// Constucts EmailAddress object from email only
        /// </summary>
        /// <param name="email">email</param>
        public EmailAddress(string email)
        {
            this.Email = email;
        }

        /// <summary>
        /// Constructs EmailAddress object from email and name
        /// </summary>
        /// <param name="email">email of the email address</param>
        /// <param name="name">name of the email address</param>
        public EmailAddress(string email, string name)
        {
            this.Email = email;
            this.Name = name;
        }

        /// <summary>
        /// Constructs EmailAddress object from email, name, company
        /// </summary>
        /// <param name="email">the email of the email address</param>
        /// <param name="name">the name of the email address</param>
        /// <param name="company">the company of the email address</param>
        public EmailAddress(string email, string name, string company)
        {
            this.Email = email;
            this.Name = name;
            this.Company = company;
        }

        //  Please read [ as <, and ] as > because "<" and ">" is part of special documentation tags
        /// <summary>
        /// Parses <c>email</c> string to EmailAddress object <c>Email</c>
        /// </summary>
        /// <param name="email">
        /// email string in one of the following formats:
        ///   "Submitter 18" [sub_18@domain.com] (TopCoder software)
        ///   [sub_18@domain.com] (TopCoder software)
        ///   "Submitter 18" [sub_18@domain.com]
        /// </param>
        /// <exception cref="MessageErrorException">Thrown if an email address can't be picked out of the string being parsed.</exception>
        public void Parse(string email)
        {
            Match match;

            // don't allow a null string
            if(email == null)
            {
                throw new MessageErrorException(ERR_NULL);
            }

            // blank out current values
            this.email = null;
            this.name = null;
            this.company = null;
            
            // rollup any crlf's
            email.Replace(TEXT_CRLF, TEXT_BLANK);

            // set up regular expressions to extract desired components
            Regex nameregex = new Regex(REGEX_NAME);
            Regex emailregex = new Regex(REGEX_EMAIL);
            Regex companyregex = new Regex(REGEX_COMPANY);
        
            // get the name
            match = nameregex.Match(email);
            if(match.Success)
            {
                this.Name = match.Groups["name"].Value;
            }
            // get the email
            match = emailregex.Match(email);
            if(match.Success)
            {
                this.Email = match.Groups["email"].Value;
            }
            else
            {
                // have to have a valid email
                throw new MessageErrorException(String.Format(ERR_INVALID_EMAIL, email));
            }
            // get the company
            match = companyregex.Match(email);
            if(match.Success)
            {
                this.Company = match.Groups["company"].Value;
            }
        }

        /// <summary>
        /// Converts EmailAddress object to a string
        /// </summary>
        /// <returns>result string presenting email address</returns>
        public override string ToString()
        {
            StringBuilder result = new StringBuilder();

            // if we don't have an email, return nothing
            if(this.email == null)
            {
                return null;
            }

            // build return string based on currently furnished values
            if(this.name != null)
            {
                result.Append(String.Format(TOSTRING_NAME, this.name));
            }
            result.Append(String.Format(TOSTRING_EMAIL, this.email));
            if(this.company != null)
            {
                result.Append(String.Format(TOSTRING_COMPANY, this.company));
            }

            return result.ToString(); 
        }

        /// <summary>
        /// Compares one EmailAddress to another (similar to String.Compare).
        /// The comparison is based on the actual email address.
        /// </summary>
        /// <param name="objA">
        /// EmailAddress object to be compared to current instance
        /// </param>
        /// <returns>
        /// -1 if this email is less than objA
        /// 0 if this email matches objA
        /// 1 if this email is greater than objA  
        /// </returns>        
        private int CompareTo(EmailAddress objA)
        {
            return(String.Compare(objA.email, this.email, true));
        }

        /// <summary>
        /// Class for comparing EmailAdresses.  Implements IComparer
        /// </summary>
        public class EmailAddressComparerAlphabetical : IComparer 
        {
            /// <summary>
            /// Compares one EmailAddress to another for the purposes
            /// of calling ArrayList.Sort
            /// </summary>
            /// <param name="objA">
            /// First EmailAddress object to be compared
            /// </param>
            /// <param name="objB">
            /// Second EmailAddress object to be compared
            /// </param>
            /// <returns>
            /// -1 if this objA is less than objB
            /// 0 if this objA matches objB
            /// 1 if this objA is greater than objB  
            /// </returns>        
            public int Compare(object objA, object objB)
            {
                return(-1 * ((EmailAddress)objA).CompareTo( ((EmailAddress)objB) ) );
            }
        }
    }
}
