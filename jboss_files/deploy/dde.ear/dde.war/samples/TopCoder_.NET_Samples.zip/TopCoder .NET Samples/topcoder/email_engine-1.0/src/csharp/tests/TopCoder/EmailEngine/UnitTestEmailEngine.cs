using System;
using NUnit.Framework;
using System.IO;
using System.Diagnostics;

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// Unit Test the emailaddresst class.
    /// </summary>
    [TestFixture]
    public class UnitTestEmailEngine
    {
        private EmailEngine ee;
        
        /// <summary>
        /// Sets up the test.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            ee = new EmailEngine();
        }

        /// <summary>
        /// test email engine error messages
        /// </summary>
        [Test]
        [ExpectedException(typeof(SendException))]
        public void EmailEngineError1()
        {
            ee.EmailSender = null;
            ee.SendMessage(new Message("From: cloris@cfl.rr.com\nTo:cloris@lorislaw.com\nSubject:subj\n\nHello!\n\nThis is the message!"));
        }

        /// <summary>
        /// test email engine error messages
        /// </summary>
        [Test]
        [ExpectedException(typeof(MessageErrorException))]
        public void EmailEngineError2()
        {
            ee.EmailSender = new SmtpProtocol();
            ee.SendMessage(null);
        }
    }
}
