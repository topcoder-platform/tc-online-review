/* UnaryOperation.cs; 
 * Copyright @ 2003, TopCoder, Inc. All rights reserved
 * 
 * @authors kyky, mishagam
 * */
using System;

namespace TopCoder.Math.ExpressionEvaluator {
    /// <summary>
    /// Summary description for UnaryOperation.
    /// </summary>
    class UnaryOperation : Expression {
        /// <summary>
        /// Defines the signature of a unary operator.
        /// </summary>
        public delegate double Operator( double operand );
        /// <summary>
        /// Creates an instance of this unary operation.
        /// TODO: Depending on the implementation of dispatch,
        /// the signature of this constructor may change.
        /// </summary>
        /// <param name="operand">Operand of this operation</param>
        /// <param name="op">Operator of this operation</param>
        public UnaryOperation( Expression operand, Operator op) {
            this.operand = operand;
            this.op = op;
        }
        /// <summary>
        /// Evaluates the operand, performs the operation, and returns the result.
        /// </summary>
        /// <param name="env">Evaluation environment - passed to the operand.</param>
        /// <returns>Evaluation result.</returns>
        public override double Evaluate( IEvaluationEnv env ) {
            return op( operand.Evaluate( env ) );
        }
        /// <summary>
        /// Converts this expression to a string representation.
        /// </summary>
        /// <returns>String representation of this expression.</returns>
        public override string ToString() {
            if ( op == OPERATOR_NEG ) {
                return "-" + operand.ToString();
            } else if ( op == OPERATOR_NOT ) {
                return "!" + operand.ToString();
            } else if (op == OPERATOR_SIN) {
                return "SIN(" + operand.ToString() + ")";
            } else if (op == OPERATOR_COS) {
                return "COS(" + operand.ToString() + ")";
            } else if (op == OPERATOR_TAN) {
                return "TAN(" + operand.ToString() + ")";
            } else if (op == OPERATOR_ASIN) {
                return "ASIN(" + operand.ToString() + ")";
            } else if (op == OPERATOR_ACOS) {
                return "ACOS(" + operand.ToString() + ")";
            } else if (op == OPERATOR_ATAN) {
                return "ATAN(" + operand.ToString() + ")";
            } else if (op == OPERATOR_EXP) {
                return "EXP(" + operand.ToString() + ")";
            } else if (op == OPERATOR_LOG) {
                return "LOG(" + operand.ToString() + ")";
            } else if (op == OPERATOR_SQRT) {
                return "SQRT(" + operand.ToString() + ")";
            } else { // TODO: Add more checks here
                return "<unknown_unary> " + operand.ToString();;
            }
        }
        /// <summary>
        /// Operand expression of this unary operation or a function.
        /// </summary>
        private Expression operand;
        /// <summary>
        /// Operator of this operation.
        /// </summary>
        private Operator op;

        /// <summary>
        /// The Negation Operator.
        /// </summary>
        public readonly static Operator OPERATOR_NEG  = new Operator( Neg );
        /// <summary>
        /// The Logical Negation Operator.
        /// </summary>
        public readonly static Operator OPERATOR_NOT  = new Operator( Not );
        /// <summary>
        /// The SIN operator
        /// </summary>
        public readonly static Operator OPERATOR_SIN  = new Operator( System.Math.Sin );
        /// <summary>
        /// The COS operator
        /// </summary>
        public readonly static Operator OPERATOR_COS  = new Operator( System.Math.Cos );
        /// <summary>
        /// The TAN operator
        /// </summary>
        public readonly static Operator OPERATOR_TAN  = new Operator( System.Math.Tan );
        /// <summary>
        /// The ASIN operator
        /// </summary>
        public readonly static Operator OPERATOR_ASIN = new Operator( System.Math.Asin );
        /// <summary>
        /// The ACOS operator
        /// </summary>
        public readonly static Operator OPERATOR_ACOS = new Operator( System.Math.Acos );
        /// <summary>
        /// The ATAN operator
        /// </summary>
        public readonly static Operator OPERATOR_ATAN = new Operator( System.Math.Atan );
        /// <summary>
        /// The EXP operator
        /// </summary>
        public readonly static Operator OPERATOR_EXP  = new Operator( System.Math.Exp );
        /// <summary>
        /// The LOG operator
        /// </summary>
        public readonly static Operator OPERATOR_LOG  = new Operator( System.Math.Log );
        /// <summary>
        /// The SQRT operator
        /// </summary>
        public readonly static Operator OPERATOR_SQRT  = new Operator( System.Math.Sqrt );

        private static double Neg( double operand ) {
            return -operand;
        }
        private static double Not( double operand ) {
            return operand == 0 ? 1 : 0;
        }
    }
}
