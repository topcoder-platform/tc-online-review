using System;
using NUnit.Framework;
using TopCoder.EmailEngine;

namespace TopCoder.EmailEngine.FunctionalTests
{
	
    /// <summary>
	/// tests email messages
	/// </summary>
	[TestFixture]
	public class MessageTest 
	{

        /// <summary>
    	/// tests creating a message
    	/// </summary>
		[Test]
		public void CreateMessage()
		{
			Message message = new Message();
			message.From.Parse("development@topcodersoftware.com");
			message.To.Parse("development@topcodersoftware.com");
			message.Body = "Hello world!";
			message.Subject = "subj";
		}

        /// <summary>
    	/// helper function for tests creating a complex message
    	/// </summary>
		public static Message GetComplexMessage()
		{
			Message m = new Message();
            m.From = new EmailAddress("development@topcodersoftware.com","Ivan");
            m.To.Add(new EmailAddress("development@topcodersoftware.com"));
			m.To.Add(new EmailAddress("development@topcodersoftware.com"));
			m.BCC.Add(new EmailAddress("development@topcodersoftware.com"));
			m.Subject = "subj";
			m.Body = "Hello!";
			return m;
		}


        /// <summary>
    	/// tests creating a complex message
    	/// </summary>
		[Test]
		public void ComplexMessage()
		{
			Message m = GetComplexMessage();
		}

        /// <summary>
    	/// helper functioning for getting an attachment message
    	/// </summary>
		public static Message GetAttachmentMessage()
		{
			Message m = new Message();
			m.From = new EmailAddress("development@topcodersoftware.com");
			m.To.Add(new EmailAddress("development@topcodersoftware.com"));
			m.To.Add(new EmailAddress("development@topcodersoftware.com"));
			m.CC.Add(new EmailAddress("development@topcodersoftware.com"));
			m.BCC.Add(new EmailAddress("development@topcodersoftware.com"));
			m.BCC.Add(new EmailAddress("development@topcodersoftware.com"));
            m.Attachments.Add(new Attachment(@"..\..\test_files\file3.tst"));
            m.Attachments.Add(new Attachment(@"..\..\test_files\file2.tst"));
            m.Attachments.Add(new Attachment(@"..\..\test_files\file.tst"));
			m.Subject = "attached files";
			return m;
		}
		
        /// <summary>
    	/// helper function for testing the retrieval of messages
    	/// </summary>
		[Test]
		public void AttachmentMessage()
		{
			Message m = GetAttachmentMessage();
		}

        /// <summary>
    	/// retrieval of the 
    	/// </summary>
		public static Message GetParseMessage()
		{
			Message m = new Message();
			m.Parse("From: development@topcodersoftware.com\nTo:development@topcodersoftware.com\nSubject:subj\n\nHello!");
			return m;
		}

        /// <summary>
    	/// helper function for parsing of a message
    	/// </summary>
		[Test]
		public void ParseMessage()
		{
			Message m = GetParseMessage();
		}

        /// <summary>
    	/// helper function for testing the retrieval of messages
    	/// </summary>
		public static Message GetAttachmentDelMessage()
		{
			Message m = GetAttachmentMessage();
			m.Attachments.Remove(0);
			return m;
		}

        /// <summary>
    	/// tests attachments
    	/// </summary>
		[Test]
		public void AttachmentDelMessage()
		{
			Message m = GetAttachmentDelMessage();
		}

	}
}
