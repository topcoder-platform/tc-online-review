using System;
using NUnit.Framework;
using System.IO;
using System.Diagnostics;

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// Unit Test the emailaddresst class.
    /// </summary>
    [TestFixture]
    public class UnitTestMessage
    {
        
        private const string TO_ADDRESS = "development@topcodersoftware.com";
        private const string FROM_ADDRESS = "development@topcodersoftware.com";
        /// <summary>
        /// test parsing a message
        /// </summary>
        [Test]
        public void MessageParse()
        {
            String msg = "From: " + FROM_ADDRESS + "\nTo:"+ TO_ADDRESS +"\nSubject:subj\n\nHello!\n\nThis is the message!";

            Message m = new Message(msg);
            
            Assertion.Assert ( m.From.Email == FROM_ADDRESS );
            Assertion.Assert ( m.To[0].Email == TO_ADDRESS );
            Assertion.Assert ( m.Subject == "subj" );
            Assertion.Assert ( m.Body == "Hello!\n\nThis is the message!" );
        }

        /// <summary>
        /// test constructor1
        /// </summary>
        [Test]
        public void MessageConstructor1()
        {
            Message m = new Message(FROM_ADDRESS, "subj", "This is the message!");
            
            Assertion.Assert ( m.To[0].Email == TO_ADDRESS );
            Assertion.Assert ( m.Subject == "subj" );
            Assertion.Assert ( m.Body == "This is the message!" );
        }

        /// <summary>
        /// test constructor2
        /// </summary>
        [Test]
        public void MessageConstructor2()
        {
            Message m = new Message(new EmailAddress(FROM_ADDRESS), "subj", "This is the message!");
            
            Assertion.Assert ( m.To[0].Email == TO_ADDRESS );
            Assertion.Assert ( m.Subject == "subj" );
            Assertion.Assert ( m.Body == "This is the message!" );
        }

        /// <summary>
        /// test message TOString
        /// </summary>
        [Test]
        public void MessageToString()
        {
            String result;
            String msg = "From: "+FROM_ADDRESS+"\nTo:"+TO_ADDRESS+"\nSubject:subj\n\nHello!\n\nThis is the message!";

            Message m = new Message(msg);
            
            result = m.ToString();

            Assertion.Assert ( result.Length > 0 );
        }

        /// <summary>
        /// test no from error
        /// </summary>
        [Test]
        [ExpectedException(typeof(MessageErrorException))]
        public void MessageWithNoFrom()
        {
            String result;
            
            Message m = new Message(new EmailAddress(FROM_ADDRESS), "subj", "This is the message!");
            
            result = m.ToString();
        }

        /// <summary>
        /// test no to or cc error
        /// </summary>
        [Test]
        [ExpectedException(typeof(MessageErrorException))]
        public void MessageWithNoToOrCC()
        {
            String result;
            String msg = "From: "+FROM_ADDRESS+"\nSubject:subj\n\nHello!\n\nThis is the message!";

            Message m = new Message(msg);
            
            result = m.ToString();
        }

    }
}
