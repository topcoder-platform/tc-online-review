/*
    Copyright c 2003, TopCoder, Inc. All rights reserved
    Author TCSDEVELOPER
*/

using System;
using System.Collections;

using TopCoder.Math.ExpressionEvaluator;

using NUnit.Framework;

namespace TopCoder.Math.ExpressionEvaluator.AccuracyTests {

    /// <summary>
    /// Test cases for the various format variables.
    /// </summary>
    [TestFixture]
    public class VariablesAccuracyTests {
        /// <summary>
        /// Expression instance for tests.
        /// </summary>
        Expression exp;

        /// <summary>
        /// Verifies that the system deals with simple variables correctly
        /// </summary>
        [Test]
        public void TestSimpleVar() {
            Hashtable ht = new Hashtable();
            exp = Expression.Parse("X");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1.234", 
                                   1.234, exp.Evaluate(new string[]{"X"}, 
                                                       new double[] {1.234}));
            ht["X"] = 51.234;
            Assertion.AssertEquals("Expression must evaluate to 51.234", 
                                   51.234, exp.Evaluate(ht));
        }

        /// <summary>
        /// Verifies that the system deals with complex variables correctly
        /// </summary>
        [Test]
        public void TestComplexVar() {
            Hashtable ht = new Hashtable();

            // Heading with underscore "_"
            exp = Expression.Parse("_X");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 1.234", 
                                   1.234, exp.Evaluate(new string[]{"_X"}, 
                                                       new double[] {1.234}));
            ht["_X"] = 61.234;
            Assertion.AssertEquals("Expression must evaluate to 61.234", 
                                   61.234, exp.Evaluate(ht));

            // Mixing characters with numbers
            exp = Expression.Parse("_X1a3Yt00");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 12.34", 
                                   12.34, 
                                   exp.Evaluate(new string[]{"_X1a3Yt00"},
                                                new double[] {12.34}));
            ht["_X1a3Yt00"] = 712.34;
            Assertion.AssertEquals("Expression must evaluate to 712.34",
                                   712.34, exp.Evaluate(ht));
            
            // Mixing with connector
            exp = Expression.Parse("_X1a.3Y.t_00");
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 123.4", 
                                   123.4, 
                                   exp.Evaluate(new string[]{"_X1a.3Y.t_00"},
                                                new double[] {123.4}));
            ht["_X1a.3Y.t_00"] = 8123.4;
            Assertion.AssertEquals("Expression must evaluate to 8123.4",
                                   8123.4, exp.Evaluate(ht));
        }

        /// <summary>
        /// Verifies that the system deals with resolver
        /// </summary>
        [Test]
        public void TestResolver() {
            exp = Expression.Parse("X", new TestNameResolver());
            Assertion.Assert("Expression must parse", exp != null);
            Assertion.AssertEquals("Expression must evaluate to 8.9", 
                                   8.9, exp.Evaluate());
        }
    }

    /// <summary>
    /// Creates instances of Literal. (For testing)
    /// </summary>
    class TestNameResolver : INameResolver {
        /// <summary>
        /// Creates an instance of Literal.
        /// </summary>
        /// <param name="name">Name of the variable.</param>
        /// <returns>An instance of Literal.</returns>
        public Expression Resolve(string name) {
            return new Literal(8.9);
        }
    }
}