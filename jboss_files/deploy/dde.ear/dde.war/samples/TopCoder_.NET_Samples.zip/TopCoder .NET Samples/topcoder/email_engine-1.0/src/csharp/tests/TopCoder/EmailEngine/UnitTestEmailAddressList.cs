using System;
using NUnit.Framework;
using System.IO;
using System.Diagnostics;

namespace TopCoder.EmailEngine
{
    /// <summary>
    /// Unit Test the Attachment class.
    /// </summary>
    [TestFixture]
    public class UnitTestEmailAddressList
    {
        /// <summary>
        /// creates an object and exercises add remove  functionality
        /// </summary>
        [Test]
        public void EmailAddressListAddRemove()
        {
            EmailAddressList eal = new EmailAddressList();
            EmailAddress ea;

            Assertion.Assert (eal.Count == 0);
            eal.Add(new EmailAddress("a@cfl.rr.com"));
            Assertion.Assert (eal.Count == 1);
            eal.Add(new EmailAddress("b@cfl.rr.com"));
            Assertion.Assert (eal.Count == 2);

            for(int loop = 0; loop < eal.Count; loop++)
            {
                ea = eal[loop];
            }

            Assertion.Assert (eal.Count == 2);
            eal.Remove(0);
            Assertion.Assert (eal.Count == 1);
            eal.Remove("b@cfl.rr.com");
            Assertion.Assert (eal.Count == 0);
            
        }

        /// <summary>
        /// creates an object and exercises add clear functionality
        /// </summary>
        [Test]
        public void EmailAddressListAddClear()
        {
            EmailAddressList eal = new EmailAddressList();

            Assertion.Assert (eal.Count == 0);
            eal.Add(new EmailAddress("a@cfl.rr.com"));
            Assertion.Assert (eal.Count == 1);
            eal.Add(new EmailAddress("b@cfl.rr.com"));
            Assertion.Assert (eal.Count == 2);

            eal.Clear();
            Assertion.Assert (eal.Count == 0);
            
        }
 
        /// <summary>
        /// creates an object and exercises ToString functionality
        /// </summary>
        [Test]
        public void EmailAddressListAddToString()
        {
            String result;
            EmailAddressList eal = new EmailAddressList();

            Assertion.Assert (eal.Count == 0);
            eal.Add(new EmailAddress("a@cfl.rr.com"));
            Assertion.Assert (eal.Count == 1);
            eal.Add(new EmailAddress("b@cfl.rr.com"));
            Assertion.Assert (eal.Count == 2);

            result = eal.ToString();
            Assertion.Assert (result == "<a@cfl.rr.com>,<b@cfl.rr.com>");
            
            eal.Clear();
        }
 
        /// <summary>
        /// creates an object and exercises index error
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void EmailAddressListIndexError()
        {
            EmailAddressList eal = new EmailAddressList();
            EmailAddress ea;

            Assertion.Assert (eal.Count == 0);
            eal.Add(new EmailAddress("a@cfl.rr.com"));
            Assertion.Assert (eal.Count == 1);
            eal.Add(new EmailAddress("b@cfl.rr.com"));
            Assertion.Assert (eal.Count == 2);

            ea = eal[345];
            eal.Clear();
            
        }

        /// <summary>
        /// creates an object and exercises remove index error
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void EmailAddressListRemoveIndexError()
        {
            EmailAddressList eal = new EmailAddressList();

            Assertion.Assert (eal.Count == 0);
            eal.Add(new EmailAddress("a@cfl.rr.com"));
            Assertion.Assert (eal.Count == 1);

            eal.Remove(345);
            eal.Clear();
            
        }

        /// <summary>
        /// creates an object that is null and exercises error
        /// </summary>
        [Test]
        [ExpectedException(typeof(MessageErrorException))]
        public void EmailAddressListAddNullError()
        {
            EmailAddressList eal = new EmailAddressList();
            eal.Add(null);
        }

        /// <summary>
        /// creates an object and sorts
        /// </summary>
        [Test]
        public void EmailAddressListSort()
        {
            EmailAddressList eal = new EmailAddressList();

            Assertion.Assert (eal.Count == 0);
            eal.Add(new EmailAddress("b@cfl.rr.com"));
            Assertion.Assert (eal.Count == 1);
            eal.Add(new EmailAddress("a@cfl.rr.com"));
            Assertion.Assert (eal.Count == 2);

            Assertion.Assert ( eal[0].Email == "b@cfl.rr.com");
            Assertion.Assert ( eal[1].Email == "a@cfl.rr.com");

            eal.Sort();

            Assertion.Assert ( eal[0].Email == "a@cfl.rr.com");
            Assertion.Assert ( eal[1].Email == "b@cfl.rr.com");

            eal.Clear();
            
        }

    }
}