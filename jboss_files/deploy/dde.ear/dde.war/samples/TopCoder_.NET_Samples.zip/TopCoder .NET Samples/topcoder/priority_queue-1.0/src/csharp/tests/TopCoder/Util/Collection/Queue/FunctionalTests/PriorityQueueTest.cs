using System;
using TopCoder.Util.Collection.Queue;
using System.Collections;

namespace TopCoder.Util.Collection.Queue.FunctionalTests
{
    using NUnit.Framework;

    /// <summary>
    /// PriorityQueueTest, a test fixture for TopCoder.Util.Collection.PriorityQueue
    /// </summary>
    [TestFixture]
    public class PriorityQueueTests
    {
        private PriorityQueue pq;

        /// <summary>
        /// Sets up test
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            pq = new PriorityQueue();
        }
        
        /// <summary>
        /// Enqueues an object to the priority queue and dequeues it
        /// </summary>
        [Test]
        public void EnqueuePeekAndDequeue()
        {
            string obj = "object";

            Assertion.AssertEquals("Bad object count.",0,pq.Count);

            pq.Enqueue(obj);

            Assertion.AssertEquals("Object not retrieved using Peek.",obj,pq.Peek());
            Assertion.AssertEquals("Bad object count.",1,pq.Count);
            Assertion.AssertEquals("Object not retrieved.",obj,pq.Dequeue());
            Assertion.AssertEquals("Bad object count.",0,pq.Count);
        }

        /// <summary>
        /// Peeks for an object in an empty priority queue
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void PeekEmpty()
        {
            pq.Peek();
        }

        /// <summary>
        /// Removes an object from an empty priority queue
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void DequeueEmpty()
        {
            pq.Dequeue();
        }

        /// <summary>
        /// Creates a synchronized priority queue with a null argument
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SynchronizedNull()
        {
            PriorityQueue.Synchronized(null);
        }

        /// <summary>
        /// Enqueues an object that does not implement the IComparable interface
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void EnqueueNotComparable()
        {
            pq.Enqueue(new object());
        }

        /// <summary>
        /// Enqueues two objects which when compared will throw an exception
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void EnqueueBadCompare()
        {
            pq.Enqueue("string");
            pq.Enqueue(7);
        }

        /// <summary>
        /// Enqueues a few objects and then clears the queue
        /// </summary>
        [Test]
        public void Clear()
        {
            pq.Enqueue(1);
            pq.Enqueue(2);
            pq.Enqueue(3);
            pq.Enqueue(4);
            Assertion.AssertEquals("Bad object count.",4,pq.Count);
            pq.Clear();
            Assertion.AssertEquals("Bad object count.",0,pq.Count);

            pq.Enqueue(0);
            Assertion.AssertEquals("Objects not properly cleared.",0,pq.Dequeue());
        }

        /// <summary>
        /// Enqueues a few objects and tests for their presence
        /// </summary>
        [Test]
        public void Contains()
        {
            Assertion.AssertEquals("Object found in an empty queue.",false,pq.Contains(0));
            pq.Enqueue(0);
            Assertion.AssertEquals("Enqueued object not found.",true,pq.Contains(0));
            Assertion.AssertEquals("Object not enqueued found.",false,pq.Contains(1));

            pq.Enqueue(4);
            pq.Enqueue(7);
            pq.Enqueue(10);
            pq.Enqueue(234);

            Assertion.AssertEquals("Enqueued object not found.",true,pq.Contains(0));
            Assertion.AssertEquals("Enqueued object not found.",true,pq.Contains(4));
            Assertion.AssertEquals("Enqueued object not found.",true,pq.Contains(7));
            Assertion.AssertEquals("Enqueued object not found.",true,pq.Contains(10));
            Assertion.AssertEquals("Enqueued object not found.",true,pq.Contains(234));
            Assertion.AssertEquals("Object not enqueued found.",false,pq.Contains(-1));
        }

        /// <summary>
        /// Enqueues a few objects and checks that they can be copied successfully
        /// </summary>
        [Test]
        public void CopyTo()
        {
            int [] enqueue_objects = {1,6,2,8,9,3,5,10};
            int [] dequeue_objects = {10,9,8,6,5,3,2,1};
            int [] copied_objects = new int [9];
            
            for(int i = 0; i < enqueue_objects.Length; ++i)
                pq.Enqueue(enqueue_objects[i]);

            pq.CopyTo(copied_objects, 0);
            for(int i = 0; i < enqueue_objects.Length; ++i)
            {
                if(copied_objects[i] != dequeue_objects[i])
                    Assertion.Fail("Objects not copied properly.");
            }

            pq.CopyTo(copied_objects, 1);
            for(int i = 0; i < enqueue_objects.Length; ++i)
            {
                if(copied_objects[i+1] != dequeue_objects[i])
                    Assertion.Fail("Objects not copied properly when involving an offset.");
            }
        }

        /// <summary>
        /// Enqueues a few objects and checks that they can be copied into an array
        /// </summary>
        [Test]
        public void ToArray()
        {
            int [] enqueue_objects = {1,6,2,8,9,3,5,10};
            int [] dequeue_objects = {10,9,8,6,5,3,2,1};
            
            for(int i = 0; i < enqueue_objects.Length; ++i)
                pq.Enqueue(enqueue_objects[i]);

            object [] copied_objects = pq.ToArray();
            Assertion.AssertEquals("ToArray() did not return a correct length array",
                enqueue_objects.Length, copied_objects.Length);

            for(int i = 0; i < enqueue_objects.Length; ++i)
            {
                if((int)copied_objects[i] != dequeue_objects[i])
                    Assertion.Fail("Objects not copied properly by ToArray().");
            }
        }

        /// <summary>
        /// Enqueues a few objects and checks that they are enumerated correctly
        /// </summary>
        [Test]
        public void Enumerate()
        {
            int [] enqueue_objects = {1,6,2,8,9,3,5,10};
            int [] dequeue_objects = {10,9,8,6,5,3,2,1};
            
            for(int i = 0; i < enqueue_objects.Length; ++i)
                pq.Enqueue(enqueue_objects[i]);

            int currindex = 0;
            foreach(int currobject in pq)
            {
                if(currobject != dequeue_objects[currindex++])
                    Assertion.Fail("Objects enumerating properly.");
            }

            Assertion.AssertEquals("Not enough objects enumerated",
                enqueue_objects.Length, currindex);
        }

        /// <summary>
        /// Enqueues a few objects, modifies the queue and attempts to enumerate
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void EnumerateOperate()
        {
            int [] enqueue_objects = {1,6,2,8,9,3,5,10};
            int [] dequeue_objects = {10,9,8,6,5,3,2,1};
            
            for(int i = 0; i < enqueue_objects.Length; ++i)
                pq.Enqueue(enqueue_objects[i]);

            IEnumerator e = pq.GetEnumerator();

            pq.Clear();
            
            e.MoveNext();
        }

        /// <summary>
        /// Enqueues a few objects and checks that they dequeued correctly where the
        /// object and value differ
        /// </summary>
        [Test]
        public void EnqueueObjectAndPriority()
        {
            int [] enqueue_objects = {1,6,2,8,9,3,5,10};
            int [] dequeue_objects = {7,4,3,1,6,5,2,0};
            
            for(int i = 0; i < enqueue_objects.Length; ++i)
                pq.Enqueue(i, enqueue_objects[i]);

            int currindex = 0;
            foreach(int currobject in pq)
            {
                if(currobject != dequeue_objects[currindex++])
                    Assertion.Fail("Objects enumerating properly.");
            }

            Assertion.AssertEquals("Not enough objects enumerated",
                enqueue_objects.Length, currindex);
        }

        /// <summary>
        /// Constructs a PriorityQueue with a collection which is null
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructBadCollection()
        {
            ICollection coll = null;
            PriorityQueue testpq = new PriorityQueue(coll);
        }

        /// <summary>
        /// Constructs a PriorityQueue with a collection which is not comparable
        /// </summary>
        [Test]
        [ExpectedException(typeof(InvalidOperationException))]
        public void ConstructIncomparableCollection()
        {
            ArrayList al = new ArrayList();
            al.Add("string");
            al.Add(7);
            PriorityQueue testpq = new PriorityQueue(al);
        }

        /// <summary>
        /// Constructs a PriorityQueue with a collection
        /// </summary>
        public void Collection()
        {
            int [] enqueue_objects = {1,6,2,8,9,3,5,10};
            int [] dequeue_objects = {10,9,8,6,5,3,2,1};

            PriorityQueue testpq = new PriorityQueue(enqueue_objects);
            
            object [] copied_objects = pq.ToArray();
            Assertion.AssertEquals("Construction by collection did not return a correct length array using ToArray()",
                enqueue_objects.Length, copied_objects.Length);

            for(int i = 0; i < enqueue_objects.Length; ++i)
            {
                if((int)copied_objects[i] != dequeue_objects[i])
                    Assertion.Fail("Construction by collection did not return correct objects using ToArray().");
            }
        }
    }
}
