/*
Copyright c 2003, TopCoder, Inc. All rights reservedusing System;
Author pzhao
Author TopCoder Software
*/

using System;

using NUnit.Framework;

namespace TopCoder.Util.Collection.Queue.StressTests
{
    /// <summary>
    /// Abstract benchmark class containing code to run a benchmark mulitple 
    /// times and compute basic statistics (min, max, mean, std. deviation). 
    /// Subclasses should implement the <c>runOnce</c> method and call 
    /// <c>runBenchmark</c> from a method that will be executed by NUnit.
    /// </summary>
    /// <remarks>
    /// This code is based on the java version of AbstractBenchmark class.
    /// </remarks>
    public abstract class AbstractBenchmark 
    {
        private string TestName;
        private int iters;
        private long min, max;
        private double mean, stddev;

        /// <summary>
        /// Constructor of <c>AbstractBenchmark</c> class.
        /// </summary>
        protected AbstractBenchmark(string TestName) {
            this.TestName = TestName;
        }

        /// <summary>
        /// Run once of the benchmark test.
        /// </summary>
        public abstract void RunOnce();

        /// <summary>
        /// Run the <c>runOnce</c> method for a specified number of 
        /// times and calculates the statistics result (min, max, mean,
        /// std. deviation). The statistics are written to standard output.
        /// </summary>
        /// <param name="iters">The number of times to run.</param>
        public void RunBenchmark(int iters) 
        {
            this.iters = iters;
            long[] times = new long[iters];
            int i;

            // Run the test for iters times
            long sum = 0;
            min = Int64.MaxValue;
            max = -1;

            for (i = 0; i < iters; i++) 
            {
                long start = Environment.TickCount;
                RunOnce();
                times[i] = Environment.TickCount - start; 
                sum += times[i];
                min = Math.Min(min, times[i]);
                max = Math.Max(max, times[i]);
            }
      
            // Calculate the statistics result
            mean = ((double) sum) / iters;
            double totaldiff = 0.0;
            for (i = 0; i < iters; i++) {
                double diff = mean - times[i];
                totaldiff += diff * diff;
            }
            stddev = Math.Sqrt(totaldiff / (iters - 1));
            
        }

        /// <summary>
        /// Output the benchmark result
        /// </summary>
        public void OutputResult()
        {
            Console.WriteLine("");
            Console.WriteLine("{0}:", TestName);
            Console.WriteLine("     iters={0} min={1} max={2} mean={3} stddev={4}",
                              iters, min, max, mean, stddev);
        }
    }
}
