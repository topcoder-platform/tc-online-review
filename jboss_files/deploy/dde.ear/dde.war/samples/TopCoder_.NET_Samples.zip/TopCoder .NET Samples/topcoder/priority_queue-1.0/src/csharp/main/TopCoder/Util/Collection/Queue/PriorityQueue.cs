/*
Copyright c 2003, TopCoder, Inc. All rights reserved
Author cruizza
Author opi
*/
using System;
using System.Collections;
using System.Threading;
using System.Reflection;

namespace TopCoder.Util.Collection.Queue
{
    /// <summary>
    /// The Priority Queue component supports standard queue functionality, except that it does not
    /// follow the first-in-first-out (FIFO) paradigm. Items added to a priority queue implementation
    /// require assigning a priority level to the item. Items then can be added in arbitrary order to the
    /// queue, but are removed based on the priority.
    /// </summary>
    /// <author>TCSDESIGNER</author>
    /// <author>TCSDEVELOPER</author>
    public class PriorityQueue : ICloneable, IEnumerable, ICollection
    {
        /// <summary>
        /// A Comparison object that compares priority values.
        /// Can be null in which case the priority object must implement the IComparable
        /// interface.
        /// </summary>
        IComparer priorityComparer = null;

        /// <summary>
        /// An array which is created when an enumeration is requested. The
        /// object is removed whenever an operation occurs.
        /// </summary>
        object [] enumArray = null;

        /// <summary>
        /// An ArrayList which is created when an enumeration is requested. The
        /// object is removed whenever an operation occurs, invalidating enumerators upon
        /// calls to IsEnumeratorValid.
        /// </summary>
        ArrayList enumerators = null;

        /// <summary>
        /// An internal object which stores an object and its associated priority
        /// </summary>
        private struct PriorityObject
        {
            public object obj;
            public object priority;
        }

        /// <summary>
        /// The heap, being the core of the priority queue with data stored in it
        /// </summary>
        PriorityObject [] heap = null;

        /// <summary>
        /// Size of the heap
        /// </summary>
        int heapSize = 0;

        /// <summary>
        /// Static constants that define the default values of the initial capacity
        /// and the growth factor.
        /// </summary>
        static int DEFAULT_INITIAL_CAPACITY = 32;
        static float DEFAULT_GROW_FACTOR = 2.0F;
        static IComparer DEFAULT_COMPARER = Comparer.Default;

        /// <summary>
        /// Attributes of the heap
        /// </summary>
        float heapGrowFactor = 0F;
        int heapInitialCapacity = 0;
        int heapCapacity = 0;

        /// <summary>
        /// The SynchronizedPriorityQueue is derived from a PriorityQueue and behaves as a
        /// thread-safe version. It must be created through the Synchronized static method.
        /// All method calls are referred through to the unsynchronized queue after using
        /// the lock command to invoke a critical section.
        /// </summary>
        private class SynchronizedPriorityQueue : PriorityQueue
        {
            private PriorityQueue queueUnsynchronized = null;

            public SynchronizedPriorityQueue(PriorityQueue queue)
            {
                queueUnsynchronized = queue;
            }

            /// <summary>
            /// The number of elements contained in the PriorityQueue.
            /// </summary>
            public override int Count 
            {
                get
                {
                    int count=0;
                    lock(this.SyncRoot)
                    {
                        count = queueUnsynchronized.Count;
                    }
                    return count; 
                }
            }

            /// <summary>
            /// true if access to the PriorityQueue is synchronized (thread-safe);
            /// otherwise, false.
            /// </summary>
            public override bool IsSynchronized { get { return true; } }

            /// <summary>
            /// An object that can be used to synchronize access to the PriorityQueue.
            /// </summary>
            public override object SyncRoot { get { return queueUnsynchronized; } }

            /// <summary>
            /// Determines whether the enumerator is valid. An enumerator is invalidated when
            /// the contents of the queue are changed.
            /// </summary>
            /// <param name="enumerator">Enumerator to check status of</param>
            /// <returns>true if the enumerator is valid; otherwise false</returns>
            protected override bool IsEnumeratorValid(PriorityQueueEnumerator enumerator)
            {
                bool isEnumValid = false;
                lock(this.SyncRoot)
                {
                    isEnumValid = queueUnsynchronized.IsEnumeratorValid(enumerator);
                }
                return isEnumValid;
            }

            /// <summary>
            /// Retrieves the object for the enumerator corresponding to the provided
            /// enumeration index.
            /// </summary>
            /// <param name="index">Index to retrieve object from</param>
            /// <param name="pqe">Enumerator which is enumerating</param>
            /// <exception cref="InvalidOperationException">Enumerator is invalid</exception>
            /// <returns>The object in the priority queue at the specified index</returns>
            protected override object EnumCurrent(int index, PriorityQueueEnumerator pqe)
            {
                object enumCur = null;
                lock(this.SyncRoot)
                {
                    enumCur = queueUnsynchronized.EnumCurrent(index, pqe);
                }
                return enumCur;
            }

            /// <summary>
            /// Removes all objects from the PriorityQueue
            /// </summary>
            public override void Clear()
            {
                lock(this.SyncRoot)
                {
                    queueUnsynchronized.Clear();
                }
            }

            /// <summary>
            /// Creates a shallow copy of the PriorityQueue
            /// </summary>
            /// <returns>A shallow copy of the PriorityQueue</returns>
            public override object Clone()
            {
                object cloneObj = null;
                lock(this.SyncRoot)
                {
                    cloneObj = queueUnsynchronized.Clone();
                }
                return cloneObj;
            }

            /// <summary>
            /// Determines whether an element is in the PriorityQueue
            /// </summary>
            /// <param name="obj">The Object to locate in the PriorityQueue. The value can
            /// be a null reference (Nothing in Visual Basic).</param>
            /// <returns>true if obj is found in the PriorityQueue; otherwise, false.</returns>
            public override bool Contains(object obj)
            {
                bool containsObj = false;
                lock(this.SyncRoot)
                {
                    containsObj = queueUnsynchronized.Contains(obj);
                }
                return containsObj;
            }

            /// <summary>
            /// Copies the PriorityQueue elements to an existing one-dimensional Array, starting
            /// at the specified array index.
            /// </summary>
            /// <param name="array">The one-dimensional Array that is the destination of the
            /// elements copied from PriorityQueue. The Array must have zero-based indexing.</param>
            /// <param name="index">The zero-based index in array at which copying begins.</param>
            public override void CopyTo(Array array, int index)
            {
                lock(this.SyncRoot)
                {
                    queueUnsynchronized.CopyTo(array, index);
                }
            }

            /// <summary>
            /// Removes and returns the object at the beginning of the Queue. This will be the
            /// object with the highest priority.
            /// </summary>
            /// <returns>The object that is removed from the beginning of the Queue.</returns>
            /// <exception cref="InvalidOperationException">The PriorityQueue is empty.</exception>
            public override object Dequeue()
            {
                object obj = null;
                lock(this.SyncRoot)
                {
                    obj = queueUnsynchronized.Dequeue();
                }
                return obj;
            }

            /// <summary>
            /// Adds an object to the PriorityQueue. Its position is based on its priority. A
            /// higher priority is placed towards the front.
            /// </summary>
            /// <param name="obj">The object to add to the PriorityQueue. The value can be a null
            /// reference (Nothing in Visual Basic).</param>
            /// <param name="priority">The priority of the object being added to the
            /// PriorityQueue.</param>
            /// <exception cref="ArgumentException">The PriorityQueue is set to use the IComparable
            /// interface, and priority does not implement the IComparable interface.</exception>
            /// <exception cref="InvalidOperationException">The comparer throws an exception.</exception>
            public override void Enqueue(object obj, object priority)
            {
                lock(this.SyncRoot)
                {
                    queueUnsynchronized.Enqueue(obj, priority);
                }
            }

            /// <summary>
            /// Adds an object to the PriorityQueue. Its position is based on the value of the
            /// object. A higher value is placed towards the front.
            /// </summary>
            /// <param name="obj">The object to add to the PriorityQueue. The value can be a null
            /// reference (Nothing in Visual Basic).</param>
            /// <exception cref="ArgumentException">The PriorityQueue is set to use the IComparable
            /// interface, and object does not implement the IComparable interface.</exception>
            /// <exception cref="InvalidOperationException">The comparer throws an exception.</exception>
            /// <remarks>In terms of priority, the object's priority is its value.</remarks>
            public override void Enqueue(object obj)
            {
                this.Enqueue(obj, obj);
            }

            /// <summary>
            /// Returns an enumerator that can iterate through the PriorityQueue.
            /// </summary>
            /// <returns>An IEnumerator for the PriorityQueue.</returns>
            public override IEnumerator GetEnumerator()
            {
                IEnumerator pqEnum = null;
                lock(this.SyncRoot)
                {
                    pqEnum = queueUnsynchronized.GetEnumerator();
                }
                return pqEnum;
            }

            /// <summary>
            /// Returns the object at the beginning of the PriorityQueue without removing it.
            /// </summary>
            /// <returns>The object at the beginning of the PriorityQueue.</returns>
            /// <exception cref="InvalidOperationException">The PriorityQueue is empty.</exception>
            public override object Peek()
            {
                object obj = null;
                lock(this.SyncRoot)
                {
                    obj = queueUnsynchronized.Peek();
                }
                return obj;
            }

            /// <summary>
            /// Copies the PriorityQueue elements to a new array.
            /// </summary>
            /// <returns>A new array containing elements copied from the PriorityQueue.</returns>
            public override object[] ToArray()
            {
                object [] objArray = null;
                lock(this.SyncRoot)
                {
                    objArray = queueUnsynchronized.ToArray();
                }
                return objArray;
            }

            /// <summary>
            /// Sets the capacity to the actual number of elements in the PriorityQueue.
            /// </summary>
            public override void TrimToSize()
            {
                lock(this.SyncRoot)
                {
                    queueUnsynchronized.TrimToSize();
                }
            }
        }

        /// <summary>
        /// An enumerator implementation for the PriorityQueue class
        /// </summary>
        protected class PriorityQueueEnumerator : IEnumerator
        {
            private PriorityQueue queue = null;
            private int index = -1;

			/// <summary>
			/// PriorityQueue enumerator constructor
			/// </summary>
			/// <param name="priqueue">PriorityQueue to enumerate</param>
            public PriorityQueueEnumerator(PriorityQueue priqueue)
            {
                this.queue = priqueue;
                // Set enumArray to the Dequeued values of the PriorityQueue queue
                this.queue.enumArray = this.queue.ToArray();
            }

            /// <summary>
            /// The current element in the collection.
            /// </summary>
            /// <exception cref="InvalidOperationException">Enumerator is invalid</exception>
            public object Current
            {
                get
                {
                    // If the enumerator is valid, return the object in the enumArray at the
                    // current index.
                    if (this.queue.IsEnumeratorValid(this))
                    {
                        return this.queue.enumArray[index];
                    }
                    else
                    {
                        throw new InvalidOperationException("Enumerator is invalid");
                    }
                }
            }

            /// <summary>
            /// Sets the enumerator to its initial position, which is before the first
            /// element in the collection.
            /// </summary>
            /// <exception cref="InvalidOperationException">Enumerator is invalid</exception>
            public void Reset()
            {
                this.index = -1;
            }

            /// <summary>
            /// Advances the enumerator to the next element of the collection.
            /// </summary>
            /// <exception cref="InvalidOperationException">Enumerator is invalid</exception>
            /// <returns>true if the enumerator was successfully advanced to the next
            /// element; false if the enumerator has passed the end of the collection.
            /// </returns>
            public bool MoveNext()
            {
                // If this enumerator is invalid, throw an InvalidOperationException
                if (!queue.IsEnumeratorValid(this))
                {
                    throw new InvalidOperationException("Enumerator is invalid");
                }

                // If there are more elements in enumArray, increment the current position
                // and return true
                if (this.index < this.queue.enumArray.Length-1)
                {
                    this.index++;
                    return true;
                }
                    // Otherwise the end of the array has been reached.
                else
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// Determine if the heap needs to expand to hold addSize more elements.
        /// </summary>
        /// <param name="addSize">The number of new objects that need to be added to the heap.</param>
        private void HeapGrow(int addSize)
        {
            // Determine if the current heap needs more space for the new objects.
            if ((this.heapSize + addSize) > this.heapCapacity)
            {
                int newSize=heapCapacity;
                // Keep incresing the heap size by heapGrowFactor until it is large enough
                // to hold the new objects.
                while (newSize < this.heapSize+addSize)
                {
					int tempSize = (int) ((float)(newSize) * this.heapGrowFactor);

                    // Add 1 to tempSize to insure that tempSize will increase even if 
                    // heapGrowFactor is small (~1.0).
					if (tempSize == newSize)
					{
						tempSize++;
					}
					newSize = tempSize;
                }
                // Allocate a new heap of size newSize
                PriorityObject [] tempHeap = new PriorityObject[newSize];
                
                this.heapCapacity = newSize;
                // Copy the contents of the old heap to the new heap.
                this.heap.CopyTo(tempHeap, 0);
                // Point heap to the new heap.
                this.heap = tempHeap;
            }
        }
        /// <summary>
        /// Remove the last reduceSize objects from the heap.
        /// </summary>
        /// <param name="reduceSize">The number of objects to remove</param>
        private void HeapReduce(int reduceSize)
        {
            this.heapSize--;
            this.heap[this.heapSize].obj = null;
            this.heap[this.heapSize].priority = null;
        }

        /// <summary>
        /// Compare function that uses defined or default Comparator
        /// </summary>
        /// <param name="a">Object to be compared</param>
        /// <param name="b">Object to be compared</param>
        private int HeapCompare(object a, object b)
        {
            int comp=0;

            try
            {
                comp = this.priorityComparer.Compare(a, b);
            }
            catch (ArgumentException argExcp)
            {
                throw argExcp;
            }
            catch (Exception excp)
            {
                throw excp;
            }
            return comp;
        }
        /// <summary>
        /// Exchange two elements in the heap.
        /// </summary>
        /// <param name="a">Object to be exchanged</param>
        /// <param name="b">Object to be exchanged</param>
        private void HeapExchange(int a, int b)
        {
            PriorityObject poTemp = this.heap[a];
            this.heap[a] = this.heap[b];
            this.heap[b] = poTemp;
        }
        /// <summary>
        /// Maintain the heap
        /// Inserts a new object into the heap so that it's priority is less than its parent
        /// but is greater than its children.
        ///		Running time of O(lg n)
        /// </summary>
        private void MaxHeapify(int top)
        {
            int largest=0;
            int heapLeft = (top*2)+1;
            int heapRight = (top*2)+2;

            if (heapLeft < this.heapSize && 
                this.HeapCompare(this.heap[heapLeft].priority, this.heap[top].priority) > 0)
            {
                largest = heapLeft;
            }
            else
            {
                largest = top;
            }
            if (heapRight < this.heapSize && 
                this.HeapCompare(this.heap[heapRight].priority, this.heap[largest].priority) > 0)
            {
                largest = heapRight;
            }

            if (largest != top)
            {
                PriorityObject poTemp = this.heap[largest];
                this.heap[largest] = this.heap[top];
                this.heap[top] = poTemp;
                this.MaxHeapify(largest);
            }
        }
        /// <summary>
        /// Set the value of a given object's priority and then move it up into the heap
        /// until it satisfies the constraints of a heap - its priority is less than its parents
        /// but greater than its children.
        /// </summary>
        /// <param name="index">Objects index into the heap.</param>
        /// <param name="priority">New priority for this object.</param>
        private void HeapIncreaseKey(int index, object priority)
        {
            if (this.HeapCompare(priority, this.heap[index].priority) >= 0)
            {
                this.heap[index].priority = priority;
                int i = index;
                // Calculate location of index's parent
			    int heapParent = (i-1)/2;

                while (i > 0 &&
                    this.HeapCompare(this.heap[heapParent].priority, this.heap[i].priority) < 0)
                {
                    this.HeapExchange(i, heapParent);
                    i = heapParent;
                    heapParent = (i-1)/2;
                }
            }
        }

        /// <summary>
        /// Pops the object off the top of the heap by manipulating the heap and
        /// decreasing the heap size.
        /// </summary>
        /// <returns>The object that was on top of the heap</returns>
        private PriorityObject PopHeap()
        {
            PriorityObject priobj;
            priobj.obj = priobj.priority = null;
            // Return a null value if the PriorityQueue is empty.
            if (this.heapSize > 0)
            {
                priobj = heap[0];
                // If there is only one element in the heap, just shrink the heap to 0.
                if (this.heapSize == 1)
                {
                    this.HeapReduce(1);
                }
                else
                {
                    // After removing the top object, move the object at the bottom of the 
                    // PriorityQueue to the top and re-"heapify" the heap.
                    this.heap[0] = this.heap[this.heapSize-1];
                    this.HeapReduce(1);
                    this.MaxHeapify(0);
                }
            }
            return priobj;
        }

        /// <summary>
        /// Peeks at the object on top of the heap
        /// </summary>
        /// <returns>The object that is on top of the heap</returns>
        private PriorityObject PeekHeap()
        {
            PriorityObject priobj;
            priobj.obj = priobj.priority = null;
            // Return a null value if the heap is empty.
            if (this.heapSize > 0)
            {
                priobj.obj = this.heap[0].obj;
                priobj.priority = this.heap[0].priority;
            }
            return priobj;
        }

        /// <summary>
        /// Pushes an object into the heap by manipulating the heap and increasing the
        /// heap size.
        /// </summary>
        /// <param name="priobj">The object to be placed in the heap</param>
        private void PushHeap(PriorityObject priobj)
        {
            // Increase the size of the heap
            this.HeapGrow(1);
            // Place the new object into the heap
            this.heap[this.heapSize] = priobj;
            // Increase the size of the heap.
            this.heapSize++;
            // Reorder the heap
            this.HeapIncreaseKey(this.heapSize-1, priobj.priority);
        }

        /// <summary>
        /// Determines whether the enumerator is valid. An enumerator is invalidated when
        /// the contents of the queue are changed.
        /// </summary>
        /// <param name="enumerator">Enumerator to check status of</param>
        /// <returns>true if the enumerator is valid; otherwise false</returns>
        protected virtual bool IsEnumeratorValid(PriorityQueueEnumerator enumerator)
        {
            // If the enumerators array has been set to null, something has been added or removed
            // from the PriorityQueue so all enumerators are invalid
            if (this.enumerators != null)
            {
                // Make sure that this enumerator came from this PriorityQueue
                if (this.enumerators.Contains(enumerator))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Retrieves the object for the enumerator corresponding to the provided
        /// enumeration index.
        /// </summary>
        /// <param name="index">Index to retrieve object from</param>
        /// <param name="pqe">Enumerator which is enumerating</param>
        /// <exception cref="InvalidOperationException">Enumerator is invalid</exception>
        /// <returns>The object in the priority queue at the specified index</returns>
        protected virtual object EnumCurrent(int index, PriorityQueueEnumerator pqe)
        {
            // If enumerator is invalid, throw InvalidOperationException
            if (!this.IsEnumeratorValid(pqe))
            {
                throw new InvalidOperationException("PriorityQueueEnumerator is invalid");
            }
            // Make sure index is within the range of enumArray
            if ((index >= 0) && (index < this.enumArray.Length))
            {
                // otherwise, return the object 
                return ((PriorityObject)this.enumArray[index]).obj;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// The number of elements contained in the PriorityQueue.
        /// </summary>
        public virtual int Count { get { return this.heapSize; } }

        /// <summary>
        /// true if access to the PriorityQueue is synchronized (thread-safe);
        /// otherwise, false.
        /// </summary>
        public virtual bool IsSynchronized { get { return false; } }

        /// <summary>
        /// An object that can be used to synchronize access to the PriorityQueue.
        /// </summary>
        public virtual object SyncRoot { get { return this; } }

        /// <summary>
        /// Handle construction details that are common across all constructors
        /// </summary>
        private void CommonConstruction(int capacity, float growFactor, IComparer comparer)
        {
            if (capacity < 0)
            {
                throw new ArgumentOutOfRangeException
                    ("capacity", capacity, "Capacity parameter cannot be negative");
            }
            if (growFactor < 1.0 || growFactor > 10.0)
            {
                throw new ArgumentOutOfRangeException
                    ("growFactor", growFactor, "GrowFactor cannot be less than 1.0 or greater than 10.0");
            }
            this.heapGrowFactor = growFactor;
            this.heapInitialCapacity = capacity;
            this.heap = new PriorityObject[heapInitialCapacity];
            this.heapCapacity = heapInitialCapacity;
            this.heapSize = 0;
            if (comparer == null)
            {
                this.priorityComparer = DEFAULT_COMPARER;
            }
            else
            {
                this.priorityComparer = comparer;
            }        
        }

        
        /// <summary>
        /// Initializes a new instance of the PriorityQueue class that is empty, has the
        /// default initial capacity and uses the default growth factor.
        /// </summary>
        /// <remarks>The default initial capacity is 32 and the default growth factor is 2.0</remarks>
        public PriorityQueue()
            : this(PriorityQueue.DEFAULT_INITIAL_CAPACITY,
                   PriorityQueue.DEFAULT_GROW_FACTOR, PriorityQueue.DEFAULT_COMPARER)
        {
        }

        /// <summary>
        /// Initializes a new instance of the PriorityQueue class that contains elements copied
        /// from the specified collection, has the same initial capacity as the number of
        /// elements copied and uses the default growth factor.
        /// </summary>
        /// <param name="col">The ICollection to copy elements from.</param>
        /// <exception cref="ArgumentNullException">col is a null reference
        /// (Nothing in Visual Basic).</exception>
        /// <exception cref="InvalidCastException">One or more elements in col do not
        /// implement the IComparable interface.</exception>
        /// <remarks>If the collection is of type PriorityQueue, the priorities are copied.
        /// The default growth factor is 2.0</remarks>
        public PriorityQueue(ICollection col)
            : this(col, PriorityQueue.DEFAULT_COMPARER)
        {
        }

        /// <summary>
        /// Initializes a new instance of the PriorityQueue class that is empty, has the
        /// default initial capacity, uses the default growth factor, and is ordered
        /// according to the specified IComparer interface.
        /// </summary>
        /// <param name="comparer">The IComparer implementation to use when comparing priorities
        /// -or-
        /// A null reference (Nothing in Visual Basic) to use the IComparable implementation
        /// of each key.</param>
        /// <remarks>The default initial capacity is 32 and the default growth factor is 2.0</remarks>
        public PriorityQueue(IComparer comparer)
            : this(PriorityQueue.DEFAULT_INITIAL_CAPACITY,
                PriorityQueue.DEFAULT_GROW_FACTOR, comparer)
        {
        }

        /// <summary>
        /// Initializes a new instance of the PriorityQueue class that contains elements copied
        /// from the specified collection, has the same initial capacity as the number of
        /// elements copied and uses the default growth factor.
        /// </summary>
        /// <param name="col">The ICollection to copy elements from.</param>
        /// <param name="comparer">The IComparer implementation to use when comparing priorities
        /// -or-
        /// A null reference (Nothing in Visual Basic) to use the IComparable implementation
        /// of each key.</param>
        /// <exception cref="ArgumentNullException">col is a null reference
        /// (Nothing in Visual Basic).</exception>
        /// <exception cref="InvalidOperationException">The comparer throws an exception.</exception>
        /// <remarks>If the collection is of type PriorityQueue, the priorities are copied.
        /// The default growth factor is 2.0</remarks>
        public PriorityQueue(ICollection col, IComparer comparer)
        {
            // If col is null, throw ArgumenNullException
            if (col == null)
            {
                throw new ArgumentNullException("ICollection col", "ICollection parameter cannot be null");
            }

            // Define a common object to compare to ICollection objects
            object commonObject = null;
            bool colIsPriorityQueue = false;
			
            // Determine if the collection is a PriorityQueue
            if (col.GetType() == typeof(TopCoder.Util.Collection.Queue.PriorityQueue))
            {
                colIsPriorityQueue = true;
            }

            // Setup all the basic values in the PriorityQueue
            this.CommonConstruction(col.Count, PriorityQueue.DEFAULT_GROW_FACTOR, comparer);

            // Iterate through the collection checking for IComparable Interfaces and for
            // "comparability" between objects.
            foreach (object o in col)
            {

                // Determine if object has implemented the IComparable Interface
                Type objectType = o.GetType().GetInterface("IComparable", true);
                if (objectType == null)
                {
                    throw new InvalidCastException
                        ("Object in collection does not implement IComparable Interface");
                }
                // Hold an object from the collection to test "comparability" against other
                // objects in the collection.
                if (commonObject == null)
                {
                    commonObject = o;
                }
                else
                {
                    try
                    {
                        // If the Collection is a PriorityQueue, test the commonObject against
                        // other objects Priority object.
                        if (colIsPriorityQueue == true)
                        {
                            this.priorityComparer.Compare(((PriorityObject)commonObject).priority,
                                ((PriorityObject)o).priority);
                        }
                        // Otherwise, just test "comparability" between the objects.
                        else
                        {
                            this.priorityComparer.Compare(commonObject, o);
                        }
                    }
                    // If any of the Compares fail, they will throw an ArgumentException.
                    // Accept this and rethrow as InvalidCastException.
                    catch (ArgumentException e)
                    {
                        throw new InvalidOperationException
                            ("Collection contains incomparable objects\n" + e);
                    }
                }

                // If the collection object is valid, place it into the PriorityQueue.
                if (colIsPriorityQueue)
                {
                    PriorityObject po = (PriorityObject) o;
                    this.Enqueue(po.obj, po.priority);
                }
                else
                {
                    this.Enqueue(o);
                }
            }		
        }

        /// <summary>
        /// Initializes a new instance of the Queue class that is empty, has the specified
        /// initial capacity and uses the default growth factor.
        /// </summary>
        /// <param name="capacity">The initial number of elements that the Queue can contain.</param>
        /// <exception cref="ArgumentOutOfRangeException">capacity is less than zero.</exception>
        /// <remarks>The default growth factor is 2.0</remarks>
        public PriorityQueue(int capacity)
            : this(capacity, PriorityQueue.DEFAULT_GROW_FACTOR,
                PriorityQueue.DEFAULT_COMPARER)
        {
        }

        /// <summary>
        /// Initializes a new instance of the Queue class that is empty, has the specified
        /// initial capacity and uses the default growth factor. Priority is ordered
        /// according to the specified IComparer interface.
        /// </summary>
        /// <param name="capacity">The initial number of elements that the Queue can contain.</param>
        /// <param name="comparer">The IComparer implementation to use when comparing priorities
        /// -or-
        /// A null reference (Nothing in Visual Basic) to use the IComparable implementation
        /// of each key.</param>
        /// <exception cref="ArgumentOutOfRangeException">capacity is less than zero.</exception>
        /// <remarks>The default growth factor is 2.0</remarks>
        public PriorityQueue(int capacity, IComparer comparer)
            : this(capacity, PriorityQueue.DEFAULT_GROW_FACTOR, comparer)
        {
        }

        /// <summary>
        /// Initializes a new instance of the Queue class that is empty, has the specified
        /// initial capacity and uses the specified growth factor.
        /// </summary>
        /// <param name="capacity">The initial number of elements that the Queue can contain.</param>
        /// <param name="growFactor">The factor by which the capacity of the Queue is expanded.</param>
        /// <exception cref="ArgumentOutOfRangeException">capacity is less than zero.
        /// -or-
        /// growFactor is less than 1.0 or greater than 10.0.</exception>
        public PriorityQueue(int capacity, float growFactor)
            : this(capacity, growFactor, PriorityQueue.DEFAULT_COMPARER)
        {
        }

        /// <summary>
        /// Initializes a new instance of the Queue class that is empty, has the specified
        /// initial capacity and uses the specified growth factor. Priority is ordered
        /// according to the specified IComparer interface.
        /// </summary>
        /// <param name="capacity">The initial number of elements that the Queue can contain.</param>
        /// <param name="growFactor">The factor by which the capacity of the Queue is expanded.</param>
        /// <param name="comparer">The IComparer implementation to use when comparing priorities
        /// -or-
        /// A null reference (Nothing in Visual Basic) to use the IComparable implementation
        /// of each key.</param>
        /// <exception cref="ArgumentOutOfRangeException">capacity is less than zero.
        /// -or-
        /// growFactor is less than 1.0 or greater than 10.0.</exception>
        public PriorityQueue(int capacity, float growFactor, IComparer comparer)
        {
            this.CommonConstruction(capacity, growFactor, comparer);
        }

        /// <summary>
        /// Removes all objects from the PriorityQueue
        /// </summary>
        public virtual void Clear()
        {
            // Clear each object reference in the heap
            for (int index=0; index<this.heapSize; index++)
            {
                this.heap[index].obj = null;
                this.heap[index].priority = null;
            }
            // Reset heapSize to 0
            this.heapSize = 0;

            // Set enumerators and enumArray to null to invalidate all enumerators.
            this.enumerators = null;
            this.enumArray = null;
        }

        /// <summary>
        /// Creates a shallow copy of the PriorityQueue
        /// </summary>
        /// <returns>A shallow copy of the PriorityQueue</returns>
        public virtual object Clone()
        {
            // Create a new PriorityQueue
            PriorityQueue priqueue = 
                new PriorityQueue(this.heapCapacity, this.heapGrowFactor, this.priorityComparer);

            // Copy each object reference (shallow copy) to the new PriorityQueue
            for (int i=0; i<this.heapSize; i++)
            {
                priqueue.heap[i] = this.heap[i];
            }

            // Set the new heapSize to the original heapSize.
            priqueue.heapSize = this.heapSize;
            return priqueue;
        }

        /// <summary>
        /// Determines whether an element is in the PriorityQueue
        /// </summary>
        /// <param name="obj">The Object to locate in the PriorityQueue. The value can
        /// be a null reference (Nothing in Visual Basic).</param>
        /// <returns>true if obj is found in the PriorityQueue; otherwise, false.</returns>
        public virtual bool Contains(object obj)
        {
            // If no object is specified, return false.
            if (obj != null)
            {
                // Search the heap for obj - return true if found, false otherwise.
                ArrayList al = new ArrayList(this.Count);
                for (int index=0; index<this.Count; index++)
                {
                    al.Add(heap[index].obj);
                }
                return (al.Contains(obj));
            }
            return false;
        }

        /// <summary>
        /// Copies the PriorityQueue elements to an existing one-dimensional Array, starting at the
        /// specified array index.
        /// </summary>
        /// <param name="array">The one-dimensional Array that is the destination of the
        /// elements copied from PriorityQueue. The Array must have zero-based indexing.</param>
        /// <param name="index">The zero-based index in array at which copying begins.</param>
        public virtual void CopyTo(Array array, int index)
        {
            int i=0;
            // Create a new PriorityQueue
            PriorityQueue priqueue =
                new PriorityQueue(this.heapCapacity, this.heapGrowFactor, this.priorityComparer);
            // Copy objects to new PriorityQueue
            for (i=0; i<this.heapSize; i++)
            {
                priqueue.heap[i].obj = this.heap[i].obj;
                priqueue.heap[i].priority = this.heap[i].priority;
            }
            priqueue.heapSize = this.heapSize;

            // Dequeue new PriorityQueue into array starting at given index
            i = index;
            while (priqueue.Count > 0)
            {
                array.SetValue(priqueue.Dequeue(), i);
                i++;
            }
        }

        /// <summary>
        /// Removes and returns the object at the beginning of the Queue. This will be the
        /// object with the highest priority.
        /// </summary>
        /// <returns>The object that is removed from the beginning of the Queue.</returns>
        /// <exception cref="InvalidOperationException">The PriorityQueue is empty.</exception>
        public virtual object Dequeue()
        {
            // Can't dequeue from an empty PriorityQueue - throw InvalidOperationException
            if (this.heapSize == 0)
            {
                throw new InvalidOperationException
                    ("Cannot Dequeue an object from an empty PriorityQueue");
            }

            // Set enumerators and enumArray to null to invalidate any Enumerators that are
            // being used.
            this.enumerators = null;
            this.enumArray = null;

            // Return object from top of heap and reorder heap.
            return this.PopHeap().obj;
        }

        /// <summary>
        /// Adds an object to the PriorityQueue. Its position is based on its priority. A
        /// higher priority is placed towards the front.
        /// </summary>
        /// <param name="obj">The object to add to the PriorityQueue. The value can be a null
        /// reference (Nothing in Visual Basic).</param>
        /// <param name="priority">The priority of the object being added to the
        /// PriorityQueue.</param>
        /// <exception cref="ArgumentException">The PriorityQueue is set to use the IComparable
        /// interface, and priority does not implement the IComparable interface.</exception>
        /// <exception cref="InvalidOperationException">The comparer throws an exception.</exception>
        public virtual void Enqueue(object obj, object priority)
        {
            // If object to be added does not implement the IComparable interface,
            // throw ArgumentException
            Type objectType = priority.GetType().GetInterface("IComparable", true);
            if (objectType == null) 
            {
                throw new ArgumentException
                    ("Object does not implement IComparable Interface", "priority");
            }
			
            // Test the "comparability" of the new object priority to objects already in
            // the PriorityQueue
            try
            {
                if (this.Count > 0)
                {
                    // Set test object to the priority object at the top of the heap.
                    object po = this.heap[0].priority;
                    this.priorityComparer.Compare(priority, po);
                }
            }
            catch (ArgumentException ae)
            {
                throw new InvalidOperationException
                    ("Object is incomparable to existing objects in PriorityQueue\n" + ae);
            }
			
            // Create a new PriorityObject, set its values and Push it onto the heap.
            PriorityObject priorobj = new PriorityObject();
            priorobj.obj = obj;
            priorobj.priority = priority;
            this.PushHeap(priorobj);

            // Set enumerators and enumArray to null to invalidate any Enumerators that are
            // being used.
            this.enumArray = null;
            this.enumerators = null;
        }

        /// <summary>
        /// Adds an object to the PriorityQueue. Its position is based on the value of the
        /// object. A higher value is placed towards the front.
        /// </summary>
        /// <param name="obj">The object to add to the PriorityQueue. The value can be a null
        /// reference (Nothing in Visual Basic).</param>
        /// <exception cref="ArgumentException">The PriorityQueue is set to use the IComparable
        /// interface, and object does not implement the IComparable interface.</exception>
        /// <exception cref="InvalidOperationException">The comparer throws an exception.</exception>
        /// <remarks>In terms of priority, the object's priority is its value.</remarks>
        public virtual void Enqueue(object obj)
        {
            // Use the object to add as the object and the priority.
            this.Enqueue(obj, obj);
        }

        /// <summary>
        /// Returns an enumerator that can iterate through the PriorityQueue.
        /// </summary>
        /// <returns>An IEnumerator for the PriorityQueue.</returns>
        public virtual IEnumerator GetEnumerator()
        {
            // Create a new enumerator
            PriorityQueueEnumerator priorQueueEnum = new PriorityQueueEnumerator(this);

            // If no other enumerators exist, allocate space for the array to track valid
            // enumerators
            if (this.enumerators == null)
            {
                this.enumerators = new ArrayList();
            }

            // Add this enumerator to the enumerators list
            this.enumerators.Add(priorQueueEnum);
            return priorQueueEnum;
        }

        /// <summary>
        /// Returns the object at the beginning of the PriorityQueue without removing it.
        /// </summary>
        /// <returns>The object at the beginning of the PriorityQueue.</returns>
        /// <exception cref="InvalidOperationException">The PriorityQueue is empty.</exception>
        public virtual object Peek()
        {
            // Can't peek into an empty PriorityQueue
            if (this.heapSize == 0)
            {
                throw new InvalidOperationException("Cannot Peek on an empty PriorityQueue");
            }

            // Return the object on top of the heap without disturbing the heap.
            return this.PeekHeap().obj;
        }

        /// <summary>
        /// Returns a PriorityQueue wrapper that is synchronized (thread-safe).
        /// </summary>
        /// <param name="queue">The PriorityQueue to synchronize.</param>
        /// <returns>A PriorityQueue wrapper that is synchronized (thread-safe).</returns>
        /// <exception cref="ArgumentNullException">
        /// queue is a null reference (Nothing in Visual Basic).
        /// </exception>
        public static PriorityQueue Synchronized(PriorityQueue queue)
        {
            // Can't synchronize a null reference
            if (queue == null)
            {
                throw new ArgumentNullException("PriorityQueue queue", "Cannot Synchronize a null queue");
            }

            // Create a new synchronized priority queue
            return new SynchronizedPriorityQueue(queue);
        }

        /// <summary>
        /// Copies the PriorityQueue elements to a new array.
        /// </summary>
        /// <returns>A new array containing elements copied from the PriorityQueue.</returns>
        public virtual object[] ToArray()
        {
            // Create an object array the same size as the heap.
            object [] objectArray = new object[this.heapSize];

            // Copy each element of the priority queue into the heap based on it's priority
            this.CopyTo(objectArray, 0);

            return objectArray;
        }

        /// <summary>
        /// Sets the capacity to the actual number of elements in the PriorityQueue.
        /// </summary>
        public virtual void TrimToSize()
        {
            // Create a new heap, sized to match the current number of objects in the current heap.
            PriorityObject [] tempHeap = new PriorityObject[heapSize];

            // Copy each element from the original heap into the new heap.
            for (int index=0; index<this.heapSize; index++)
            {
                tempHeap[index] = this.heap[index];
            }

            // Set the PriorityQueue objects to the new values.
            this.heap = tempHeap;
            this.heapInitialCapacity = this.heapSize;
            this.heapCapacity = this.heapSize;
        }
    }
}
