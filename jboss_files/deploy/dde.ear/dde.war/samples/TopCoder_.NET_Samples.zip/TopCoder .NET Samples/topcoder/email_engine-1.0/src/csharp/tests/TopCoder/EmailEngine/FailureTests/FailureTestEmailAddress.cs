using System;
using NUnit.Framework;

namespace TopCoder.EmailEngine.FailureTests {

    /// <summary>
    /// This tests EmailAddress.
    /// </summary>
    [TestFixture]
    public class FailureTestEmailAddress {

        /// <summary>
        /// This calls EmailAddress.Parse with null parameter
        /// </summary>
        [Test]
        [ExpectedException(typeof(MessageErrorException))]
        public void EmailAddressParseNull() {
            EmailAddress ea = new EmailAddress();
            ea.Parse(null);
        }

        /// <summary>
        /// This tests whether name and company are reset on Parse
        /// </summary>
        [Test]
        public void EmailAddressParseReset() {
            EmailAddress ea = new EmailAddress("a", "a", "a");
            ea.Parse("a@a.a");
            Assertion.Assert(ea.Name == null);
            Assertion.Assert(ea.Company == null);
        }

    }

}
