// @author mathgodleo
// @copyright (c) TopCoder Software

using System;
using System.Diagnostics;
using NUnit.Framework;

namespace TopCoder.LoggingWrapper.FailureTests
{
	/// <summary>
	/// Test cases for Diagnostic implementation.
	/// </summary>
	[TestFixture]
	//[Ignore("")]
	public class DiagnosticImplFailureTests
	{
		/// <summary>
		/// Set ups configuration of the LogManager
		/// </summary>
		[SetUp]
		public void StartUp()
		{
			if(EventLog.Exists("DiagnosticImplFailureTests"))
				EventLog.Delete("DiagnosticImplFailureTests");
			LogManager.Configuration = new System.Collections.Specialized.NameValueCollection();        
			LogManager.Configuration.Add(LogManager.CLASS_PARAMETER, "TopCoder.LoggingWrapper.DiagnosticImpl");
			LogManager.Configuration.Add("Source", "DiagnosticImplFailureTests");
			LogManager.Configuration.Add("LogName", "DiagnosticImplFailureTests");
			LogManager.LoadConfiguration();
		}

		/// <summary>
		/// Tests a null 1st parameter to Log().
		/// </summary>
		[Test]
		[ExpectedException(typeof(System.ArgumentNullException))]
		public void testLogNull()
		{
			LogManager.Log(null);
		}

		/// <summary>
		/// Tests a null 3rd parameter to Log().
		/// </summary>
		[Test]
		[ExpectedException(typeof(System.ArgumentNullException))]
		public void testLogNull2()
		{
			LogManager.Log(Level.DEBUG, "Hello World {0}", null);
		}

		/// <summary>
		/// Tests a null 1st parameter to Log().
		/// </summary>
		[Test]
		[ExpectedException(typeof(System.ArgumentNullException))]
		public void testLogNull3()
		{
			LogManager.Log(null, "Hello World {0}", "!");
		}

		/// <summary>
		/// Tests that every logging level works.
		/// </summary>
		[Test]
		public void testAllLevels()
		{
			EventLog ea = new EventLog("DiagnosticImplFailureTests",".","DiagnosticImplFailureTests");
			LogManager.Log(Level.DEBUG, "DEBUG");
			LogManager.Log(Level.ERROR, "ERROR");
			LogManager.Log(Level.FAILUREAUDIT, "FAILURE");
			LogManager.Log(Level.FATAL, "FATAL");
			LogManager.Log(Level.INFO, "INFO");
			LogManager.Log(Level.OFF, "OFF"); // shouldn't write anything.
			LogManager.Log(Level.SUCCESSAUDIT, "SUCCESS");
			LogManager.Log(Level.WARN, "WARN");
			EventLogEntry[] entries=new EventLogEntry[ea.Entries.Count];
			ea.Entries.CopyTo(entries,0);
			Assertion.AssertEquals("wrong number of entries written", 7, entries.Length);
			Assertion.AssertEquals("DEBUG",entries[0].Message);
			Assertion.AssertEquals("ERROR",entries[1].Message);
			Assertion.AssertEquals("FAILURE",entries[2].Message);
			Assertion.AssertEquals("FATAL",entries[3].Message);
			Assertion.AssertEquals("INFO",entries[4].Message);
			Assertion.AssertEquals("SUCCESS",entries[5].Message);
			Assertion.AssertEquals("WARN",entries[6].Message);
			ea.Clear();                            
		}

		[TearDown]
		public void Down()
		{
			if(EventLog.Exists("DiagnosticImplFailureTests"))
			{
				EventLog.Delete("DiagnosticImplFailureTests");
			}
		}
	}
}
