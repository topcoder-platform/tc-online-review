package com.topcoder.util.log.log4j;

import org.apache.log4j.Logger;
import com.topcoder.util.log.Log;
import com.topcoder.util.log.Level;
import com.topcoder.util.log.LogException;

/**
 * This is the Log4J specific implementation of the <tt>Log</tt> interface.
 * 
 * @author StinkyCheeseMan
 * @version 1.0
 * 
 * @see com.topcoder.util.log.Log
 */
public class Log4jLog implements Log
{
    // Instance of the underlying logger for Log4J
    private Logger logger;
    // The underlying Level for the logger instance
    private org.apache.log4j.Level currentLevel;

    /**
     * Single argument constructor to initialize the log with the specified
     * <tt>name</tt>. The <tt>name</tt> parameter will be used to initialize the
     * underlying logger.
     * 
     * @param name The name for this instance of the log.
     */
    public Log4jLog(String name)
    {
        logger = Logger.getLogger(name);
        Logger effectiveLogger = (Logger) logger.getParent();
        currentLevel = effectiveLogger.getLevel();
        while (effectiveLogger != null && currentLevel == null)
        {
            effectiveLogger = (Logger) effectiveLogger.getParent();
            currentLevel = effectiveLogger.getLevel();
        }
    }

    /**
     * Use this method to log a <tt>message</tt> at the specified <tt>level</tt>.
     * 
     * @param level The level at which the message should be logged.
     * @param message The message to log.
     * 
     * @throws com.topcoder.util.log.LogException if an error occurs in the
     * 		call to the underlying logger's log method.
     */
    public final void log(Level level, Object message) throws LogException
    {
        if (level == null)
            throw new LogException(new NullPointerException("level is null"));
        if (message == null)
            throw new LogException(new NullPointerException("message is null"));

        if (getLog4jEquivalentLevel(level) == null)
            throw new LogException(null);

        if (level.equals(Level.OFF))
            return;

        try
        {
            logger.log(getLog4jEquivalentLevel(level), message);
        }
        catch (Exception e)
        {
            throw new LogException(e);
        }
    }

    /**
     * This method checks if a certain logging <tt>level</tt> is presently
     * enabled.
     * 
     * @param level The level to check.
     * 
     * @return boolean - true if the <tt>level</tt> is enabled; false otherwise;
     */
    public final boolean isEnabled(Level level) throws LogException
    {
        if (level == null)
            throw new LogException(new NullPointerException("level is null"));

		// Handle the special cases of ALL and OFF
        if (level.equals(Level.OFF))
        {
            return currentLevel.toInt() == org.apache.log4j.Level.OFF_INT;
        }
        else if (level.equals(Level.ALL))
        {
            return !(currentLevel.toInt() == org.apache.log4j.Level.OFF_INT);
        }
        else
        {
            try
            {
                return logger.isEnabledFor(getLog4jEquivalentLevel(level));
            }
            catch (Exception e)
            {
                throw new LogException(e);
            }
        }
    }

    /**
     * This method is used to map a com.topcoder.util.log.Level object into a
     * org.apache.log4j.Level object. It should be noted that some TopCoder levels
     * map to the same Log4J levels.
     * 
     * @param level The com.topcoder.util.log.Level object that will be mapped to
     * 		a org.apache.log4j.Level object.
     * 
     * @return org.apache.log4j.Level - The mapped level.
     */
    private final org.apache.log4j.Level getLog4jEquivalentLevel(Level level)
    {
        if (level.equals(Level.FINEST))
            return org.apache.log4j.Level.DEBUG;
        else if (level.equals(Level.TRACE))
            return org.apache.log4j.Level.DEBUG;
        else if (level.equals(Level.DEBUG))
            return org.apache.log4j.Level.DEBUG;
        else if (level.equals(Level.CONFIG))
            return org.apache.log4j.Level.INFO;
        else if (level.equals(Level.INFO))
            return org.apache.log4j.Level.INFO;
        else if (level.equals(Level.WARN))
            return org.apache.log4j.Level.WARN;
        else if (level.equals(Level.ERROR))
            return org.apache.log4j.Level.ERROR;
        else if (level.equals(Level.FATAL))
            return org.apache.log4j.Level.FATAL;
        else if (level.equals(Level.ALL))
            return org.apache.log4j.Level.FATAL;
        else if (level.equals(Level.OFF))
            return org.apache.log4j.Level.OFF;
        else
            return null;
    }
}