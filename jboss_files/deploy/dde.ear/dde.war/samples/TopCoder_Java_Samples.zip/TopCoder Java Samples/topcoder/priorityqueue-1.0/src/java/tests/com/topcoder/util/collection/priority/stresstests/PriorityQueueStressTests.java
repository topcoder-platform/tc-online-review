package com.topcoder.util.collection.priority.stresstests;

import junit.framework.TestSuite;
import junit.framework.Test;
import junit.framework.TestCase;
import com.topcoder.util.collection.priority.ArrayPriorityQueue;
import com.topcoder.util.collection.priority.HashPriorityQueue;
import com.topcoder.util.collection.priority.LinkedPriorityQueue;
import com.topcoder.util.collection.priority.PriorityQueue;
import com.topcoder.util.collection.priority.TreePriorityQueue;

import java.util.Random;
import java.util.HashSet;

/**
 * <p>This test case aggregates all Stress test cases on various priority queue implementations.</p>
 *
 * @author TopCoder Software
 * @version 1.0
 *
 * Copyright � 2003, TopCoder, Inc. All rights reserved
 */
public class PriorityQueueStressTests extends TestCase {

    /** Max number of enqueues/dequeues to run */
    private static final int MAX_RUNS = 4000;

    /** Random number generator for random priority levels */
    private static final Random RAND = new Random(12345L);

    /**
     * Tests the scalability of many enqueues using different priority levels.  Calls enqueue using the various
     * priority queue implementations.
     */
    public void testEnqueueDiffPriority() {
        Integer values[] = new Integer[MAX_RUNS];
        int priorities[] = new int[MAX_RUNS];
        for (int i = 0; i < values.length; i++) {
            int num = RAND.nextInt();
            values[i] = new Integer(num);
            priorities[i] = num;
        }

        PriorityQueue pq = new HashPriorityQueue();
        long start = System.currentTimeMillis();
        for (int i = 0; i < MAX_RUNS; i++) {
            pq.enqueue(values[i], priorities[i]);
        }
        System.out.println("enqueued "
                           + MAX_RUNS
                           + " times using HashPriorityQueue took "
                           + (System.currentTimeMillis() - start)
                           + " milliseconds");

        pq = new ArrayPriorityQueue();
        start = System.currentTimeMillis();
        for (int i = 0; i < MAX_RUNS; i++) {
            pq.enqueue(values[i], priorities[i]);
        }
        System.out.println("enqueued "
                           + MAX_RUNS
                           + " times using ArrayPriorityQueue took "
                           + (System.currentTimeMillis() - start)
                           + " milliseconds");

        pq = new LinkedPriorityQueue();
        start = System.currentTimeMillis();
        for (int i = 0; i < MAX_RUNS; i++) {
            pq.enqueue(values[i], priorities[i]);
        }
        System.out.println("enqueued "
                           + MAX_RUNS
                           + " times using LinkedPriorityQueue took "
                           + (System.currentTimeMillis() - start)
                           + " milliseconds");

        pq = new TreePriorityQueue();
        start = System.currentTimeMillis();
        for (int i = 0; i < MAX_RUNS; i++) {
            pq.enqueue(values[i], priorities[i]);
        }
        System.out.println("enqueued "
                           + MAX_RUNS
                           + " times using TreePriorityQueue took "
                           + (System.currentTimeMillis() - start)
                           + " milliseconds");
    }

    /**
     * Tests scalability of many enqueues with the same priority using various priority queue implementations.
     */
    public void testEnqueueSamePriority() {
        Integer values[] = new Integer[MAX_RUNS];
        int priority = 1;
        for (int i = 0; i < values.length; i++) {
            int num = RAND.nextInt();
            values[i] = new Integer(num);
        }

        PriorityQueue pq = new HashPriorityQueue();
        long start = System.currentTimeMillis();
        for (int i = 0; i < MAX_RUNS; i++) {
            pq.enqueue(values[i], priority);
        }
        System.out.println("enqueued "
                           + MAX_RUNS
                           + " times using HashPriorityQueue took "
                           + (System.currentTimeMillis() - start)
                           + " milliseconds");

        pq = new ArrayPriorityQueue();
        start = System.currentTimeMillis();
        for (int i = 0; i < MAX_RUNS; i++) {
            pq.enqueue(values[i], priority);
        }
        System.out.println("enqueued "
                           + MAX_RUNS
                           + " times using ArrayPriorityQueue took "
                           + (System.currentTimeMillis() - start)
                           + " milliseconds");

        pq = new LinkedPriorityQueue();
        start = System.currentTimeMillis();
        for (int i = 0; i < MAX_RUNS; i++) {
            pq.enqueue(values[i], priority);
        }
        System.out.println("enqueued "
                           + MAX_RUNS
                           + " times using LinkedPriorityQueue took "
                           + (System.currentTimeMillis() - start)
                           + " milliseconds");

        pq = new TreePriorityQueue();
        start = System.currentTimeMillis();
        for (int i = 0; i < MAX_RUNS; i++) {
            pq.enqueue(values[i], priority);
        }
        System.out.println("enqueued "
                           + MAX_RUNS
                           + " times using TreePriorityQueue took "
                           + (System.currentTimeMillis() - start)
                           + " milliseconds");
    }

    /**
     * Tests the scalability of many dequeues on the various priority queue implementations
     */
    public void testDequeue() {
        PriorityQueue pq;
        HashSet set = new HashSet();
        for (int i = 0; i < MAX_RUNS; i++) {
            set.add(new Integer(i));
        }

        pq = new ArrayPriorityQueue();
        pq.enqueueAll(set, 1);
        long start = System.currentTimeMillis();
        while (!pq.isEmpty()) {
            pq.dequeue();
        }
        System.out.println("dequeued "
                           + MAX_RUNS
                           + " times using ArrayPriorityQueue took "
                           + (System.currentTimeMillis() - start)
                           + " milliseconds");

        pq = new HashPriorityQueue();
        pq.enqueueAll(set, 1);
        start = System.currentTimeMillis();
        while (!pq.isEmpty()) {
            pq.dequeue();
        }
        System.out.println("dequeued "
                           + MAX_RUNS
                           + " times using HashPriorityQueue took "
                           + (System.currentTimeMillis() - start)
                           + " milliseconds");

        pq = new LinkedPriorityQueue();
        pq.enqueueAll(set, 1);
        start = System.currentTimeMillis();
        while (!pq.isEmpty()) {
            pq.dequeue();
        }
        System.out.println("dequeued "
                           + MAX_RUNS
                           + " times using LinkedPriorityQueue took "
                           + (System.currentTimeMillis() - start)
                           + " milliseconds");

        pq = new TreePriorityQueue();
        pq.enqueueAll(set, 1);
        start = System.currentTimeMillis();
        while (!pq.isEmpty()) {
            pq.dequeue();
        }
        System.out.println("dequeued "
                           + MAX_RUNS
                           + " times using TreePriorityQueue took "
                           + (System.currentTimeMillis() -  start)
                           + " milliseconds");
    }

    /**
     * Returns the suite of priority queue stress tests
     * @return the suite of tests
     */
    public static Test suite() {
        return new TestSuite(PriorityQueueStressTests.class);
    }
}
