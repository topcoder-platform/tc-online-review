/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collection;


/**
 * This implementation of PriorityQueue is backed by an
 * ArrayList. This class provides on average O(n)-time,O(n)-data move
 * for insertions and O(1)-time, O(1)-data move for removals.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
public class ArrayPriorityQueue
    extends ListPriorityQueue implements Cloneable, Serializable {
    
    /**
     * Creates new queue with empty internal storage.
     */
    public ArrayPriorityQueue() {
        objects    = new ArrayList();
        priorities = new ArrayList();
    }
    
    /**
     * Creates new queue with empty internal storage with given
     * initial capacity.
     *
     * @param initialCapacity The initial capacity of internal storage
     *
     * @throws IllegalArgumentException if initialCapacity &lt; 0
     */
    public ArrayPriorityQueue(int initialCapacity) {
        if (initialCapacity < 0) {
            throw new IllegalArgumentException();
        }

        objects    = new ArrayList(initialCapacity);
        priorities = new ArrayList(initialCapacity);
    }
    
    /**
     * Creates new internal storage and inserts all the objects in the
     * given collection at the default priority level.
     *
     * @param collection The collection of objects to add
     *
     * @throws NullPointerException if collection is null
     */
    public ArrayPriorityQueue(Collection collection) {
        this(collection.size());
        addAll(collection);
    }
    
    /**
     * Construct a copy of the queue, maintaining order and priority.
     *
     * @param queue a queue to copy
     *
     * @throws NullPointerException if queue is null
     */
    public ArrayPriorityQueue(ArrayPriorityQueue queue) {
        if (null == queue) {
            throw new NullPointerException();
        }

        objects    = new ArrayList(queue.objects);
        priorities = new ArrayList(queue.priorities);
    }
    
    /**
     * Return a deep copy of the queue.
     *
     * @return a deep copy of the queue.
     */
    public Object clone() {
        return new ArrayPriorityQueue(this);
    }
}
