package com.topcoder.util.errorhandling.failuretests;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.topcoder.util.errorhandling.BaseError;
import com.topcoder.util.errorhandling.BaseException;
import com.topcoder.util.errorhandling.BaseRuntimeException;

/**
 * <p>Tests <code>initCause</code>, constructors.</p>
 *
 * <p>Copyright &copy; 2003, TopCoder, Inc. All rights reserved.</p>
 *
 * @author Revoklaw
 * @version 1.0
 */
public class ExceptionCreationFailure extends TestCase {
    public void testBaseExceptionInitCauseFailure(){

        try {
            BaseException be = new BaseException(new Exception());
            be.initCause(new Throwable());
            fail("Should have thrown IllegalStateException (tried to reset cause)");
        } catch (IllegalStateException e) { }

        try {
            Throwable t = null;
            BaseException be = new BaseException(t);
            try {
                be.initCause(t);
                fail("Should have thrown IllegalStateException (tried to reset cause from null)");
            } catch (IllegalStateException e) { }
        } catch (Exception e){
            fail("Should handle null cause with no exception");
        }

        try {
            BaseException be = new BaseException("message",new Exception());
            be.initCause(new Throwable());
            fail("Should have thrown IllegalStateException (tried to reset cause)");
        } catch (IllegalStateException e) { }

        try {
            BaseException be = new BaseException("Hello", null);
            try {
                be.initCause(null);
                fail("Should have thrown IllegalStateException (tried to reset cause from null)");
            } catch (IllegalStateException e) { }
        } catch (Exception e){
            fail("Should handle null cause with no exception");
        }

        try {
            BaseException be = new BaseException("hello");
            be.initCause(new Throwable());
            try {
                be.initCause(new Throwable());
                fail("Should have thrown IllegalStateException (tried to reset cause)");
            } catch (IllegalStateException e) { }
        } catch (Exception e){
            fail("Should handle null cause with no exception");
        }

        try {
            BaseException be = new BaseException();
            be.initCause(new Throwable());
            try {
                be.initCause(new Throwable());
                fail("Should have thrown IllegalStateException (tried to reset cause)");
            } catch (IllegalStateException e) { }
        } catch (Exception e){
            fail("Should handle null cause with no exception");
        }

        try {
            BaseException be = new BaseException();
            be.initCause(be);
            fail("Should have thrown IllegalArgumentException (set cause as self)");
        } catch (IllegalArgumentException iae) { }

        try {
            BaseException be = new BaseException("message");
            be.initCause(be);
            fail("Should have thrown IllegalArgumentException (set cause as self)");
        } catch (IllegalArgumentException iae) { }

        try {
            Throwable t = null;
            BaseException be = new BaseException(t);
            be.initCause(be);
            fail("Should have thrown IllegalArgumentException (set cause as self)");
        } catch (IllegalArgumentException iae) { }

        try {
            BaseException be = new BaseException("message", null);
            be.initCause(be);
            fail("Should have thrown IllegalArgumentException (set cause as self)");
        } catch (IllegalArgumentException iae) { }
    }

    public void testBaseRuntimeExceptionInitCauseFailure(){

        try {
            BaseRuntimeException bre = new BaseRuntimeException(new Exception());
            bre.initCause(new Throwable());
            fail("Should have thrown IllegalStateException (tried to reset cause)");
        } catch (IllegalStateException e) { }

        try {
            Throwable t = null;
            BaseRuntimeException bre = new BaseRuntimeException(t);
            try {
                bre.initCause(t);
                fail("Should have thrown IllegalStateException (tried to reset cause from null)");
            } catch (IllegalStateException e) { }
        } catch (Exception e){
            fail("Should handle null cause with no exception");
        }

        try {
            BaseRuntimeException bre = new BaseRuntimeException("message",new Exception());
            bre.initCause(new Throwable());
            fail("Should have thrown IllegalStateException (tried to reset cause)");
        } catch (IllegalStateException e) { }

        try {
            BaseRuntimeException bre = new BaseRuntimeException("Hello", null);
            try {
                bre.initCause(null);
                fail("Should have thrown IllegalStateException (tried to reset cause from null)");
            } catch (IllegalStateException e) { }
        } catch (Exception e){
            fail("Should handle null cause with no exception");
        }

        try {
            BaseRuntimeException bre = new BaseRuntimeException("hello");
            bre.initCause(new Throwable());
            try {
                bre.initCause(new Throwable());
                fail("Should have thrown IllegalStateException (tried to reset cause)");
            } catch (IllegalStateException e) { }
        } catch (Exception e){
            fail("Should handle null cause with no exception");
        }

        try {
            BaseRuntimeException bre = new BaseRuntimeException();
            bre.initCause(new Throwable());
            try {
                bre.initCause(new Throwable());
                fail("Should have thrown IllegalStateException (tried to reset cause)");
            } catch (IllegalStateException e) { }
        } catch (Exception e){
            fail("Should handle null cause with no exception");
        }

        try {
            BaseRuntimeException bre = new BaseRuntimeException();
            bre.initCause(bre);
            fail("Should have thrown IllegalArgumentException (set cause as self)");
        } catch (IllegalArgumentException iae) { }

        try {
            BaseRuntimeException bre = new BaseRuntimeException("message");
            bre.initCause(bre);
            fail("Should have thrown IllegalArgumentException (set cause as self)");
        } catch (IllegalArgumentException iae) { }

        try {
            Throwable t = null;
            BaseRuntimeException bre = new BaseRuntimeException(t);
            bre.initCause(bre);
            fail("Should have thrown IllegalArgumentException (set cause as self)");
        } catch (IllegalArgumentException iae) { }

        try {
            BaseRuntimeException bre = new BaseRuntimeException("message", null);
            bre.initCause(bre);
            fail("Should have thrown IllegalArgumentException (set cause as self)");
        } catch (IllegalArgumentException iae) { }
    }

    public void testBaseErrorInitCauseFailure(){

        try {
            BaseError be = new BaseError(new Exception());
            be.initCause(new Throwable());
            fail("Should have thrown IllegalStateException (tried to reset cause)");
        } catch (IllegalStateException e) { }

        try {
            Throwable t = null;
            BaseError be = new BaseError(t);
            try {
                be.initCause(null);
                fail("Should have thrown IllegalStateException (tried to reset cause from null)");
            } catch (IllegalStateException e) { }
        } catch (Exception e){
            fail("Should handle null cause with no exception");
        }

        try {
            BaseError be = new BaseError("message",new Exception());
            be.initCause(new Throwable());
            fail("Should have thrown IllegalStateException (tried to reset cause)");
        } catch (IllegalStateException e) { }

        try {
            BaseError be = new BaseError("Hello", null);
            try {
                be.initCause(null);
                fail("Should have thrown IllegalStateException (tried to reset cause from null)");
            } catch (IllegalStateException e) { }
        } catch (Exception e){
            fail("Should handle null cause with no exception");
        }

        try {
            BaseError be = new BaseError("hello");
            be.initCause(new Throwable());
            try {
                be.initCause(new Throwable());
                fail("Should have thrown IllegalStateException (tried to reset cause)");
            } catch (IllegalStateException e) { }
        } catch (Exception e){
            fail("Should handle null cause with no exception");
        }

        try {
            BaseError be = new BaseError();
            be.initCause(new Throwable());
            try {
                be.initCause(new Throwable());
                fail("Should have thrown IllegalStateException (tried to reset cause)");
            } catch (IllegalStateException e) { }
        } catch (Exception e){
            fail("Should handle null cause with no exception");
        }

        try {
            BaseError be = new BaseError();
            be.initCause(be);
            fail("Should have thrown IllegalArgumentException (set cause as self)");
        } catch (IllegalArgumentException iae) { }

        try {
            BaseError be = new BaseError("message");
            be.initCause(be);
            fail("Should have thrown IllegalArgumentException (set cause as self)");
        } catch (IllegalArgumentException iae) { }

        try {
            Throwable t = null;
            BaseError be = new BaseError(t);
            be.initCause(be);
            fail("Should have thrown IllegalArgumentException (set cause as self)");
        } catch (IllegalArgumentException iae) { }

        try {
            BaseError be = new BaseError("message", null);
            be.initCause(be);
            fail("Should have thrown IllegalArgumentException (set cause as self)");
        } catch (IllegalArgumentException iae) { }


    }


    public static Test suite() {
        return new TestSuite(ExceptionCreationFailure.class);
    }
}
