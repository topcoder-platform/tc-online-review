/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import junit.framework.Test;
import junit.framework.TestSuite;


/**
 * Unit tests for synchronized priority queue wrapper class.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
public class SynchronizedPriorityQueueTests extends PriorityQueueTests {
    /**
     * Return a suite of tests.
     *
     * @return a suite of tests.
     */
    public static Test suite() {
        return new TestSuite(SynchronizedPriorityQueueTests.class);
    }

    /** Create a queue for testing. */
    public void setUp() {
        queue =
            PriorityQueues.synchronizedPriorityQueue(new ArrayPriorityQueue());
    }
    
    /**
     * Verify the behavior of enqueue across multiple threads.
     */
    public void testEnqueue() {
        class TestThread extends Thread {
            private PriorityQueue queue = null;
            private int threadNo = 0;

            public TestThread(PriorityQueue queue, int threadNo) {
                this.queue = queue;
                this.threadNo = threadNo;
            }

            public void run() {
                if ((threadNo % 2) == 0) {
                    for (int i = 0; i < 500; ++i) {
                        queue.enqueue(new Integer(i), i);
                    }
                } else {
                    for (int i = 499; i >= 0; --i) {
                        queue.enqueue(new Integer(i), i);
                    }
                }
            }
        }

        PriorityQueue queue =
            PriorityQueues.synchronizedPriorityQueue(new ArrayPriorityQueue());
        Thread[] threads = new Thread[5];

        for (int i = 0; i < threads.length; ++i) {
            threads[i] = new TestThread(queue, i);
        }

        for (int i = 0; i < threads.length; ++i) {
            threads[i].start();
        }

        for (int i = 0; i < threads.length; ++i) {
            try {
                threads[i].join();
            } catch (InterruptedException e) {
            }
        }

        for (int i = 499; i >= 0; --i) {
            for (int j = 0; j < threads.length; ++j) {
                assertEquals(new Integer(i), queue.dequeue());
            }
        }
    }
}
