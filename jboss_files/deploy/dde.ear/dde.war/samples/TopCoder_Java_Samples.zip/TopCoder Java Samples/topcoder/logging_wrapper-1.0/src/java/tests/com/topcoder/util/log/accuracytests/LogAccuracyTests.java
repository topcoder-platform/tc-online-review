/*
 * LogAccuracyTests.java
 */
package com.topcoder.util.log.accuracytests;

import java.io.IOException;

import com.topcoder.util.log.Level;
import com.topcoder.util.log.Log;
import com.topcoder.util.log.LogException;
import com.topcoder.util.log.LogFactory;
import com.topcoder.util.log.functionaltests.AbstractLoggingAccuracyTests;

/**
 * Tests for correct design behavior of the Log implementation.  Some tests
 * depend on the logging threshold being INFO
 */
public class LogAccuracyTests extends AbstractLoggingAccuracyTests {

    private LogFactory factory;
    private Log log;
    private final static String logName =
            "com.topcoder.util.log.LogAccuracyTests";
    private static int messageSerial = 1;

    public LogAccuracyTests(String testName) {
        super(testName);
    }

    public void setUp() throws Exception {
        super.setUp();
        factory = LogFactory.getInstance();
        log = factory.getLog(logName);
    }

    /*
     * Those levels that correspond to different levels in the Log4J interface
     * have been selected here.  That would not be necessary if there were a
     * good way to detect which were mapped to the same Log4J levels.
     */
    public void testIsEnabled() throws LogException {
        if (!(log instanceof com.topcoder.util.log.basic.BasicLog)) {
	        assertTrue("FATAL messages disabled", log.isEnabled(Level.FATAL));
	        assertTrue("ERROR messages disabled", log.isEnabled(Level.ERROR));
	        assertTrue("WARN messages disabled",  log.isEnabled(Level.WARN));
	        assertTrue("INFO messages disabled",  log.isEnabled(Level.INFO));
	        assertTrue("DEBUG messages enabled", !log.isEnabled(Level.DEBUG));
        }
    }

    public void testLog_Logged() throws LogException, IOException {
        if (!(log instanceof com.topcoder.util.log.basic.BasicLog)) {
            String message = "The log is being tested (" + serialNumber++ + ")";
            log.log(Level.INFO, message);
            assertTrue("The message was not logged as expected",
                    wasLogged(message));
        }
    }

    public void testLog_NotLogged() throws LogException, IOException {
        if (!(log instanceof com.topcoder.util.log.basic.BasicLog)) {
            String message = "The log is being tested (" + serialNumber++ + ")";
            log.log(Level.DEBUG, message);
            assertTrue("The message was logged, contrary to expectation",
                    !wasLogged(message));
        }
    }

    public void testLog_LevelAll() throws LogException, IOException {
        if (!(log instanceof com.topcoder.util.log.basic.BasicLog)) {
            String message = "The log is being tested (" + serialNumber++ + ")";
            log.log(Level.ALL, message);
            assertTrue("The message was not logged as expected",
                    wasLogged(message));
        }
    }

    public void testLog_LevelOff() throws LogException, IOException {
        if (!(log instanceof com.topcoder.util.log.basic.BasicLog)) {
            String message = "The log is being tested (" + serialNumber++ + ")";
            log.log(Level.OFF, message);
            assertTrue("The message was logged, contrary to expectation",
                    !wasLogged(message));
        }
    }

}

