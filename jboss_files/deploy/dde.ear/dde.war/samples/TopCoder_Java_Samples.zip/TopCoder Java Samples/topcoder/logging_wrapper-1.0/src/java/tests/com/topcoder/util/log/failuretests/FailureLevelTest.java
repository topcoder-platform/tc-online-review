/**
 * JUnit failure tests for methods in com.topcoder.util.log.Level.
 * 
 * @author heather
 * Copyright � 2002, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.log.failuretests;

import com.topcoder.util.log.Level;
import com.topcoder.util.log.functionaltests.LogTest;

public class FailureLevelTest extends LogTest {
   
    public FailureLevelTest(String s) {
        super(s);
    }

    /**
     * test Level.equals with a null argument
     */
    public void testEquals_Null() {
        assertEquals(Level.OFF.equals(null), false);
    }

    /**
     * test Level.equals with a non-Level argument
     */
    public void testEquals_NotLevel() {
        assertEquals(Level.WARN.equals(new String("test")), false);
    }
}
