package com.topcoder.util.collection.priority.stresstests;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * <p>This test case aggregates all Stress test cases.</p>
 *
 * @author TopCoder Software
 * @version 1.0
 *
 * Copyright � 2003, TopCoder, Inc. All rights reserved
 */
public class StressTests extends TestCase {

    /**
     * Return the stress test cases
     *
     * @return the stress tests
     */
    public static Test suite() {
        final TestSuite suite = new TestSuite();
        suite.addTest(PriorityQueueStressTests.suite());
        suite.addTest(SynchronizedPriorityQueueStressTests.suite());
        return suite;
    }

}


        
