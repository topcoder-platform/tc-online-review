/*
 * Tests loadConfiguration
 * @author ttsuchi
 */
package com.topcoder.util.log.functionaltests;

import com.topcoder.util.log.LogFactory;

public class LoadConfigTest extends LogTest {
    public LoadConfigTest(String s) {
        super(s);
    }

    /*
     * tests LogFactory.loadConfiguration.
     */
    public void testPropertyLog() {
        try {
            useAlternateConfiguration();
            LogFactory.loadConfiguration();
            assertEquals("alternate", LogFactory.getAttribute("test"));
        }
        catch(Exception e) {
            fail(e.getMessage());
        }
        finally {
            try {
                useOriginalConfiguration();
                LogFactory.loadConfiguration();
            } catch (Exception ignored) { ignored.printStackTrace(); }
        }
    }
}
