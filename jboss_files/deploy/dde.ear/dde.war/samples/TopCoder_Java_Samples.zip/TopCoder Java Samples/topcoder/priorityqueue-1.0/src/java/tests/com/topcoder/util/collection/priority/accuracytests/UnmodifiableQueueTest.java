package com.topcoder.util.collection.priority.accuracytests;

import com.topcoder.util.collection.priority.LinkedPriorityQueue;
import com.topcoder.util.collection.priority.TreePriorityQueue;
import com.topcoder.util.collection.priority.PriorityQueue;
import com.topcoder.util.collection.priority.PriorityQueues;
import junit.framework.TestSuite;
import junit.framework.Test;

/**
 * DOCUMENT ME!!!
 * 
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 * @author msuhocki
 * @version 1.0
 */
public class UnmodifiableQueueTest extends PriorityQueueTest {
    
    /**
     * instantiate PriorityQueue instance 
     */
    public void setUp() {
        PriorityQueue queue1 = new LinkedPriorityQueue();
        
        for (int i = 0; i < arrays[10].length; i++) {
            queue.enqueue(arrays[10][i], level10_11[i]);
        }
        
        queue = PriorityQueues.unmodifiablePriorityQueue(queue1);
    }
    
    /** can't use */    
    public void testAdd() {}
    
    /** can't use */    
    public void testAddAll1() {}
    
    /** can't use */    
    public void testAddAll2() {}
    
    /** can't use */    
    public void testAddAll3() {}
    
    /** can't use */    
    public void testAddAll4() {}
    
    /** can't use */    
    public void testClear() {}
    
    /**
     * Tests PriorityQueue.contains(Object)
     */
    public void testContains() {
        assertTrue(queue.contains("String1"));
        assertTrue(queue.contains("String2"));
        assertTrue(queue.contains("String3"));
        assertTrue(queue.contains("String4"));
        assertTrue(queue.contains("String5"));
        assertFalse(queue.contains("String6"));
        assertFalse(queue.contains(new Integer(1)));
    }
    
    /**
     * Tests PriorityQueue.containsAll(Collection)
     */
    public void testContainsAll() {
        assertTrue(queue.containsAll(lists[11]));
        assertTrue(queue.containsAll(lists[10]));
        assertTrue(queue.containsAll(lists[9]));
        assertTrue(queue.containsAll(lists[8]));
        assertTrue(queue.containsAll(lists[1]));
        assertFalse(queue.containsAll(lists[0]));
    }
    
    /** can't use */    
    public void testDequeue() {}
    
    /** can't use */    
    public void testEnqueue() {}
    
    /** can't use */    
    public void testEnqueueAll() {}
    
    /**
     * Tests PriorityQueue.equals(Object)
     */
    public void testEquals() throws Exception {
        PriorityQueue queue1 = new TreePriorityQueue();
        
        assertTrue(queue.equals(queue));
        assertFalse(queue.equals(queue1));
        
        queue1.addAll(lists[10]);
        assertFalse(queue.equals(queue1));
        
        queue1.clear();
        queue1.addAll(lists[11]);
        assertTrue(queue.equals(queue1));
        
        assertFalse(queue.equals(lists[11]));
    }
    
    /**
     * Tests PriorityQueue.isEmpty()
     */
    public void testIsEmpty() {
        assertFalse(queue.isEmpty());
    }
    
    /**
     * Tests PriorityQueue.iterator()
     */
    public void testIterator() {
        checkList(lists[11]);  // uses iterator        
    }
    
    /**
     * Tests PriorityQueue.peek()
     */
    public void testPeek() {
        assertEquals("String1", queue.peek());
    }
    
    /** can't use */    
    public void testRemove() {}
    
    /** can't use */    
    public void testRemoveAll() {}
    
    /** can't use */    
    public void testRetainAll() {}
    
    /**
     * Tests PriorityQueue.size()
     */
    public void testSize() {
        assertEquals(arrays[10].length, queue.size());
    }
    
    /**
     * Tests PriorityQueue.toArray()
     */
    public void testToArray() {
        Object[] array;
        
        array = queue.toArray();
        assertEquals(arrays[11].length, array.length);
        for (int i = 0; i < array.length; i++) {
            assertEquals(""+i, arrays[11][i], array[i]);
        }
    }
    
    /**
     * Tests PriorityQueue.toArray(Object[])
     */
    public void testToArray_ObjectA() {
        String[] dummy = new String[0];
        String[] array;
        
        array = (String[]) queue.toArray(dummy);
        assertEquals(arrays[11].length, array.length);
        for (int i = 0; i < array.length; i++) {
            assertEquals(""+i, arrays[11][i], array[i]);
        }
    }
    
    public static Test suite() {
        return new TestSuite(SynchronizedQueueTest.class);
    }
}
