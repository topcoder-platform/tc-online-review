package com.topcoder.util.cache;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * <p>This test case tests the cache's <code>get()</code> method,
 * as well as other cache functionality:</p>
 * <ul>
 *  <li>maximum size limit</li>
 *  <li>object timeout</li>
 *  <li>memory management</li>
 * </ul>
 *
 * <p>See the separate <code>ConcurrencyTestCase</code> for tests
 * of multi-threaded behavior.</p>
 *
 * @author srowen
 * @version 1.0
 */
public class GetObjectFromCacheTestCase extends TestCase {

    /**
     * tests retrieving objects
     */
    public void testGet() {
        SimpleCache cache = new SimpleCache();
        assertNull("Cache should return null for non-existent keys",
                   cache.get("foo1"));
        cache.put("foo1", "bar1");
        assertEquals("Cache should return objects that are added",
                     "bar1",
                     cache.get("foo1"));
    }

    /**
     * Verifies the maximum size of the cache
     */
    public void testMaxSize() {
        SimpleCache cache =
            new SimpleCache(2, SimpleCache.NO_TIMEOUT, new FIFOCacheEvictionStrategy());
        cache.put("foo1", "bar1");
        cache.put("foo2", "bar2");
        assertEquals("Cache should return objects that are added",
                     "bar1",
                     cache.get("foo1"));
        cache.put("foo3", "bar3");
        assertNull("Cache should evict objects in FIFO order by default",
                   cache.get("foo1"));
        assertEquals("Cache should return objects that are added",
                     "bar2",
                     cache.get("foo2"));
    }

    /**
     * Verifies that objects are removed that have timed out
     */
    public void testTimeout() {
        SimpleCache cache =
            new SimpleCache(SimpleCache.NO_MAX_SIZE, 1000, new FIFOCacheEvictionStrategy());
        cache.put("foo1", "bar1");
        assertEquals("Cache should return objects that are added",
                     "bar1",
                     cache.get("foo1"));

        try {
            Thread.sleep(1000 + 5000 + 500); // thread cleans up timed out entries every 5 seconds
        } catch(InterruptedException ie) {
            // continue - shouldn't happen anyway
        }

        cache.put("foo2", "bar2");
        assertNull("Cache should timeout entries",
                   cache.get("foo1"));
        assertEquals("Cache should return objects that are added",
                     "bar2",
                     cache.get("foo2"));
    }

    /**
     * Tests loading large amounnts of data into the simple cache
     */
    public void testMemoryManagement() {
        SimpleCache cache = new SimpleCache();
        cache.put("foo1", "bar1");

        // is this reliable?
        List hog = new ArrayList();
        try {
            while(true) {
                hog.add(new int[100000]);
            }
        } catch(OutOfMemoryError oome) {
            hog = null;
        }

        assertNull("Cache should clear entries in low memory situations",
                   cache.get("foo1"));
    }

    /**
     * Test illegal arguments for the get method
     */
    public void testIllegalArguments() {
        SimpleCache cache = new SimpleCache();
        try {
            cache.get(null);
            fail("Null key should cause an IllegalArgumentException");
        } catch(IllegalArgumentException iae) {
            // good
        }
    }

    /**
     * Suite used to run tests
     */
    public static Test suite() {
        return new TestSuite(GetObjectFromCacheTestCase.class);
    }
}
