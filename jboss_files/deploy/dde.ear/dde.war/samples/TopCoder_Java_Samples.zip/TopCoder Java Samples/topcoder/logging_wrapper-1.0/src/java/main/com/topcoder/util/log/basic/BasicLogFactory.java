package com.topcoder.util.log.basic;

import com.topcoder.util.log.Log;
import com.topcoder.util.log.LogException;
import com.topcoder.util.log.LogFactory;

/**
 * Basic implementation of the LogFactory interface.
 * 
 * @author StinkyCheeseMan
 * @version 1.0
 */
public final class BasicLogFactory extends LogFactory
{
	/**
	 * Returns a basic log instance. The <tt>name</tt> attribute is ignored.
	 * 
	 * @param name Ignored.
	 * 
	 * @return Log - A basic log instance.
	 */
    public final Log getLog(String name) throws LogException
    {
        if (name == null)
            throw new LogException(new NullPointerException("name is null"));
        return new BasicLog();
    }

}