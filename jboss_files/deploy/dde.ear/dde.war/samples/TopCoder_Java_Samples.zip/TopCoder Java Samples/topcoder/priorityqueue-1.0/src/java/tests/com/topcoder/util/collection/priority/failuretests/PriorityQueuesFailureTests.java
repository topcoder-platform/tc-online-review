/*
 * @(#)PriorityQueuesFailureTestCase.java     1.0 Aug 18, 2003
 * 
 * Copyright � 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority.failuretests;

import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.topcoder.util.collection.priority.ArrayPriorityQueue;
import com.topcoder.util.collection.priority.HashPriorityQueue;
import com.topcoder.util.collection.priority.PriorityQueue;
import com.topcoder.util.collection.priority.PriorityQueues;

/**
 * Failure tests for the class <code>PriorityQueues</code> and the private 
 * classes: <code>SynchronizedQueue</code>, 
 * <code>SynchronizedSerializableQueue</code>, <code>UnmodifiableQueue</code> 
 * and <code>UnmodifiableSerializableQueue</code>. 
 * 
 * @version 1.0
 * @author MPhk
 */
public class PriorityQueuesFailureTests extends TestCase {
    /**
     * The name of this test suite 
     */
    private static String NAME = "Priority Queues Failure Test";
    
    /**
     * Invalid value for the initial capacity of the queues  
     */
    public static int INVALID_SIZE = -1;

    /**
     * Null <code>PriorityQueue</code> queue used for testing
     */
    private PriorityQueue nullQueue; 
    
    /**
     * Unmodifiable <code>PriorityQueue</code> queue used for testing
     */
    private PriorityQueue upQueue;
    
    /**
     * Synchronized empty <code>PriorityQueue</code> queue used for testing
     */
    private PriorityQueue speQueue;

    /**
     * Synchronized non-empty <code>PriorityQueue</code> queue used for testing
     */
    private PriorityQueue spneQueue;

    /**
     * Non-empty <code>PriorityQueue</code> queue used for testing
     */
    private PriorityQueue nonEmptyQueue;

    /**
     * Returns the test suite containing the methods of this class 
     * 
     * @return a TestSuite
     */
    public static TestSuite suite() {
        TestSuite suite = new TestSuite(PriorityQueuesFailureTests.class);
        suite.setName(NAME);
        return suite;
    }
    
    /* (non-Javadoc)
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        // initialize null queue
        nullQueue = null;

        // initialize non-empty queue 
        nonEmptyQueue = new HashPriorityQueue();
        assertNotNull(nonEmptyQueue);
        nonEmptyQueue.add(new String("Object"));
        assertTrue(nonEmptyQueue.size() > 0);
        
        // initialize unmodifiable queue
        PriorityQueue emptyQueue1 = new ArrayPriorityQueue();
        assertNotNull(emptyQueue1);
        upQueue = PriorityQueues.unmodifiablePriorityQueue(emptyQueue1);
        assertNotNull(upQueue);
        
        // initialize synchronized queues
        PriorityQueue emptyQueue2 = new ArrayPriorityQueue();
        assertNotNull(emptyQueue2);
        speQueue = PriorityQueues.synchronizedPriorityQueue(emptyQueue2);
        assertNotNull(speQueue);
        PriorityQueue nonEmptyQueue1 = new HashPriorityQueue(nonEmptyQueue);
        spneQueue = PriorityQueues.synchronizedPriorityQueue(nonEmptyQueue1);
        assertNotNull(spneQueue);
    }

    /* (non-Javadoc)
     * @see junit.framework.TestCase#tearDown()
     */
    protected void tearDown() throws Exception {
        nullQueue = null;
        upQueue = null;
        speQueue = null;
        spneQueue = null;
    }
    
    /**
     * Test the method <code>unmodifiablePriorityQueue</code> with null 
     * <code>PriorityQueue<code> argument. Should throw a 
     * <code>NullPointerException</code>. Test must pass. 
     */
    public void testUnmodifiableNull() {
        try {
            PriorityQueues.unmodifiablePriorityQueue(nullQueue);
            fail("Should throw a NullPointerException!");    
        } catch (NullPointerException npe) {
            // exception expected
        }
    }
    
    /**
     * Test the method <code>add</code> of class 
     * <code>UnmodifiablePriorityQueue</code> with non-null argument. Should  
     * throw an <code>UnsupportedOperationException</code>. Test must pass. 
     */
    public void testUnmodifiableAdd() {
        try {
            upQueue.add(new Object());
            fail("Should throw an UnsupportedOperationException!");    
        } catch (UnsupportedOperationException uoe) {
            // exception expected
        }
    }    
    
    /**
     * Test the method <code>addAll</code> of class 
     * <code>UnmodifiablePriorityQueue</code> with non-null argument. Should 
     *  throw an <code>UnsupportedOperationException</code>. Test must pass. 
     */
    public void testUnmodifiableAddAll1() {
        try {
            upQueue.addAll(nonEmptyQueue);
            fail("Should throw an UnsupportedOperationException!");    
        } catch (UnsupportedOperationException uoe) {
            // exception expected
        }
    }
    
    /**
     * Test the method <code>addAll</code> of class 
     * <code>UnmodifiablePriorityQueue</code> with null argument. Should 
     *  throw an <code>UnsupportedOperationException</code>. Test must pass. 
     */
    public void testUnmodifiableAddAll2() {
        try {
            upQueue.addAll(null);
            fail("Should throw an UnsupportedOperationException!");    
        } catch (UnsupportedOperationException uoe) {
            // exception expected
        }
    }
    
    /**
     * Test the method <code>clear</code> of class 
     * <code>UnmodifiablePriorityQueue</code>. Should throw an  
     * <code>UnsupportedOperationException</code>. Test must pass. 
     */
    public void testUnmodifiableClear() {
        try {
            upQueue.clear();
            fail("Should throw an UnsupportedOperationException!");    
        } catch (UnsupportedOperationException uoe) {
            // exception expected
        }
    }
    
    /**
     * Test the method <code>containsAll</code> of class 
     * <code>UnmodifiablePriorityQueue</code>. Should throw an  
     * <code>NullPointerException</code>. Test must pass. 
     */
    public void testUnmodifiableContainsAll() {
        try {
            upQueue.containsAll(null);
            fail("Should throw an NullPointerException!");    
        } catch (NullPointerException npe) {
            // exception expected
        }
    }

    /**
     * Test the method <code>remove</code> of class 
     * <code>UnmodifiablePriorityQueue</code> with non-null argument. Should 
     * throw an  <code>UnsupportedOperationException</code>. Test must pass. 
     */
    public void testUnmodifiableRemove1() {
        try {
            upQueue.remove(new Object());
            fail("Should throw an UnsupportedOperationException!");    
        } catch (UnsupportedOperationException uoe) {
            // exception expected
        }
    }
    
    /**
     * Test the method <code>remove</code> of class 
     * <code>UnmodifiablePriorityQueue</code> with null argument. Should throw   
     * an <code>UnsupportedOperationException</code>. Test must pass. 
     */
    public void testUnmodifiableRemove2() {
        try {
            upQueue.remove(null);
            fail("Should throw an UnsupportedOperationException!");    
        } catch (UnsupportedOperationException uoe) {
            // exception expected
        }
    }    

    /**
     * Test the method <code>removeAll</code> of class 
     * <code>UnmodifiablePriorityQueue</code> with non-null argument. Should 
     * throw an  <code>UnsupportedOperationException</code>. Test must pass. 
     */
    public void testUnmodifiableRemoveAll1() {
        try {
            upQueue.removeAll(nonEmptyQueue);
            fail("Should throw an UnsupportedOperationException!");    
        } catch (UnsupportedOperationException uoe) {
            // exception expected
        }
    }
    
    /**
     * Test the method <code>removeAll</code> of class 
     * <code>UnmodifiablePriorityQueue</code> with null argument. Should throw   
     * an <code>UnsupportedOperationException</code>. Test must pass. 
     */
    public void testUnmodifiableRemoveAll2() {
        try {
            upQueue.removeAll(null);
            fail("Should throw an UnsupportedOperationException!");    
        } catch (UnsupportedOperationException uoe) {
            // exception expected
        }
    }    

    /**
     * Test the method <code>retainAll</code> of class 
     * <code>UnmodifiablePriorityQueue</code> with non-null argument. Should 
     * throw an  <code>UnsupportedOperationException</code>. Test must pass. 
     */
    public void testUnmodifiableRetainAll1() {
        try {
            upQueue.retainAll(nonEmptyQueue);
            fail("Should throw an UnsupportedOperationException!");    
        } catch (UnsupportedOperationException uoe) {
            // exception expected
        }
    }
    
    /**
     * Test the method <code>retainAll</code> of class 
     * <code>UnmodifiablePriorityQueue</code> with null argument. Should throw   
     * an <code>UnsupportedOperationException</code>. Test must pass. 
     */
    public void testUnmodifiableRetainAll2() {
        try {
            upQueue.retainAll(null);
            fail("Should throw an UnsupportedOperationException!");    
        } catch (UnsupportedOperationException uoe) {
            // exception expected
        }
    }    

    /**
     * Test the method <code>dequeue</code> of class 
     * <code>UnmodifiablePriorityQueue</code>. Should throw an  
     * <code>UnsupportedOperationException</code>. Test must pass. 
     */
    public void testUnmodifiableDequeue() {
        try {
            upQueue.dequeue();
            fail("Should throw an UnsupportedOperationException!");    
        } catch (UnsupportedOperationException uoe) {
            // exception expected
        }
    }
    
    /**
     * Test the method <code>enqueue</code> of class 
     * <code>UnmodifiablePriorityQueue</code> with non-null argument. Should  
     * throw an <code>UnsupportedOperationException</code>. Test must pass. 
     */
    public void testUnmodifiableEnqueue() {
        try {
            upQueue.enqueue(new Object(), PriorityQueue.DEFAULT_PRIORITY);
            fail("Should throw an UnsupportedOperationException!");    
        } catch (UnsupportedOperationException uoe) {
            // exception expected
        }
    }    
    
    /**
     * Test the method <code>enqueueAll</code> of class 
     * <code>UnmodifiablePriorityQueue</code> with non-null argument. Should 
     * throw an <code>UnsupportedOperationException</code>. Test must pass. 
     */
    public void testUnmodifiableEnqueueAll1() {
        try {
            upQueue.enqueueAll(nonEmptyQueue, PriorityQueue.DEFAULT_PRIORITY);
            fail("Should throw an UnsupportedOperationException!");    
        } catch (UnsupportedOperationException uoe) {
            // exception expected
        }
    }
    
    /**
     * Test the method <code>enqueueAll</code> of class 
     * <code>UnmodifiablePriorityQueue</code> with null argument. Should 
     * throw an <code>UnsupportedOperationException</code>. Test must pass. 
     */
    public void testUnmodifiableEnqueueAll2() {
        try {
            upQueue.enqueueAll(null, PriorityQueue.DEFAULT_PRIORITY);
            fail("Should throw an UnsupportedOperationException!");    
        } catch (UnsupportedOperationException uoe) {
            // exception expected
        }
    }
    
    /**
     * Tests the iterator method <code>remove</code> on a queue of type 
     * <code>UnmodifiablePriorityQueue</code>. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testUnmodifiableIteratorRemove() {
        Iterator it = upQueue.iterator();
        assertNotNull(it);
        try {
            it.remove();
            fail("Should throw a UnsupportedOperationException!");
        } catch (UnsupportedOperationException nsee) {
            // expected exception
        }
    }  
    
    /**
     * Test the method <code>synchronizedPriorityQueue</code> with null 
     * <code>PriorityQueue<code> argument. Should throw a 
     * <code>NullPointerException</code>. Test must pass. 
     */
    public void testSynchronizedNull() {
        try {
            PriorityQueues.synchronizedPriorityQueue(nullQueue);
            fail("Should throw a NullPointerException!");    
        } catch (NullPointerException npe) {
            // exception expected
        }
    }    
    
    /**
     * Tests the <code>addAll</code> method of 
     * <code>SynchronizedPriorityQueue</code> class with a null parameter on an 
     * empty queue. Should throw a <code>NullPointerException</code>. 
     * Test must pass.
     */
    public void testSynchronizedAddAllE() {
        try {
            speQueue.addAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }

    /**
     * Tests the <code>addAll</code> method of 
     * <code>SynchronizedPriorityQueue</code> class with a null parameter on a 
     * non-empty queue. Should throw a <code>NullPointerException</code>. 
     * Test must pass.
     */
    public void testSynchronizedAddAllNE() {
        try {
            spneQueue.addAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }

    /**
     * Tests the <code>containsAll</code> method of 
     * <code>SynchronizedPriorityQueue</code> class with a null parameter on an 
     * empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testSynchronizedContainsAllE() {
        try {
            speQueue.containsAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }

    /**
     * Tests the <code>containsAll</code> method of 
     * <code>SynchronizedPriorityQueue</code> class with a null parameter on a 
     * non-empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testSynchronizedContainsAllNE() {
        try {
            spneQueue.containsAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }
    
    /**
     * Tests the <code>removeAll</code> method of 
     * <code>SynchronizedPriorityQueue</code> class with a null parameter on an 
     * empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testSynchronizedRemoveAllE() {
        try {
            speQueue.removeAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }

    /**
     * Tests the <code>removeAll</code> method of 
     * <code>SynchronizedPriorityQueue</code> class with a null parameter on a  
     * non-empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testSynchronizedRemoveAllNE() {
        try {
            spneQueue.removeAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }
    
    /**
     * Tests the <code>retainAll</code> method of 
     * <code>SynchronizedPriorityQueue</code> class with a null parameter on an 
     * empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testSynchronizedRetainAllE() {
        try {
            speQueue.retainAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }
    
    /**
     * Tests the <code>retainAll</code> method of 
     * <code>SynchronizedPriorityQueue</code> class with a null parameter on a 
     * non-empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testSynchronizedRetainAllNE() {
        try {
            spneQueue.retainAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }    
    
    /**
     * Tests the <code>toArray</code> method of 
     * <code>SynchronizedPriorityQueue</code> class with a null parameter on a 
     * empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testSynchronizedToArrayE() {
        try {
            speQueue.toArray((String[])null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }
    
    /**
     * Tests the <code>toArray</code> method of 
     * <code>SynchronizedPriorityQueue</code> class with a null parameter on a 
     * non-empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testSynchronizedToArrayNE1() {
        try {
            spneQueue.toArray((String[])null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }

    /**
     * Tests the <code>toArray</code> method of 
     * <code>SynchronizedPriorityQueue</code> class with an invalid type 
     * parameter on a non-empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testSynchronizedToArrayNE2() {
        try {
            spneQueue.toArray(new Integer[] {});
            fail("Should throw a ArrayStoreException!");
        } catch (ArrayStoreException ase) {
            // expected exception
        }
    }    
    
    /**
     * Tests the <code>dequeue</code> method of 
     * <code>SynchronizedPriorityQueue</code> class on an empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testSynchronizedDequeue() {
        try {
            speQueue.dequeue();
            fail("Should throw an IllegalStateException!");
        } catch (IllegalStateException ise) {
            // expected exception
        }        
    }

    /**
     * Tests the <code>peek</code> method of 
     * <code>SynchronizedPriorityQueue</code> class on an empty queue. 
     * Should throw a <code>IllegalStateException</code>. Test must pass.
     */
    public void testSynchronizedPeek() {
        try {
            speQueue.peek();
            fail("Should throw an IllegalStateException!");
        } catch (IllegalStateException ise) {
            // expected exception
        }        
    }
    
    /**
     * Tests the <code>enqueueAll</code> method of 
     * <code>SynchronizedPriorityQueue</code> class with a null parameter on an empty 
     * queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testSynchronizedEnqueueAllE() {
        try {
            speQueue.enqueueAll((Collection)null, 
                                  PriorityQueue.DEFAULT_PRIORITY);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }

    /**
     * Tests the <code>enqueueAll</code> method of 
     * <code>SynchronizedPriorityQueue</code> class with a null parameter on a 
     * non-empty queue.
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testSynchronizedEnqueueAllNE() {
        try {
            spneQueue.enqueueAll((Collection)null, 
                                     PriorityQueue.DEFAULT_PRIORITY);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }    
    
    /**
     * Tests the iterator method <code>next</code> on an empty queue of type 
     * <code>SynchronizedPriorityQueue</code>. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testSynchronizedIteratorNextE() {
        Iterator it = speQueue.iterator();
        assertNotNull(it);
        try {
            it.next();
            fail("Should throw a NoSuchElementException!");
        } catch (NoSuchElementException nsee) {
            // expected exception
        }
    }
    
    /**
     * Tests the iterator method <code>next</code> on a not-empty queue of type 
     * <code>SynchronizedPriorityQueue</code>.  
     * After the second call should throw a <code>NullPointerException</code>. 
     * Test must pass.
     */
    public void testSynchronizedIteratorNextNE() {
        Iterator it = spneQueue.iterator();
        assertNotNull(it);
        try {
            assertTrue(it.hasNext());
            it.next();
            assertFalse(it.hasNext());
            it.next();
            fail("Should throw a NoSuchElementException!");
        } catch (NoSuchElementException nsee) {
            // expected exception
        }
    }    
    
    /**
     * Tests the iterator method <code>remove</code> on an empty queue of type 
     * <code>SynchronizedPriorityQueue</code>. 
     * Should throw a <code>IllegalStateException</code>. Test must pass.
     */
    public void testSynchronizedIteratorRemoveE() {
        Iterator it = speQueue.iterator();
        assertNotNull(it);
        try {
            it.remove();
            fail("Should throw a IllegalStateException!");
        } catch (IllegalStateException ise) {
            // expected exception
        }
    }
    
    /**
     * Tests the iterator method <code>remove</code> on a not-empty queue of  
     * type <code>SynchronizedPriorityQueue</code>. Tries to remove the same 
     * element for two times. Should throw a <code>IllegalStateException</code>. 
     * Test must pass.
     */
    public void testSynchronizedIteratorRemoveNE() {
        Iterator it = spneQueue.iterator();
        assertNotNull(it);
        try {
            assertTrue(it.hasNext());
            it.next();
            it.remove();
            assertTrue(it!=null);
            it.remove();
            fail("Should throw a IllegalStateException!");
        } catch (IllegalStateException ise) {
            // expected exception
        }
    }     
    
    /**
     * Tests the iterator methods <code>remove</code> and <code>next</code>on a 
     * not-empty queue of type <code>SynchronizedPriorityQueue</code>. Tries to 
     * remove the single element of the queue than tries to obtain the next 
     * element. Should throw a <code>NoSuchElementException</code>. 
     * Test must pass.
     */
    public void testSynchronizedIteratorRemoveNextNE() {
        Iterator it = spneQueue.iterator();
        assertNotNull(it);
        try {
            assertTrue(it.hasNext());
            it.next();
            it.remove();
            assertFalse(it.hasNext());
            it.next();
            fail("Should throw a NoSuchElementException!");
        } catch (NoSuchElementException nsee) {
            // expected exception
        }
    }
}
