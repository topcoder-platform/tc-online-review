package com.topcoder.util.log.basic;

import com.topcoder.util.log.Level;
import com.topcoder.util.log.Log;
import com.topcoder.util.log.LogException;
import com.topcoder.util.log.LogFactory;

/**
 * This is the basic implementation of the <tt>Log</tt> interface.
 *
 * @author StinkyCheeseMan
 * @version 1.0
 *
 * @see com.topcoder.util.log.Log
 */
public final class BasicLog implements Log
{
    public static final String SYSTEM_OUT = "System.out";
    public static final String SYSTEM_ERR = "System.err";
    public static final String LOG_TARGET = "basic.log.target";
    
    /**
     * This method calls the <tt>toString</tt> method on the <tt>message</tt> argument and outputs its value to System.err.
     * The level is ignored.
     *
     * @param level Ignored
     * @param message The message to log.
     *
     * @throws com.topcoder.util.log.LogException if any error occurs
     */
    public final void log(Level level, Object message) throws LogException
    {
        if (level == null)
            throw new LogException(new NullPointerException("level is null"));
            
        if (message == null)
            throw new LogException(new NullPointerException("message is null"));

        try
        {
            String msg = message instanceof String ? (String) message : message.toString();
            if (LogFactory.getAttribute(LOG_TARGET).equals(SYSTEM_ERR)) {
                System.err.println(msg);
            } else if (LogFactory.getAttribute(LOG_TARGET).equals(SYSTEM_OUT)) {
                System.out.println(msg);
            } else {    // output to System.err by default
                System.err.println(msg);
            }
        }
        catch (Exception e)
        {
            throw new LogException(e);
        }
    }

	/**
	 * This method always returns true, because levels are meaningless for the basic logger.
	 * 
	 * @see com.topcoder.util.log.Log#isEnabled(Level)
	 */
    public boolean isEnabled(Level level) throws LogException {
        if (level == null)
            throw new LogException(new NullPointerException("level is null"));
            
        return true;
    }
}