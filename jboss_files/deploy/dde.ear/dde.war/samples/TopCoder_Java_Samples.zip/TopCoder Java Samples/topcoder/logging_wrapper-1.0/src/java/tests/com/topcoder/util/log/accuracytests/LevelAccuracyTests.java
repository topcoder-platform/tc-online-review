/*
 * TestLevel.java
 */
package com.topcoder.util.log.accuracytests;

import java.util.HashSet;

import com.topcoder.util.log.Level;
import com.topcoder.util.log.functionaltests.AbstractLoggingAccuracyTests;

public class LevelAccuracyTests extends AbstractLoggingAccuracyTests {

    public LevelAccuracyTests(String testName) {
        super(testName);
    }

    public void testLevels() {
        HashSet levelSet = new HashSet();

        assertNotNull("OFF is null", Level.OFF);
        levelSet.add(Level.OFF);
        assertNotNull("FINEST is null", Level.FINEST);
        assertTrue("FINEST matches equals another level",
                levelSet.add(Level.FINEST));
        assertNotNull("TRACE is null", Level.TRACE);
        assertTrue("TRACE matches equals another level",
                levelSet.add(Level.TRACE));
        assertNotNull("DEBUG is null", Level.DEBUG);
        assertTrue("DEBUG matches equals another level",
                levelSet.add(Level.DEBUG));
        assertNotNull("CONFIG is null", Level.CONFIG);
        assertTrue("CONFIG matches equals another level",
                levelSet.add(Level.CONFIG));
        assertNotNull("INFO is null", Level.INFO);
        assertTrue("INFO matches equals another level",
                levelSet.add(Level.INFO));
        assertNotNull("WARN is null", Level.WARN);
        assertTrue("WARN matches equals another level",
                levelSet.add(Level.WARN));
        assertNotNull("ERROR is null", Level.ERROR);
        assertTrue("ERROR matches equals another level",
                levelSet.add(Level.ERROR));
        assertNotNull("FATAL is null", Level.FATAL);
        assertTrue("FATAL matches equals another level",
                levelSet.add(Level.FATAL));
        assertNotNull("ALL is null", Level.ALL);
        assertTrue("ALL matches equals another level",
                levelSet.add(Level.ALL));
    }
}
