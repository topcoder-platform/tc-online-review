package com.topcoder.util.cache.failuretests;

import com.topcoder.util.cache.*;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import java.util.ArrayList;

/**
 * Failure tests for Simple Cache
 *
 * @author kvin
 * @version 1.0
 */
public class FailureTests extends TestCase {

    /** 
     * This eviction strategy never removes an object
     */
    class NPCacheEvictionStrategy implements CacheEvictionStrategy {
	
	public void notifyOfCacheGet(Object key){}

	public void notifyOfCachePut(Object key){}

	public void notifyOfCacheRemove(Object key){}

	public void notifyOfCacheClear(){}

	public Object getNextKeyToEvict(){
	    return null;
	}

    }

    /** 
     * This eviction strategy returns something that does not exist in the cache
     */
    class MRRCacheEvictionStrategy extends FIFOCacheEvictionStrategy {
	
	private ArrayList toRemove;
	
	public MRRCacheEvictionStrategy() {
	    super();
	    toRemove=new ArrayList();
	}

	public void notifyOfCacheRemove(Object key) {
	    toRemove.add(key);
	    super.notifyOfCacheRemove(key);   
	}

	public Object getNextKeyToEvict() {
	    if(!toRemove.isEmpty() ) {
		Object o=toRemove.get(toRemove.size() - 1);
		toRemove.remove(toRemove.size() - 1);
		return o;
	    }
	    else {
		return super.getNextKeyToEvict();
	    }
	}
	
    }


    /**
     * tests that various exceptions are thrown at the correct time
     */
    public void testBadCacheEvictionStrategies() {
	SimpleCache testCache=new SimpleCache(2, SimpleCache.NO_TIMEOUT, 
					      new MRRCacheEvictionStrategy() );
	assertEquals("Max size should be 2", 2, testCache.getMaxCacheSize() );
	
	testCache.put("a", "A");
	testCache.put("b", "B");
	testCache.remove("b");
	testCache.put("c", "C");
	testCache.put("d", "D");
	if(testCache.get("a")!=null && testCache.get("c")!=null
	   && testCache.get("d")!=null) {
	    fail("Cache should clear something else when CacheEvictionStrategy returns something not in cache");
	}
	

	testCache=new SimpleCache(2, SimpleCache.NO_TIMEOUT, 
					      new NPCacheEvictionStrategy() );
	assertEquals("Max size should be 2", 2, testCache.getMaxCacheSize() );
	
	testCache.put("a", "A");
	testCache.put("b", "B");
	testCache.put("c", "C");
	if(testCache.get("a")!=null && testCache.get("b")!=null 
	   && testCache.get("c")!=null) {
	    fail("Cache should clear something even when CacheEvictionStrategy returns null");
	}

    }
    
    /**
     * tests that various exceptions are thrown at the correct time
     */
    public void testExceptionsThrown() {
	SimpleCache testCache;
	
	try {
	    testCache=new SimpleCache(0,100, new FIFOCacheEvictionStrategy() );
	    fail("Non-positive maxCacheSize should throw exception");
	}
	catch (IllegalArgumentException e) {}

	try {
	    testCache=new SimpleCache(100,0, new FIFOCacheEvictionStrategy() );
	    fail("Non-positive timeoutMS should throw exception");
	}
	catch (IllegalArgumentException e) {}

	try {
	    testCache=new SimpleCache(100,100, null );
	    fail("Null evictionStrategy should throw exception");
	}
	catch (IllegalArgumentException e) {}
	
	testCache=new SimpleCache(2,10000, new FIFOCacheEvictionStrategy() );

	try {
	    testCache.put(null, "a");
	    fail("Null argument to put should throw exception");
	}
	catch (IllegalArgumentException e) {}
	
	try {
	    testCache.get(null);
	    fail("Null argument to get should throw exception");
	}
	catch (IllegalArgumentException e) {}

	try {
	    testCache.remove(null);
	    fail("Null argument to remove should throw exception");
	}
	catch (IllegalArgumentException e) {}

	testCache.put("a", "A");
	assertNotNull("Entry in cache should be retrievable", 
		     testCache.get("a") );
	testCache.put("b", "B");
	try {
	    testCache.put("b", null);
	}
	catch (java.lang.Exception e) {
	    fail("Null value to put should be valid");
	}
	testCache.put("c", "C");
	assertNotNull("Putting null value should remove from cache", 
		     testCache.get("a") );
	
    }

    /**
     * runs test
     */
    public static Test suite() {
        return new TestSuite(FailureTests.class);
    }

}










