/**
 *
 * Copyright � 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority.accuracytests;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * <p>This test case aggregates all Accuracy test cases.</p>
 *
 * @author TopCoder
 * @version 1.0
 */
public class AccuracyTests extends TestCase {

    public static Test suite() {
        final TestSuite suite = new TestSuite();
        suite.addTest(ArrayPriorityQueueTest.suite());
        suite.addTest(HashPriorityQueueTest.suite());
        suite.addTest(LinkedPriorityQueueTest.suite());
        suite.addTest(TreePriorityQueueTest.suite());
        suite.addTest(SingletonPriorityQueueTest.suite());
        suite.addTest(SynchronizedQueueTest.suite());
        suite.addTest(UnmodifiableQueueTest.suite());
        return suite;
    }

}
