package com.topcoder.util.collection.priority.accuracytests;

import com.topcoder.util.collection.priority.TreePriorityQueue;
import com.topcoder.util.collection.priority.PriorityQueue;
import com.topcoder.util.collection.priority.PriorityQueues;
import junit.framework.TestSuite;
import junit.framework.Test;

/**
 * Tests the singleton PriorityQueue returned by PriorityQueues.singletonPriorityQueue(Object)
 * 
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 * @author msuhocki
 * @version 1.0
 */
public class SingletonPriorityQueueTest extends UnmodifiableQueueTest {
    PriorityQueue nullQueue;
    
    /**
     * instantiate PriorityQueue instance 
     */
    public void setUp() {
        nullQueue = PriorityQueues.singletonPriorityQueue(null);
        queue = PriorityQueues.singletonPriorityQueue("String1");
    }

    /**
     * Tests PriorityQueue.contains(Object)
     */
    public void testContains() {
        assertTrue(queue.contains("String1"));
        assertFalse(queue.contains("String2"));
        assertFalse(nullQueue.contains("String1"));
        assertTrue(nullQueue.contains(null));
    }
    
    /**
     * Tests PriorityQueue.containsAll(Collection)
     */
    public void testContainsAll() {
        assertTrue(queue.containsAll(lists[2]));
        assertFalse(queue.containsAll(lists[4]));
        assertFalse(nullQueue.containsAll(lists[2]));
        assertTrue(nullQueue.containsAll(empty));
    }
    
    /**
     * Tests PriorityQueue.equals(Object)
     */
    public void testEquals() throws Exception {
        PriorityQueue queue1 = new TreePriorityQueue();
        
        assertTrue(queue.equals(lists[4]));
        assertFalse(queue.equals(queue1));
        
        queue1.add("String1");
        assertTrue(queue.equals(queue1));
        
        assertFalse(queue.equals("String1"));
        
        assertFalse(nullQueue.equals(null));
    }
    
    /**
     * Tests PriorityQueue.isEmpty()
     */
    public void testIsEmpty() {
        assertFalse(queue.isEmpty());
        assertFalse(nullQueue.isEmpty());
    }
    
    /**
     * Tests PriorityQueue.iterator()
     */
    public void testIterator() {
        checkList(lists[4]);  // uses iterator        
    }
    
    /**
     * Tests PriorityQueue.peek()
     */
    public void testPeek() {
        assertEquals("String1", queue.peek());
        assertEquals(null, nullQueue.peek());
    }
    
    /**
     * Tests PriorityQueue.size()
     */
    public void testSize() {
        assertEquals(1, queue.size());
        assertEquals(1, nullQueue.size());
    }
    
    /**
     * Tests PriorityQueue.toArray()
     */
    public void testToArray() {
        Object[] array;
        
        array = queue.toArray();
        assertEquals(1, array.length);
        assertEquals("String1", array[0]);
        
        array = nullQueue.toArray();
        assertEquals(1, array.length);
        assertEquals(null, array[0]);
    }
    
    /**
     * Tests PriorityQueue.toArray(Object[])
     */
    public void testToArray_ObjectA() {
        String[] dummy = new String[0];
        String[] array;
        
        array = (String[]) queue.toArray(dummy);
        assertEquals(1, array.length);
        assertEquals("String1", array[0]);

        array = (String[]) nullQueue.toArray(dummy);
        assertEquals(1, array.length);
        assertEquals(null, array[0]);
    }
    
    public static Test suite() {
        return new TestSuite(SynchronizedQueueTest.class);
    }
}
