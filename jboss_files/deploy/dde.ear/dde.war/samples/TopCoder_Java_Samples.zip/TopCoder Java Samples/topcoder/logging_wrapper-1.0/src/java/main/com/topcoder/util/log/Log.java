package com.topcoder.util.log;

/**
 * The Log interface should be extended by classes that wish to provide a custom
 * logging implementation. The <tt>log</tt> method is used to log a message using
 * the underlying implementation, and the <tt>isEnabled</tt> method is used to determine
 * if a specific logging level is currently being logged.
 * 
 * @author StinkyCheeseMan
 * @version 1.0
 */
public interface Log
{
    void log(Level level, Object message) throws LogException;
    boolean isEnabled(Level level) throws LogException;
}