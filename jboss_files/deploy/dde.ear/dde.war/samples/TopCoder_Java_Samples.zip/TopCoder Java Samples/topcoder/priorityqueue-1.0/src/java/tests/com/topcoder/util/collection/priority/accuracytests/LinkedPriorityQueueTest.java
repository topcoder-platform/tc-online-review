package com.topcoder.util.collection.priority.accuracytests;

import com.topcoder.util.collection.priority.LinkedPriorityQueue;
import junit.framework.TestSuite;
import junit.framework.Test;

/**
 * LinkedPriorityQueue test cases.  Functionality in PriorityQueueTest.
 * 
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 * @author msuhocki
 * @version 1.0
 */
public class LinkedPriorityQueueTest extends PriorityQueueTest {

    /**
     * instantiate PriorityQueue instance 
     */
    public void setUp() {
        queue = new LinkedPriorityQueue();
    }

    /**
     * Tests LinkedPriorityQueue constructor.
     */
    public void testArrayPriorityQueue() {
        LinkedPriorityQueue queue1;
        
        queue = new LinkedPriorityQueue();
        assertTrue(queue.isEmpty());
        
        queue.addAll(lists[0]);
        
        queue1 = new LinkedPriorityQueue(queue);
        assertEquals(queue, queue1);
        
        queue1 = new LinkedPriorityQueue(queue);
        assertEquals(queue, queue1);
    }

    public static Test suite() {
        return new TestSuite(LinkedPriorityQueueTest.class);
    }
}
