/**
 * JUnit test case for code separation functions.
 * @author ttsuchi
 */
package com.topcoder.util.log.functionaltests;

import com.topcoder.util.log.Level;
import com.topcoder.util.log.Log;
import com.topcoder.util.log.LogException;
import com.topcoder.util.log.LogFactory;

public class EnabledTest extends LogTest {
    public EnabledTest(String s) {
        super(s);
    }

    /**
     * tests Log.isEnabled. Log level should be set at INFO level.
     */
    public void testIsEnabled() {
        try {
            Log enabledLog = LogFactory.getInstance().getLog("enabledLog");
            if (!(enabledLog instanceof com.topcoder.util.log.basic.BasicLog)) {
                assertTrue(
                        enabledLog.isEnabled(Level.ALL) &&
                        enabledLog.isEnabled(Level.FATAL) &&
                        enabledLog.isEnabled(Level.ERROR) &&
                        enabledLog.isEnabled(Level.WARN) &&
                        enabledLog.isEnabled(Level.INFO) &&
                        // The following fails because of the mapping of levels
                        // in log4j
                        //!enabledLog.isEnabled(Level.CONFIG) &&
                        !enabledLog.isEnabled(Level.DEBUG) &&
                        !enabledLog.isEnabled(Level.TRACE) &&
                        !enabledLog.isEnabled(Level.FINEST) &&
                        !enabledLog.isEnabled(Level.OFF)
                );
            }
        }
        catch(Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * tests logging at different logging levels. Log level should be set at INFO level.
     */
    public void testLevelLogging() {
        String highMessage = "High Level";
        String lowMessage = "Low Level";
        try {
            Log enabledLog = LogFactory.getInstance().getLog("enabledLog");
            if (!(enabledLog instanceof com.topcoder.util.log.basic.BasicLog)) {
                enabledLog.log(Level.FATAL, highMessage);
                enabledLog.log(Level.TRACE, lowMessage);
                assertTrue(compareLogResult(highMessage) && !compareLogResult(lowMessage));
            }
        }
        catch(LogException le) {
            fail(le.getException().getMessage());
        }
        catch(Exception e) {
            fail(e.getMessage());
        }
    }
}
