/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import junit.framework.Test;
import junit.framework.TestSuite;


/**
 * Unit tests for hash map implementation of priority queues.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
public class HashPriorityQueueTests extends PriorityQueueTests {
    /**
     * Return a suite of tests.
     *
     * @return a suite of tests.
     */
    public static Test suite() {
        return new TestSuite(HashPriorityQueueTests.class);
    }

    /**
     * Create a simple queue for testing.
     */
    public void setUp() {
        queue = new HashPriorityQueue();
    }

    /** Verify behavior of constructors. */
    public void testConstructors1() {
        HashPriorityQueue q1 = new HashPriorityQueue();
        assertEquals(0, q1.size());
    }

    /** Verify behavior of constructors. */
    public void testConstructors2() {
        HashPriorityQueue q2 = new HashPriorityQueue(500);
        assertEquals(0, q2.size());
    }

    /** Verify behavior of constructors. */
    public void testConstructors3() {
        HashPriorityQueue q3 = new HashPriorityQueue(0);
    }

    /** Verify behavior of constructors. */
    public void testConstructors4() {
        try {
            HashPriorityQueue q4 = new HashPriorityQueue(-1);
            fail();
        } catch (IllegalArgumentException e) {
        }
    }

    /** Verify behavior of constructors. */
    public void testConstructors5() {
        HashPriorityQueue q1 = new HashPriorityQueue();
        HashPriorityQueue q5 = new HashPriorityQueue(q1);
        assertEquals(q5, q1);
    }

    /** Verify behavior of constructors. */
    public void testConstructors6() {
        HashPriorityQueue q3 = new HashPriorityQueue(0, 1.0f);
    }

    /** Verify behavior of constructors. */
    public void testConstructors7() {
        try {
            HashPriorityQueue q = new HashPriorityQueue(null);
            fail();
        } catch (NullPointerException e) {
        }
    }

    /**
     * Verify behavior of clone method.
     */
    public void testClone() {
        for (int i = 0; i < 5; ++i) {
            queue.add(new Integer(i));
        }

        PriorityQueue other =
            (PriorityQueue) ((HashPriorityQueue) queue).clone();
        assertEquals(queue, other);
        
        other.dequeue();
        assertFalse(queue.equals(other));
    }
}
