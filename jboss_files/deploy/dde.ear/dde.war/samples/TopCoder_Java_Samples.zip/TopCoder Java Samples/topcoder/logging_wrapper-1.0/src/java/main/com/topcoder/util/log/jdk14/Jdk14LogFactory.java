package com.topcoder.util.log.jdk14;

import com.topcoder.util.log.jdk14.Jdk14Log;
import com.topcoder.util.log.LogFactory;
import com.topcoder.util.log.Log;
import com.topcoder.util.log.LogException;

/**
 * JDK 1.4 specific implementation of the LogFactory interface.
 * 
 * @author StinkyCheeseMan
 * @version 1.0
 */
public final class Jdk14LogFactory extends LogFactory
{
	/**
	 * Returns a JDK 1.4 specific log instance for the specified <tt>name</tt>.
	 * 
	 * @param name The name associated with the log.
	 * 
	 * @return Log A log instance associated with the specified <tt>name</tt>.
	 */
    public final Log getLog(String name) throws LogException
    {
        if (name == null)
            throw new LogException(new NullPointerException("name cannot be null"));

        return new Jdk14Log(name);
    }

}