package com.topcoder.util.log.jdk14;

import com.topcoder.util.log.Log;
import com.topcoder.util.log.Level;
import com.topcoder.util.log.LogException;

import java.util.logging.Logger;

/**
 * This is the JDK 1.4 specific implementation of the <tt>Log</tt> interface.
 *
 * @author StinkyCheeseMan
 * @version 1.0
 *
 * @see com.topcoder.util.log.Log
 */
public class Jdk14Log implements Log
{
    // Instance of the underlying logger for JDK 1.4
    private Logger logger;
    // The underlying Level for the logger instance
    private java.util.logging.Level currentLevel;

    /**
     * Single argument constructor to initialize the log with the specified
     * <tt>name</tt>. The <tt>name</tt> parameter will be used to initialize the
     * underlying logger.
     *
     * @param name The name for this instance of the log.
     */
    public Jdk14Log(String name)
    {
        logger = Logger.getLogger(name);
        Logger effectiveLogger = logger.getParent();
        currentLevel = effectiveLogger.getLevel();
        while (effectiveLogger != null && currentLevel == null)
        {
            effectiveLogger = effectiveLogger.getParent();
            currentLevel = effectiveLogger.getLevel();
        }
    }

    /**
     * Use this method to log a <tt>message</tt> at the specified <tt>level</tt>.
     *
     * @param level The level at which the message should be logged.
     * @param message The message to log.
     *
     * @throws com.topcoder.util.log.LogException if an error occurs in the
     *    call to the underlying logger's log method.
     */
    public final void log(Level level, Object message) throws LogException
    {
        if (level == null)
            throw new LogException(new NullPointerException("level is null"));
        if (message == null)
            throw new LogException(new NullPointerException("message is null"));

        if (getJdk14EquivalentLevel(level) == null)
            throw new LogException(null);

        if (level.equals(Level.OFF))
            return;

        try
        {
            String msg = message instanceof String ? (String) message : message.toString();
            logger.log(getJdk14EquivalentLevel(level), msg);
        }
        catch (Exception e)
        {
            throw new LogException(e);
        }
    }

    /**
     * This method checks if a certain logging <tt>level</tt> is presently
     * enabled.
     *
     * @param level The level to check.
     *
     * @return boolean - true if the <tt>level</tt> is enabled; false otherwise;
     */
    public final boolean isEnabled(Level level) throws LogException
    {
        if (level == null)
            throw new LogException(new NullPointerException("level is null"));

		// Handle the special cases of ALL and OFF
        if (level.equals(Level.OFF))
        {
            return currentLevel.equals(java.util.logging.Level.OFF);
        }
        else if (level.equals(Level.ALL))
        {
            return !currentLevel.equals(java.util.logging.Level.OFF);
        }
        else
        {
            try
            {
                return logger.isLoggable(getJdk14EquivalentLevel(level));
            }
            catch (Exception e)
            {
                throw new LogException(e);
            }
        }
    }

    /**
     * This method is used to map a com.topcoder.util.log.Level object into a
     * java.util.logging.Level object. It should be noted that some TopCoder levels
     * map to the same JDK levels.
     *
     * @param level The com.topcoder.util.log.Level object that will be mapped to
     *    a java.util.logging.Level object.
     *
     * @return java.util.logging.Level - The mapped level.
     */
    private final java.util.logging.Level getJdk14EquivalentLevel(Level level)
    {
        if (level.equals(Level.FINEST))
            return java.util.logging.Level.FINEST;
        else if (level.equals(Level.TRACE))
            return java.util.logging.Level.FINER;
        else if (level.equals(Level.DEBUG))
            return java.util.logging.Level.FINE;
        else if (level.equals(Level.CONFIG))
            return java.util.logging.Level.CONFIG;
        else if (level.equals(Level.INFO))
            return java.util.logging.Level.INFO;
        else if (level.equals(Level.WARN))
            return java.util.logging.Level.WARNING;
        else if (level.equals(Level.ERROR))
            return java.util.logging.Level.SEVERE;
        else if (level.equals(Level.FATAL))
            return java.util.logging.Level.SEVERE;
        else if (level.equals(Level.ALL))
            return java.util.logging.Level.SEVERE;
        else if (level.equals(Level.OFF))
            return java.util.logging.Level.OFF;
        else
            return null;
    }
}