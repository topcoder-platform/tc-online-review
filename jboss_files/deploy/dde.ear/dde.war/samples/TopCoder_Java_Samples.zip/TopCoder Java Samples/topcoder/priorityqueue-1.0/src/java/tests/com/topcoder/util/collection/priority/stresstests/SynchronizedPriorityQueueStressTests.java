package com.topcoder.util.collection.priority.stresstests;

import com.topcoder.util.collection.priority.PriorityQueue;
import com.topcoder.util.collection.priority.PriorityQueues;
import com.topcoder.util.collection.priority.ArrayPriorityQueue;
import junit.framework.Test;
import junit.framework.TestSuite;
import junit.framework.TestCase;

/**
 * <p>This test case aggregates all Stress test cases on the synchronized wrapper.</p>
 *
 * @author TopCoder Software
 * @version 1.0
 *
 * Copyright � 2003, TopCoder, Inc. All rights reserved
 */
public class SynchronizedPriorityQueueStressTests extends TestCase {

    /**
     * Tests 25 threads simultaneously enqueueing and dequeueing a shared priority queue
     * @throws InterruptedException if thread is interrupted
     */
    public void testThreads() throws InterruptedException {
        PriorityQueue pq = PriorityQueues.synchronizedPriorityQueue(new ArrayPriorityQueue());
        Thread threads[] = new Thread[25];
        for (int i = 0; i < threads.length; i++) {
            threads[i] = new PQThread(pq);
        }

        long start = System.currentTimeMillis();
        for (int i = 0; i < threads.length; i++) {
            threads[i].start();
        }
        for (int i = 0; i < threads.length; i++) {
            threads[i].join();
        }
        System.out.println("took "
                           + (System.currentTimeMillis() - start)
                           + " milliseconds to run 25 threads"
                           + " simultaneously enqueueing and dequeueing 1000 times each");
    }

    /**
     * Returns the suite of tests
     * @return the suite of tests
     */
    public static Test suite() {
        return new TestSuite(SynchronizedPriorityQueueStressTests.class);
    }
}

/**
 * The thread class which takes in a shared priority queue and when run, enqueues and dequeues 1000 times.
 */
class PQThread extends Thread {
    /** shared priority queue */
    private PriorityQueue pq;

    /**
     * Creates the thread object which uses a shared priority queue
     * @param pq the shared priority queue
     */
    public PQThread(PriorityQueue pq) {
        this.pq = pq;
    }

    /**
     * Uses the shared priority queue and enqueues and dequeues 1000 times
     */
    public void run() {
        for (int i = 0; i < 1000; i++) {
            pq.enqueue(new Integer(i), i);
        }
        for (int i = 0; i < 1000; i++) {
            pq.dequeue();
        }
    }
}
