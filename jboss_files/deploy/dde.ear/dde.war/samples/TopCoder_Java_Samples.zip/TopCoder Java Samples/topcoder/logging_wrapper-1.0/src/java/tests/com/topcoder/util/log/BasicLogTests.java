package com.topcoder.util.log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.StringTokenizer;

import junit.framework.TestCase;

import com.topcoder.util.config.ConfigManagerException;
import com.topcoder.util.log.basic.BasicLog;

public class BasicLogTests extends TestCase {
    private PrintStream originalOut = System.out;
    private File outputFile;
    private FileOutputStream outputFileStream;
    private static final String SYSTEM_OUT_FILE = "System.out.txt";

    public BasicLogTests(String s) {
        super(s);
    }

    /**
     * Used to test the output for the basic logger. Only output to System.out is tested, so the basic.log.target property must be set to 
     * System.out in the Logging.xml file.
     */
    public void testLogOutput_1() {
        try {
            if (LogFactory.getAttribute(BasicLog.LOG_TARGET) != null && LogFactory.getAttribute(BasicLog.LOG_TARGET).trim().length() != 0 && !LogFactory.getAttribute(BasicLog.LOG_TARGET).equals(BasicLog.SYSTEM_ERR)) {

                String testMessage = "test message";
                try {
                    LogFactory.getInstance().getLog("placeholder").log(Level.ERROR, testMessage);
                } catch (LogException e) {
                    fail("Unexpected exception caught.");
                }

                // confirm the contents of the outputFile
                assertTrue(confirmFileContents(testMessage));
            }
        } catch (ConfigManagerException e) {
            throw new RuntimeException("Cannot access logging properties. " + e.getMessage());
        }
    }

    /**
        * Used to test the output for the basic logger. Only output to System.out is tested, so the basic.log.target property must be set to 
        * System.out in the Logging.xml file.
        */
    public void testLogOutput_2() {
        try {
            if (LogFactory.getAttribute(BasicLog.LOG_TARGET) != null && LogFactory.getAttribute(BasicLog.LOG_TARGET).trim().length() != 0 && !LogFactory.getAttribute(BasicLog.LOG_TARGET).equals(BasicLog.SYSTEM_ERR)) {

                String testMessage = "test message\nNext line";
                try {
                    LogFactory.getInstance().getLog("placeholder").log(Level.ERROR, testMessage);
                } catch (LogException e) {
                    fail("Unexpected exception caught. " + e.getMessage());
                }

                // confirm the contents of the outputFile
                assertTrue(confirmFileContents(testMessage));
            }
        } catch (ConfigManagerException e) {
            throw new RuntimeException("Cannot access logging properties. " + e.getMessage());
        }
    }

    /**
     * This method tests the isEnabled method. It should always return true for the basic logger.
     */
    public void testIsEnabled() {
        try {
            Log basicLog = LogFactory.getInstance().getLog("doesn't matter");
            assertTrue(basicLog.isEnabled(Level.ALL));
            assertTrue(basicLog.isEnabled(Level.CONFIG));
            assertTrue(basicLog.isEnabled(Level.DEBUG));
            assertTrue(basicLog.isEnabled(Level.ERROR));
            assertTrue(basicLog.isEnabled(Level.FATAL));
            assertTrue(basicLog.isEnabled(Level.FINEST));
            assertTrue(basicLog.isEnabled(Level.INFO));
            assertTrue(basicLog.isEnabled(Level.OFF));
            assertTrue(basicLog.isEnabled(Level.TRACE));
            assertTrue(basicLog.isEnabled(Level.WARN));
        } catch (LogException e) {
            fail("Unexpected exception caught. " + e.getMessage());
        }    
    }
    
    protected void setUp() throws Exception {
        super.setUp();
        outputFile = new File(SYSTEM_OUT_FILE);
        outputFileStream = new FileOutputStream(outputFile);
        System.setOut(new PrintStream(outputFileStream));
    }

    protected void tearDown() throws Exception {
        super.tearDown();

        System.setOut(originalOut);

        if (outputFileStream != null && outputFile != null) {
            try {
                outputFileStream.close();
                outputFile.delete();
            } catch (Exception e) {
                // ignore
            }
        }
    }

    private boolean confirmFileContents(String matchString) {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(new FileInputStream(outputFile)));
            String line = reader.readLine();
            StringTokenizer st = new StringTokenizer(matchString, "\n");
            while (line != null && st.hasMoreTokens()) {
                if (!line.equals(st.nextToken())) {
                    return false;
                }

                line = reader.readLine();
            }

            if (line == null && st.hasMoreTokens()) {
                return false;
            } else {
                return true;
            }
        } catch (Exception e) {
            throw new RuntimeException("Cannot access redirected output file.");
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (Exception e) {}
            }
        }
    }

}
