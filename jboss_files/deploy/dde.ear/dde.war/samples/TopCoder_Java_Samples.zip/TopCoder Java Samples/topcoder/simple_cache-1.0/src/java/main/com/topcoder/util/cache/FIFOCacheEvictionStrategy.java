package com.topcoder.util.cache;

import java.util.HashMap;
import java.util.TreeMap;

/**
 * <p>An implementation of CacheEvictionStrategy interface with
 * the FIFO (First In First Out) Stategy.</p>
 *
 * <p>Copyright &copy 2002, TopCoder, Inc. All rights reserved</p>
 *
 * @author  WishingBone
 * @version 1.0
 */
public class FIFOCacheEvictionStrategy implements CacheEvictionStrategy {

    /** map from key to its id
     */
    private HashMap mapKey2ID;

    /** map from id to its key
     */
    private TreeMap mapID2Key;

    /** the last id used
     */
    private int lastID;

    /** contructor
     */
    public FIFOCacheEvictionStrategy() {
        mapKey2ID = new HashMap();
        mapID2Key = new TreeMap();
        lastID = 0;
    }

    /** notify of cache when "get" method happened on the specified key
     * @param   key     the specified key on which "get" method happened
     */
    public void notifyOfCacheGet(Object key) {
        // simply nothing :)
    }

    /** notify of cache when "put" method happened on the specified key
     * @param   key     the specified key on which "put" method happened
     */
    public void notifyOfCachePut(Object key) {
        Integer id = new Integer(lastID ++);
        // obtain a new id, put into both maps
        synchronized (mapKey2ID) {
            mapKey2ID.put(key, id);
        }
        synchronized (mapID2Key) {
            mapID2Key.put(id, key);
        }
    }

    /** notify of cache when "remove" method happened on the specified key
     * @param   key     the specified key on which "remove" method happened
     */
    public void notifyOfCacheRemove(Object key) {
        Integer id;
        // remove from both maps
        synchronized (mapKey2ID) {
            id = (Integer)mapKey2ID.get(key);
            if (id != null)
                mapKey2ID.remove(key);
        }
        synchronized (mapID2Key) {
            if (id != null)
                mapID2Key.remove(id);
        }
    }

    /** notify of cache when "clear" method happened
     */
    public void notifyOfCacheClear() {
        // clear both maps
        synchronized (mapKey2ID) {
            mapKey2ID.clear();
        }
        synchronized (mapID2Key) {
            mapID2Key.clear();
        }
    }

    /** decides the next key to evict when the cache is full
     *  @param the key to evict
     */
    public Object getNextKeyToEvict() {
        Integer id;
        Object key;
        // find the key with the smallest id
        // remove from both maps
        synchronized (mapID2Key) {
            id = (Integer)mapID2Key.firstKey();
            key = mapID2Key.get(id);
            mapID2Key.remove(id);
            synchronized (mapKey2ID) {
                mapKey2ID.remove(key);
            }
        }
        return key;
    }

}
