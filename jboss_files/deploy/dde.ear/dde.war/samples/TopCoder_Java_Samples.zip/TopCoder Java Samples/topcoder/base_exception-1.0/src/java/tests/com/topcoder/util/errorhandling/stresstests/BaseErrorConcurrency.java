package com.topcoder.util.errorhandling.stresstests;

import java.util.Hashtable;
import junit.framework.TestCase;
import com.topcoder.util.errorhandling.*;
import java.io.PrintStream;
import java.io.PrintWriter;

/**
 * <p>This test launches a number of threads each accessing their own 
 * BaseError.</p>
 *
 * @author aksonov
 * @version 1.0
 */
public class BaseErrorConcurrency extends AbstractBenchmark {

    private static final int CHAIN_LENGTH = 200;
    private static final int NUM_THREADS = 100;

    public BaseErrorConcurrency(){
        super("BaseErrorConcurrency");
    }

    /**
     * <p>This test launches a number of threads each creating long chain 
     * contained from BaseError objects.</p>
     *
     * @exception InterruptedException if the test is interrupted
     */
    public void testBaseErrorConcurrency()  throws Exception{
        runBenchmark(10, "BaseError");
    }

    public void runOnce() throws InterruptedException {
        BaseErrorTester[] threads = new BaseErrorTester[NUM_THREADS];
        for (int i = 0; i < threads.length; ++i) {
            threads[i] = new BaseErrorTester();
            threads[i].start();
        }
        for (int i = 0; i < threads.length; ++i) {
            threads[i].join();
            assertTrue("all threads should complete successfully", 
                       threads[i].getSuccess());
        }
    }

    /**
     * Thread that executes a single test of the BaseError.
     */
    class BaseErrorTester extends Thread {
        /**
         * Returns an indicator of whether the thread completed successfully.
         *
         * @return an indicator of whether the thread completed successfully
         */
        public boolean getSuccess() {
            return success;
        }

        /**
         * Indicator of whether the thread completed successfully.
         */
        private boolean success = true;

        /**
         * The main loop of the thread.
         */
        public void run() {
            BaseError exception = new BaseError();
            try {
                exception.initCause(new Exception());
                for (int i=0;i<CHAIN_LENGTH;i++){
                    exception = new BaseError("Exception "+new Integer(i).toString(),exception);
                }
                throw exception;
            } catch (final BaseError ex2){
                assertEquals(exception, ex2);
                for (int i=CHAIN_LENGTH;i>0;i--){
                    exception = (BaseError)CauseUtils.getCause(exception);
                }
                return;
            } catch (final Exception ex) {
                success = false;
            }
            fail("Exception should thrown");
        }
    }
}
