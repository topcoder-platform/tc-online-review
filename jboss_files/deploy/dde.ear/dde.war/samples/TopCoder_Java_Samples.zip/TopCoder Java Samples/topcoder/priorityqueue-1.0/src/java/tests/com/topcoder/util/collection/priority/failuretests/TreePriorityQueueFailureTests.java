/*
 * @(#)TreePriorityQueueFailureTestCase.java     1.0 Aug 18, 2003
 * 
 * Copyright � 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority.failuretests;

import java.util.Collection;

import junit.framework.TestSuite;

import com.topcoder.util.collection.priority.TreePriorityQueue;

/**
 * Failure tests for the class <code>TreePriorityQueue</code>. 
 * 
 * @version 1.0
 * @author MPhk
 */
public class TreePriorityQueueFailureTests extends PriorityQueueFailureTests {
    /**
     * Returns the test suite containing the methods of this class 
     * 
     * @return a TestSuite
     */
    public static TestSuite suite() {
        TestSuite suite = new TestSuite(TreePriorityQueueFailureTests.class);
        suite.setName("Tree " + NAME);
        return suite;
    }
    
    /* (non-Javadoc)
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        nullQueue = (TreePriorityQueue)null;
        emptyQueue = new TreePriorityQueue();
        assertNotNull(emptyQueue);
        nonEmptyQueue = new TreePriorityQueue();
        assertNotNull(nonEmptyQueue);
        nonEmptyQueue.add(new String("Object"));
    }

    /**
     * Tests the constructor with parameter <code>Collection</code> of 
     * <code>TreePriorityQueue</code> for illegal argument (null). The 
     * constructor should throw a <code>NullPointerException</code>.
     * Test must pass.
     */
    public void testConstructor1() {
        try {
            nullQueue = new TreePriorityQueue((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
        assertEquals(nullQueue, null);
    }    

    /**
     * Tests the constructor with parameter <code>TreePriorityQueue</code> of 
     * <code>TreePriorityQueue</code> for illegal argument (null). The 
     * constructor should throw a <code>NullPointerException</code>.
     * Test must pass.
     */
    public void testConstructor2() {
        try {
            nullQueue = new TreePriorityQueue((TreePriorityQueue)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
        assertEquals(nullQueue, null);
    }
}
