/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import junit.framework.Test;
import junit.framework.TestSuite;


/**
 * Test tree map implementation of priority queue.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
public class TreePriorityQueueTests extends PriorityQueueTests {
    /** Return a suite of unit tests. */
    public static Test suite() {
        return new TestSuite(TreePriorityQueueTests.class);
    }

    /** Create a queue for testing. */
    public void setUp() {
        queue = new TreePriorityQueue();
    }

    /** Verify behavior of constructors. */
    public void testConstructors1() {
        TreePriorityQueue q1 = new TreePriorityQueue();
        assertEquals(0, q1.size());
    }

    /** Verify behavior of constructors. */
    public void testConstructors2() {
        try {
            TreePriorityQueue q = new TreePriorityQueue(null);
            fail();
        } catch (NullPointerException e) {
        }
    }

    /** Verify behavior of constructors. */
    public void testConstructors3() {
        TreePriorityQueue q1 = new TreePriorityQueue();
        TreePriorityQueue q2 = new TreePriorityQueue(q1);
        assertEquals(q2, q1);
    }
    
    /**
     * Verify behavior of clone method.  A clone is a deep copy, so
     * that it is initial equal to the original, but can be modified
     * separately.
     */
    public void testClone() {
        for (int i = 0; i < 5; ++i) {
            queue.add(new Integer(i));
        }
        
        PriorityQueue other
            = (PriorityQueue) ((TreePriorityQueue) queue).clone();
        assertEquals(queue, other);
        
        other.dequeue();
        assertFalse(queue.equals(other));
    }
}
