package com.topcoder.util.log.stresstests;

import junit.framework.Test;
import junit.framework.TestSuite;

import com.topcoder.util.log.Level;
import com.topcoder.util.log.Log;
import com.topcoder.util.log.LogException;
import com.topcoder.util.log.LogFactory;
import com.topcoder.util.log.functionaltests.LogTest;

public class StressTest extends LogTest {
    public StressTest(String s) {
        super(s);
    }

    private Log simpleLog;
    private int numThreads = 30;
    private int numRuns = 1000;

    private class Runner implements Runnable {
        private Log simpleLog;
        private int numRuns;
        public Runner(Log l, int r) {
               simpleLog = l;
               numRuns = r;
        }

        public void run() {
            String message = Thread.currentThread().getName();

            message += ": Message Level Is ";

            try {
                for (int k = 0; k < numRuns; k++) {
                    simpleLog.log(Level.OFF, message+"OFF");
                    simpleLog.log(Level.FINEST, message+"FINEST"+k);
                    simpleLog.log(Level.TRACE, message+"TRACE"+k);
                    simpleLog.log(Level.DEBUG, message+"DEBUG"+k);
                    simpleLog.log(Level.CONFIG, message+"CONFIG"+k);
                    simpleLog.log(Level.INFO, message+"INFO"+k);
                    simpleLog.log(Level.WARN, message+"WARN"+k);
                    simpleLog.log(Level.ERROR, message+"ERROR"+k);
                    simpleLog.log(Level.FATAL, message+"FATAL"+k);
                    simpleLog.log(Level.ALL, message+"ALL"+k);
                }
            } catch (Exception e) {
                fail(e.getMessage());
            }
        }
    }

    /*
     * tests LogFactory.log(int, String)
     */
    public void testSimpleLog() {
        try {
            simpleLog = LogFactory.getInstance().getLog("stressLog");

            Runner r = new Runner(simpleLog, numRuns);

            Thread t[] = new Thread[numThreads];
            for (int i = 0; i < numThreads; i++) {
                t[i] = new Thread(r);
            }
            for (int i = 0; i < numThreads; i++) {
                t[i].start();
            }
            for (int i = 0; i < numThreads; i++) {
                try {
                    t[i].join();
                } catch (InterruptedException ie) {}
            }
        } catch(LogException le) {
            fail(le.getException().getMessage());
        } catch(Exception e) {
            fail(e.getMessage());
        }

        //no asserts (output should be checked manually
    }

    public static void main (String args[]) {
        junit.textui.TestRunner.run(suite());
    }

    public static Test suite() {
        return new TestSuite(StressTest.class);
    }
}
