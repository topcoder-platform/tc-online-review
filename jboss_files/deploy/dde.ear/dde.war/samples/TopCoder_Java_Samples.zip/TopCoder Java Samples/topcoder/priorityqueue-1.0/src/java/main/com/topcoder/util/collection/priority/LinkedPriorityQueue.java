/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.NoSuchElementException;


/**
 * This implementation of PriorityQueue is backed by an
 * LinkedList. This class provides on average O(n)-time,O(n)-data move
 * for insertions and O(1)-time, O(1)-data move for removals.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
public class LinkedPriorityQueue
    extends ListPriorityQueue implements Cloneable, Serializable {
    
    /**
     * Creates new empty internal storage.
     */
    public LinkedPriorityQueue() {
        objects    = new LinkedList();
        priorities = new ArrayList();
    }

    /**
     * Creates new internal storage and inserts all the objects in the
     * given collection at the default priority level.
     *
     * @param collection The collection of objects to add
     *
     * @throws NullPointerException if collection is null
     */
    public LinkedPriorityQueue(Collection collection) {
        this();
        addAll(collection);
    }

    /**
     * Construct a copy of the queue, maintaining order and priority.
     *
     * @param queue a queue to copy
     *
     * @throws NullPointerException if queue is null
     */
    public LinkedPriorityQueue(LinkedPriorityQueue queue) {
        if (null == queue) {
            throw new NullPointerException();
        }

        objects    = new LinkedList(queue.objects);
        priorities = new ArrayList(queue.priorities);
    }
    
    /**
     * Destructively returns the object currently at the head of the
     * queue.
     *
     * @return the next object at the highest priority level and
     * remove that object from the queue
     *
     * @throws IllegalStateException if the queue is empty
     *
     * @see peek
     */
    public Object dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException();
        }
        priorities.remove(priorities.size() - 1);
        return ((LinkedList) objects).removeLast();
    }

    /**
     * Non-destructively (the queue is not modified) return the object
     * currently at the head of the queue.  This is the same object
     * that would be (desctructively) returned by
     * <code>dequeue</code>.
     *
     * @return the object currently at the head of the queue
     *
     * @throws IllegalStateException if the queue is empty
     *
     * @see dequeue
     */
    public Object peek() {
        if (isEmpty()) {
            throw new IllegalStateException();
        }
        return ((LinkedList) objects).getLast();
    }

    /**
     * Construct an iterator for the priority queue.  The order of
     * iteration for priority queues is defined to be the queue's
     * priority order.  In other words, the iterator will return
     * objects in the same order they would be retrieved by
     * <code>dequeue</code>.
     *
     * @return an iterator over all the objects in the queue in priority order
     */
    public Iterator iterator() {
        return new Iterator() {
                // begin at the end, go backward to the beginning, then stop
                private ListIterator objectIterator =
                    ((LinkedList) objects).listIterator(objects.size());
                private int priorityIterator = size();

                public boolean hasNext() {
                    return objectIterator.hasPrevious();
                }

                public Object next() {
                    if (!hasNext()) {
                        throw new NoSuchElementException();
                    }

                    --priorityIterator;
                    return objectIterator.previous();
                }

                public void remove() {
                    objectIterator.remove();
                    priorities.remove(priorityIterator);
                }
            };
    }

    /**
     * Return a deep copy of the queue.
     *
     * @return a deep copy of the queue.
     */
    public Object clone() {
        return new LinkedPriorityQueue(this);
    }
}
