/*
 * @(#)PriorityQueueFailureTestCase.java     1.0 Aug 18, 2003
 * 
 * Copyright � 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority.failuretests;

import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

import junit.framework.TestCase;

import com.topcoder.util.collection.priority.PriorityQueue;

/**
 * Failure tests for the class <code>PriorityQueue</code>. 
 * 
 * @version 1.0
 * @author MPhk
 */
public class PriorityQueueFailureTests extends TestCase {
    /**
     * The name of this test suite 
     */
    protected static String NAME = "Priority Queue Failure Test";
    
    /**
     * Invalid value for the initial capacity of the queues  
     */
    public static int INVALID_SIZE = -1;

    /**
     * A null <code>PriorityQueue</code> used for testing
     */
    protected PriorityQueue nullQueue;
    
    /**
     * An empty <code>PriorityQueue</code> used for testing
     */
    protected PriorityQueue emptyQueue;
    
    /**
     * A non-empty <code>PriorityQueue</code> used for testing
     */
    protected PriorityQueue nonEmptyQueue;
    
    /* (non-Javadoc)
     * @see junit.framework.TestCase#tearDown()
     */
    protected void tearDown() throws Exception {
        nullQueue = null;
        emptyQueue = null;
        nonEmptyQueue = null;
    }

    /**
     * Tests the <code>addAll</code> method of <code>PriorityQueue</code>
     * class with a null parameter on an empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testAddAllE() {
        try {
            emptyQueue.addAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }

    /**
     * Tests the <code>addAll</code> method of <code>PriorityQueue</code>
     * class with a null parameter on a non-empty queue.
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testAddAllNE() {
        try {
            nonEmptyQueue.addAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }

    /**
     * Tests the <code>containsAll</code> method of 
     * <code>PriorityQueue</code> class with a null parameter on an 
     * empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testContainsAllE() {
        try {
            emptyQueue.containsAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }

    /**
     * Tests the <code>containsAll</code> method of 
     * <code>PriorityQueue</code> class with a null parameter on a 
     * non-empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testContainsAllNE() {
        try {
            nonEmptyQueue.containsAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }
    
    /**
     * Tests the <code>removeAll</code> method of 
     * <code>PriorityQueue</code> class with a null parameter on an empty 
     * queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testRemoveAllE() {
        try {
            emptyQueue.removeAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }

    /**
     * Tests the <code>removeAll</code> method of 
     * <code>PriorityQueue</code> class with a null parameter on a  
     * non-empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testRemoveAllNE() {
        try {
            nonEmptyQueue.removeAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }
    
    /**
     * Tests the <code>retainAll</code> method of 
     * <code>PriorityQueue</code> class with a null parameter on an empty
     * queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testRetainAllE() {
        try {
            emptyQueue.retainAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }
    
    /**
     * Tests the <code>retainAll</code> method of 
     * <code>PriorityQueue</code> class with a null parameter on a 
     * non-empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testRetainAllNE() {
        try {
            nonEmptyQueue.retainAll((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }    
    
    /**
     * Tests the <code>toArray</code> method of 
     * <code>PriorityQueue</code> class with a null parameter on a 
     * empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testToArrayE() {
        try {
            emptyQueue.toArray((String[])null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }
    
    /**
     * Tests the <code>toArray</code> method of 
     * <code>PriorityQueue</code> class with a null parameter on a 
     * non-empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testToArrayNE1() {
        try {
            nonEmptyQueue.toArray((String[])null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }

    /**
     * Tests the <code>toArray</code> method of 
     * <code>PriorityQueue</code> class with an invalid type parameter  
     * on a non-empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testToArrayNE2() {
        try {
            nonEmptyQueue.toArray(new Integer[] {});
            fail("Should throw a ArrayStoreException!");
        } catch (ArrayStoreException ase) {
            // expected exception
        }
    }    
    
    /**
     * Tests the <code>dequeue</code> method of 
     * <code>PriorityQueue</code> class on an empty queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testDequeue() {
        try {
            emptyQueue.dequeue();
            fail("Should throw an IllegalStateException!");
        } catch (IllegalStateException ise) {
            // expected exception
        }        
    }

    /**
     * Tests the <code>peek</code> method of 
     * <code>PriorityQueue</code> class on an empty queue. 
     * Should throw a <code>IllegalStateException</code>. Test must pass.
     */
    public void testPeek() {
        try {
            emptyQueue.peek();
            fail("Should throw an IllegalStateException!");
        } catch (IllegalStateException ise) {
            // expected exception
        }        
    }
    
    /**
     * Tests the <code>enqueueAll</code> method of 
     * <code>PriorityQueue</code> class with a null parameter on an empty 
     * queue. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testEnqueueAllE() {
        try {
            emptyQueue.enqueueAll((Collection)null, 
                                  PriorityQueue.DEFAULT_PRIORITY);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }

    /**
     * Tests the <code>enqueueAll</code> method of 
     * <code>PriorityQueue</code> class with a null parameter on a 
     * non-empty queue.
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testEnqueueAllNE() {
        try {
            nonEmptyQueue.enqueueAll((Collection)null, 
                                     PriorityQueue.DEFAULT_PRIORITY);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
    }    
    
    /**
     * Tests the iterator method <code>next</code> on an empty queue of type 
     * <code>PriorityQueue</code>. 
     * Should throw a <code>NullPointerException</code>. Test must pass.
     */
    public void testIteratorNextE() {
        Iterator it = emptyQueue.iterator();
        assertNotNull(it);
        try {
            it.next();
            fail("Should throw a NoSuchElementException!");
        } catch (NoSuchElementException nsee) {
            // expected exception
        }
    }
    
    /**
     * Tests the iterator method <code>next</code> on a not-empty queue of type 
     * <code>PriorityQueue</code>.  
     * After the second call should throw a <code>NullPointerException</code>. 
     * Test must pass.
     */
    public void testIteratorNextNE() {
        Iterator it = nonEmptyQueue.iterator();
        assertNotNull(it);
        try {
            assertTrue(it.hasNext());
            it.next();
            assertFalse(it.hasNext());
            it.next();
            fail("Should throw a NoSuchElementException!");
        } catch (NoSuchElementException nsee) {
            // expected exception
        }
    }    
    
    /**
     * Tests the iterator method <code>remove</code> on an empty queue of type 
     * <code>PriorityQueue</code>. 
     * Should throw a <code>IllegalStateException</code>. Test must pass.
     */
    public void testIteratorRemoveE() {
        Iterator it = emptyQueue.iterator();
        assertNotNull(it);
        try {
            it.remove();
            fail("Should throw a IllegalStateException!");
        } catch (IllegalStateException ise) {
            // expected exception
        }
    }
    
    /**
     * Tests the iterator method <code>remove</code> on a not-empty queue of  
     * type <code>PriorityQueue</code>. Tries to remove the same element 
     * for two times. Should throw a <code>IllegalStateException</code>. 
     * Test must pass.
     */
    public void testIteratorRemoveNE() {
        Iterator it = nonEmptyQueue.iterator();
        assertNotNull(it);
        try {
            assertTrue(it.hasNext());
            it.next();
            it.remove();
            assertTrue(it!=null);
            it.remove();
            fail("Should throw a IllegalStateException!");
        } catch (IllegalStateException ise) {
            // expected exception
        }
    }     
    
    /**
     * Tests the iterator methods <code>remove</code> and <code>next</code>on a 
     * not-empty queue of type <code>PriorityQueue</code>. Tries to remove 
     * the single element of the queue than tries to obtain the next element. 
     * Should throw a <code>NoSuchElementException</code>. Test must pass.
     */
    public void testIteratorRemoveNextNE() {
        Iterator it = nonEmptyQueue.iterator();
        assertNotNull(it);
        try {
            assertTrue(it.hasNext());
            it.next();
            it.remove();
            assertFalse(it.hasNext());
            it.next();
            fail("Should throw a NoSuchElementException!");
        } catch (NoSuchElementException nsee) {
            // expected exception
        }
    } 
}
