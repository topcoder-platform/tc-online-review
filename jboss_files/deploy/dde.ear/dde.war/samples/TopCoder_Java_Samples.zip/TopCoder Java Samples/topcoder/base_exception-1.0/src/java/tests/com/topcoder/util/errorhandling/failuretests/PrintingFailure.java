package com.topcoder.util.errorhandling.failuretests;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;

import com.topcoder.util.errorhandling.BaseError;
import com.topcoder.util.errorhandling.BaseException;
import com.topcoder.util.errorhandling.BaseRuntimeException;

/**
 * <p>Tests <code>initCause</code>, constructors.</p>
 *
 * <p>Copyright &copy; 2003, TopCoder, Inc. All rights reserved.</p>
 *
 * @author Revoklaw
 * @version 1.0
 */
public class PrintingFailure extends TestCase {
    public void testPrintingBaseExceptionFailure(){
        BaseException be = new BaseException("Message", null);
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        be.printStackTrace(pw);
        checkStackTrace(sw.toString());
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        be.printStackTrace(ps);
        checkStackTrace(baos.toString());

        be = new BaseException("Message");
        sw = new StringWriter();
        pw = new PrintWriter(sw);
        be.printStackTrace(pw);
        checkStackTrace(sw.toString());
        baos = new ByteArrayOutputStream();
        ps = new PrintStream(baos);
        be.printStackTrace(ps);
        checkStackTrace(baos.toString());

        Throwable t = null;
        be = new BaseException(t);
        sw = new StringWriter();
        pw = new PrintWriter(sw);
        be.printStackTrace(pw);
        assertTrue(sw.toString().indexOf("Caused by:") == -1);
        baos = new ByteArrayOutputStream();
        ps = new PrintStream(baos);
        be.printStackTrace(ps);
        assertTrue(baos.toString().indexOf("Caused by:") == -1);

        be = new BaseException();
        sw = new StringWriter();
        pw = new PrintWriter(sw);
        be.printStackTrace(pw);
        assertTrue(sw.toString().indexOf("Caused by:") == -1);
        baos = new ByteArrayOutputStream();
        ps = new PrintStream(baos);
        be.printStackTrace(ps);
        assertTrue(baos.toString().indexOf("Caused by:") == -1);

        try{
          pw = null;
          be.printStackTrace(pw);
          fail("Should throw an exception on null PrintWriter");
        }
        catch(NullPointerException e){ }
        try{
          ps = null;
          be.printStackTrace(ps);
          fail("Should throw an exception on null PrintStream");
        }
        catch(NullPointerException e){ }
    }

    public void testPrintingBaseRuntimeExceptionFailure(){
        BaseRuntimeException bre = new BaseRuntimeException("Message", null);
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        bre.printStackTrace(pw);
        checkStackTrace(sw.toString());
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        bre.printStackTrace(ps);
        checkStackTrace(baos.toString());

        bre = new BaseRuntimeException("Message");
        sw = new StringWriter();
        pw = new PrintWriter(sw);
        bre.printStackTrace(pw);
        checkStackTrace(sw.toString());
        baos = new ByteArrayOutputStream();
        ps = new PrintStream(baos);
        bre.printStackTrace(ps);
        checkStackTrace(baos.toString());

        Throwable t = null;
        bre = new BaseRuntimeException(t);
        sw = new StringWriter();
        pw = new PrintWriter(sw);
        bre.printStackTrace(pw);
        assertTrue(sw.toString().indexOf("Caused by:") == -1);
        baos = new ByteArrayOutputStream();
        ps = new PrintStream(baos);
        bre.printStackTrace(ps);
        assertTrue(baos.toString().indexOf("Caused by:") == -1);

        bre = new BaseRuntimeException();
        sw = new StringWriter();
        pw = new PrintWriter(sw);
        bre.printStackTrace(pw);
        assertTrue(sw.toString().indexOf("Caused by:") == -1);
        baos = new ByteArrayOutputStream();
        ps = new PrintStream(baos);
        bre.printStackTrace(ps);
        assertTrue(baos.toString().indexOf("Caused by:") == -1);

        try{
          pw = null;
          bre.printStackTrace(pw);
          fail("Should throw an exception on null PrintWriter");
        }
        catch(NullPointerException e){ }
        try{
          ps = null;
          bre.printStackTrace(ps);
          fail("Should throw an exception on null PrintStream");
        }
        catch(NullPointerException e){ }
    }

    public void testPrintingBaseErrorFailure(){
        BaseError be = new BaseError("Message", null);
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        be.printStackTrace(pw);
        checkStackTrace(sw.toString());
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        be.printStackTrace(ps);
        checkStackTrace(baos.toString());

        be = new BaseError("Message");
        sw = new StringWriter();
        pw = new PrintWriter(sw);
        be.printStackTrace(pw);
        checkStackTrace(sw.toString());
        baos = new ByteArrayOutputStream();
        ps = new PrintStream(baos);
        be.printStackTrace(ps);
        checkStackTrace(baos.toString());

        Throwable t = null;
        be = new BaseError(t);
        sw = new StringWriter();
        pw = new PrintWriter(sw);
        be.printStackTrace(pw);
        assertTrue(sw.toString().indexOf("Caused by:") == -1);
        baos = new ByteArrayOutputStream();
        ps = new PrintStream(baos);
        be.printStackTrace(ps);
        assertTrue(baos.toString().indexOf("Caused by:") == -1);

        be = new BaseError();
        sw = new StringWriter();
        pw = new PrintWriter(sw);
        be.printStackTrace(pw);
        assertTrue(sw.toString().indexOf("Caused by:") == -1);
        baos = new ByteArrayOutputStream();
        ps = new PrintStream(baos);
        be.printStackTrace(ps);
        assertTrue(baos.toString().indexOf("Caused by:") == -1);

        try{
          pw = null;
          be.printStackTrace(pw);
          fail("Should throw an exception on null PrintWriter");
        }
        catch(NullPointerException e){ }
        try{
          ps = null;
          be.printStackTrace(ps);
          fail("Should throw an exception on null PrintStream");
        }
        catch(NullPointerException e){ }
    }

    private void checkStackTrace(String stackTrace) {
        assertTrue(stackTrace.indexOf("Message") >= 0);
        assertTrue(stackTrace.indexOf("Caused by:") == -1);
    }

    public static Test suite() {
        return new TestSuite(PrintingFailure.class);
    }
}
