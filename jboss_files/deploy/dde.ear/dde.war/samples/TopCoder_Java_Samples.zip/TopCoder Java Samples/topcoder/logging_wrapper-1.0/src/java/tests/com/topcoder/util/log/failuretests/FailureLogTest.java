/**
 * JUnit failure tests for methods in com.topcoder.util.log.Log.
 * 
 * @author heather
 * Copyright � 2002, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.log.failuretests;

import com.topcoder.util.log.Level;
import com.topcoder.util.log.Log;
import com.topcoder.util.log.LogException;
import com.topcoder.util.log.LogFactory;
import com.topcoder.util.log.functionaltests.LogTest;

public class FailureLogTest extends LogTest {

    public FailureLogTest(String s) {
        super(s);
    }

    /**
     * tests Log.isEnabled with null argument.
     */
    public void testIsEnabled_Null() {
        try {
            Log enabledLog = LogFactory.getInstance().getLog("enabledLog");

            try {
                enabledLog.isEnabled(null);
                fail("Expected LogException");
            } catch (LogException ignore) {}

        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * tests Log.log with two null arguments
     */
    public void testLog_NullNull() {
        try {
            Log enabledLog = LogFactory.getInstance().getLog("enabledLog");

            try {
                enabledLog.log(null, null);
                fail("Expected LogException");
            } catch (LogException ignore) {}
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * tests Log.log with a null Level and a valid message
     */
    public void testLog_NullValid() {
        try {
            Log enabledLog = LogFactory.getInstance().getLog("enabledLog");

            if (!(enabledLog instanceof com.topcoder.util.log.basic.BasicLog)) {
                try {
                    enabledLog.log(null, new String("some message"));
                    fail("Expected LogException");
                } catch (LogException ignore) {}
            }
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

    /**
     * tests Log.log with a valid Level and a null message
     */
    public void testLog_ValidNull() {
        try {
            Log enabledLog = LogFactory.getInstance().getLog("enabledLog");

            try {
                enabledLog.log(Level.TRACE, null);
                fail("Expected LogException");
            } catch (LogException ignore) {}
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }

}
