/**
 * JUnit failure tests for methods in com.topcoder.util.log.LogFactory.
 * 
 * @author heather
 * Copyright � 2002, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.log.failuretests;

import com.topcoder.util.config.ConfigManagerException;
import com.topcoder.util.log.LogException;
import com.topcoder.util.log.LogFactory;
import com.topcoder.util.log.functionaltests.LogTest;

public class FailureLogFactoryTest extends LogTest {
   
    public FailureLogFactoryTest(String s) {
        super(s);
    }

    /**
     * tests LogFactory.getAttribute with null argument.
     */
    public void testGetAttribute_Null() 
        throws ConfigManagerException, LogException {
        LogFactory lf = LogFactory.getInstance();
        try {
            LogFactory.getAttribute(null);
//            fail("Expected LogException");    -- This should be ConfigManagerException
            fail("Expected ConfigManagerException");
        } catch (Exception e) {
//            if (!(e instanceof LogException)) {   -- This should be ConfigManagerException
            if (!(e instanceof ConfigManagerException)) {
                fail("Expected LogException");
            }
        }
    }

    /**
     * tests LogFactory.getAttribute with a String argument that is an invalid
     * attribute.  I'm assuming that a null return is the expected behavior.
     */
    public void testGetAttribute_InvalidAttribute() throws ConfigManagerException, LogException {
        LogFactory lf = LogFactory.getInstance();
        String s = LogFactory.getAttribute(new String(""));
        assertEquals("Doesn't handle invalid attribute", s, null);
    }

    /**
     * test LogFactory getLog with null argument.
     */
    public void testGetLog_Null() throws LogException {
        LogFactory lf = LogFactory.getInstance();
        try {
            lf.getLog(null);
            fail("Expected LogException");
        } catch (Exception e) {
            if (!(e instanceof LogException)) {
                fail("Expected LogException");
            }
        }
    }

    /**
     * tests that only one instance of LogFactory can exist at a time
     */
    public void testCreateInstance_MultipleCalls() throws ClassNotFoundException,
                                                          IllegalAccessException,
                                                          InstantiationException,
                                                          LogException, 
                                                          ConfigManagerException {
        LogFactory lf1 = LogFactory.createInstance();
        LogFactory lf2 = LogFactory.createInstance();
        assertEquals("Multiple instances of LogFactory, test 1", LogFactory.getInstance(), lf1);
        assertEquals("Multiple instances of LogFactory, test 2", LogFactory.getInstance(), lf2);
        assertEquals("Multiple instances of LogFactory, test 3", lf1, lf2);
        
    }
}
