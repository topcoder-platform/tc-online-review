package com.topcoder.util.cache.stresstests;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.topcoder.util.cache.*;
/**
 * StressTests.java
 *
 * @author dpozdol
 * @version 1.0
 */
public class StressTests extends TestCase {

    /**
     * tests a large cache size
     */
    public void testGetBigCache() {

        SimpleCache cache = new SimpleCache();

        cache.put("foo1", "bar1");

        for (int i = 0; i < 10000; i ++)
          cache.put(""+i, ""+i);

        assertEquals("Cache should return objects that are added",
                     "bar1",
                     cache.get("foo1"));

        assertNull("Cache should return null for non-existent keys",
                   cache.get("foo2"));

    }

    /**
     * tests a large time out limit
     */
    public void testBigLimit() {
        SimpleCache cache =
            new SimpleCache(10000, SimpleCache.NO_TIMEOUT, new FIFOCacheEvictionStrategy());
        cache.put("foo1", "bar1");

        for (int i = 0; i < 9999; i ++)
          cache.put(""+i, ""+i);

        assertEquals("Cache should return objects that are added",
                     "bar1",
                     cache.get("foo1"));

        cache.put("foo3", "bar3");

        assertNull("Cache should evict objects in FIFO order by default",
                   cache.get("foo1"));
    }

    /**
     * tests the remove function against a large cache
     */
    public void testBigRemove() {
        SimpleCache cache = new SimpleCache();
        cache.put("foo1", "bar1");

        for (int i = 0; i < 9999; i ++)
          cache.put(""+i, ""+i);

        assertEquals("Cache should return objects that are added",
                     "bar1",
                     cache.get("foo1"));

        for (int i = 0; i < 9999; i ++)
          cache.remove(""+i);

        assertEquals("Cache should return objects that are added",
                     "bar1",
                     cache.get("foo1"));

    }

    /**
     * runs the tests 
     */
    public static Test suite() {
        return new TestSuite(StressTests.class);
    }
}
