package com.topcoder.util.collection.priority.accuracytests;

import com.topcoder.util.collection.priority.TreePriorityQueue;
import junit.framework.TestSuite;
import junit.framework.Test;

/**
 * ArrayPriorityQueue test cases.  Functionality in PriorityQueueTest.
 * 
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 * @author msuhocki
 * @version 1.0
 */
public class TreePriorityQueueTest extends PriorityQueueTest {

    /**
     * instantiate PriorityQueue instance 
     */
    public void setUp() {
        queue = new TreePriorityQueue();
    }

    /**
     * Tests TreePriorityQueue constructor.
     */
    public void testArrayPriorityQueue() {
        TreePriorityQueue queue1;
        
        queue = new TreePriorityQueue();
        assertTrue(queue.isEmpty());
        
        queue.addAll(lists[0]);
        
        queue1 = new TreePriorityQueue(queue);
        assertEquals(queue, queue1);
        
        queue1 = new TreePriorityQueue(queue);
        assertEquals(queue, queue1);
    }
    
    public static Test suite() {
        return new TestSuite(TreePriorityQueueTest.class);
    }
}
