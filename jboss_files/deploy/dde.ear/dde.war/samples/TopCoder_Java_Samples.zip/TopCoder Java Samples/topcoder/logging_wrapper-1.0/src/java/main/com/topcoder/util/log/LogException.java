package com.topcoder.util.log;

/**
 * Exception class for all logging exceptions thrown from this API. It provides
 * the ability to reference the underlying exception via the <tt>getException</tt>
 * method.
 * 
 * @author StinkyCheeseMan
 * @version 1.0
 */
public class LogException extends Exception
{
    private Throwable throwable; // represents the nested exception

	/**
	 * Constructor takes a <tt>throwable</tt> as the underlying exception.
	 * 
	 * @param throwable The underlying exception.
	 */
    public LogException(Throwable throwable)
    {
        super();
        this.throwable = throwable;
    }

	/**
	 * Accessor for the underlying exception.
	 * 
	 * @return Throwable - The nested exception.
	 */
    public Throwable getException()
    {
        return throwable;
    }
}