/*
 * JUnit test case for simple logging functions.
 * @author ttsuchi
 */
package com.topcoder.util.log.functionaltests;

import com.topcoder.util.log.Level;
import com.topcoder.util.log.Log;
import com.topcoder.util.log.LogException;
import com.topcoder.util.log.LogFactory;

public class SimpleTest extends LogTest {
    public SimpleTest(String s) {
        super(s);
    }

    /*
     * tests LogFactory.log(int, String)
     */
    public void testSimpleLog() {
        String message = "This is a test";
        try {
            Log simpleLog = LogFactory.getInstance().getLog("simpleLog");
            if (!(simpleLog instanceof com.topcoder.util.log.basic.BasicLog)) {
                simpleLog.log(Level.ALL, message);
                assertTrue(compareLogResult(message));
            }
        }
        catch(LogException le) {
            fail(le.getException().getMessage());
        }
        catch(Exception e) {
            fail(e.getMessage());
        }
    }

}
