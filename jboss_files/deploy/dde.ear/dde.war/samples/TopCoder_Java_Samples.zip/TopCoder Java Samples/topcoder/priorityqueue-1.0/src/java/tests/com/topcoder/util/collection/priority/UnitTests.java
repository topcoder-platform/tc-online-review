/**
 * Copyright � 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * This test case aggregates all Unit test cases.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 */
public class UnitTests extends TestCase {
    /**
     * A suite of unit tests.
     *
     * @return a suite of unit tests.
     */
    public static Test suite() {
        final TestSuite suite = new TestSuite();
        suite.addTest(ArrayPriorityQueueTests.suite());
        suite.addTest(HashPriorityQueueTests.suite());
        suite.addTest(LinkedPriorityQueueTests.suite());
        suite.addTest(SynchronizedPriorityQueueTests.suite());
        suite.addTest(TreePriorityQueueTests.suite());
        suite.addTest(UnmodifiablePriorityQueueTests.suite());

        return suite;
    }
}
