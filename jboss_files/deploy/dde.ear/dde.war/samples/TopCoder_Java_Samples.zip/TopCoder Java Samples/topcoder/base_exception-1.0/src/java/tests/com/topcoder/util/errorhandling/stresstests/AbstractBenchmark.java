package com.topcoder.util.errorhandling.stresstests;

import junit.framework.TestCase;

/**
 * Abstract benchmark class containing code to run a benchmark mulitple times
 * and compute basic statistics (min, max, mean, std. deviation). Subclasses
 * should implement the {@link #runOnce runOnce} method and call {@link
 * #runBenchmark runBenchmark} from a method that will be executed by JUnit.
 *
 * @author RachaelLCook 
 * @author TopCoder Software
 * @version 1.0
 */

public abstract class AbstractBenchmark extends TestCase {
    /**
     * Creates a new <code>AbstractBenchmark</code> instance.
     *
     * @param testName
     *    the name of the benchmark test
     */
    protected AbstractBenchmark(final String testName) {
        super(testName);
    }

    /**
     * Executes a single instance of the benchmark.
     * 
     * @exception Exception thrown when an unexpected exception occurs
     */
    protected abstract void runOnce() throws Exception;

    /**
     * Executes the {@link #runOnce runOnce} method a specified number of 
     * times and computes some basic statistics (min, max, mean,
     * std. deviation) based on the timing of each invocation. The statistics
     * are written to standard error.    
     *
     * @param iters
     *    the number of iterations to execute
     * @param what
     *    a description of the benchmark for display purposes
     * @exception Exception thrown when an unexpected exception occurs
     */
    protected void runBenchmark(final int iters, final String what) 
        throws Exception {
        final long[] times = new long[iters];

        // execute the thruput test iters times
        long sum = 0;
        long min = Long.MAX_VALUE;
        long max = -1;
        System.err.println("<starting " + what + " benchmark>");
        for (int i = 0; i < iters; ++i) {
            final long start = System.currentTimeMillis();
            runOnce();
            times[i] = System.currentTimeMillis() - start; 
            sum += times[i];
            min = Math.min(min, times[i]);
            max = Math.max(max, times[i]);
        }
      
        // compute the average and standard deviation
        double mean = ((double) sum) / iters;
        double totalDiff = 0.0;
        for (int i = 0; i < iters; ++i) {
            double diff = mean - times[i];
            totalDiff += diff * diff;
        }
        double stdDev = Math.sqrt(totalDiff / (iters - 1));
        System.err.println
            ("[" + what + ": iters=" + iters + " min=" + min + " max=" + max 
             + " mean=" + mean + " stddev=" + stdDev + "]");
    }
}
