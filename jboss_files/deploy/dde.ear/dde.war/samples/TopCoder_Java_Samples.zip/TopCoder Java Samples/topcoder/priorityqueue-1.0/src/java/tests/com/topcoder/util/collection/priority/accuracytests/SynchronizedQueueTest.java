package com.topcoder.util.collection.priority.accuracytests;

import com.topcoder.util.collection.priority.LinkedPriorityQueue;
import com.topcoder.util.collection.priority.PriorityQueue;
import com.topcoder.util.collection.priority.PriorityQueues;
import junit.framework.TestSuite;
import junit.framework.Test;

/**
 * Tests the SynchronizedQueue returned by PriorityQueues.synchronizedPriorityQueue(Object)
 * 
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 * @author msuhocki
 * @version 1.0
 */
public class SynchronizedQueueTest extends PriorityQueueTest {
    
    /**
     * instantiate PriorityQueue instance 
     */
    public void setUp() {
        PriorityQueue queue1 = new LinkedPriorityQueue();
        queue = PriorityQueues.synchronizedPriorityQueue(queue1);
    }
    
    public static Test suite() {
        return new TestSuite(SynchronizedQueueTest.class);
    }
}
