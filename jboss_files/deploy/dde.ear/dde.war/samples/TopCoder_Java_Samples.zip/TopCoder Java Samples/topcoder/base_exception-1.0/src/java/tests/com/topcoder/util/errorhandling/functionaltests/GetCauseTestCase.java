package com.topcoder.util.errorhandling.functionaltests;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.topcoder.util.errorhandling.BaseError;
import com.topcoder.util.errorhandling.BaseException;
import com.topcoder.util.errorhandling.BaseRuntimeException;
import com.topcoder.util.errorhandling.CauseUtils;

/**
 * <p>Tests <code>initCause(), <code>getCause()</code>, and
 * <code>CauseUtils</code>.</p>
 *
 * <p>Copyright &copy; 2003, TopCoder, Inc. All rights reserved.</p>
 *
 * @author TCSDESIGNER
 * @version 1.0
 */
public class GetCauseTestCase extends TestCase {

    public void testSetBaseExceptionCause() {
        final Throwable cause = new Exception();
        BaseException be = new BaseException(cause);
        assertEquals("Cause should match the given cause",
                     cause,
                     be.getCause());

        be = new BaseException();
        final Throwable self = be.initCause(cause);
        assertSame("initCause should return self", be, self);
        assertEquals("Cause should match the given cause",
                     cause,
                     be.getCause());

        be = new BaseException();
        be.initCause(null);
        assertNull("Should be no cause", be.getCause());
    }

    public void testSetBaseRuntimeExceptionCause() {
        final Throwable cause = new Exception();
        BaseRuntimeException bre = new BaseRuntimeException(cause);
        assertEquals("Cause should match the given cause",
                     cause,
                     bre.getCause());

        bre = new BaseRuntimeException();
        final Throwable self = bre.initCause(cause);
        assertSame("initCause should return self", bre, self);
        assertEquals("Cause should match the given cause",
                     cause,
                     bre.getCause());

        bre = new BaseRuntimeException();
        bre.initCause(null);
        assertNull("Should be no cause", bre.getCause());
    }

    public void testSetBaseErrorCause() {
        final Throwable cause = new Exception();
        BaseError be = new BaseError(cause);
        assertEquals("Cause should match the given cause",
                     cause,
                     be.getCause());

        be = new BaseError();
        final Throwable self = be.initCause(cause);
        assertSame("initCause should return self", be, self);
        assertEquals("Cause should match the given cause",
                     cause,
                     be.getCause());

        be = new BaseError();
        be.initCause(null);
        assertNull("Should be no cause", be.getCause());
    }

    public void testCauseUtils() {
        final Throwable t1 = new Throwable();
        final Throwable t2 = new Throwable(t1);
        final BaseException be1 = new BaseException(t2);
        final BaseException be2 = new BaseException(be1);

        assertSame("CauseUtils should correctly extract cause",
                   be1, CauseUtils.getCause(be2));
        assertSame("CauseUtils should correctly extract cause",
                   t2, CauseUtils.getCause(be1));
        assertSame("CauseUtils should correctly extract cause",
                   t1, CauseUtils.getCause(t2));
    }

    public static Test suite() {
        return new TestSuite(GetCauseTestCase.class);
    }
}
