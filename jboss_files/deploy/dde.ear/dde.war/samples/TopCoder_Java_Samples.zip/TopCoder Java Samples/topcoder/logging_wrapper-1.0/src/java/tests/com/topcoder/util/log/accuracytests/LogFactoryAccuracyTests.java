/*
 * LogFactoryAccuracyTests.java
 */
package com.topcoder.util.log.accuracytests;

import com.topcoder.util.config.ConfigManagerException;
import com.topcoder.util.log.LogException;
import com.topcoder.util.log.LogFactory;
import com.topcoder.util.log.functionaltests.AbstractLoggingAccuracyTests;

import java.io.IOException;

public class LogFactoryAccuracyTests extends AbstractLoggingAccuracyTests {

    public LogFactoryAccuracyTests(String testName) {
        super(testName);
    }

    public void testGetInstance() throws LogException {
        LogFactory factory = LogFactory.getInstance();
        assertNotNull("The instance returned is null", factory);
    }

    public void testLoadConfiguration() throws ConfigManagerException,
            IOException {
        saveConfigFile("config.save");
        try {
            copyConfiguration("Logging.xml.test1");
            LogFactory.loadConfiguration();
            assertEquals("Did not obtain correct attribute;", "config1",
                    LogFactory.getAttribute("accuracyTest"));
            copyConfiguration("Logging.xml.test2");
            LogFactory.loadConfiguration();
            assertEquals("Did not obtain correct attribute;", "config2",
                    LogFactory.getAttribute("accuracyTest"));
        } finally {
            restoreConfigFile("config.save");
            LogFactory.loadConfiguration();
        }
    }

}
