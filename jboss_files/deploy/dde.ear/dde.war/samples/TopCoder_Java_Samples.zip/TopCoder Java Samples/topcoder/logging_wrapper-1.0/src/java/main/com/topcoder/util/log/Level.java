package com.topcoder.util.log;

/**
 * The Level class maintains the list of acceptable logging levels.
 *
 * @author StinkyCheeseMan
 * @version 1.0
 */
public final class Level
{
    // member field to indicate the value of this level
    private final int level;

    // constant values for all logging levels
    private static final int OFF_LEVEL = 0;
    private static final int FINEST_LEVEL = 100;
    private static final int TRACE_LEVEL = 200;
    private static final int DEBUG_LEVEL = 300;
    private static final int CONFIG_LEVEL = 400;
    private static final int INFO_LEVEL = 500;
    private static final int WARN_LEVEL = 600;
    private static final int ERROR_LEVEL = 700;
    private static final int FATAL_LEVEL = 800;
    private static final int ALL_LEVEL = 900;

    // public logging levels
    /** Indicates that all logging should be turned off. */
    public static final Level OFF = new Level(OFF_LEVEL);
    public static final Level FINEST = new Level(FINEST_LEVEL);
    public static final Level TRACE = new Level(TRACE_LEVEL);
    public static final Level DEBUG = new Level(DEBUG_LEVEL);
    public static final Level CONFIG = new Level(CONFIG_LEVEL);
    public static final Level INFO = new Level(INFO_LEVEL);
    public static final Level WARN = new Level(WARN_LEVEL);
    public static final Level ERROR = new Level(ERROR_LEVEL);
    public static final Level FATAL = new Level(FATAL_LEVEL);
    /** Indicates that all levels should be logged. */
    public static final Level ALL = new Level(ALL_LEVEL);

    /**
     * Contructor is private to prevent instantiation outside of the class.
     *
     * @param level The value of this logging level.
     */
    private Level(int level)
    {
        this.level = level;
    }

    /**
     * This method returns the integer representation of the level.
     *
     * @return level - The integer representation of the level
     */
    public final int intValue()
    {
        return level;
    }

    /**
     * Override the equals method to allow Level objects to be compared for equality.
     *
     * @param level The level object to be compared to this object for equality.
     *
     * @return boolean - true if the Level objects are equal; false otherwise
     */
    public final boolean equals(Object level)
    {
        if (level == this)
            return true;

        if (!(level instanceof Level))
            return false;

        Level comparisonLevel = (Level) level;

        if (comparisonLevel.intValue() == this.level)
            return true;

        return false;
    }

    /**
     * Override the toString method to return a human-readable representation of
     * the Level object.
     *
     * @return String - human-readable representation of the Level
     */
    public final String toString()
    {
        if (this.equals(OFF))
            return "OFF";
        else if (this.equals(FINEST))
            return "FINEST";
        else if (this.equals(TRACE))
            return "TRACE";
        else if (this.equals(DEBUG))
            return "DEBUG";
        else if (this.equals(CONFIG))
            return "CONFIG";
        else if (this.equals(INFO))
            return "INFO";
        else if (this.equals(WARN))
            return "WARN";
        else if (this.equals(ERROR))
            return "ERROR";
        else if (this.equals(FATAL))
            return "FATAL";
        else if (this.equals(ALL))
            return "ALL";
        else
            return null;
    }
}