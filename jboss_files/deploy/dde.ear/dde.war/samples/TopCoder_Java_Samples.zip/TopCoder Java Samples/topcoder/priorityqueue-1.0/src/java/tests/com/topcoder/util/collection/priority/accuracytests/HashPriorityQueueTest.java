package com.topcoder.util.collection.priority.accuracytests;

import com.topcoder.util.collection.priority.HashPriorityQueue;
import junit.framework.TestSuite;
import junit.framework.Test;

/**
 * HashPriorityQueue test cases.  Functionality in PriorityQueueTest.
 * 
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 * @author msuhocki
 * @version 1.0
 */
public class HashPriorityQueueTest extends PriorityQueueTest {

    /**
     * instantiate PriorityQueue instance 
     */
    public void setUp() {
        queue = new HashPriorityQueue();
    }
    
    /**
     * Tests HashPriorityQueue constructor.
     */
    public void testArrayPriorityQueue() {
        HashPriorityQueue queue1;
        
        queue = new HashPriorityQueue();
        assertTrue(queue.isEmpty());
        
        queue = new HashPriorityQueue(100);
        assertTrue(queue.isEmpty());
        
        queue = new HashPriorityQueue(100, 10);
        assertTrue(queue.isEmpty());
        
        queue.addAll(lists[0]);
        
        queue1 = new HashPriorityQueue(queue);
        assertEquals(queue, queue1);
        
        queue1 = new HashPriorityQueue(queue);
        assertEquals(queue, queue1);
    }
    
    public static Test suite() {
        return new TestSuite(HashPriorityQueueTest.class);
    }
}
