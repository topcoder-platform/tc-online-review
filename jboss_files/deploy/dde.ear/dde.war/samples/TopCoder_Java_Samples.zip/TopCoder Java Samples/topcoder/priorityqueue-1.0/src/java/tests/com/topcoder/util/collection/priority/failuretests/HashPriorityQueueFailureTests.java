/*
 * @(#)HashPriorityQueueFailureTestCase.java     1.0 Aug 18, 2003
 * 
 * Copyright � 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority.failuretests;

import java.util.Collection;

import junit.framework.TestSuite;

import com.topcoder.util.collection.priority.HashPriorityQueue;

/**
 * Failure tests for the class <code>HashPriorityQueue</code>. 
 * 
 * @version 1.0
 * @author MPhk
 */
public class HashPriorityQueueFailureTests extends PriorityQueueFailureTests {
    /**
     * Returns the test suite containing the methods of this class 
     * 
     * @return a TestSuite
     */
    public static TestSuite suite() {
        TestSuite suite = new TestSuite(HashPriorityQueueFailureTests.class);
        suite.setName("Hash " + NAME);
        return suite;
    }
    
    /* (non-Javadoc)
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        nullQueue = (HashPriorityQueue)null;
        emptyQueue = new HashPriorityQueue();
        assertNotNull(emptyQueue);
        nonEmptyQueue = new HashPriorityQueue();
        assertNotNull(nonEmptyQueue);
        nonEmptyQueue.add(new String("Object"));
    }

    /**
     * Tests the constructor with parameter <code>int</code> of 
     * <code>HashPriorityQueue</code> for illegal argument (<0). The 
     * constructor should throw a <code>NullPointerException</code>.
     * Test must pass.
     */
    public void testConstructor1() {
        try {
            nullQueue = new HashPriorityQueue(INVALID_SIZE);
            fail("Should throw an IllegalArgumentException!");
        } catch (IllegalArgumentException iae) {
            // expected exception
        }
        assertEquals(nullQueue, null);
    }
    
    /**
     * Tests the constructor with parameter <code>Collection</code> of 
     * <code>HashPriorityQueue</code> for illegal argument (null). The 
     * constructor should throw a <code>NullPointerException</code>.
     * Test must pass.
     */
    public void testConstructor2() {
        try {
            nullQueue = new HashPriorityQueue((Collection)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
        assertEquals(nullQueue, null);
    }    

    /**
     * Tests the constructor with parameter <code>HashPriorityQueue</code> of 
     * <code>HashPriorityQueue</code> for illegal argument (null). The 
     * constructor should throw a <code>NullPointerException</code>.
     * Test must pass.
     */
    public void testConstructor3() {
        try {
            nullQueue = new HashPriorityQueue((HashPriorityQueue)null);
            fail("Should throw a NullPointerException!");
        } catch (NullPointerException npe) {
            // expected exception
        }
        assertEquals(nullQueue, null);
    }

    /**
     * Tests the constructor with parameters <code>int</code> and <code>int
     * </code> of <code>HashPriorityQueue</code> for illegal argument 
     * (loadFactor < 0). The constructor should throw a  
     * <code>NullPointerException</code>.
     * Test must pass.
     */
    public void testConstructor4() {
        try {
            nullQueue = new HashPriorityQueue(1, INVALID_SIZE);
            fail("Should throw an IllegalArgumentException!");
        } catch (IllegalArgumentException iae) {
            // expected exception
        }
        assertEquals(nullQueue, null);
    }

    /**
     * Tests the constructor with parameters <code>int</code> and <code>int
     * </code> of <code>HashPriorityQueue</code> for illegal argument 
     * (initialCapacity < 0). The constructor should throw a  
     * <code>NullPointerException</code>.
     * Test must pass.
     */
    public void testConstructor5() {
        try {
            nullQueue = new HashPriorityQueue(INVALID_SIZE, 0.2f);
            fail("Should throw an IllegalArgumentException!");
        } catch (IllegalArgumentException iae) {
            // expected exception
        }
        assertEquals(nullQueue, null);
    }
}
