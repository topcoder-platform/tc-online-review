/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;


/**
 * Tests which should apply to all priority queue implementations.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
public class PriorityQueueTests extends TestCase {

    /** A queue to test against, of the appropriate derived variety. */
    protected PriorityQueue queue = null;

    /** Add enqueues new items at the default priority level. */
    public void testAdd1() {
        for (int i = 0; i < 5; ++i) {
            queue.add(new Integer(i));
        }
        assertEquals(5, queue.size());

        // insertion order is preserved for items at the same priority level
        Object[] array = queue.toArray();
        for (int i = 0; i < 5; ++i) {
            assertEquals(i, ((Integer) array[i]).intValue());
        }
    }

    /** Add enqueues new items at the default priority level. */
    public void testAdd2() {
        for (int i = 0; i < 5; ++i) {
            queue.add(new Integer(i));
        }
        assertEquals(5, queue.size());
        
        // an item at a higher priority level inserts at the front of the queue
        queue.enqueue(new Integer(5), 1);
        assertEquals(6, queue.size());
        assertEquals(5, ((Integer) queue.peek()).intValue());
    }

    /** AddAll enqueues multiple items at the default priority level. */
    public void testAddAll1() {
        // addAll requires a valid collection argument
        try {
            queue.addAll(null);
            fail();
        } catch (NullPointerException e) {
        }
    }

    /** AddAll enqueues multiple items at the default priority level. */
    public void testAddAll2() {
        // collection order is preserved
        Collection collection = new ArrayList();
        for (int i = 0; i < 5; ++i) {
            collection.add(new Integer(i));
        }

        queue.addAll(collection);
        assertEquals(5, queue.size());

        Object[] arr1 = queue.toArray();
        Object[] arr2 = collection.toArray();
        for (int i = 0; i < 5; ++i) {
            assertEquals(arr1[i], arr2[i]);
        }
    }

    /** Contains checks for the presence of an object */
    public void testContains1() {
        for (int i = 0; i < 5; ++i) {
            queue.add(new Integer(i));
        }

        // items that haven't been added are not contained
        assertFalse(queue.contains(new Integer(5)));
    }

    /** Contains checks for the presence of an object */
    public void testContains2() {
        for (int i = 0; i < 5; ++i) {
            queue.add(new Integer(i));
        }

        // items that have been added are contained
        for (int i = 0; i < 5; ++i) {
            assertTrue(queue.contains(new Integer(i)));
        }
    }

    /** Contains checks for the presence of an object */
    public void testContains3() {
        for (int i = 0; i < 5; ++i) {
            queue.add(new Integer(i));
        }

        // items that have been removed are no longer contained
        queue.dequeue();
        assertFalse(queue.contains(new Integer(0)));
    }

    /** ContainsAll checks for the presense of a collection of objects. */
    public void testContainsAll1() {
        try {
            queue.containsAll(null);
            fail();
        } catch (NullPointerException e) {
        }
    }

    /** ContainsAll checks for the presense of a collection of objects. */
    public void testContainsAll2() {
        Collection collection = new ArrayList();
        for (int i = 0; i < 5; ++i) {
            collection.add(new Integer(i));
        }

        // does not contain items before they are added
        assertFalse(queue.containsAll(collection));
    }

    /** ContainsAll checks for the presense of a collection of objects. */
    public void testContainsAll3() {
        Collection collection = new ArrayList();
        for (int i = 0; i < 5; ++i) {
            collection.add(new Integer(i));
        }

        // does contain items after they are added
        queue.addAll(collection);
        assertTrue(queue.containsAll(collection));
    }

    /** ContainsAll checks for the presense of a collection of objects. */
    public void testContainsAll4() {
        Collection collection = new ArrayList();
        for (int i = 0; i < 5; ++i) {
            collection.add(new Integer(i));
        }
        queue.addAll(collection);

        // does not contain items that haven't been added to the queue
        collection.add(new Integer(5));
        assertFalse(queue.containsAll(collection));
    }

    /** Verify behavior of dequeue. */
    public void testDequeue1() {
        // can't dequeue an empty queue
        try {
            assertTrue(queue.isEmpty());
            queue.dequeue();
            fail();
        } catch (IllegalStateException e) {
        }
    }

    /** Verify behavior of dequeue. */
    public void testDequeue2() {
        // dequeue removes its object from the queue
        Object object = new Integer(1);
        queue.add(object);
        assertFalse(queue.isEmpty());
        assertEquals(object, queue.dequeue());
        assertTrue(queue.isEmpty());
    }

    /** Verify behavior of dequeue. */
    public void testDequeue3() {
        // dequeue removes objects in order of priority
        for (int i = 0; i < 5; ++i) {
            queue.enqueue(new Integer(i), i);
        }
        assertEquals(5, queue.size());

        for (int i = 4; i >= 0; --i) {
            assertEquals(new Integer(i), queue.dequeue());
        }
        assertEquals(0, queue.size());
    }

    /** Verify behavior of enqueue. */
    public void testEnqueue() {
        // items are ordered by priority, by insertion order within priority
        for (int i = 0; i < 5; ++i) {
            queue.enqueue(new Integer(i), i / 2);
        }
        assertEquals(5, queue.size());

        int[] ordered = { 4, 2, 3, 0, 1 };
        for (int i = 0; i < 5; ++i) {
            assertEquals(new Integer(ordered[i]), queue.dequeue());
        }
        assertEquals(0, queue.size());
    }

    /** Verify behavior of enqueueAll. */
    public void testEnqueueAll1() {
        // requires a valid collection argument
        try {
            queue.enqueueAll(null, 0);
            fail();
        } catch (NullPointerException e) {
        }
    }

    /** Verify behavior of enqueueAll. */
    public void testEnqueueAll2() {
        // collection order is preserved
        Collection collection = new ArrayList();
        for (int i = 0; i < 5; ++i) {
            collection.add(new Integer(i));
        }

        queue.enqueueAll(collection, -500);
        assertEquals(5, queue.size());

        Object[] arr1 = queue.toArray();
        Object[] arr2 = collection.toArray();
        for (int i = 0; i < 5; ++i) {
            assertEquals(arr1[i], arr2[i]);
        }
    }

    /** Priority queues can be equal regardless of concrete implementation. */
    public void testEquals1() {
        // a queue is equal to its copy
        PriorityQueue other = new ArrayPriorityQueue(queue);
        assertEquals(queue, other);
    }

    /** Priority queues can be equal regardless of concrete implementation. */
    public void testEquals2() {
        // unless one contains items the other doesn't
        PriorityQueue other = new ArrayPriorityQueue(queue);
        queue.add(new Integer(5));
        assertFalse(queue.equals(other));

        other.add(new Integer(5));
        assertEquals(queue, other);
    }

    /** Priority queues can be equal regardless of concrete implementation. */
    public void testEquals3() {
        // not equal if objects are in a different order
        PriorityQueue other = new ArrayPriorityQueue(queue);
        queue.enqueue(new Integer(1), 1);
        queue.enqueue(new Integer(5), 5);
        other.enqueue(new Integer(1), 5);
        other.enqueue(new Integer(5), 1);
        assertFalse(queue.equals(other));
    }

    /** Queues that compare equal should return the same hash code. */
    public void testHashCode() {
        // a queue is equal to its copy
        PriorityQueue other = new ArrayPriorityQueue(queue);
        for (int i = 0; i < 5; ++i) {
            queue.enqueue(new Integer(i), i);
            other.enqueue(new Integer(i), i);
        }
        assertEquals(queue.hashCode(), other.hashCode());
    }

    /** iterator returns objects in same order as dequeue. */
    public void testIterator() {
        for (int i = 0; i < 5; ++i) {
            queue.enqueue(new Integer(i), i / 2);
        }
        assertEquals(5, queue.size());

        Iterator it = queue.iterator();
        int[] ordered = { 4, 2, 3, 0, 1 };
        for (int i = 0; i < 5; ++i) {
            assertTrue(it.hasNext());
            assertEquals(new Integer(ordered[i]), it.next());
        }
        assertEquals(5, queue.size());

        try {
            assertFalse(it.hasNext());
            it.next();
            fail();
        } catch (NoSuchElementException e) {
        }
    }

    /** Verify behavior of iterator's remove method. */
    public void testIteratorRemove() {
        for (int i = 0; i < 5; ++i) {
            queue.enqueue(new Integer(i), i);
        }
        assertEquals(5, queue.size());

        // can't remove items before starting iteration
        Iterator it = queue.iterator();
        try {
            it.remove();
            fail();
        } catch (IllegalStateException e) {
        }

        // ok to remove item once after viewing it
        for (int i = 4; i >= 0; --i) {
            assertTrue(it.hasNext());
            assertEquals(new Integer(i), it.next());
            it.remove();
            try {
                it.remove();
                fail();
            } catch (IllegalStateException e) {
            }
        }
        assertFalse(it.hasNext());

        // removing items in the iterator updates the queue
        assertTrue(queue.isEmpty());
    }

    /** Verify behavior of peek method. */
    public void testPeek1() {
        // can't look into an empty queue
        try {
            assertEquals(true, queue.isEmpty());
            queue.peek();
            fail();
        } catch (IllegalStateException e) {
        }
    }

    /** Verify behavior of peek method. */
    public void testPeek2() {
        // can peek multiple times - not destructive
        Object object = new Integer(1);
        queue.add(object);
        assertFalse(queue.isEmpty());
        assertEquals(object, queue.peek());
        assertEquals(object, queue.peek());

        queue.dequeue();
        assertTrue(queue.isEmpty());
    }

    /** Verify behavior of remove method. */
    public void testRemove() {
        for (int i = 0; i < 5; ++i) {
            queue.enqueue(new Integer(i), i / 2);
        }
        assertEquals(5, queue.size());

        queue.remove(new Integer(3));

        Iterator it = queue.iterator();
        int[] ordered = { 4, 2, 0, 1 };
        for (int i = 0; i < ordered.length; ++i) {
            assertTrue(it.hasNext());
            assertEquals(new Integer(ordered[i]), it.next());
        }
        assertEquals(ordered.length, queue.size());

        try {
            assertFalse(it.hasNext());
            it.next();
            fail();
        } catch (NoSuchElementException e) {
        }
    }

    /** Verify behavior of removeAll. */
    public void testRemoveAll1() {
        try {
            queue.removeAll(null);
        } catch (NullPointerException e) {
        }
    }
        
    /** Verify behavior of removeAll. */
    public void testRemoveAll2() {
        for (int i = 0; i < 5; ++i) {
            queue.enqueue(new Integer(i), i / 2);
        }
        assertEquals(5, queue.size());

        Collection collection = new ArrayList();
        collection.add(new Integer(3));
        collection.add(new Integer(4));

        queue.removeAll(collection);

        Iterator it = queue.iterator();
        int[] ordered = { 2, 0, 1 };
        for (int i = 0; i < ordered.length; ++i) {
            assertTrue(it.hasNext());
            assertEquals(new Integer(ordered[i]), it.next());
        }
        assertEquals(ordered.length, queue.size());

        try {
            assertFalse(it.hasNext());
            it.next();
            fail();
        } catch (NoSuchElementException e) {
        }
    }

    /** Verify behavior of retainAll method. */
    public void testRetainAll1() {
        try {
            queue.retainAll(null);
        } catch (NullPointerException e) {
        }
    }
        
    /** Verify behavior of retainAll method. */
    public void testRetainAll2() {
        for (int i = 0; i < 5; ++i) {
            queue.enqueue(new Integer(i), i / 2);
        }
        assertEquals(5, queue.size());

        Collection collection = new ArrayList();
        collection.add(new Integer(1));
        collection.add(new Integer(2));
        collection.add(new Integer(3));

        queue.retainAll(collection);

        Iterator it = queue.iterator();
        int[] ordered = { 2, 3, 1 };
        for (int i = 0; i < ordered.length; ++i) {
            assertTrue(it.hasNext());
            assertEquals(new Integer(ordered[i]), it.next());
        }
        assertEquals(ordered.length, queue.size());

        try {
            assertFalse(it.hasNext());
            it.next();
            fail();
        } catch (NoSuchElementException e) {
        }
    }

    /** Verify behavior of size method. */
    public void testSize() {
        assertEquals(0, queue.size());
        queue.add(new Integer(3));
        assertEquals(1, queue.size());
        queue.dequeue();
        assertEquals(0, queue.size());
    }
    
    /** Verify conversion to array. */
    public void testToArray1() {
        for (int i = 0; i < 5; ++i) {
            queue.add(new Integer(i));
        }
        Object[] arr1 = {
            new Integer(0),
            new Integer(1),
            new Integer(2),
            new Integer(3),
            new Integer(4)
        };
        Object[] arr2 = queue.toArray();
        for (int i = 0; i < 5; ++i) {
            assertEquals(arr1[i], arr2[i]);
        }
    }
    
    /** Verify conversion to array. */
    public void testToArray2() {
        for (int i = 0; i < 5; ++i) {
            queue.add(new Integer(i));
        }
        Object[] arr1 = {
            new Integer(0),
            new Integer(1),
            new Integer(2),
            new Integer(3),
            new Integer(4)
        };
        Object[] arr2 = queue.toArray(new Integer[5]);
        for (int i = 0; i < 5; ++i) {
            assertEquals(arr1[i], arr2[i]);
        }
    }
    
    /** Verify conversion to string. */
    public void testToString() {
        for (int i = 0; i < 5; ++i) {
            queue.add(new Integer(i));
        }
        assertEquals("[0, 1, 2, 3, 4]", queue.toString());
    }
}
