/*
 * @(#)CheckStackTraceTest.java
 *
 * Copyright (c) 2003, TopCoder, Inc. All rights reserved
 */

package com.topcoder.util.errorhandling;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.topcoder.util.errorhandling.BaseError;
import com.topcoder.util.errorhandling.BaseException;
import com.topcoder.util.errorhandling.BaseRuntimeException;

/**
 * Tests <code>BaseError</code>'s, <code>BaseException</code>'s and 
 * <code>BaseRuntimeException</code>'s <code>printStackTrace</code>.
 *
 * @author Sleeve
 * @version 1.0
 */
 
public class CheckStackTraceTest extends TestCase {

    /**
     * Checks to see that printStackTrace is throwing NullPointerExceptions
     * and printing out a stack trace for BaseRuntimeException
     */
    public void testBaseRuntimeExceptionStackTrace() {
        BaseRuntimeException b = new BaseRuntimeException();
        
        // throwing NullPointerExceptions?
        try {
            b.printStackTrace((PrintStream) null);
            fail("Should have thrown a NullPointerException (BRE)");
        } catch(NullPointerException npe) {
        }
        try {
            b.printStackTrace((PrintWriter) null);
            fail("Should have thrown a NullPointerException (BRE)");
        } catch(NullPointerException npe) {
        }
        
        // test the printStackTrace methods
        b = new BaseRuntimeException("test", null);
        final BaseRuntimeException b2 = new BaseRuntimeException("test2", b);

        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
        
        b2.printStackTrace(pw);
        checkStackTrace(sw.toString());

        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final PrintStream ps = new PrintStream(baos);
        
        b2.printStackTrace(ps);
        checkStackTrace(baos.toString());

        System.err.println("TESTING PURPOSES:");
        b2.printStackTrace();
    }
    
    /**
     * Checks to see that printStackTrace is throwing NullPointerExceptions
     * and printing out a stack trace for BaseException
     */
    public void testBaseExceptionStackTrace() {
        BaseException b = new BaseException();
        
        // throwing NullPointerExceptions?
        try {
            b.printStackTrace((PrintStream) null);
            fail("Should have thrown a NullPointerException (BEx)");
        } catch(NullPointerException npe) {
        }
        try {
            b.printStackTrace((PrintWriter) null);
            fail("Should have thrown a NullPointerException (BEx)");
        } catch(NullPointerException npe) {
        }
        
        // test the printStackTrace methods
        b = new BaseException("test", null);
        final BaseException b2 = new BaseException("test2", b);

        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
        
        b2.printStackTrace(pw);
        checkStackTrace(sw.toString());

        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final PrintStream ps = new PrintStream(baos);
        
        b2.printStackTrace(ps);
        checkStackTrace(baos.toString());

        System.err.println("TESTING PURPOSES:");
        b2.printStackTrace();
    }
    
    /**
     * Checks to see that printStackTrace is throwing NullPointerExceptions
     * and printing out a stack trace for BaseError
     */
    public void testBaseErrorStackTrace() {
        final Throwable cause = new Exception("cause");
        BaseError b = new BaseError();
        
        // throwing NullPointerExceptions?
        try {
            b.printStackTrace((PrintStream) null);
            fail("Should have thrown a NullPointerException (BE)");
        } catch(NullPointerException npe) {
        }
        try {
            b.printStackTrace((PrintWriter) null);
            fail("Should have thrown a NullPointerException (BE)");
        } catch(NullPointerException npe) {
        }
        
        // test the printStackTrace methods
        b = new BaseError("test", cause);
        final BaseError b2 = new BaseError("test2", b);

        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
        
        b2.printStackTrace(pw);
        checkStackTrace(sw.toString());

        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final PrintStream ps = new PrintStream(baos);
        
        b2.printStackTrace(ps);
        checkStackTrace(baos.toString());

        System.err.println("TESTING PURPOSES:");
        b2.printStackTrace();
    }
    
    private void checkStackTrace(final String stackTrace) {
        assertTrue("test", stackTrace.indexOf("test") >= 0);
        assertTrue("test2", stackTrace.indexOf("test2") >= 0);
        assertTrue("caused by", stackTrace.indexOf("Caused by:") >= 0);
    }
    
    public static Test suite() {
        return new TestSuite(CheckStackTraceTest.class);
    }
}