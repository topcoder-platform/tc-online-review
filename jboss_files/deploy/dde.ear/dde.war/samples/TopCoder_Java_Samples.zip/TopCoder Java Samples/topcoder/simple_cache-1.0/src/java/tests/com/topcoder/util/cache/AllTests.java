package com.topcoder.util.cache;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import com.topcoder.util.cache.accuracytests.AccuracyTests;
import com.topcoder.util.cache.failuretests.FailureTests;
import com.topcoder.util.cache.stresstests.StressTests;

/**
 * <p>This test case aggregates all Simple Cache test cases.</p>
 *
 * @author srowen
 * @version 1.0
 */
public class AllTests extends TestCase {

    /** 
     * runs all tests
     */
    public static Test suite() {
        TestSuite suite = new TestSuite();
        suite.addTest(CreateCacheTestCase.suite());
        suite.addTest(GetObjectFromCacheTestCase.suite());
        suite.addTest(PutObjectInCacheTestCase.suite());
        suite.addTest(ClearRemoveObjectFromCacheTestCase.suite());
        suite.addTest(ConcurrencyTestCase.suite());
        suite.addTest(CacheEvictionStrategyTestCase.suite());

        //accuracy tests
        suite.addTest(AccuracyTests.suite());
        
        //failure tests
        suite.addTest(FailureTests.suite());
        
        //stress tests
        suite.addTest(StressTests.suite());
        
        return suite;
    }
}
