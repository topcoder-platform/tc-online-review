/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import java.util.LinkedList;
import junit.framework.Test;
import junit.framework.TestSuite;


/**
 * Unit tests for array priority queue implementation.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
public class ArrayPriorityQueueTests extends PriorityQueueTests {
    /** Return a suite of tests. */
    public static Test suite() {
        return new TestSuite(ArrayPriorityQueueTests.class);
    }
    
    /** Create a queue for testing. */
    public void setUp() {
        queue = new ArrayPriorityQueue();
    }

    /** Verify behavior of ArrayPriorityQueue constructors. */
    public void testConstructors1() {
        ArrayPriorityQueue q1 = new ArrayPriorityQueue();
        assertEquals(0, q1.size());
    }

    /** Verify behavior of ArrayPriorityQueue constructors. */
    public void testConstructors2() {
        ArrayPriorityQueue q2 = new ArrayPriorityQueue(500);
        assertEquals(0, q2.size());
    }
    
    /** Verify behavior of ArrayPriorityQueue constructors. */
    public void testConstructors3() {
        ArrayPriorityQueue q3 = new ArrayPriorityQueue(0);
        assertEquals(0, q3.size());
    }

    /** Verify behavior of ArrayPriorityQueue constructors. */
    public void testConstructors4() {
        try {
            ArrayPriorityQueue q4 = new ArrayPriorityQueue(-1);
            fail();
        } catch (IllegalArgumentException e) {
        }
    }

    /** Verify behavior of ArrayPriorityQueue constructors. */
    public void testConstructors5() {
        ArrayPriorityQueue q5 = new ArrayPriorityQueue(new LinkedList());
        assertEquals(0, q5.size());
    }

    /** Verify behavior of ArrayPriorityQueue constructors. */
    public void testConstructors6() {
        ArrayPriorityQueue q1 = new ArrayPriorityQueue();
        ArrayPriorityQueue q6 = new ArrayPriorityQueue(q1);
        assertEquals(q6, q1);

    }

    /** Verify behavior of ArrayPriorityQueue constructors. */
    public void testConstructors7() {
        try {
            ArrayPriorityQueue q = new ArrayPriorityQueue(null);
            fail();
        } catch (NullPointerException e) {
        }
    }
    
    /**
     * Verify behavior of clone method.  A clone is a deep copy, so
     * that it is initial equal to the original, but can be modified
     * separately.
     */
    public void testClone() {
        for (int i = 0; i < 5; ++i) {
            queue.add(new Integer(i));
        }
        
        PriorityQueue other
            = (PriorityQueue) ((ArrayPriorityQueue) queue).clone();
        assertEquals(queue, other);
        
        other.dequeue();
        assertFalse(queue.equals(other));
    }
}
