/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import junit.framework.Test;
import junit.framework.TestSuite;


/**
 * Unit tests for linked list priority queue implementation.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
public class LinkedPriorityQueueTests extends PriorityQueueTests {
    /** Return a suite of tests. */
    public static Test suite() {
        return new TestSuite(LinkedPriorityQueueTests.class);
    }

    /** Create a queue for testing. */
    public void setUp() {
        queue = new LinkedPriorityQueue();
    }

    /** Verify behavior of LinkedPriorityQueue constructors. */
    public void testConstructors1() {
        LinkedPriorityQueue q = new LinkedPriorityQueue();
        assertEquals(0, q.size());
    }

    /** Verify behavior of LinkedPriorityQueue constructors. */
    public void testConstructors2() {
        try {
            LinkedPriorityQueue q = new LinkedPriorityQueue(null);
            fail();
        } catch (NullPointerException e) {
        }
    }

    /** Verify behavior of LinkedPriorityQueue constructors. */
    public void testConstructors3() {
        LinkedPriorityQueue q1 = new LinkedPriorityQueue();
        LinkedPriorityQueue q2 = new LinkedPriorityQueue(q1);
        assertEquals(q2, q1);
    }

    /**
     * Verify behavior of clone method.  A clone is a deep copy, so
     * that it is initial equal to the original, but can be modified
     * separately.
     */
    public void testClone() {
        for (int i = 0; i < 5; ++i) {
            queue.add(new Integer(i));
        }
        
        PriorityQueue other =
            (PriorityQueue) ((LinkedPriorityQueue) queue).clone();
        assertEquals(queue, other);
        
        other.dequeue();
        assertFalse(queue.equals(other));
    }
}
