package com.topcoder.util.cache;

/**
 * <p>Cache is, essentially, a Map-like interface.</p>
 *
 * <p>Copyright &copy 2002, TopCoder, Inc. All rights reserved</p>
 *
 * @author  WishingBone
 * @version 1.0
 */
public interface Cache {

    /** look up the for value with specified key in the cache
     * @param   key     the specified key
     * @return          value if found in cache, null otherwise
     * @throws  IllegalArgumentException    when key is null
     */
    Object get(Object key);

    /** put value with its key into the cache, if value is null,
     * it acts as if remove value with specified key from the cache
     * @param   key     the key for the value
     * @param   value   the value
     * @throws  IllegalArgumentException    when key is null
     */
    void put(Object key, Object value);

    /** remove value with specified key from the cache
     * @param   key     the specified key
     * @return          value if found in cache, null otherwise
     * @throws  IllegalArgumentException    when key is null
     */
    Object remove(Object key);

    /** clear the cache
     */
    void clear();

}
