/*
 * Superclass for all logging interface tests. Includes codes to set up and destroy testing environment.
 * @author ttsuchi
 */
package com.topcoder.util.log.functionaltests;

import junit.framework.TestCase;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;

public abstract class LogTest extends TestCase {
    /*
     * Loggers must be configured to output to "test.log" file in the current directory
     */
    private static File logFile = new File(System.getProperty("user.dir"),"test.log");


    /*
     * Location for configuration files
     */
    private static File configDir = new File(System.getProperty("user.dir"),"conf/com/topcoder/util/log");

    /*
     * Using alternate configuration file?
     */
    private boolean isUsingAlternate = false;

    public LogTest(String s) {
        super(s);
    }


    /*
     * Compare what's written to the log file to the parameter.
     * *NOTE* The logging implementation classes must be configured to write to the
     * "test.log" file where this test class is being run.
     *
     * This method returns true as long as the parameter appears in any line of the log file.
     */
    protected boolean compareLogResult(String parameter)
    throws IOException {
        try {
            BufferedReader in = new BufferedReader(new FileReader(logFile));
            for(String line = in.readLine(); line != null; line = in.readLine()) {
                for(int i=0; i<line.length(); ++i) if(line.startsWith(parameter,i)) return true;
            }
            return false;
        }
        catch(IOException e) {
            throw e;
        }
        finally {
            // Try deleting the file for each test case
            // Hope the log file is not locked ...
            if(logFile.exists() && logFile.isFile()) logFile.delete();
        }
    }

    /*
     * Use alternate configuration (logging.xml.2)
     */
    protected void useAlternateConfiguration()
    throws IOException {
        if(!isUsingAlternate) {
            new File(configDir, "Logging.xml").renameTo(new File(configDir, "Logging.xml.0"));
            new File(configDir, "Logging.xml.2").renameTo(new File(configDir, "Logging.xml"));
            isUsingAlternate = true;
        }
    }

    /*
     * Revert to original configuration
     */
    protected void useOriginalConfiguration()
    throws IOException {
        if(isUsingAlternate) {
            new File(configDir, "Logging.xml").renameTo(new File(configDir, "Logging.xml.2"));
            new File(configDir, "Logging.xml.0").renameTo(new File(configDir, "Logging.xml"));
            isUsingAlternate = false;
        }
    }

    /*
     * Clean the environment
     */
    protected void tearDown() throws Exception {
        if(logFile.exists() && logFile.isFile()) logFile.delete();
        useOriginalConfiguration();
    }
}
