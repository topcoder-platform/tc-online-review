/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.NoSuchElementException;


/**
 * Provides for common functionality between the implementations of
 * <code>HashPriorityQueue</code> and <code>TreePriorityQueue</code>.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
class MapPriorityQueue extends AbstractPriorityQueue {
    
    /** Map each priority value to a list of objects at that priority. */
    protected Map objects        = null;

    /** A list of unique priorities.  These are the keys to the objects map. */
    private ArrayList priorities = null;

    /**
     * The size of both objects and priorities is the number of
     * separate priority values, not the number of individual
     * objects. We could sum the size of all the lists in objects, but
     * it is easier and quicker to maintain a separate count.
     */
    private int numObjects = 0;

    /**
     * Creates new empty internal storage.
     */
    protected MapPriorityQueue() {
        priorities = new ArrayList();
    }

    /**
     * Creates new empty internal storage with given initial capacity.
     *
     * @param initialCapacity The initial capacity of internal storage
     *
     * @throws IllegalArgumentException if initialCapacity &lt; 0
     */
    protected MapPriorityQueue(int initialCapacity) {
        if (initialCapacity < 0) {
            throw new IllegalArgumentException();
        }
        priorities = new ArrayList(initialCapacity);
    }

    /**
     * Construct a copy of the queue, maintaining order and priority.
     *
     * @param queue a queue to duplicate
     *
     * @throws NullPointerException if queue is null
     */
    protected MapPriorityQueue(MapPriorityQueue queue) {
        if (null == queue) {
            throw new NullPointerException();
        }
        priorities = new ArrayList(queue.priorities);
        numObjects = queue.numObjects;
    }

    /**
     * Destructively returns the object currently at the head of the
     * queue.
     *
     * @return the next object at the highest priority level and
     * remove that object from the queue
     *
     * @throws IllegalStateException if the queue is empty
     *
     * @see peek
     */
    public Object dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException();
        }

        Integer priority = (Integer) priorities.get(priorities.size() - 1);
        LinkedList list = (LinkedList) objects.get(priority);
        Object object = list.removeFirst();

        if (list.isEmpty()) {
            objects.remove(priority);
            priorities.remove(priorities.size() - 1);
        }

        --numObjects;
        return object;
    }

    /**
     * Non-destructively (the queue is not modified) return the object
     * currently at the head of the queue.  This is the same object
     * that would be (desctructively) returned by
     * <code>dequeue</code>.
     *
     * @return the object currently at the head of the queue
     *
     * @throws IllegalStateException if the queue is empty
     *
     * @see dequeue
     */
    public Object peek() {
        if (isEmpty()) {
            throw new IllegalStateException();
        }

        Integer priority = (Integer) priorities.get(priorities.size() - 1);
        LinkedList list = (LinkedList) objects.get(priority);

        return list.getFirst();
    }

    /**
     * Inserts the given object into the queue at the specified
     * priority level.  Objects within the same priority level are
     * stored in a first-in first-out (FIFO) manner.  Mirroring the
     * Java Collection library, there is no concept of
     * &quot;fullness&quot;, with the rationale that memory will be
     * exhausted long before it happens.
     *
     * @param object The object to queue up
     * @param priority The priority level of the object
     *
     * @return true if the queue is modified
     */
    public boolean enqueue(Object object, int priority) {
        Integer intPriority = new Integer(priority);

        if (!objects.containsKey(intPriority)) {
            objects.put(intPriority, new LinkedList());

            int insertLocation = 0;
            for (; insertLocation < priorities.size(); ++insertLocation) {
                Integer currentPriority =
                    (Integer) priorities.get(insertLocation);
                if (currentPriority.intValue() >= priority) {
                    break;
                }
            }
            priorities.add(insertLocation, intPriority);
        }

        LinkedList list = (LinkedList) objects.get(intPriority);
        list.add(object);
        ++numObjects;

        return true;
    }

    /**
     * Construct an iterator for the priority queue.  The order of
     * iteration for priority queues is defined to be the queue's
     * priority order.  In other words, the iterator will return
     * objects in the same order they would be retrieved by
     * <code>dequeue</code>.
     *
     * @return an iterator over all the objects in the queue in priority order
     */
    public Iterator iterator() {
        return new Iterator() {
                // iterate through priority levels
                private int     priorityIterator = priorities.size();
                private Integer priority         = null;

                // iterate through items at a given priority level
                private LinkedList list           = null;
                private Iterator   objectIterator = null;

                // flag to prevent attempts to delete the same object twice
                private boolean removed = false;

                public boolean hasNext() {
                    // true while there are more objects at the current level
                    if ((null != objectIterator) && objectIterator.hasNext()) {
                        return true;
                    }

                    // also true if there are more priority levels
                    return priorityIterator > 0;
                }

                public Object next() {
                    // check preconditions
                    if (!hasNext()) {
                        throw new NoSuchElementException();
                    }

                    // it's a "new" object (to the user) and hasn't been removed
                    removed = false;

                    // step to the next object and return it
                    if ((null == objectIterator) || !objectIterator.hasNext()) {
                        --priorityIterator;
                        priority = (Integer) priorities.get(priorityIterator);
                        list = (LinkedList) objects.get(priority);
                        objectIterator = list.iterator();
                    }

                    return objectIterator.next();
                }

                public void remove() {
                    // ensure we've just returned a legal element
                    if (null == objectIterator) {
                        throw new IllegalStateException();
                    }

                    // ensure that we haven't already removed this element
                    if (removed) {
                        throw new IllegalStateException();
                    }

                    --numObjects;

                    // remove the object from the current priority level
                    objectIterator.remove();

                    // remove the current priority level if no more objects
                    if (list.isEmpty()) {
                        objects.remove(priority);
                        list = null;
                        objectIterator = null;
                        priorities.remove(priorityIterator);
                        --priorityIterator;

                        if (priorityIterator >= 0) {
                            priority = (Integer) priorities.get(priorityIterator);
                            list = (LinkedList) objects.get(priority);
                            objectIterator = list.iterator();
                        }
                    }

                    removed = true;
                }
            };
    }

    /**
     * Return the number of objects in the queue.
     *
     * @return the number of objects in the queue
     */
    public int size() {
        return numObjects;
    }
}
