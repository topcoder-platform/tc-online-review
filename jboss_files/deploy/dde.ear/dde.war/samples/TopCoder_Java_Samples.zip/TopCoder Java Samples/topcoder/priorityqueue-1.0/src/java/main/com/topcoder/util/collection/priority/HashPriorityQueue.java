/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import java.io.Serializable;

import java.util.Collection;
import java.util.HashMap;


/**
 * This implementation of PriorityQueue is backed by a HashMap. This
 * class provides on average O(1)-time, O(1)-data move for insertions
 * and O(1)-time, O(1)-data move for removals.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
public class HashPriorityQueue
    extends MapPriorityQueue implements Cloneable, Serializable {
    
    /**
     * Creates new empty internal storage.
     */
    public HashPriorityQueue() {
        objects = new HashMap();
    }

    /**
     * Creates new empty internal storage with given initial capacity.
     *
     * @param initialCapacity The initial capacity of internal storage
     *
     * @throws IllegalArgumentException if initialCapacity &lt; 0
     */
    public HashPriorityQueue(int initialCapacity) {
        super(initialCapacity);
        objects = new HashMap(initialCapacity);
    }
    
    /**
     * Creates new empty internal storage with given initial capacity
     * and load factor.
     *
     * @param initialCapacity The initial capacity of internal storage
     * @param loadFactor The load factor of the hash map
     *
     * @throws IllegalArgumentException if initialCapacity &lt; 0
     */
    public HashPriorityQueue(int initialCapacity, float loadFactor) {
        super(initialCapacity);
        objects = new HashMap(initialCapacity, loadFactor);
    }

    /**
     * Creates new internal storage and inserts all the objects in the
     * given collection at the default priority level.
     *
     * @param collection The collection of objects to add
     *
     * @throws NullPointerException if collection is null
     */
    public HashPriorityQueue(Collection collection) {
        this(collection.size());
        addAll(collection);
    }

    /**
     * Construct a copy of the queue, maintaining order and priority.
     *
     * @param queue a queue to copy
     *
     * @throws NullPointerException if queue is null
     */
    public HashPriorityQueue(HashPriorityQueue queue) {
        super(queue);
        objects = new HashMap(queue.objects);
    }

    /**
     * Return a deep copy of the queue.
     *
     * @return a deep copy of the queue.
     */
    public Object clone() {
        return new HashPriorityQueue(this);
    }
}
