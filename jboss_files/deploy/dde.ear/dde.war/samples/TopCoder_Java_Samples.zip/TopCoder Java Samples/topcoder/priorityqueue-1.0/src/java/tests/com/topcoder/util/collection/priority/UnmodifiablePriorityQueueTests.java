/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import java.util.Iterator;


/**
 * Unit tests for read-only priority queue wrapper class.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
public class UnmodifiablePriorityQueueTests extends TestCase {
    /**
     * Return a suite of tests.
     *
     * @return a suite of tests.
     */
    public static Test suite() {
        return new TestSuite(UnmodifiablePriorityQueueTests.class);
    }
    
    /** A simple queue for testing. */
    private PriorityQueue queue;
    
    /** Create a simple queue to test against. */
    public void setUp() {
        PriorityQueue q = new ArrayPriorityQueue();
        for (int i = 0; i < 5; ++i) {
            q.add(new Integer(i));
        }
        queue = PriorityQueues.unmodifiablePriorityQueue(q);
    }

    /** Verify creating of singleton queue. */
    public void testSingletonPriorityQueue() {
        PriorityQueue q =
            PriorityQueues.singletonPriorityQueue(new Integer(1));
        assertEquals(1, q.size());
        assertEquals(q.peek(), new Integer(1));
        
        try {
            q.add(new Integer(2));
            fail();
        } catch (UnsupportedOperationException e) {
        }
    }
    
    /** Verify behavior of add method. */
    public void testAdd() {
        try {
            queue.add(new Integer(28));
            fail();
        } catch (UnsupportedOperationException e) {
        }
    }
    
    /** Verify behavior of addAll method. */
    public void testAddAll() {
        try {
            queue.add(queue);
            fail();
        } catch (UnsupportedOperationException e) {
        }
    }
    
    /** Verify behavior of clear method. */
    public void testClear() {
        try {
            queue.clear();
            fail();
        } catch (UnsupportedOperationException e) {
        }
    }
    
    /** Contains checks for the presence of an object */
    public void testContains() {
        assertFalse(queue.contains(new Integer(5)));
    }

    /** ContainsAll checks for the presense of a collection of objects. */
    public void testContainsAll() {
        try {
            queue.containsAll(null);
            fail();
        } catch (NullPointerException e) {
        }
    }

    /** Priority queues can be equal regardless of concrete implementation. */
    public void testEquals() {
        PriorityQueue other = new ArrayPriorityQueue(queue);
        assertEquals(queue, other);
    }

    /** Queues that compare equal should return the same hash code. */
    public void testHashCode() {
        // a queue is equal to its copy
        PriorityQueue other = new ArrayPriorityQueue(queue);
        assertEquals(queue.hashCode(), other.hashCode());
    }
    
    /** Verify behavior of iterator. */
    public void testIterator() {
        Iterator it = queue.iterator();
        while (it.hasNext()) {
            Object o = it.next();
            try {
                it.remove();
                fail();
            } catch (UnsupportedOperationException e) {
            }
        }
    }

    /** Verify behavior of peek method. */
    public void testPeek() {
        assertEquals(false, queue.isEmpty());
        assertEquals(new Integer(0), queue.peek());
    }
    
    /** Verify behavior of remove method. */
    public void testRemove() {
        try {
            queue.remove(new Integer(1));
            fail();
        } catch (UnsupportedOperationException e) {
        }
    }
    
    /** Verify behavior of removeAll method. */
    public void testRemoveAll() {
        try {
            queue.removeAll(queue);
            fail();
        } catch (UnsupportedOperationException e) {
        }
    }
    
    /** Verify behavior of retainAll method. */
    public void testRetainAll() {
        try {
            queue.retainAll(queue);
            fail();
        } catch (UnsupportedOperationException e) {
        }
    }
    
    /** Verify behavior of dequeue method. */
    public void testDequeue() {
        try {
            Object o = queue.dequeue();
            fail();
        } catch (UnsupportedOperationException e) {
        }
    }
    
    /** Verify behavior of enqueue method. */
    public void testEnqueue() {
        try {
            queue.enqueue(new Integer(28), 28);
            fail();
        } catch (UnsupportedOperationException e) {
        }
    }
    
    /** Verify behavior of enqueueAll method. */
    public void testEnqueueAll() {
        try {
            queue.enqueueAll(queue, 28);
            fail();
        } catch (UnsupportedOperationException e) {
        }
    }

    /** Verify behavior of size method. */
    public void testSize() {
        assertEquals(5, queue.size());
    }
    
    /** Verify conversion to array. */
    public void testToArray1() {
        Object[] arr1 = {
            new Integer(0),
            new Integer(1),
            new Integer(2),
            new Integer(3),
            new Integer(4)
        };
        Object[] arr2 = queue.toArray();
        for (int i = 0; i < 5; ++i) {
            assertEquals(arr1[i], arr2[i]);
        }
    }
    
    /** Verify conversion to array. */
    public void testToArray2() {
        Object[] arr1 = {
            new Integer(0),
            new Integer(1),
            new Integer(2),
            new Integer(3),
            new Integer(4)
        };
        Object[] arr2 = queue.toArray(new Integer[5]);
        for (int i = 0; i < 5; ++i) {
            assertEquals(arr1[i], arr2[i]);
        }
    }

    /** Verify conversion to string. */
    public void testToString() {
        assertEquals("[0, 1, 2, 3, 4]", queue.toString());
    }
}
