package com.topcoder.util.cache;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * <p>This test case tests the SimpleCache constructors.</p>
 *
 * @author srowen
 * @version 1.0
 */
public class CreateCacheTestCase extends TestCase {

    /**
     * tests creation of the cache
     */
    public void testCreateCache() {
        SimpleCache simpleCache = new SimpleCache();
        assertEquals("Max size should default to no max",
                     SimpleCache.NO_MAX_SIZE,
                     simpleCache.getMaxCacheSize());
        assertEquals("Timeout should default to no timeout",
                     SimpleCache.NO_TIMEOUT,
                     simpleCache.getTimeoutMS());

        simpleCache =
            new SimpleCache(10000, 24*60*60*1000, new FIFOCacheEvictionStrategy());
        assertEquals("Max size should match given size",
                     10000,
                     simpleCache.getMaxCacheSize());
        assertEquals("Timeout should match given timeout",
                     24*60*60*1000,
                     simpleCache.getTimeoutMS());
    }
    /**
     * test the illegal arguments
     */
    public void testIllegalConstructorArgs() {

        // should throw an IllegalArgumentException - see spec
        try {
            new SimpleCache(0, 1000, new LRUCacheEvictionStrategy());
            fail("Nonpositive max size should cause an IllegalArgumentException");
        } catch(IllegalArgumentException iae) {
            // good
        }
        try {
            new SimpleCache(10000, 0, new LRUCacheEvictionStrategy());
            fail("Nonpositive timeout should cause an IllegalArgumentException");
        } catch(IllegalArgumentException iae) {
            // good
        }
        try {
            new SimpleCache(10000, 1000, null);
            fail("Null eviction strategy should cause an IllegalArgumentException");
        } catch(IllegalArgumentException iae) {
            // good
        }
    }
    
    /**
     * Suite to run test cases
     */
    public static Test suite() {
        return new TestSuite(CreateCacheTestCase.class);
    }
}
