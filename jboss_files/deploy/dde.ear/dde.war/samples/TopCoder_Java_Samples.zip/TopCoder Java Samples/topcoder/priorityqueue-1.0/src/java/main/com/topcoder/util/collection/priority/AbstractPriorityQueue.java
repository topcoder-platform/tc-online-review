/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import java.util.AbstractCollection;
import java.util.Collection;
import java.util.Iterator;


/**
 * This class provides a skeletal implementation of the PriorityQueue
 * interface, to minimize efforts required to implement the
 * interface. Sub-classes may override any of the methods for
 * performance and other reasons.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
abstract class AbstractPriorityQueue
    extends AbstractCollection implements PriorityQueue {
    
    /**
     * Inserts all the objects in the given collection into the queue
     * at the specified priority level. Objects within the same
     * priority level are stored in a first-in first-out (FIFO)
     * manner. Mirroring the Java Collection library, there is no
     * concept of &quot;fullness&quot;, with the rationale that memory
     * will be exhausted long before it happens.
     *
     * @param collection The collection of objects to add
     * @param priority The priority level of the objects
     *
     * @return true if the queue is modified
     *
     * @throws NullPointerException if collection is null
     */
    public boolean enqueueAll(Collection collection, int priority) {
        if (null == collection) {
            throw new NullPointerException();
        }

        Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            enqueue(iterator.next(), priority);
        }
        return true;
    }

    /**
     * Calls enqueue(obj, DEFAULT_PRIORITY) to do the actual work.
     *
     * @param object The object to add
     *
     * @return true if the queue changed
     */
    public boolean add(Object object) {
        return enqueue(object, DEFAULT_PRIORITY);
    }

    /**
     * Compare two <code>PriorityQueue</code> objects for
     * equality. Two priority queues are equal if they contain the
     * same objects in the same order.
     *
     * @param object an object to compare
     *
     * @return true iff the two queues are equal
     */
    public boolean equals(Object object) {
        // implement the same interface
        if (!(object instanceof PriorityQueue)) {
            return false;
        }

        // are of the same size (optimization)
        PriorityQueue queue = (PriorityQueue) object;
        if (this.size() != queue.size()) {
            return false;
        }

        // contain the same elements
        Iterator it1 = this.iterator();
        Iterator it2 = queue.iterator();

        while (it1.hasNext() && it2.hasNext()) {
            Object obj1 = it1.next();
            Object obj2 = it2.next();

            if (!((obj1 == null) ? (obj2 == null) : obj1.equals(obj2))) {
                return false;
            }
        }
        
        return true;
    }

    /**
     * Return a 32-bit integer summary of the object, having the
     * characteristic that two objects that compare equal will have
     * the same hash value.
     *
     * @return a hash value for the object.
     */
    public int hashCode() {
        int value = 0;
        
        Iterator it = iterator();
        while (it.hasNext()) {
            value ^= it.next().hashCode();
        }
        return value;
    }

    /**
     * Remove from the queue all elements contained in the specified
     * collection.
     *
     * @param collection objects to be removed
     *
     * @return true iff the queue is modified
     *
     * @throws NullPointerException if the collection is null
     */
    public boolean removeAll(Collection collection) {
        if (null == collection) {
            throw new NullPointerException();
        }
        return super.removeAll(collection);
    }

    /**
     * Remove from the queue all elements not contained in the
     * specified collection.
     *
     * @param collection objects to be preserved
     *
     * @return true iff the queue is modified
     *
     * @throws NullPointerException if the collection is null
     */
    public boolean retainAll(Collection collection) {
        if (null == collection) {
            throw new NullPointerException();
        }
        return super.retainAll(collection);
    }
}
