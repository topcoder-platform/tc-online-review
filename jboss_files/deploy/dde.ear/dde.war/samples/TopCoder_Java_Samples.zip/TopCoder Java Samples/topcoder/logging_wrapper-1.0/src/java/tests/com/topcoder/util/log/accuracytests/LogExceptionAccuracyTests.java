/*
 * LogExceptionTest.java
 */
package com.topcoder.util.log.accuracytests;

import com.topcoder.util.log.LogException;
import com.topcoder.util.log.functionaltests.AbstractLoggingAccuracyTests;

public class LogExceptionAccuracyTests extends AbstractLoggingAccuracyTests {

    public LogExceptionAccuracyTests(String testName) {
        super(testName);
    }

    public void testGetException() {
        Exception e = new Exception("exception");
        LogException le = new LogException(e);
        assertTrue("Exceptions don't match", e == le.getException());
    }
}

