package com.topcoder.util.cache;

import java.lang.ref.Reference;
import java.lang.ref.SoftReference;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;

/**
 * <p>An implementation for the Cache interface.</p>
 *
 * <p>Copyright &copy 2002, TopCoder, Inc. All rights reserved</p>
 *
 * @author  WishingBone
 * @version 1.0
 */
public class SimpleCache implements Cache {

    /** constant value for no max size for the cache
     */
    public static final int NO_MAX_SIZE = Integer.MAX_VALUE;

    /** constant value for no timeout for the cache
     */
    public static final long NO_TIMEOUT = Long.MAX_VALUE;

    /** the maximum number of entries allowed in the cache
     */
    private int maxCacheSize;

    /** timeout value for the cache, in milliseconds
     */
    private long timeoutMS;

    /** eviction strategy for the cache, used when there is no room for
     * new entries
     */
    private CacheEvictionStrategy evictionStrategy;

    /** map from key to SoftReference which holds the cached value
     */
    private HashMap map;

    /** cleanup thread which runs every five second to check for and remove
     * timeouted entries
     */
    private CacheCleanupThread cleanup;

    /** constructor for SimpleCache with default parameters
     * (NO_MAX_SIZE, NO_TIMEOUT, FIFOCacheEvictionStrategy)
     */
    public SimpleCache() {
        maxCacheSize = NO_MAX_SIZE;
        timeoutMS = NO_TIMEOUT;
        evictionStrategy = new FIFOCacheEvictionStrategy();
        map = new HashMap();
        // no need for cleanup thread
    }

    /** contructor for Simple Cache with specified parameters
     * @param   maxCacheSize    the maximum number of entries allowed
     *                          in the cache
     * @param   timeoutMS       eviction strategy for the cache, used
     *                          when there is no room for new entries
     * @param   evictionStrategy    eviction strategy for the cache,
     *                              used when there is no room for new
     *                              entries
     * @throws  IllegalArgumentException
     *                            when 1) maxCacheSize is non-positive;
     *                                 2) timeoutMS is non-positive;
     *                                 3) evictionStrategy is null
     */
    public SimpleCache(int maxCacheSize,
                       long timeoutMS,
                       CacheEvictionStrategy evictionStrategy) 
                       throws IllegalArgumentException {
        // check for illegal arguments
        if (maxCacheSize <= 0 || timeoutMS <= 0 ||
            evictionStrategy == null) {
            throw new IllegalArgumentException();
        }
        this.maxCacheSize = maxCacheSize;
        this.timeoutMS = timeoutMS;
        this.evictionStrategy = evictionStrategy;
        map = new HashMap();
        // start cleanup thread
        if (timeoutMS < NO_TIMEOUT) {
            cleanup = new CacheCleanupThread();
            cleanup.start();
        }
    }

    /** get maxCacheSize of the cache
     * @return          maxCacheSize
     */
    public int getMaxCacheSize() {
        return maxCacheSize;
    }

    /** get timeoutMS of the cache
     * @return          timeoutMS
     */
    public long getTimeoutMS() {
        return timeoutMS;
    }

    /** look up the for value with specified key in the cache
     * @param   key     the specified key
     * @return          value if found in cache, null otherwise
     * @throws  IllegalArgumentException    when key is null
     */
    public Object get(Object key) throws IllegalArgumentException {
        if (key == null) {
            throw new IllegalArgumentException();
        }
        Reference ref;
        synchronized (map) {
            ref = (Reference)map.get(key);
        }
        // key might not exist in the map
        if (ref == null) {
            return null;
        }
        Entry entry = (Entry)ref.get();
        // entry might be null if JVM reclaims it, when we remove the key
        // and notify eviction strategy with "remove" and return null
        if (entry == null) {
            synchronized (map) {
                map.remove(key);
            }
            evictionStrategy.notifyOfCacheRemove(key);
            return null;
        }
        // notify with "get"
        evictionStrategy.notifyOfCacheGet(key);
        return entry.getValue();
    }

    /** put value with its key into the cache, if value is null,
     * it acts as if remove value with specified key from the cache
     * @param   key     the key for the value
     * @param   value   the value
     * @throws  IllegalArgumentException    when key is null
     */
    public void put(Object key, Object value) {
        // if value is null, just call remove
        if (value == null){
            remove(key);
            return;
        }
        if (key == null) {
            throw new IllegalArgumentException();
        }
        boolean evict;
        // when the map does not contain the key and max size if reached
        // we should evict an entry to make room for the new one
        synchronized (map) {
            evict = !map.containsKey(key) && map.size() == maxCacheSize;
        }
        if (evict) {
            Object evictKey = evictionStrategy.getNextKeyToEvict();
            // eviction strategy might return null
            // or the return value does not exist in the map
            // remove anything in such situation
            synchronized (map) {
                if (evictKey == null || !map.containsKey(evictKey)) {
                    map.remove(map.keySet().iterator().next());
                }
                else {
                    map.remove(evictKey);
                }
            }
        }
        // calculate timestamp, check for overflow
        // put a SoftReference to the value and timestamp into the map
        // it might overwrite old value
        // notify with "put"
        long timesOutAt = NO_TIMEOUT - System.currentTimeMillis() - timeoutMS;
        if (timesOutAt <= 0) {
            timesOutAt = NO_TIMEOUT;
        }
        else {
            timesOutAt = NO_TIMEOUT - timesOutAt;
        }
        synchronized (map) {
            map.put(key, new SoftReference(new Entry(value, timesOutAt)));
        }
        evictionStrategy.notifyOfCachePut(key);
    }

    /** remove value with specified key from the cache
     * @param   key     the specified key
     * @return          value if found in cache, null otherwise
     * @throws  IllegalArgumentException    when key is null
     */
    public Object remove(Object key) {
        if (key == null) {
            throw new IllegalArgumentException();
        }
        Reference ref;
        synchronized (map) {
            ref = (Reference)map.get(key);
        }
        // key might not exist in the map
        if (ref == null) {
            return null;
        }
        // remove the key and notify eviction strategy with "remove"
        synchronized (map) {
            map.remove(key);
        }
        evictionStrategy.notifyOfCacheRemove(key);
        Entry entry = (Entry)ref.get();
        // entry might be null if JVM reclaims it, just return null
        if (entry == null) {
            return null;
        }
        return entry.getValue();
    }

    /** clear the cache
     */
    public void clear() {
        synchronized (map) {
            map.clear();
        }
        // notify with "clear"
        evictionStrategy.notifyOfCacheClear();
    }

    /** finalize method
     */
    public void finalize() {
        if (timeoutMS < NO_TIMEOUT) {
            cleanup.halt();
        }
    }

    /* inner class that holds value and timestamp
     */
    private class Entry {

        /* value
         */
        private Object value;

        /* timestamp
         */
        private long timesOutAt;

        /* constructor
         * @param   value       value to be hold
         * @param   timesOutAt  timestamp for the value
         */
        public Entry(Object value, long timesOutAt) {
            this.value = value;
            this.timesOutAt = timesOutAt;
        }

        /* get value
         * @return the stored value
         */
        public Object getValue() {
            return value;
        }

        /* get timestamp
         * @return when the object times out
         */
        public long getTimesOutAt() {
            return timesOutAt;
        }

    }

    /* inner thread which cleans up timeouted entries in the cache
     */
    private class CacheCleanupThread extends Thread {

        /* time interval for the check, in milliseconds,
         * which is five seconds by default
         */
        private static final long CHECK_INTERVAL_MS = 5000;

        /* contructor, set as deamon thread
         */
        private CacheCleanupThread() {
            setDaemon(true);
        }

        /* thread body
         */
        public void run() {
            for (;;) {
                // run every five seconds
                try {
                    sleep(CHECK_INTERVAL_MS);
                } catch (InterruptedException e) {
                }
                // get current time
                // entrys timestamped before this would be removed
                long current = System.currentTimeMillis();
                synchronized (map) {
                    Set entrySet = map.entrySet();
                    Iterator i = entrySet.iterator();
                    // iterate throw the map
                    while (i.hasNext()) {
                        Map.Entry mapEntry = (Map.Entry)i.next();
                        Reference ref = (Reference)mapEntry.getValue();
                        Entry entry = ref == null ? null : (Entry)ref.get();
                        // entry might be null when JVM reclaimed it
                        // remove and notify with "remove" if neccesary
                        if (entry == null ||
                            entry.getTimesOutAt() <= current) {
                            i.remove();
                            evictionStrategy.notifyOfCacheRemove(
                                    mapEntry.getKey());
                        }
                    }
                }
            }
        }

        /** halt the thread, set as user thread
         */
        private void halt() {
            setDaemon(false);
        }

    }

}
