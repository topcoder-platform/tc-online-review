/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import java.util.Collection;


/**
 * This is the interface representing a priority queue. It extends
 * from the Collection interface and adds several new methods:
 * enqueue, enqueueAll, dequeue, and peek. Objects are inserted into
 * the priority queue with a given priority level (or a suitable
 * default if none is specified). Upon removal, the object with the
 * highest priority is returned first. Objects at the same priority
 * level are removed according to their insertion order. An object may
 * be inserted into the queue multiple times, at the same or different
 * priority levels. null's are also permitted.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
public interface PriorityQueue extends Collection {
    
    /** The default priority if none is specified. */
    public static final int DEFAULT_PRIORITY = 0;

    /**
     * Destructively returns the object currently at the head of the
     * queue.
     *
     * @return the next object at the highest priority level and
     * remove that object from the queue
     *
     * @throws IllegalStateException if the queue is empty
     *
     * @see peek
     */
    public Object dequeue();

    /**
     * Inserts the given object into the queue at the specified
     * priority level.  Objects within the same priority level are
     * stored in a first-in first-out (FIFO) manner.  Mirroring the
     * Java Collection library, there is no concept of
     * &quot;fullness&quot;, with the rationale that memory will be
     * exhausted long before it happens.
     *
     * @param object The object to queue up
     * @param priority The priority level of the object
     *
     * @return true if the queue is modified
     */
    public boolean enqueue(Object object, int priority);

    /**
     * Inserts all the objects in the given collection into the queue
     * at the specified priority level. Objects within the same
     * priority level are stored in a first-in first-out (FIFO)
     * manner. Mirroring the Java Collection library, there is no
     * concept of &quot;fullness&quot;, with the rationale that memory
     * will be exhausted long before it happens.
     *
     * @param collection The collection of objects to add
     * @param priority The priority level of the objects
     *
     * @return true if the queue is modified
     *
     * @throws NullPointerException if collection is null
     */
    public boolean enqueueAll(Collection collection, int priority);

    /**
     * Non-destructively (the queue is not modified) return the object
     * currently at the head of the queue.  This is the same object
     * that would be (desctructively) returned by
     * <code>dequeue</code>.
     *
     * @return the object currently at the head of the queue
     *
     * @throws IllegalStateException if the queue is empty
     *
     * @see dequeue
     */
    public Object peek();
}
