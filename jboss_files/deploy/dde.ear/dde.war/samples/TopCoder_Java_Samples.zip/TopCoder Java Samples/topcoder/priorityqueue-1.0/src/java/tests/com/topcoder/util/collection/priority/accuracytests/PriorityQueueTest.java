package com.topcoder.util.collection.priority.accuracytests;

import com.topcoder.util.collection.priority.PriorityQueue;
import com.topcoder.util.collection.priority.TreePriorityQueue;

import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


/**
 * Abstract base class for PriorityQueue accuracy tests.
 *
 * @author msuhocki
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
public abstract class PriorityQueueTest extends TestCase {
    /** sub-classes should define the queue with the type to be tested */
    protected PriorityQueue queue;

    Object[][] arrays = new Object[][] {
            
            /*  0 */ new Object[] { "String1", "String2", "String3", new Integer(1), null, "String4" }, 
            /*  1 */ new Object[] {  }, 
            /*  2 */ new Object[] { "String1" }, 
            /*  3 */ new Object[] { "String1", "String3", null }, 
            /*  4 */ new Object[] { "String1", "String2", "String5" },
            /*  5 */ new Object[] { "String1", "String2", "String3", new Integer(1), null, "String4", "String1" },
            /*  6 */ new Object[] { "String1", "String3", "String2", new Integer(1), "String4", null, "String1" },
            /*  7 */ new Object[] { "String1", "String2", "String3", "String4", "String5", "String5" },
            /*  8 */ new Object[] { "String1", "String2" }, 
            /*  9 */ new Object[] { "String3", "String4", "String5" },
            /* 10 */ new Object[] { "String3", "String4", "String5", "String1", "String2" },
            /* 11 */ new Object[] { "String1", "String2", "String3", "String4", "String5" }
        };

    List[] lists = new List[arrays.length];
    int[] level5_6 = new int[] { Integer.MAX_VALUE, 2, Integer.MAX_VALUE, 2, 0, 1, 0 };
    int[] level10_11 = new int[] { 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 10 };
    List empty;

    /**
     * Creates a new PriorityQueueTest object.
     */
    public PriorityQueueTest() {
        for (int i = 0; i < arrays.length; i++) {
            lists[i] = constructList(arrays[i]);
        }

        empty = lists[1];
    }

    /**
     * Should instantiate a PriorityQueue object.
     */
    public abstract void setUp();

    /**
     * nothing
     */
    public void tearDown() {
    }

    /**
     * Generates a list based on an array.
     *
     * @param array the array
     *
     * @return the list
     */
    protected List constructList(Object[] array) {
        ArrayList list = new ArrayList();

        for (int i = 0; i < array.length; i++) {
            list.add(array[i]);
        }

        return list;
    }

    /**
     * checks the queue against a list
     *
     * @param list the list
     */
    protected void checkList(List list) {
        Iterator it1 = queue.iterator();
        Iterator it2 = list.iterator();

        while (it1.hasNext() && it2.hasNext()) {
            assertEquals(it1.next(), it2.next());
        }

        assertFalse("Queue has too many elements", it1.hasNext());
        assertFalse("Queue has too few elements", it2.hasNext());
        assertEquals(list.size(), queue.size());
    }

    /**
     * Tests PriorityQueue.add(Object)
     */
    public void testAdd() {
        queue.add("String1");
        assertEquals("String1", queue.peek());

        queue.add(null);
        assertEquals("String1", queue.peek());

        queue.add("String2");
        assertEquals("String1", queue.peek());

        queue.dequeue();
        assertEquals(null, queue.peek());

        queue.dequeue();
        assertEquals("String2", queue.peek());
    }

    /**
     * Tests PriorityQueue.addAll(Collection)
     */
    public void testAddAll1() {
        queue.addAll(lists[0]);
        checkList(lists[0]);
    }

    /**
     * Tests PriorityQueue.addAll(Collection)
     */
    public void testAddAll2() {
        queue.addAll(lists[1]);
        checkList(lists[1]);
    }

    /**
     * Tests PriorityQueue.addAll(Collection)
     */
    public void testAddAll3() {
        queue.addAll(lists[2]);
        checkList(lists[2]);
    }

    /**
     * Tests PriorityQueue.addAll(Collection)
     */
    public void testAddAll4() {
        queue.addAll(lists[0]);
        queue.addAll(lists[2]);
        checkList(lists[5]);
    }

    /**
     * Tests PriorityQueue.clear()
     */
    public void testClear() {
        queue.addAll(lists[0]);
        queue.clear();
        checkList(empty);
    }

    /**
     * Tests PriorityQueue.contains(Object)
     */
    public void testContains() {
        assertFalse(queue.contains("String1"));
        assertFalse(queue.contains(null));

        queue.addAll(lists[0]);
        assertTrue(queue.contains("String1"));
        assertTrue(queue.contains("String2"));
        assertTrue(queue.contains("String3"));
        assertTrue(queue.contains("String4"));
        assertFalse(queue.contains("String5"));
        assertTrue(queue.contains(null));
        assertTrue(queue.contains(new Integer(1)));
        assertFalse(queue.contains(new Integer(2)));
    }

    /**
     * Tests PriorityQueue.containsAll(Collection)
     */
    public void testContainsAll() {
        assertFalse(queue.containsAll(lists[0]));
        assertTrue(queue.containsAll(lists[1]));

        queue.addAll(lists[0]);
        assertTrue(queue.containsAll(lists[0]));
        assertTrue(queue.containsAll(lists[1]));
        assertTrue(queue.containsAll(lists[2]));
        assertTrue(queue.containsAll(lists[3]));
        assertFalse(queue.containsAll(lists[4]));
        assertTrue(queue.containsAll(lists[5]));
    }

    /**
     * Tests PriorityQueue.dequeue()
     */
    public void testDequeue() {
        for (int i = 0; i < arrays[5].length; i++) {
            queue.enqueue(arrays[5][i], level5_6[i]);
        }

        for (int i = 0; i < arrays[5].length; i++) {
            Object obj = queue.dequeue();
            assertEquals("" + i, arrays[6][i], obj);
        }
    }

    /**
     * Tests PriorityQueue.enqueue(Object, int)
     */
    public void testEnqueue() {
        for (int i = 0; i < arrays[5].length; i++) {
            queue.enqueue(arrays[5][i], level5_6[i]);
        }

        checkList(lists[6]);
    }

    /**
     * Tests PriorityQueue.enqueueAll(Collection, int)
     */
    public void testEnqueueAll() {
        queue.enqueueAll(empty, 100);
        assertTrue(queue.isEmpty());

        queue.enqueueAll(lists[9], 15);
        queue.enqueueAll(lists[8], 10);

        checkList(lists[10]);
    }

    /**
     * Tests PriorityQueue.equals(Object)
     *
     * @throws Exception on exceptions
     */
    public void testEquals() throws Exception {
        PriorityQueue queue1 = new TreePriorityQueue();

        assertTrue(queue.equals(queue));
        assertTrue(queue.equals(queue1));

        queue.enqueue("String1", 3);
        assertFalse(queue.equals(queue1));
        assertFalse(queue1.equals(queue));

        queue1.enqueue("String1", 2);
        assertTrue(queue.equals(queue1));
        assertTrue(queue1.equals(queue));

        queue.enqueue("String2", 2);
        queue1.enqueue("String2", 3);
        assertFalse(queue.equals(queue1));
        assertFalse(queue1.equals(queue));

        ArrayList list = new ArrayList();
        list.add("String1");
        list.add("String2");
        assertFalse(queue.equals(list));
    }

    /**
     * nothing
     */
    public void testHashCode() {
        // no test
    }

    /**
     * Tests PriorityQueue.isEmpty()
     */
    public void testIsEmpty() {
        assertTrue(queue.isEmpty());
        queue.add(new Object());
        assertFalse(queue.isEmpty());
        queue.clear();
        assertTrue(queue.isEmpty());
    }

    /**
     * Tests PriorityQueue.iterator()
     */
    public void testIterator() {
        Iterator it1;

        it1 = queue.iterator();
        assertNotNull(it1);
        assertFalse(it1.hasNext());

        for (int i = 0; i < arrays[5].length; i++) {
            queue.enqueue(arrays[5][i], level5_6[i]);
        }

        checkList(lists[6]); // uses iterator        
    }

    /**
     * Tests PriorityQueue.peek()
     */
    public void testPeek() {
        queue.add("String1");
        assertEquals("String1", queue.peek());
    }

    /**
     * Tests PriorityQueue.remove(Object)
     */
    public void testRemove() {
        queue.enqueue("String1", 1);
        queue.enqueue("String1", 2);
        queue.enqueue("String2", 2);
        queue.remove("String1");
        assertEquals(2, queue.size());
        assertEquals("String2", queue.peek());
        queue.remove("String2");
        assertEquals(1, queue.size());
        queue.remove("String1");
        assertEquals(0, queue.size());
        ;
    }

    /**
     * Tests PriorityQueue.removeAll(Collection)
     */
    public void testRemoveAll() {
        queue.removeAll(lists[0]);
        assertTrue(queue.isEmpty());

        queue.addAll(lists[10]);
        queue.removeAll(lists[9]);
        checkList(lists[8]);

        queue.removeAll(empty);
        checkList(lists[8]);

        queue.removeAll(lists[8]);
        assertTrue(queue.isEmpty());
    }

    /**
     * Tests PriorityQueue.retainAll(Collection)
     */
    public void testRetainAll() {
        queue.retainAll(lists[0]);
        assertTrue(queue.isEmpty());

        queue.addAll(lists[10]);
        queue.retainAll(lists[9]);
        checkList(lists[9]);

        queue.retainAll(empty);
        assertTrue(queue.isEmpty());
    }

    /**
     * Tests PriorityQueue.size()
     */
    public void testSize() {
        assertEquals(0, queue.size());

        queue.add("StringA");
        assertEquals(1, queue.size());

        queue.add("StringB");
        assertEquals(2, queue.size());

        queue.enqueue("StringC", 15);
        assertEquals(3, queue.size());

        queue.enqueueAll(lists[0], 30);
        assertEquals(3 + lists[0].size(), queue.size());

        queue.addAll(lists[0]);
        assertEquals(3 + (2 * lists[0].size()), queue.size());

        queue.remove("StringA");
        assertEquals(2 + (2 * lists[0].size()), queue.size());
    }

    /**
     * Tests PriorityQueue.toArray()
     */
    public void testToArray() {
        Object[] array;

        array = queue.toArray();
        assertEquals(0, array.length);

        queue.add("String0");
        array = queue.toArray();
        assertEquals(1, array.length);
        assertEquals("String0", array[0]);

        queue.clear();
        queue.addAll(lists[0]);
        array = queue.toArray();
        assertEquals(arrays[0].length, array.length);

        for (int i = 0; i < array.length; i++) {
            assertEquals("" + i, arrays[0][i], array[i]);
        }

        queue.clear();

        for (int i = 0; i < arrays[5].length; i++) {
            queue.enqueue(arrays[5][i], level5_6[i]);
        }

        array = queue.toArray();
        assertEquals(arrays[6].length, array.length);

        for (int i = 0; i < array.length; i++) {
            assertEquals("" + i, arrays[6][i], array[i]);
        }
    }

    /**
     * Tests PriorityQueue.toArray(Object)
     */
    public void testToArray_ObjectA() {
        String[] dummy = new String[0];
        String[] array;

        array = (String[]) queue.toArray(dummy);
        assertEquals(0, array.length);

        queue.add("String0");
        array = (String[]) queue.toArray(dummy);
        assertEquals(1, array.length);
        assertEquals("String0", array[0]);

        queue.clear();
        queue.addAll(lists[7]);
        array = (String[]) queue.toArray(dummy);
        assertEquals(arrays[0].length, array.length);

        for (int i = 0; i < array.length; i++) {
            assertEquals("" + i, arrays[7][i], array[i]);
        }

        queue.clear();

        for (int i = 0; i < arrays[10].length; i++) {
            queue.enqueue(arrays[10][i], level10_11[i]);
        }

        array = (String[]) queue.toArray(dummy);
        assertEquals(arrays[11].length, array.length);

        for (int i = 0; i < array.length; i++) {
            assertEquals("" + i, arrays[11][i], array[i]);
        }
    }
}
