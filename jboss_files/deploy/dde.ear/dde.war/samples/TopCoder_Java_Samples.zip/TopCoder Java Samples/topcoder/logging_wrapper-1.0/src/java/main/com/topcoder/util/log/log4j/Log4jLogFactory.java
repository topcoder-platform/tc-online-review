package com.topcoder.util.log.log4j;

import com.topcoder.util.log.log4j.Log4jLog;
import com.topcoder.util.log.LogFactory;
import com.topcoder.util.log.Log;
import com.topcoder.util.log.LogException;

/**
 * Log4J specific implementation of the LogFactory interface.
 * 
 * @author StinkyCheeseMan
 * @version 1.0
 */
public final class Log4jLogFactory extends LogFactory
{

    /**
	 * Returns a Log4J specific log instance for the specified <tt>name</tt>.
	 * 
	 * @param name The name associated with the log.
	 * 
	 * @return Log A log instance associated with the specified <tt>name</tt>.
	 */
    public final Log getLog(String name) throws LogException
    {
        if (name == null)
            throw new LogException(new NullPointerException("name cannot be null"));
        return new Log4jLog(name);
    }

}