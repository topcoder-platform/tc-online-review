package com.topcoder.util.cache.accuracytests;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * <p>This test case aggregates all accuracy test cases.</p>
 *
 * @author haha
 * @version 1.0
 */
public class AccuracyTests extends TestCase {

    /** 
     * Runs all Accuracy tests 
     */
    public static Test suite() {
        final TestSuite suite = new TestSuite();
        suite.addTest(AccuracyCreateCacheTestCase.suite());
        suite.addTest(AccuracyGetObjectFromCacheTestCase.suite());
        suite.addTest(AccuracyPutObjectInCacheTestCase.suite());
        suite.addTest(AccuracyClearRemoveObjectFromCacheTestCase.suite());
        suite.addTest(AccuracyConcurrencyTestCase.suite());
        suite.addTest(AccuracyCacheEvictionStrategyTestCase.suite());
        return suite;
    }
}
