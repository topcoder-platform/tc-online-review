package com.topcoder.util.log;

import com.topcoder.util.config.ConfigManager;
import com.topcoder.util.config.ConfigManagerException;

/**
 * Abstract factory class that all underlying implementations must extend
 * in order to log via this API. This is a Singleton class to ensure that
 * there exists one log factory per JVM.
 * 
 * @author StinkyCheeseMan
 * @version 1.0
 */
public abstract class LogFactory
{
    // Namespace is used by the configuration manager
    private static final String NAMESPACE = "com.topcoder.util.log";
    private static LogFactory instance;

    private static String factoryClass;
    private static boolean configUpdated = true;

    /**
     * Used to obtain a reference to the single instance of the specific
     * implementation of this abstract class.
     * 
     * @return LogFactory - Implementation specific factory for creating
     * 		Log objects.
     * 
     * @throws LogException if an exception occurs while retrieving the
     * 		instance.
     */
    public static final LogFactory getInstance() throws LogException
    {
        if (instance == null || configUpdated)
        {
            try
            {
                loadConfiguration();
                instance = (LogFactory) Class.forName(factoryClass).newInstance();
                configUpdated = false;
            }
            catch (Exception e)
            {
                throw new LogException(e);
            }
        }

        return instance;
    }

    /**
     * Method used to cause the factory to reload its configuration data. The 
     * behavior of other methods may change after a call to this method.
     * 
     * @throws ConfigManagerException if an error occurs while loading the 
     * 		configuration.
     */
    public static final void loadConfiguration() throws ConfigManagerException
    {
        ConfigManager.getInstance().refreshAll();
        factoryClass = ConfigManager.getInstance().getString(NAMESPACE, "factoryClass");
        configUpdated = true;
    }

    /**
     * Method used to actually create an instance of the underlying implementation
     * class. Note: this is an abstract class, so we cannot do this with a 
     * constructor.
     * 
     * @return LogFactory - implementation dependent instance of LogFactory
     */
    public static final LogFactory createInstance() throws ClassNotFoundException, IllegalAccessException, InstantiationException
    {
        if (instance == null || configUpdated)
        {
            try
            {
                loadConfiguration();
                instance = (LogFactory) Class.forName(factoryClass).newInstance();
                configUpdated = false;
            }
            catch (Exception e)
            {
                throw new InstantiationException();
            }
        }

        return instance;
    }

    /**
     * Method used to retrieve a logging attribute from the configuration manager.
     * 
     * @param name The name of the attribute to retrieve.
     * 
     * @return String - the value of the attribute loaded from the configuration
     * 		manager
     * 
     * @throws ConfigManagerException if an error occurs while accessing the
     * 		configuration manager.
     */
    public static final String getAttribute(String name) throws ConfigManagerException
    {
        if (name == null)
            throw new ConfigManagerException("attribute name cannot be null");

        return ConfigManager.getInstance().getString(NAMESPACE, name);
    }

    /**
     * Abstract method that all implementing class should implement to provide 
     * a mechanism to retrieve a <tt>name</tt>-based <tt>Log</tt> implementation.
     * 
     * @param name The name of the logger to retrieve.
     * 
     * @return Log An implementation-specific instance of the Log interface.
     */
    public abstract Log getLog(String name) throws LogException;
}