/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import java.io.Serializable;

import java.util.Collection;
import java.util.Iterator;


/**
 * This is a utility class consisting of only static methods that
 * return singleton, synchronized, and unmodifiable priority queues,
 * respectively.  It mirrors the java.util.Collections utility class.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
public class PriorityQueues {
    
    /**
     * This represents an empty priority queue.  All initially empty
     * priority queues should be equal to this static instance
     * (equals() should return true).
     */
    public static final PriorityQueue EMPTY_PRIORITY_QUEUE =
        unmodifiablePriorityQueue(new LinkedPriorityQueue());

    /**
     * Private constructor to prevent instantiation.
     */
    private PriorityQueues() { }

    /**
     * Construct an immutable PriorityQueue containing only the given object.
     *
     * @param object The object to put into the queue
     *
     * @return an immutable PriorityQueue containing only the given object.
     */
    public static PriorityQueue singletonPriorityQueue(Object object) {
        PriorityQueue queue = new ArrayPriorityQueue();
        queue.add(object);

        return unmodifiablePriorityQueue(queue);
    }

    /**
     * Construct a thread-safe wrapper around the given queue.
     *
     * @param queue the queue to be wrapped
     *
     * @return a thread-safe PriorityQueue backed by the given queue
     *
     * @throws NullPointerException if queue is null
     */
    public static PriorityQueue synchronizedPriorityQueue(PriorityQueue queue) {
        if (null == queue) {
            throw new NullPointerException();
        }
        if (queue instanceof Serializable) {
            return new SynchronizedSerializableQueue(queue);
        }
        return new SynchronizedQueue(queue);
    }

    /**
     * Return an unmodifiable view of the given queue. Any attempt to
     * change the queue should result in
     * UnsupportedOperationException.
     *
     * @param queue The queue to be wrapped
     *
     * @return an immutable PriorityQueue backed by the given queue
     *
     * @throws NullPointerException if queue is null
     */
    public static PriorityQueue unmodifiablePriorityQueue(PriorityQueue queue) {
        if (null == queue) {
            throw new NullPointerException();
        }
        if (queue instanceof Serializable) {
            return new UnmodifiableSerializableQueue(queue);
        }
        return new UnmodifiableQueue(queue);
    }
}

/**
 * This utility class implements a thread-safe wrapper around a given
 * priority queue.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
class SynchronizedQueue extends AbstractPriorityQueue {
    
    /** Contains the data we are synchronizing access to. */
    private PriorityQueue queue;

    /**
     * Construct a wrapper around the given queue.
     *
     * @param queue the priority queue to wrap
     *
     * @throws NullPointerException if queue is null
     */
    public SynchronizedQueue(PriorityQueue queue) {
        if (null == queue) {
            throw new NullPointerException();
        }
        this.queue = queue;
    }
    
    /**
     * Add an object at the default priority.
     *
     * @param object the object to add
     *
     * @return true if the queue changed
     */
    public boolean add(Object object) {
        synchronized (this) {
            return queue.add(object);
        }
    }

    /**
     * Add several objects at the default priority.
     *
     * @param collection the objects to add
     *
     * @return true if the queue changed
     *
     * @throws NullPointerException if collection is null
     */
    public boolean addAll(Collection collection) {
        synchronized (this) {
            return queue.addAll(collection);
        }
    }

    /**
     * Remove all objects from the queue.
     */
    public void clear() {
        synchronized (this) {
            queue.clear();
        }
    }

    /**
     * Determine if the given object is in the queue.
     *
     * @param object the object to test
     *
     * @return true if the object is contained in the queue
     */
    public boolean contains(Object object) {
        synchronized (this) {
            return queue.contains(object);
        }
    }

    /**
     * Determine if several objects are in the queue.
     *
     * @param collection the objects to test
     *
     * @return true if all objects are contained in the queue
     *
     * @throws NullPointerException if collection is null
     */
    public boolean containsAll(Collection collection) {
        synchronized (this) {
            return queue.containsAll(collection);
        }
    }

    /**
     * Compare two <code>PriorityQueue</code> objects for
     * equality. Two priority queues are equal if they contain the
     * same objects in the same order.
     *
     * @param object an object to compare
     *
     * @return true iff the two queues are equal
     */
    public boolean equals(Object object) {
        synchronized (this) {
            return queue.equals(object);
        }
    }
    
    /**
     * Return a 32-bit integer summary of the object, having the
     * characteristic that two objects that compare equal will have
     * the same hash value.
     *
     * @return a hash value for the object.
     */
    public int hashCode() {
        synchronized (this) {
            return queue.hashCode();
        }
    }

    /**
     * Determine if the queue contains no elements.
     *
     * @return true if the queue is empty
     */
    public boolean isEmpty() {
        synchronized (this) {
            return queue.isEmpty();
        }
    }

    /**
     * Not thread-safe.  The Java Collections interface specifies that
     * the user will need to manually lock the collection while
     * iterating over it
     *
     * @return an iterator for the contained queue.
     */
    public Iterator iterator() {
        return queue.iterator();
    }

    /**
     * Delete an object from the queue.
     *
     * @param object the object to delete
     *
     * @return true if the queue changed
     */
    public boolean remove(Object object) {
        synchronized (this) {
            return queue.remove(object);
        }
    }

    /**
     * Delete multiple objects from the queue.
     *
     * @param collection the objects to delete
     *
     * @return true if the queue changed
     *
     * @throws NullPointerException if collection is null
     */
    public boolean removeAll(Collection collection) {
        synchronized (this) {
            return queue.removeAll(collection);
        }
    }

    /**
     * Delete non-specified objects from the queue.
     *
     * @param collection the objects to keep
     *
     * @return true if the queue changed
     *
     * @throws NullPointerException if collection is null
     */
    public boolean retainAll(Collection collection) {
        synchronized (this) {
            return queue.retainAll(collection);
        }
    }

    /**
     * Return the number of objects in the queue.
     *
     * @return the number of objects in the queue
     */
    public int size() {
        synchronized (this) {
            return queue.size();
        }
    }

    /**
     * Return an array containing all the elements in the queue.
     *
     * @return an array containing all the elements in the queue
     */
    public Object[] toArray() {
        synchronized (this) {
            return queue.toArray();
        }
    }

    /**
     * Return an array containing all the elements in the queue. The
     * runtime type of the returned array is that of the argument.
     *
     * @param array an array where the elements are to be stored
     *
     * @return an array containing all the elements in the queue
     */
    public Object[] toArray(Object[] array) {
        synchronized (this) {
            return queue.toArray(array);
        }
    }

    /**
     * Destructively returns the object currently at the head of the
     * queue.
     *
     * @return the next object at the highest priority level and
     * remove that object from the queue
     *
     * @see peek
     */
    public Object dequeue() {
        synchronized (this) {
            return queue.dequeue();
        }
    }

    /**
     * Inserts the given object into the queue at the specified
     * priority level.  Objects within the same priority level are
     * stored in a first-in first-out (FIFO) manner.  Mirroring the
     * Java Collection library, there is no concept of
     * &quot;fullness&quot;, with the rationale that memory will be
     * exhausted long before it happens.
     *
     * @param object The object to queue up
     * @param priority The priority level of the object
     *
     * @return true if the queue is modified
     */
    public boolean enqueue(Object object, int priority) {
        synchronized (this) {
            return queue.enqueue(object, priority);
        }
    }

    /**
     * Inserts all the objects in the given collection into the queue
     * at the specified priority level. Objects within the same
     * priority level are stored in a first-in first-out (FIFO)
     * manner. Mirroring the Java Collection library, there is no
     * concept of &quot;fullness&quot;, with the rationale that memory
     * will be exhausted long before it happens.
     *
     * @param collection The collection of objects to add
     * @param priority The priority level of the objects
     *
     * @return true if the queue is modified
     * @throws NullPointerException if collection is null
     */
    public boolean enqueueAll(Collection collection, int priority) {
        synchronized (this) {
            return queue.enqueueAll(collection, priority);
        }
    }

    /**
     * Non-destructively (the queue is not modified) return the object
     * currently at the head of the queue.  This is the same object
     * that would be (desctructively) returned by
     * <code>dequeue</code>.
     *
     * @return the object currently at the head of the queue
     *
     * @see dequeue
     */
    public Object peek() {
        synchronized (this) {
            return queue.peek();
        }
    }
}

/**
 * This utility class implements a serializable, thread-safe wrapper
 * around a given priority queue.  The Java Collections API specifies
 * that synchronized wrappers are only serializable if their contained
 * collections are also serializable.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
class SynchronizedSerializableQueue
    extends SynchronizedQueue implements Serializable {
    
    /**
     * Construct a wrapper around the given queue.
     *
     * @param queue the priority queue to wrap
     *
     * @throws NullPointerException if queue is null
     */
    public SynchronizedSerializableQueue(PriorityQueue queue) {
        super(queue);
    }
}

/**
 * This utility class implements a read-only wrapper around a given
 * priority queue.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
class UnmodifiableQueue extends AbstractPriorityQueue {
    
    /** Contains the data we are restricting access to. */
    private PriorityQueue queue;

    /**
     * Construct a wrapper around the given queue.
     *
     * @param queue the priority queue to wrap
     *
     * @throws NullPointerException if queue is null
     */
    public UnmodifiableQueue(PriorityQueue queue) {
        if (null == queue) {
            throw new NullPointerException();
        }
        this.queue = queue;
    }
    
    /**
     * Return an iterator for the queue that does not support remove.
     *
     * @return a read-only iterator
     */
    public Iterator iterator() {
        class UnmodifiableIterator implements Iterator {
            private Iterator iterator;

            public UnmodifiableIterator(Iterator iterator) {
                if (null == iterator) {
                    throw new NullPointerException();
                }

                this.iterator = iterator;
            }

            public boolean hasNext() {
                return iterator.hasNext();
            }

            public Object next() {
                return iterator.next();
            }

            public void remove() {
                throw new UnsupportedOperationException();
            }
        }
        ;

        return new UnmodifiableIterator(queue.iterator());
    }

    /**
     * We don't support adding an object.
     *
     * @param object the object to add
     *
     * @return true if the queue changed
     *
     * @throws UnsupportedOperationException always
     */
    public boolean add(Object object) {
        throw new UnsupportedOperationException();
    }

    /**
     * We don't support adding multiple objects.
     *
     * @param collection the objects to add
     *
     * @return true if the queue changed
     *
     * @throws UnsupportedOperationException always
     */
    public boolean addAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    /**
     * We don't support clearing the queue.
     *
     * @throws UnsupportedOperationException always
     */
    public void clear() {
        throw new UnsupportedOperationException();
    }

    /**
     * Determine if the given object is in the queue.
     *
     * @param object the object to test
     *
     * @return true if the object is contained in the queue
     */
    public boolean contains(Object object) {
        return queue.contains(object);
    }

    /**
     * Determine if several objects are in the queue.
     *
     * @param collection the objects to test
     *
     * @return true if all objects are contained in the queue
     * @throws NullPointerException if collection is null
     */
    public boolean containsAll(Collection collection) {
        return queue.containsAll(collection);
    }

    /**
     * Compare two <code>PriorityQueue</code> objects for
     * equality. Two priority queues are equal if they contain the
     * same objects in the same order.
     *
     * @param object an object to compare
     *
     * @return true iff the two queues are equal
     */
    public boolean equals(Object object) {
        return queue.equals(object);
    }
    
    /**
     * Return a 32-bit integer summary of the object, having the
     * characteristic that two objects that compare equal will have
     * the same hash value.
     *
     * @return a hash value for the object.
     */
    public int hashCode() {
        return queue.hashCode();
    }


    /**
     * Determine if the queue contains no elements.
     *
     * @return true if the queue is empty
     */
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    /**
     * We don't delete an object from the queue.
     *
     * @param object the object to delete
     *
     * @return true if the queue changed
     *
     * @throws UnsupportedOperationException always
     */
    public boolean remove(Object object) {
        throw new UnsupportedOperationException();
    }

    /**
     * We don't delete an object from the queue.
     *
     * @param collection the objects to delete
     *
     * @return true if the queue changed
     *
     * @throws UnsupportedOperationException always
     */
    public boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    /**
     * We don't delete an object from the queue.
     *
     * @param collection the objects to delete
     *
     * @return true if the queue changed
     *
     * @throws UnsupportedOperationException always
     */
    public boolean retainAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    /**
     * Return the number of objects in the queue.
     *
     * @return the number of objects in the queue
     */
    public int size() {
        return queue.size();
    }

    /**
     * Return an array containing all the elements in the queue.
     *
     * @return an array containing all the elements in the queue
     */
    public Object[] toArray() {
        return queue.toArray();
    }

    /**
     * Return an array containing all the elements in the queue. The
     * runtime type of the returned array is that of the argument.
     *
     * @param array an array where the elements are to be stored
     *
     * @return an array containing all the elements in the queue
     */
    public Object[] toArray(Object[] array) {
        return queue.toArray(array);
    }

    /**
     * We don't dequeue.
     *
     * @return nothing, always throws an exception
     *
     * @throws UnsupportedOperationException always
     */
    public Object dequeue() {
        throw new UnsupportedOperationException();
    }

    /**
     * We don't enqueue.
     *
     * @param object an object to enqueue
     * @param priority and its corresponding priority
     *
     * @return nothing, always throws
     *
     * @throws UnsupportedOperationException always
     */
    public boolean enqueue(Object object, int priority) {
        throw new UnsupportedOperationException();
    }

    /**
     * We don't enqueue.
     *
     * @param collection a collection of objects to enqueue
     * @param priority and their priority
     *
     * @return nothing, always throws
     *
     * @throws UnsupportedOperationException always
     */
    public boolean enqueueAll(Collection collection, int priority) {
        throw new UnsupportedOperationException();
    }

    /**
     * Non-destructively (the queue is not modified) return the object
     * currently at the head of the queue.  This is the same object
     * that would be (desctructively) returned by
     * <code>dequeue</code>.
     *
     * @return the object currently at the head of the queue
     *
     * @see dequeue
     */
    public Object peek() {
        return queue.peek();
    }
}

/**
 * This utility class implements a serializable, read-only wrapper
 * around a given priority queue.  The Java Collections API specifies
 * that synchronized wrappers are only serializable if their contained
 * collections are also serializable.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
class UnmodifiableSerializableQueue
    extends UnmodifiableQueue implements Serializable {
    
    /**
     * Construct a wrapper around the given queue.
     *
     * @param queue the priority queue to wrap
     */
    public UnmodifiableSerializableQueue(PriorityQueue queue) {
        super(queue);
    }
}
