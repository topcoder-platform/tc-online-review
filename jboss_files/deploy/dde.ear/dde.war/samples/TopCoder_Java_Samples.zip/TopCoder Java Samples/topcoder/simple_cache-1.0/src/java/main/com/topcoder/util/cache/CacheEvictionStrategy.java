package com.topcoder.util.cache;

/**
 * <p>CacheEvictionStrategy decides which entry to evict when cache is
 * full.</p>
 *
 * <p>Copyright &copy 2002, TopCoder, Inc. All rights reserved</p>
 *
 * @author  WishingBone
 * @version 1.0
 */
public interface CacheEvictionStrategy {

    /** notify of cache when "get" method happened on the specified key
     * @param   key     the specified key on which "get" method happened
     */
    void notifyOfCacheGet(Object key);

    /** notify of cache when "put" method happened on the specified key
     * @param   key     the specified key on which "put" method happened
     */
    void notifyOfCachePut(Object key);

    /** notify of cache when "remove" method happened on the specified key
     * @param   key     the specified key on which "remove" method happened
     */
    void notifyOfCacheRemove(Object key);

    /** notify of cache when "clear" method happened
     */
    void notifyOfCacheClear();

    /** decides the next key to evict when the cache is full
     *  @return the key to be evicted
     */
    Object getNextKeyToEvict();

}
