/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import java.io.Serializable;

import java.util.Collection;
import java.util.TreeMap;


/**
 * This implementation of PriorityQueue is backed by a TreeMap. This
 * class provides on average O(log n)-time, O(1)-data move for
 * insertions and O(log n)-time, O(1)-data move for removals.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
public class TreePriorityQueue
    extends MapPriorityQueue implements Cloneable, Serializable {
    
    /**
     * Creates new empty internal storage.
     */
    public TreePriorityQueue() {
        objects = new TreeMap();
    }

    /**
     * Creates new internal storage and inserts all the objects in the
     * given collection at the default priority level.
     *
     * @param collection The collection of objects to add
     *
     * @throws NullPointerException if collection is null
     */
    public TreePriorityQueue(Collection collection) {
        this();
        addAll(collection);
    }

    /**
     * Construct a copy of the queue, maintaining order and priority.
     *
     * @param queue to construct a copy of
     *
     * @throws NullPointerException if queue is null
     */
    public TreePriorityQueue(TreePriorityQueue queue) {
        super(queue);
        objects = new TreeMap(queue.objects);
    }

    /**
     * Return a deep copy of the queue.
     *
     * @return a deep copy of the queue.
     */
    public Object clone() {
        return new TreePriorityQueue(this);
    }
}
