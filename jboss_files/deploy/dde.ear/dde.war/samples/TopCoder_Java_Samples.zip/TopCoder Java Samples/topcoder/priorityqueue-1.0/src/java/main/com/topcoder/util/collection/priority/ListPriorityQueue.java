/**
 * Copyright &copy 2003, TopCoder, Inc. All rights reserved
 */
package com.topcoder.util.collection.priority;

import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;


/**
 * Provides for common functionality between the implementations of
 * <code>ArrayPriorityQueue</code> and
 * <code>LinkedPriorityQueue</code>.
 *
 * @author TangentZ
 * @author esessoms
 * @version 1.0
 *
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 */
class ListPriorityQueue extends AbstractPriorityQueue {
    
    /** Maintains objects in priority order. */
    protected List objects    = null;
    
    /**
     * Maintains object priorities, in order.  There is a one-to-one
     * correspondence between priority values in this list and objects
     * in the objects list.
     */
    protected List priorities = null;

    /**
     * Destructively returns the object currently at the head of the
     * queue.
     *
     * @return the next object at the highest priority level and
     * remove that object from the queue
     *
     * @throws IllegalStateException if the queue is empty
     *
     * @see peek
     */
    public Object dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException();
        }
        priorities.remove(priorities.size() - 1);
        return objects.remove(objects.size() - 1);
    }
    
    /**
     * Inserts the given object into the queue at the specified
     * priority level.  Objects within the same priority level are
     * stored in a first-in first-out (FIFO) manner.  Mirroring the
     * Java Collection library, there is no concept of
     * &quot;fullness&quot;, with the rationale that memory will be
     * exhausted long before it happens.
     *
     * @param object The object to queue up
     * @param priority The priority level of the object
     *
     * @return true if the queue is modified
     */
    public boolean enqueue(Object object, int priority) {
        int insertLocation = 0;
        for (; insertLocation < priorities.size(); ++insertLocation) {
            Integer currentPriority = (Integer) priorities.get(insertLocation);
            if (currentPriority.intValue() >= priority) {
                break;
            }
        }
        
        priorities.add(insertLocation, new Integer(priority));
        objects.add(insertLocation, object);
        
        return true;
    }
    
    /**
     * Non-destructively (the queue is not modified) return the object
     * currently at the head of the queue.  This is the same object
     * that would be (desctructively) returned by
     * <code>dequeue</code>.
     *
     * @return the object currently at the head of the queue
     *
     * @throws IllegalStateException if the queue is empty
     *
     * @see dequeue
     */
    public Object peek() {
        if (isEmpty()) {
            throw new IllegalStateException();
        }
        return objects.get(objects.size() - 1);
    }

    /**
     * Construct an iterator for the priority queue.  The order of
     * iteration for priority queues is defined to be the queue's
     * priority order.  In other words, the iterator will return
     * objects in the same order they would be retrieved by
     * <code>dequeue</code>.
     *
     * @return an iterator over all the objects in the queue in priority order
     */
    public Iterator iterator() {
        return new Iterator() {
                // identifies the element most-recently retrieved via next()
                private int currentPosition = size();

                // flag to prevent attempts to delete the same object twice
                private boolean removed = false;

                public boolean hasNext() {
                    // true until we've returned the 0-th element
                    return currentPosition > 0;
                }

                public Object next() {
                    // there better be a next element to step to
                    if (!hasNext()) {
                        throw new NoSuchElementException();
                    }

                    // it's a "new" object (to the user) and hasn't been removed
                    removed = false;

                    --currentPosition;
                    return objects.get(currentPosition);
                }

                public void remove() {
                    // ensure we've just returned a legal element
                    if ((currentPosition < 0) || (size() <= currentPosition)) {
                        throw new IllegalStateException();
                    }

                    // ensure that we haven't already removed this element
                    if (removed) {
                        throw new IllegalStateException();
                    }

                    // carry-out the actual removal
                    objects.remove(currentPosition);
                    priorities.remove(currentPosition);
                    removed = true;
                }
            };
    }

    /**
     * Return the number of objects in the queue.
     *
     * @return the number of objects in the queue
     */
    public int size() {
        return objects.size();
    }
}
