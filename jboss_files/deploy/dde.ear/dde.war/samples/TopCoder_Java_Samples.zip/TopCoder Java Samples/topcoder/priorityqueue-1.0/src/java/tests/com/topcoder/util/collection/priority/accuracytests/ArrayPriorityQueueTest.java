package com.topcoder.util.collection.priority.accuracytests;

import com.topcoder.util.collection.priority.ArrayPriorityQueue;
import junit.framework.TestSuite;
import junit.framework.Test;

/**
 * ArrayPriorityQueue test cases.  Functionality in PriorityQueueTest.
 * 
 * @copyright &copy; 2003 TopCoder, Inc. All rights reserved
 * @author msuhocki
 * @version 1.0
 */
public class ArrayPriorityQueueTest extends PriorityQueueTest {

    /**
     * instantiate PriorityQueue instance 
     */
    public void setUp() {
        queue = new ArrayPriorityQueue();
    }
    
    /**
     * Tests ArrayPriorityQueue constructor.
     */
    public void testArrayPriorityQueue() {
        ArrayPriorityQueue queue1;
        
        queue = new ArrayPriorityQueue();
        assertTrue(queue.isEmpty());
        
        queue = new ArrayPriorityQueue(100);
        assertTrue(queue.isEmpty());
        
        queue.addAll(lists[0]);
        
        queue1 = new ArrayPriorityQueue(queue);
        assertEquals(queue, queue1);
        
        queue1 = new ArrayPriorityQueue(queue);
        assertEquals(queue, queue1);
    }
    
    public static Test suite() {
        return new TestSuite(ArrayPriorityQueueTest.class);
    }
}
