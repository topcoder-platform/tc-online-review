/*
 * AbstractLoggingAccuracyTests.java
 */
package com.topcoder.util.log.functionaltests;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import junit.framework.TestCase;

public abstract class AbstractLoggingAccuracyTests extends TestCase {

    private static final String CONFIG_NAME =
            "conf/com/topcoder/util/log/Logging.xml";
    private static final File CONFIG_FILE = new File(System.getProperty("user.dir"), CONFIG_NAME);
    private File logFile =
            new File(System.getProperty("user.dir"),"test.log");

    protected static int serialNumber = 1;

    public AbstractLoggingAccuracyTests(String testName) {
        super(testName);
    }
    protected void saveConfigFile(String name) throws IOException {
        File saveFile = new File("conf/com/topcoder/util/log/"+name);
        if (saveFile.equals(CONFIG_FILE)) {
            throw new IllegalArgumentException("Can't save file to itself");
        }
        if (saveFile.exists()) {
            saveFile.delete();
        }
        CONFIG_FILE.renameTo(saveFile);
    }

    protected void restoreConfigFile(String name) throws IOException {
    	System.err.println(CONFIG_FILE);
        File saveFile = new File("conf/com/topcoder/util/log/"+name);
        if (saveFile.equals(CONFIG_FILE)) {
            throw new IllegalArgumentException("Can't restore file to itself");
        }
        if (CONFIG_FILE.exists()) {
            CONFIG_FILE.delete();
        }
        saveFile.renameTo(CONFIG_FILE);
    }

    protected void copyConfiguration(String name) throws IOException {
        File sourceFile = new File("conf/com/topcoder/util/log/"+name);
        if (sourceFile.equals(CONFIG_FILE)) {
            throw new IllegalArgumentException(
                    "Specified file is already the config file");
        }
        FileInputStream in = new FileInputStream(sourceFile);
        FileOutputStream out = new FileOutputStream(CONFIG_FILE);
        byte[] buffer = new byte[1024];
        for (int count = in.read(buffer); count >= 0; count = in.read(buffer)) {
            out.write(buffer, 0, count);
        }
        out.close();
        in.close();
    }

    protected boolean wasLogged(String message) throws IOException {
        StringBuffer sb = new StringBuffer();
        BufferedReader in =
                new BufferedReader(new FileReader(logFile));
        for (String s = in.readLine(); s != null; s = in.readLine()) {
            if (s.indexOf(message) != -1) {
                return true;
            }
        }
        in.close();
        return false;
    }

}

