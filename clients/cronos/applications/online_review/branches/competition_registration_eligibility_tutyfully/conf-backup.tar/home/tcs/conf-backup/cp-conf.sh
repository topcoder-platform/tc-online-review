cp /home/tcs/conf-backup/JNDIUtils.properties /home/tcs/jboss-4.0.2/server/default/deploy/review.war/WEB-INF/classes/com/topcoder/naming/jndiutility/
cp /home/tcs/conf-backup/JNDIUtils.properties /home/tcs/jboss-4.0.2/server/default/deploy/scorecard_admin.war/WEB-INF/classes/com/topcoder/naming/jndiutility/
cp /home/tcs/conf-backup/ApplicationServer.properties /home/tcs/jboss-4.0.2/server/default/conf/
cp /home/tcs/conf-backup/CatalogBean.properties /home/tcs/jboss-4.0.2/server/default/conf/com/topcoder/dde/catalog/
cp /home/tcs/conf-backup/OnlineReview.xml /home/tcs/jboss-4.0.2/server/default/deploy/review.war/WEB-INF/classes/
cp /home/tcs/conf-backup/Project_Phase_Template_Config.xml /home/tcs/jboss-4.0.2/server/default/conf/com/topcoder/project/phases/template/

