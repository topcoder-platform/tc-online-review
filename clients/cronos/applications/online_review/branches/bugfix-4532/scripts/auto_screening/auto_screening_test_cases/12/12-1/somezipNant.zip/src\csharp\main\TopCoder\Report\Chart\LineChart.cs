// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using TopCoder.Report.Chart.Elements;

namespace TopCoder.Report.Chart 
{
    /// <summary>
    /// <p> Represents Line Chart.
    /// There is one of the commonest forms of graph, particularly
    /// favoured by scientists,
    /// with data points displayed against X and Y axes and all the points
    /// connected with a single line.</p>
    /// <p> This chart can one or more data series. Every line has corresponded
    /// data series.
    /// Use series attributes to set appropriate line.</p>
    /// <p> The points themselves need not be shown. Use chart attribute to
    /// model this behavior.</p>
    /// <p> Alternatively, all the data points may be shown and a line drawn
    /// which doesn't necessarily go through them all but which gives a
    /// reasonable 'best fit' to them all.
    /// Use chart attribute to set needed type of line.</p>
    /// </summary>
    
    public class LineChart : Axial2DChart 
    {
        /// Constructor LineChart
        /// <summary>
        /// <p>Constructs line chart with given label and axis specified in
        /// second and third parameters.</p>
        /// <p>Simply uses base constructor</p>
        /// </summary>
        /// <exception>ArgumentNullException if any parameter is null</exception>
        /// <param name='label'>label to associate with chart</param>
        /// <param name='firstAxis'>first axis</param>
        /// <param name='secondAxis'>second axis</param>
        public LineChart(string label, Axis firstAxis, Axis secondAxis) : base(label, firstAxis, secondAxis) 
        {
        }
    }
    
}
