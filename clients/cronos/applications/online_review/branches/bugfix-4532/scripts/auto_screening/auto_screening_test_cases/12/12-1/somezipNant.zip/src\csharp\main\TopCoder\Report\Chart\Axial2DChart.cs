// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using TopCoder.Report.Chart.Elements;
using System;

namespace TopCoder.Report.Chart 
{
    
    ///  <summary>
    ///  <p>Represents a two-dimensional chart with two axes</p>
    ///  </summary>
    public class Axial2DChart : AxialChart 
    {
        /// Constructor Axial2DChart
        /// <summary>
        /// <p>Constructs a new instance of Axial2DChart with specified
        /// label and axes. Provided axes cannot be equal.</p>
        /// </summary>
        /// <exception>ArgumentNullException if any parameter is null</exception>
        /// <exception>ArgumentException if axes are equal</exception>
        /// <param name='label'>label to associate with this chart</param>
        /// <param name='firstAxis'>first axis</param>
        /// <param name='secondAxis'>second axis</param>
        public Axial2DChart(string label, Axis firstAxis, Axis secondAxis) : base(label, 2) 
        {
            if (firstAxis == null)
            {
                throw new ArgumentNullException("firstAxis", "firstAxis cannot be null");
            }
            if (secondAxis == null)
            {
                throw new ArgumentNullException("secondAxis", "secondAxis cannot be null");
            }
            if (firstAxis.Equals(secondAxis))
            {
                throw new ArgumentException("Equal Axes", "firstAxis and secondAxis cannot be equal");
            }
            axes[0] = firstAxis;
            axes[1] = secondAxis;
        }
    }
}
