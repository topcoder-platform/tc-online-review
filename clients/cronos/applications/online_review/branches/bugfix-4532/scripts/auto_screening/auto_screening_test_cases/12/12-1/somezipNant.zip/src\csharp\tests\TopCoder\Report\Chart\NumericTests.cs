// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;
using NUnit.Framework;
using System.Collections;

namespace TopCoder.Report.Chart.Elements {
    /// <summary>
    /// This test class will test Numeric Class.
    /// </summary>
    [TestFixture]
    public class NumericTests
    {
        /// <summary>
        /// Numeric used for tests
        /// </summary>
        Numeric numeric;

        /// <summary>
        /// Attributes setup for common tests.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            numeric = new Numeric(1);
        }
        
        /// <summary>
        /// Tests value property
        /// </summary>
        [Test]
        public void ValuePropertyTest()
        {
            Assert.AreEqual(1, numeric.Value);
        }
        
        /// <summary>
        /// Tests changing value property
        /// </summary>
        [Test]
        public void ChangeValuePropertyTest()
        {
            numeric.Value = 2;
            Assert.AreEqual(2, numeric.Value);
        }
        
        /// <summary>
        /// Tests equelity
        /// </summary>
        [Test]
        public void ToDoubleTest()
        {
            Assert.AreEqual(1, numeric.ToDouble());
        }
    }
}
