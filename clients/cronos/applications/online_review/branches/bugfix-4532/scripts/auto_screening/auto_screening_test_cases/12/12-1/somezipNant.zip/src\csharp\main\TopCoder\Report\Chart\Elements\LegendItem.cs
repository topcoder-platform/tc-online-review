// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System.Drawing;
using System;

namespace TopCoder.Report.Chart.Elements 
{
    /// <summary>
    /// <p>LegendItem class encapsulates the information for a legend
    /// for a specific Series.</p>
    /// <p>If any attribute key (defined by this component or by the
    /// application) has not been defined in this LegendItem, the
    /// attribute will default to what (if any) value that is specified
    /// in the Series.</p>
    /// <p>The application can reset the legend information back to its
    /// default values (as specified by the Series) by simply call of
    /// ClearAttributes() method.</p>
    /// <p>This class will override the AttributableObject get-indexer
    /// method to retrieve the Series's attribute information if
    /// it has has not been specified for this class. This class  will
    /// be created by the Series class.</p>
    /// </summary>
    
    public class LegendItem : AttributableObject 
    {
        /// Attribute series
        /// <summary>
        /// <p>This variable represents the Series that this legend
        /// information is about. </p>
        /// <p>This variable is set at construction time and has an
        /// immutable reference to the associated Series. This variable is
        /// referenced by the get-indexer and getter methods to provide
        /// default attribute values.</p>
        /// </summary>
        private Series series = null;
        
        /// Attribute Series
        /// <summary>
        /// <p>Returns Series to associate 0with this class.</p>
        /// </summary>
        public Series Series 
        {
            get 
            {
                return series;
            }
        }
        
        /// Attribute Label
        /// <summary>
        /// <p>Overridden property for attribute Label.</p>
        /// <p>Getter method gets base.Label. If it is not null the method
        /// returns it, otherwise - series.Label.</p>
        /// <p>Setter method just does this["label"] = value.</p>
        /// <p>As LegendItem instance has default value for label it can
        /// set label attribute to null.</p>
        /// </summary>
        public override string Label 
        {
            get 
            {
                return base.Label != null ? base.Label : series.Label;
            }
            set 
            {
                // Avoiding the enlargement of the collection if the value is null. (it is its default)
                if (value == null) 
                {
                    attributes.Remove("label");
                } 
                else
                {
                    this["label"] = value;
                }
            }
        }
        
        /// Attribute Color
        /// <summary>
        /// <p>Overridden property for attribute Color.</p>
        /// <p>Getter method gets base.Color. If it is not null the method
        /// returns it, otherwise - series.Color.</p>
        /// <p>Setter method just does base.Color = value.</p>
        /// </summary>
        public override Color Color 
        {
            get 
            {
                return base.Color != Color.Empty ? base.Color : series.Color;
            }
            set 
            {
                base.Color = value;
            }
        }
        
        /// Attribute Annotation
        /// <summary>
        /// <p>Overridden property for attribute Annotation.</p>
        /// <p>Getter method gets base.Annotation. If it is not null the
        /// method returns it, otherwise - series.Annotation.</p>
        /// <p>Setter method just does base.Annotation = value.</p>
        /// </summary>
        public override string Annotation 
        {
            get 
            {
                return base.Annotation != null ? base.Annotation : series.Annotation;
            }
            set 
            {
                base.Annotation = value;
            }
        }
        
        /// Attribute Icon
        /// <summary>
        /// <p>Overridden property for attribute Icon.</p>
        /// <p>Getter method this["icon"]. If it is not null the
        /// method returns it, otherwise - series.Icon.</p>
        /// <p>Setter method just does this["icon"] = value.</p>
        /// </summary>
        public object Icon
        {
            get 
            {
                return this["icon"] != null ? this["icon"] : series.Icon;
            }
            set 
            {
                // Avoiding the enlargement of the collection if the value is null. (it is its default)
                if (value == null) 
                {
                    attributes.Remove("icon");
                } 
                else
                {
                    this["icon"] = value;
                }
            }
        }
        
        /// Constructor LegendItem
        /// <summary>
        /// <p>Constructs new LegendItem for given series. Sets series
        /// variable</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='series'>series to associate with this object</param>
        public LegendItem(Series series) 
        {
            if (series == null)
            {
                throw new ArgumentNullException("series", "series cannot be null");
            }
            this.series = series;
        }
        
        /// Operation this
        /// <summary>
        /// <p>Getter indexer of class. Returns attribute object to
        /// associate with specified key. If key is not found returns
        /// appropriate attribute value of series.</p>
        /// <p>Getter indexer of class. Sets the attribute associated with the specified key.
        /// If the specified key is not found creates a new element using the specified key
        /// and value.</p>
        /// </summary>
        /// <exception>ArgumentNullException if key is null</exception>
        /// <param name='key'>key to locate attribute</param>
        /// <returns>value of attribute with given key</returns>
        public override object this[object key] 
        {
            get
            {
                if (key == null)
                {
                    throw new ArgumentNullException("key", "key cannot be null");
                }
                return attributes[key] != null ? attributes[key] : series[key];
            }
            set
            {
                if (key == null)
                {
                    throw new ArgumentNullException("key", "key cannot be null");
                }
                // Avoiding the enlargement of the collection if the value is null. (it is its default)
                if (value == null)
                {
                    attributes.Remove(key);
                }
                else
                {
                    attributes[key] = value;
                }
            }
        }
        
        /// Operation ClearAttributes
        /// <summary>
        /// <p>Clears all the attribute information defined. This method
        /// simply calls attributes.Clear() method.</p>
        /// </summary>
        /// <returns>void</returns>
        public override void ClearAttributes() 
        {
            attributes.Clear();
        }
    }
}
