// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using TopCoder.Report.Chart.Elements;

namespace TopCoder.Report.Chart
{
    
    /// <summary>
    /// <p> Represents bar chart.
    /// It is a 'horizontal histogram', in which data values are represented by horizontal bars.
    /// Not used widely, but particularly effective where each individualdata point has to be named.</p>
    /// <p> The bar chart can have several data series.
    /// It has two axes. Horizontal axis is value axis. Vertical axis is
    /// category axis.</p>
    /// <p> Every data point is rendered as rectange. Its width corresponds
    /// to data value.
    /// Its color is defined by series.Color (this behavior can be overriden).</p>
    /// <p> Bar can start from not zero point. Use ChartData attribute to
    /// model this behavior.</p>
    /// <p> The category can have one or more value depended on bar chart
    /// kind.
    /// Use appropriate ChartData class to model it.</p>
    /// </summary>
    
    public class BarChart : Axial2DChart 
    {
        /// Constructor BarChart
        /// <summary>
        /// <p>Constructs bar chart with given label and axis specified in
        /// second and third parameters.</p>
        /// <p>Simply uses base constructor</p>
        /// </summary>
        /// <exception>ArgumentNullException if any parameter is null</exception>
        /// <param name='label'>label to associate with chart</param>
        /// <param name='categoryAxis'>category axis</param>
        /// <param name='valueAxis'>value axis</param>
        public BarChart(string label, Axis categoryAxis, Axis valueAxis) : base(label, categoryAxis, valueAxis) 
        {
        }
    }
    
}
