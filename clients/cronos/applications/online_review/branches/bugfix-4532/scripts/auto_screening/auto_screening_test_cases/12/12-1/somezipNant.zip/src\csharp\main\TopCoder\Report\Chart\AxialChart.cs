// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System.Collections;
using TopCoder.Report.Chart.Elements;
using System;

namespace TopCoder.Report.Chart 
{
    /// <summary>
    /// <p>A chart that contains single axis or multiple axes. All chart implementations that contain axes
    /// (histograms, 2D charts and so on) should extend this class.</p>
    /// <p>The axial chart contains a fixed number of axes that is specified during class construction. The
    /// number of axes cannot be changed after construction.</p>
    /// </summary>
    public abstract class AxialChart : Chart
    {
        /// Attribute axes
        /// <summary>
        /// <p>A set of axes associated with this AxialChart</p>
        /// </summary>
        protected IList axes = null;
        
        /// Attribute AxisCount
        /// <summary>
        /// <p>Returns the number of axes associated with AxialChart</p>
        /// </summary>
        public int AxisCount 
        {
            get 
            {
                return axes.Count;
            }
        }
        
        /// Attribute AxesSyncRoot
        /// <summary>
        /// <p>An object that can be used to synchronize access to data.</p>
        /// <p>Simply returns axes.SyncRoot</p>
        /// <p>Some operations (enumerating through a collection for example) are intrinsically not
        /// a thread-safe procedure. Even when a collection is synchronized, other threads could still
        /// modify the collection. To guarantee thread safety during operation execution,
        /// you should lock the collection during the entire enumeration.</p>
        /// <p>Lock this variable to prevents any access to axes list.</p>
        /// </summary>
        public object AxesSyncRoot 
        {
            get 
            {
                return axes.SyncRoot;
            }
        }
        
        /// Constructor AttributableObject
        /// <summary>
        /// <p>Constructs AxialChart with given label and given number of axes.</p>
        /// <p>Constructor creates ArrayList of fixed size and sets this.Label property.</p>
        /// </summary>
        /// <exception>ArgumentNullException if label is null</exception>
        /// <exception>ArgumentException if axisNumber is negative or zero value</exception>
        /// <param name='label'>label to associate with this chart</param>
        /// <param name='axisNumber'>axisNumber the number of axes</param>
        protected  AxialChart(string label, int axisNumber) : base(label) 
        {
            // base class will handle null label
            if (axisNumber <= 0)
            {
                throw new ArgumentException("axisNumber", "axisNumber cannot be <= 0");
            }
            
            // initializes the axes collection with null values to make it fixed.
            axes = new ArrayList(axisNumber);
            for (int i=0; i < axisNumber; i++) 
            {
                axes.Add(null);
            }
            
            // makes a fixed collection with count = axisNumber
            axes = ArrayList.FixedSize(axes);
            this.Label = label;
        }
        
        /// Operation GetAxis
        /// <summary>
        /// <p>Returns element of exes collection with given index.</p>
        /// </summary>
        /// <exception>ArgumentOutOfRangeException if index is not in range [0, axes.Count-1]</exception>
        /// <param name='index'>index of axes element</param>
        /// <returns>axis with given index</returns>
        public Axis GetAxis(int index) 
        {
            if (index < 0 || index >= axes.Count)
            {
                throw new ArgumentOutOfRangeException("index", "index must be between 0 and " 
                    + (axes.Count - 1).ToString());
            }
            return (Axis) axes[index];
        }
        
        /// Operation GetAxisIndex
        /// <summary>
        /// <p>Returns index of the first element of exes collection with given label.
        /// If there is no element returns null.</p>
        /// <p>This method iterates through axes collection. If current element.Label
        /// is equal to parameter returns it. If none is found returns null.</p>
        /// <p>To do this operation thread safe method should lock axes array using
        /// axes.SyncRoot</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='label'></param>
        public int GetAxisIndex(string label)
        {
            if (label == null)
            {
                throw new ArgumentNullException("label", "label could not be null");
            }
            lock (axes.SyncRoot) 
            {
                // enumerating axes for comparision
                IEnumerator axesEnum = axes.GetEnumerator();
                for (int i=0; axesEnum.MoveNext(); i++) 
                {
                    if (((Axis) axesEnum).Label == label)
                    {
                        return i;
                    }
                }
            }
            return -1;
        }
        
        /// Operation SetAxis
        /// <summary>
        /// <p>Set axis with given label to given value.</p>
        /// <p>Simply uses axes[GetIndex(label)]=value</p>
        /// <p>To do this operation thread safe method should lock axes array using
        /// axes.SyncRoot</p> 
        /// </summary>
        /// <exception>ArgumentNullException if any parameter is null</exception>
        /// <exception>ArgumentException if GetIndex(label) returns -1</exception>
        /// <param name='label'>label to associate with axis element</param>
        /// <param name='axis'>new value of element</param>
        /// <returns>void</returns>
        public void SetAxis(string label, Axis axis) 
        {
            if (label == null)
            {
                throw new ArgumentNullException("label", "label cannot be null");
            }
            if (axis == null)
            {
                throw new ArgumentNullException("axis", "axis cannot be null");
            }
            if (GetIndex(label) == -1)
            {
                throw new ArgumentException("label", "label could not be found");
            }
            lock (axes.SyncRoot) 
            {
                foreach (Axis axisItem in axes) 
                {
                    if (axis.Equals(axisItem)) 
                    {
                        throw new ArgumentException("axis", "axis already exists");
                    }
                }
                axes[GetIndex(label)]=axis;
            }
        }
    }
}

