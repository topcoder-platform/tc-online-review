// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;
using NUnit.Framework;
using System.Collections;
using TopCoder.Report.Chart.Elements;

namespace TopCoder.Report.Chart {
    /// <summary>
    /// This test class will test AxialChart Class.
    /// </summary>
    [TestFixture]
    public class AxialChartTests
    {
        #region "class MockAxialChart"
        /// <summary>
        /// This class inherits from AxialChart.
        /// </summary>
        private class MockAxialChart: AxialChart
        {
            /// <summary>
            /// Create a MockAxialChart, calling the base constructor.
            /// </summary>
            /// <param name="label">label for the chart</param>
            /// <param name="axisNumber">axisNumber of the chart</param>
            public MockAxialChart(string label, int axisNumber) : base (label, axisNumber)
            {
            }
        }
        #endregion
        
        /// <summary>
        /// MockAxialChart used for tests
        /// </summary>
        MockAxialChart mockAxialChart;
        
        /// <summary>
        /// Attributes setup for common tests.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            mockAxialChart = new MockAxialChart("mock1", 2);
        }
        
        /// <summary>
        /// Tests null constructor
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorNullParamTest()
        {
            new MockAxialChart(null, 2);
        }
        
        /// <summary>
        /// Tests invalid parameter in constructor
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void ConstructorNullParamTest2()
        {
            new MockAxialChart("axialChart1", 0);
        }
        
        /// <summary>
        /// Tests invalid parameter in constructor
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void ConstructorNullParamTest3()
        {
            new MockAxialChart("axialChart1", -1);
        }
    }
}
