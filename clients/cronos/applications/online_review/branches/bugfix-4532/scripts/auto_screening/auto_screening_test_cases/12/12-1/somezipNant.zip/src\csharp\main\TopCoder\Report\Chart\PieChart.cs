// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using TopCoder.Report.Chart.Elements;
using System;

namespace TopCoder.Report.Chart 
{
    /// <summary>
    /// <p>Represents pie chart. A pie chart is a circular chart divided
    /// into segments, illustrating relative magnitudes or frequencies.</p>
    /// <p>This chart has only data series. Every element of data series
    /// renders as circle segment with appropriate arc length (and
    /// consequently, the central angle and the area). </p>
    /// <p>A chart with one or more wedge separated from the rest of the disk
    /// is called an exploded pie chart. Use ChartData attributes to model
    /// this behavior.</p>
    /// <p>Some data corresponded to the small values are combined into one
    /// group "Others". Use MultiValue to model it.</p>
    /// </summary>
    public class PieChart : Chart 
    {
        /// Attribute Series
        /// <summary>
        /// <p>Get property for pie chart data series. Uses GetSeries(0) method.</p>
        /// </summary>
        public Series Series 
        {
            get 
            {
                return (GetSeries(0));
            }
        }
        
        /// Constructor PieChart
        /// <summary>
        /// <p>Constructs pie chart with given label and data series.</p>
        /// <p>Uses base(label) constructor. Adds given series to series
        /// collection. Fixes series collection size.</p>
        /// </summary>
        /// <exception>ArgumentNullException if any parameter is null</exception>
        /// <param name='label'>label to associate with pie chart</param>
        /// <param name='series'>data series to associate with chart</param>
        public PieChart(string label, Series series) : base(label) 
        {
            // base class will handle null label
            AddSeries(series);
            FixSize();
        }
    }
}
