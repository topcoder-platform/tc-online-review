// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System.Collections;
using System;

namespace TopCoder.Report.Chart.Elements 
{
    /// <summary>
    /// <p>A ChartData that may contain several values associated with
    /// it. Such objects could be used in multi-axial charts, for
    /// example, 2D charts. The values of such MultiValue objects are
    /// associated with some key. In axial charts the axes can be used
    /// as a key to associate with values.</p>
    /// </summary>
    public class MultiValue : ChartData 
    {
        /// Constructor MultiValue
        /// <summary>
        /// <p>Constructs a new MultiValue with given label.</p>
        /// <p>Simply uses base(label)</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='label'>label to associate with this MultiValue
        /// object</param>
        public MultiValue(string label) : base(label) 
        {
            // base class will handle a null label
        }
        
        /// Constructor MultiValue
        /// <summary>
        /// <p>Constructs a new MultiValue with given label and data.</p>
        /// <p>This constructor simply uses base(label, data)</p>
        /// </summary>
        /// <exception>ArgumentNullException if any parameter is null</exception>
        /// <param name='label'>label to associate with the MultiValue object</param>
        /// <param name='data'>data to associate with the MultiValue object</param>
        public MultiValue(string label, IDictionary data) : base(label, data) 
        {
            // base class will handle a null label
        }
        
        /// Operation AddValue
        /// <summary>
        /// <p>Adds new value to data collection. If an element with the
        /// same key already exists method throws ArgumentException.</p>
        /// <p>Simply uses data.Add(key, dataValue) method.</p>
        /// </summary>
        /// <exception>ArgumentNullException if any parameter is null</exception>
        /// <exception>ArgumentException if en element with the same key
        /// already exists</exception>
        /// <param name='key'>key to associate with value</param>
        /// <param name='dataValue'>new value</param>
        /// <returns>void</returns>
        public void AddValue(object key, INumeric dataValue) 
        {
            if (GetValue(key) != null) 
            {
                throw new ArgumentException("key","key cannot exist in the collection");
            }
            SetValue(key, dataValue);
        }
        
        /// Operation RemoveValue
        /// <summary>
        /// <p>Removes element with the given key. If
        /// data collection does not contain an element with the specified
        /// key, it remains unchanged.</p>
        /// <p>Simply uses data.Remove(key) method.</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='key'>key to associate with value</param>
        /// <returns>void</returns>
        public void RemoveValue(object key) 
        {
            if (key == null) 
            {
                throw new ArgumentNullException("key","key cannot be null");
            }
            
            data.Remove(key);
        }
        
        /// Operation GetEnumerator
        /// <summary>
        /// <p>Returns enumerator for data collection.</p>
        /// <p>Simply uses data.GetEnumerator() method</p>
        /// </summary>
        /// <returns> enumerator for data collection</returns>
        public IDictionaryEnumerator GetEnumerator() 
        {
            return data.GetEnumerator();
        }
    }
    
}
