// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;
using System.Drawing;
using System.Collections;
using NUnit.Framework;
using System.Threading;
using TopCoder.Report.Chart.Elements;

namespace TopCoder.Report.Chart
{
    /// <summary>
    /// Shows hows notification are sent
    /// </summary>
    [TestFixture]
    public class chart_dataDemo
    {
        /// <summary>
        /// Axis for the demo
        /// </summary>
        private Axis horizontal;
        
        /// <summary>
        /// Axis for the demo
        /// </summary>
        private Axis vertical;
        
        /// <summary>
        /// Chart for the demo
        /// </summary>
        private Chart chart;
        
        /// <summary>
        /// Series for the demo
        /// </summary>
        private Series reds;
        
        /// <summary>
        /// ChartData for the demo
        /// </summary>
        private ChartData reds235;
        
        /// <summary>
        /// ChartData for the demo
        /// </summary>
        private ChartData reds236;
        
        /// <summary>
        /// ChartData for the demo
        /// </summary>
        private ChartData reds237;
        
        /// <summary>
        /// LegendItem for the demo
        /// </summary>
        private LegendItem redsLegend;
        
        /// <summary>
        /// Series for the demo
        /// </summary>
        private Series yellows;
        
        /// <summary>
        /// ChartData for the demo
        /// </summary>
        private ChartData yellows235;
        
        /// <summary>
        /// ChartData for the demo
        /// </summary>
        private ChartData yellows236;
        
        /// <summary>
        /// ChartData for the demo
        /// </summary>
        private ChartData yellows237;
        
        /// <summary>
        /// LegendItem for the demo
        /// </summary>
        private LegendItem yellowsLegend;
        
        /// <summary>
        /// Series for the demo
        /// </summary>
        private Series blues;
        
        /// <summary>
        /// ChartData for the demo
        /// </summary>
        private ChartData blues235;
        
        /// <summary>
        /// ChartData for the demo
        /// </summary>
        private ChartData blues236;
        
        /// <summary>
        /// ChartData for the demo
        /// </summary>
        private ChartData blues237;
        
        /// <summary>
        /// LegendItem for the demo
        /// </summary>
        private LegendItem bluesLegend;
        
        /// <summary>
        /// Legend for the demo
        /// </summary>
        private Legend legend;
        
        /// <summary>
        /// String for Chart's Name
        /// </summary>
        private string chartName;
        
        /// <summary>
        /// Chart's Background Color
        /// </summary>
        private Color backgroundColor;
        
        /// <summary>
        /// Int for seriesCount
        /// </summary>
        private int seriesCount;
        
        /// <summary>
        /// String for Legend
        /// </summary>
        private string legendLabel;
        
        /// <summary>
        /// Color for Legend's Background Color
        /// </summary>
        private Color legendBackgroundColor;
        
        /// <summary>
        /// Setting up common objects for the demo
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            //-------------------------------------------------------
            //             Chart data creation
            //-------------------------------------------------------
            
            // Create horizontal axis labeled with "SRM"
            horizontal = new Axis("SRM");
            
            // Create vertical axis labeled with "percents"
            vertical = new Axis("percents");
            
            // Specify minimum and maximum value for  vertical axis
            vertical.MinimumValue =  0;
            vertical.MaximumValue = 100;
            
            // Create a 2D axial chart with given axes
            chart = new Axial2DChart("SRM statistics", horizontal, vertical);
            
            // set chart background color
            chart["backgroundcolor"] = Color.Gray;
            
            //create Series for reds
            reds = new Series("reds");
            
            //set series attribute
            reds.Color = Color.Red;
            
            // create SingleValue for data points for reds
            // we use absolute values, to convert them into percents is the chart renderer task.
            reds235 = new SingleValue("235", new Numeric(10));
            reds236 = new SingleValue("236", new Numeric(20));
            reds237 = new SingleValue("237", new Numeric(30));
            
            //add data points to Series
            reds.Add(reds235);
            reds.Add(reds236);
            reds.Add(reds237);
            
            //add Series to chart
            chart.AddSeries(reds);
            
            //get this series legend and
            //set some attributes of this series legend info
            redsLegend = reds.LegendItem;
            redsLegend.Label = "Reds";
            
            //create Series for yellows
            yellows = new Series("yellow");
            
            //set series attribute
            yellows.Color = Color.Yellow;
            
            // create SingleValue for data points for yellows
            // we use absolute values, to convert them into percents is the chart renderer task.
            yellows235 = new SingleValue("235", new Numeric(40));
            yellows236 = new SingleValue("236", new Numeric(40));
            yellows237 = new SingleValue("237", new Numeric(40));
            
            //add data points to Series
            yellows.Add(yellows235);
            yellows.Add(yellows236);
            yellows.Add(yellows237);
            
            //add Series to chart
            chart.AddSeries(yellows);
            
            //get this series legend and
            //set some attributes of this series legend info
            yellowsLegend = yellows.LegendItem;
            yellowsLegend.Label = "Yellows";
            
            //create Series for blues
            blues = new Series("blues");
            
            //set series attribute
            blues.Color = Color.Blue;
            
            // create SingleValue for data points for blues
            // we use absolute values, to convert them into percents is the chart renderer task.
            blues235 = new SingleValue("235", new Numeric(50));
            blues236 = new SingleValue("236", new Numeric(40));
            blues237 = new SingleValue("237", new Numeric(30));
            
            //add data points to Series
            blues.Add(blues235);
            blues.Add(blues236);
            blues.Add(blues237);
            
            //add Series to chart
            chart.AddSeries(blues);
            
            //get this series legend and
            //set some attributes of this series legend info
            bluesLegend = blues.LegendItem;
            bluesLegend.Label = "Blues";
            
            //customize chart legend
            // override chart background color value
            legend = chart.Legend;
            legend["backgroundcolor"] = Color.White;
            
            //----------------------------------------------------------
            //  Chart data information getting
            //----------------------------------------------------------
            
            // get chart attribute
            chartName = chart.Label;
            backgroundColor = (Color) chart["backgroundcolor"];
            seriesCount = chart.SeriesCount;
            
            // get chart legend
            legend = chart.Legend;
            
            // get legend label (returns chart label)
            legendLabel = legend.Label;
            
            // get legend background color (returns overridden value)
            legendBackgroundColor = (Color) legend["backgroundcolor"];
        }
        
        /// <summary>
        /// Demo as specified in Component Specification
        /// </summary>
        [Test]
        public void demoSpecs()
        {
            Console.WriteLine("");
            Console.WriteLine("---------------= Chart Specs Demo =----------------");
            Console.WriteLine("");
            
            // print series information
            for(int i=0; i<chart.SeriesCount; i++)
            {
                Series series = chart.GetSeries(i);
                
                // print series label
                Console.WriteLine(series.Label);
                
                foreach(ChartData point in series)
                {
                    //print data point label and value
                    Console.WriteLine("  *-- SRM " + point.Label + " - " 
                        + (int)((SingleValue)point).Data.ToDouble());
                }
            }
        }
        
        /// <summary>
        /// Rendering example Demo
        /// </summary>
        [Test]
        public void renderDemo()
        {
            Console.WriteLine("");
            Console.WriteLine("---------------= Chart Rendering Demo =----------------");
            Console.WriteLine("");
            Console.WriteLine("Rendering chart...");
            Console.WriteLine("");
            Console.WriteLine(chart.Label);
            Console.WriteLine("");
            // print series information
            bool firstOne;
            for(int k=0; k<3; k++)
            {
                firstOne = true;
                Console.Write("   ");
                for(int i=0; i<chart.SeriesCount; i++)
                {
                    Series series = chart.GetSeries(i);
                    
                    // Renders the graph horizontally.
                    for (int j=0; j < (int)(((SingleValue)series.GetValue(k)).Data.ToDouble()/10); j++) 
                    {
                        if (firstOne) 
                        {
                            Console.Write(series.GetValue(k).Label.ToString());
                            Console.Write(" - ");
                            firstOne = false;
                        }
                        
                        // Renders B, Y or R for every %10 in the series value.
                        if (series.Color == Color.Blue) 
                        {
                            Console.Write("[B]");
                        }
                        if (series.Color == Color.Yellow) 
                        {
                            Console.Write("[Y]");
                        }
                        if (series.Color == Color.Red) 
                        {
                            Console.Write("[R]");
                        }
                    }
                }
                Console.WriteLine("");
                Console.WriteLine("");
            }
            
            // Finally renders legends.
            Console.WriteLine("Legends:");
            Console.WriteLine("");
            Console.WriteLine(" R - " + redsLegend.Label);
            Console.WriteLine(" Y - " + yellowsLegend.Label);
            Console.WriteLine(" B - " + bluesLegend.Label);
        }
    }
}
