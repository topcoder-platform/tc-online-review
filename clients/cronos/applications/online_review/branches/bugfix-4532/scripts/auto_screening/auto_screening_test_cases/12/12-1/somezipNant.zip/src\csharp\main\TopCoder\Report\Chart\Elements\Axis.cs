// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;

namespace TopCoder.Report.Chart.Elements 
{
    /// <summary>
    /// <p>An axis used to render the axial charts. This version contains
    /// only a label associated with it. The Axis objects can be used as
    /// a key to be associated with values in MultiValue objects.</p>
    /// </summary>
    public class Axis : AttributableObject 
    {
        /// Attribute _MINIMAL_VALUE
        /// <summary>
        /// <p>Private constant for holding the value of minimal_value attribute name.</p>
        /// </summary>
        private const string _MINIMAL_VALUE = "minimal_value";

        /// Attribute _MAXIMAL_VALUE
        /// <summary>
        /// <p>Private constant for holding the value of maximal_value attribute name.</p>
        /// </summary>
        private const string _MAXIMAL_VALUE = "maximal_value";
        
        /// Attribute MinimumValue
        /// <summary>
        /// <p>Property for the attributte MinimalValue.</p>
        /// <p>This optional attribute is the minimum value from numeric
        /// representation of chart elements for this axis.</p>
        /// <p>Getter method just returns this[_MINIMAL_VALUE].
        /// If key is not found method returns null.</p>
        /// <p>Setter method just does this[_MINIMAL_VALUE] =
        /// value If key is not found method creates element with key
        /// "color" and specified value.</p>
        /// </summary>
        public double MinimumValue 
        {
            get 
            {
                return (this[_MINIMAL_VALUE] == null || !(this[_MINIMAL_VALUE] is double)) 
                    ? double.NaN : (double) this[_MINIMAL_VALUE];
            }
            set {
                // Improved performance: Avoiding the enlargement of the collection if the 
                // value is double.NaN. (it is its default)
                if (value == double.NaN) 
                {
                    attributes.Remove(_MINIMAL_VALUE);
                } 
                else 
                {
                    if (MaximumValue != double.NaN) 
                    {
                        if (value > MaximumValue) 
                        {
                            throw new ArgumentException("MinimumValue", 
                                "MinimumValue cannot be greater than MaximumValue");
                        }
                    }
                    this[_MINIMAL_VALUE] = value;
                }
            }
        }
        
        /// Attribute MaximumValue
        /// <summary>
        /// <p>Property for the attributte MaximalValue.</p>
        /// <p>This optional attribute is the maximum value from numeric
        /// representation of chart elements for this axis.</p>
        /// <p>Getter method just returns this[_MAXIMAL_VALUE].
        /// If key is not found method returns null.</p>
        /// <p>Setter method just does this[_MAXIMAL_VALUE] =
        /// value If key is not found method creates element with key
        /// "color" and specified value.</p>
        /// </summary>
        public double MaximumValue 
        {
            get 
            {
                return (this[_MAXIMAL_VALUE] == null || !(this[_MAXIMAL_VALUE] is double)) 
                    ? double.NaN : (double) this[_MAXIMAL_VALUE];
            }
            set 
            {
                // Improved performance: Avoiding the enlargement of the collection if the 
                // value is double.NaN. (it is its default)
                if (value == double.NaN) 
                {
                    attributes.Remove(_MAXIMAL_VALUE);
                } 
                else
                {
                    if (MinimumValue != double.NaN) 
                    {
                        if (value < MinimumValue) 
                        {
                            throw new ArgumentException("MaximumValue", 
                                "MaximumValue cannot be less than MinimumValue");
                        }
                    }
                    this[_MAXIMAL_VALUE] = value;
                }
            }
        }
        
        /// Constructor Axis
        /// <summary>
        /// <p>Constructs a new Axis with specified label.</p>
        /// <p>Simply uses base(label)</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='label'>label to associate with axis</param>
        public Axis(string label): base(label)
        {
            // base class will handle a null label
        }
        
        /// Operation Equals
        /// <summary>
        /// Overridden method of object object. Determines whether the
        /// specified object is equal to the current axis object.
        /// <p>Axis objects with the same label are equal, otherwise they
        /// are not.</p>
        /// </summary>
        /// <param name='o'>object to compare with current axis object</param>
        /// <returns>true if the specified Object is equal to the this axis
        /// object; otherwise, false.</returns>
        public override bool Equals(object o) 
        {
            // try catches Cast exception if it exists. (if object is of a different type, just return false)
            bool areEqual = false;
            try 
            {
                areEqual = (((Axis) o).Label == this.Label);
            } 
            catch 
            {
                // silently ignore all errors.
            }
            return (areEqual);
        }
        
        /// Operation GetHashCode
        /// <summary>
        /// <p>Overridden method of object object. Returns
        /// a hash code for the current Axis object.</p>
        /// <p>Hashcode of Axis object is equal of hashcode of its label.</p>
        /// </summary>
        /// <returns>A hash code for the current axis object</returns>
        public override int GetHashCode() 
        {
            return this.Label.GetHashCode();
        }
    }
    
}
