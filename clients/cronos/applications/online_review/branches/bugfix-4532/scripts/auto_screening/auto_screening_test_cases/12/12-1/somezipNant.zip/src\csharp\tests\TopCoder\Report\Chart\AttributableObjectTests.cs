// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;
using NUnit.Framework;
using System.Drawing;
using System.Collections;

namespace TopCoder.Report.Chart.Elements 
{
    /// <summary>
    /// This test class will test AttributableObject Class.
    /// </summary>
    [TestFixture]
    public class AttributableObjectTests
    {
        
        #region "class MockIndex"
        /// <summary>
        /// This class inherits from AttributableObject.
        /// </summary>
        private class MockAttributableObject: AttributableObject
        {
            /// <summary>
            /// Create a MockAttributableObject, calling the base constructor. (without params)
            /// </summary>
            public MockAttributableObject() : base ()
            {
            }
            
            /// <summary>
            /// Create a MockAttributableObject, calling the base constructor. (with label param)
            /// </summary>
            /// <param name="label">the label for the AttributableObject</param>
            public MockAttributableObject(string label) : base (label)
            {
            }
        }
        #endregion
        
        
        /// <summary>
        /// The MockAttributableObject that will be used for testing the abstract class
        /// </summary>
        private MockAttributableObject MockAttObj;
        
        
        /// <summary>
        /// Attributes setup for common tests.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            MockAttObj = new MockAttributableObject();
        }
        
        /// <summary>
        /// Tests null constructor
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullConstructorTest()
        {
            new MockAttributableObject(null);
        }
        
        /// <summary>
        /// Tests null label set
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullLabelSetTest()
        {
            MockAttObj.Label = null;
        }
        
        /// <summary>
        /// Tests label set in constructor
        /// </summary>
        [Test]
        public void LabelSetInConstructorTest()
        {
            MockAttributableObject MockAttObj2 = new MockAttributableObject("label1") ;
            Assert.AreEqual("label1", MockAttObj2.Label);
        }
        
        /// <summary>
        /// Tests label set and get
        /// </summary>
        [Test]
        public void LabelSetGetTest()
        {
            MockAttObj.Label = "label1";
            Assert.AreEqual("label1", MockAttObj.Label);
        }
        
        /// <summary>
        /// Tests color set and get
        /// </summary>
        [Test]
        public void ColorSetGetTest()
        {
            MockAttObj.Color = Color.Beige;
            Assert.AreEqual(Color.Beige, MockAttObj.Color);
        }
        
        /// <summary>
        /// Tests null color get
        /// </summary>
        [Test]
        public void ColorGetNullTest()
        {
            Assert.AreEqual(Color.Empty, MockAttObj.Color);
        }
        
        /// <summary>
        /// Tests null annotation set
        /// </summary>
        [Test]
        public void NullAnnotationSetTest()
        {
            MockAttObj.Annotation = null;
        }
        
        /// <summary>
        /// Tests annotation set and get
        /// </summary>
        [Test]
        public void AnnotationSetGetTest()
        {
            MockAttObj.Annotation = "annotation1";
            Assert.AreEqual("annotation1", MockAttObj.Annotation);
        }
        
        /// <summary>
        /// Tests null annotation get
        /// </summary>
        [Test]
        public void AnnotationGetNullTest()
        {
            Assert.AreEqual(null, MockAttObj.Annotation);
        }
        
        /// <summary>
        /// Tests all properties set and get
        /// </summary>
        [Test]
        public void AllPropertiesSetGetTest()
        {
            MockAttObj.Label = "label1";
            MockAttObj.Color = Color.Beige;
            MockAttObj.Annotation = "annotation1";
            Assert.AreEqual("label1", MockAttObj.Label);
            Assert.AreEqual(Color.Beige, MockAttObj.Color);
            Assert.AreEqual("annotation1", MockAttObj.Annotation);
        }
        
        /// <summary>
        /// Tests all properties set and get repeatedly
        /// </summary>
        [Test]
        public void AllPropertiesSetGetTwiceTest()
        {
            INumeric a = new Numeric(10);
            INumeric b = null;

            string pepe = null;
            
            string s = pepe as string;
            

            MockAttObj.Label = "label1";
            MockAttObj.Label = "label2";
            MockAttObj.Color = Color.Beige;
            MockAttObj.Color = Color.Aqua;
            MockAttObj.Annotation = "annotation1";
            MockAttObj.Annotation = "annotation2";
            Assert.AreEqual("label2", MockAttObj.Label);
            Assert.AreEqual(Color.Aqua, MockAttObj.Color);
            Assert.AreEqual("annotation2", MockAttObj.Annotation);
        }
        
        /// <summary>
        /// Tests indexer
        /// </summary>
        [Test]
        public void IndexerTest()
        {
            MockAttObj["1"] = "one";
            MockAttObj["2"] = "t-o";
            MockAttObj["2"] = "two";
            
            Assert.AreEqual("one", MockAttObj["1"]);
            Assert.AreEqual("two", MockAttObj["2"]);
        }
        
        /// <summary>
        /// Tests clearing attributes
        /// </summary>
        [Test]
        public void ClearAttributesTest()
        {
            MockAttObj.Label = "label1";
            MockAttObj.Color = Color.Beige;
            MockAttObj.Annotation = "annotation1";
            Assert.AreEqual("label1", MockAttObj.Label);
            Assert.AreEqual(Color.Beige, MockAttObj.Color);
            Assert.AreEqual("annotation1", MockAttObj.Annotation);
            MockAttObj.ClearAttributes();
            Assert.AreEqual("label1", MockAttObj.Label);
            Assert.AreEqual(Color.Empty , MockAttObj.Color);
            Assert.AreEqual(null, MockAttObj.Annotation);
        }
        
        /// <summary>
        /// Tests getting attribute enumerator
        /// </summary>
        [Test]
        public void GetAttributeEnumeratorTest()
        {
            MockAttObj.Label = "label1";
            MockAttObj.Color = Color.Beige;
            MockAttObj.Annotation = "annotation1";
            IDictionaryEnumerator attEnum = MockAttObj.GetAttributeEnumerator();
            while (attEnum.MoveNext()) 
            {
                if (attEnum.Key.ToString()  == "label") 
                {
                    Assert.AreEqual("label1", attEnum.Value.ToString());
                }
                if (attEnum.Key.ToString()  == "color") 
                {
                    Assert.AreEqual(Color.Beige, (Color)attEnum.Value);
                }
                if (attEnum.Key.ToString()  == "annotation") 
                {
                    Assert.AreEqual("annotation1", attEnum.Value.ToString());
                }
            }
        }
    }
}
