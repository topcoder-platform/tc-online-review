// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;
using System.Collections;
using TopCoder.Report.Chart.Elements;

namespace TopCoder.Report.Chart 
{
    /// <summary>
    ///</summary>
    public abstract class Chart : AttributableObject
    {
        /// Attribute legend
        /// <summary>
        /// <p>This variable represents the legend used for this chart.
        /// This variable is created at instantiation time and will be
        /// immutable through the life of the Chart.</p>
        /// <p>Since the ChartLegend is an nested
        /// class, will have access to all the Chart variables and methods.</p>
        /// </summary>
        private Legend legend;
        
        
        /// Attribute series
        /// <summary>
        /// <p>This variable represents a list of series associated with tis chart</p>
        /// </summary>
        private IList series = ArrayList.Synchronized(new ArrayList());
        
        
        /// Attribute Legend
        /// <summary>
        /// <p>Returns legend variable for this chart.
        /// and bool Equals(object o)</p>
        /// </summary>
        public Legend Legend 
        {
            get 
            {
                return legend;
            }
        }
        
        /// Attribute SyncRoot
        /// <summary>
        /// <p>An object that can be used to synchronize access to chart data.</p>
        /// <p>Simply returns series.SyncRoot</p>
        /// <p>Lock this variable to prevents any access to this chart series collection
        /// from other threads.</p>
        /// </summary>
        public object SyncRoot 
        {
            get 
            {
                return series.SyncRoot;
            }
        }
        
        /// Attribute SeriesCount
        /// <summary>
        /// <p>Returns the number of series associated with Chart</p>
        /// </summary>
        public int SeriesCount 
        {
            get 
            {
                return series.Count;
            }
        }
        
        /// Constructor Chart(
        /// <summary>
        /// <p>Constructs chart with given label.</p>
        /// <p>Uses base(label) constructor.</p>
        /// </summary>
        /// <param name='label'>label to associate with this chart</param>
        protected Chart(string label) : base(label) 
        {
            legend = new Legend(this);
        }
        
        /// Operation GetSeries
        /// <summary>
        /// <p>Returns series with given index.</p>
        /// <p>Simply returns series[index]</p>
        /// </summary>
        /// <exception>ArgumentOutOfRangeException if index is not in range [0, series.Count-1]</exception>
        /// <param name='index'>element index</param>
        /// <returns>series with given index</returns>
        public Series GetSeries(int index) 
        {
            if (index < 0 || index >= series.Count)
            {
                throw new ArgumentOutOfRangeException("index", "index must be between 0 and " 
                    + (series.Count - 1).ToString());
            }
            return (Series) series[index];
        }
        
        
        /// Operation GetIndex
        /// <summary>
        /// <p>Returns index of the first element to contain Series with given label.
        /// If none is found returns -1.</p>
        /// <p>This method iterates through series collection. If element.Label
        /// is equal to parameter method returns index of this element. If there is
        /// no element with this label the method returns -1</p>
        /// <p>To do this operation thread safe method should lock series array
        /// using series.SyncRoot</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='label'>label to locate in series collection</param>
        /// <returns>index of the first element with given label</returns>
        public int GetIndex(string label) 
        {
            if (label == null){
                throw new ArgumentNullException("label", "label cannot be null");
            }
            
            lock (series.SyncRoot) 
            {
                IEnumerator seriesEnum = series.GetEnumerator();
                for (int i=0; seriesEnum.MoveNext(); i++) 
                {
                    if (((Series) seriesEnum.Current).Label == label) 
                    {
                        return i;
                    }
                }
            }
            return -1;
        }
        
        /// Operation AddSeries
        /// <summary>
        /// <p>Adds series to this chart.</p>
        /// <p>Simply uses series.Add(series)</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <exception>NotSupportedException if collection has fixed size</exception>
        /// <param name='series'>series to be added</param>
        /// <returns>void</returns>
        public void AddSeries(Series series) 
        {
            if (series == null)
            {
                throw new ArgumentNullException("series", "series cannot be null");
            }
            if (this.series.IsFixedSize)
            {
                throw new NotSupportedException("series");
            }
            
            this.series.Add(series);
        }
        
        /// Operation RemoveSeries
        /// <summary>
        /// <p>Removes all copies of given series from this chart. Does nothing if specified
        /// Series does not exist within this Chart.</p>
        /// <p>This method iterates through legendItems collection. If element is equal to
        /// parameter this method removes this element.</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <exception>NotSupportedException if collection has fixed size</exception>
        /// <param name='series'>series to be removed</param>
        /// <returns>void</returns>
        public void RemoveSeries(Series series) 
        {
            if (series == null)
            {
                throw new ArgumentNullException("series", "series cannot be null");
            }
            if (this.series.IsFixedSize)
            {
                throw new NotSupportedException("series");
            }
            int i = this.series.IndexOf(series);
            while (i >= 0) 
            {
                this.series.RemoveAt(i);
                i = this.series.IndexOf(series);
            }
        }
        
        /// Operation RemoveSeriesAt
        /// <summary>
        /// <p>Removes series with given index.</p>
        /// <p>Simply uses series.RemoveAt(index)</p>
        /// </summary>
        /// <exception>ArgumentOutOfRangeException if index is not in range [0, legendItems.Count-1]</exception>
        /// <exception>NotSupportedException if collection has fixed size</exception>
        /// <param name='index'>series index</param>
        /// <returns>void</returns>
        public void RemoveSeriesAt(int index) 
        {
            if (index < 0 || index >= series.Count)
            {
                throw new ArgumentOutOfRangeException("index", "index must be between 0 and " 
                    + (series.Count - 1).ToString());
            }
            if (series.IsFixedSize)
            {
                throw new NotSupportedException("series");
            }
            series.RemoveAt(index);
        }
        
        /// Operation GetEnumerator
        /// <returns><p>Returns enumerator to iterate through series collection</p>
        /// <p>Simply uses series.GetEnumerator() method</p></returns>
        ///
        public IEnumerator GetEnumerator()
        {
            return series.GetEnumerator();
        }
        
        /// Operation FixSize
        /// <summary>
        /// <p>Fix size of series collection. After this operation any calls of
        /// AddSeries and RemoveSeries methods will throw NotSupportedOperationException.</p>
        /// <p>Sets series to series.FixedSize.</p>
        /// </summary>
        /// <returns>void</returns>
        public void FixSize() 
        {
            series = ArrayList.FixedSize(series);
        }
    }
}
