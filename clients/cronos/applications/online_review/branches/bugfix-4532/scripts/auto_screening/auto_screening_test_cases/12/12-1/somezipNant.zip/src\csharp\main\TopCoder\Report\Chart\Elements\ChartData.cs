// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System.Collections;
using System;

namespace TopCoder.Report.Chart.Elements 
{
    /// <summary>
    /// <p>An abstract class representing the single chart data point that contains the data to display
    /// within chart. The values of ChartData are represented as INumeric objects.</p>
    /// </summary>
    public abstract class ChartData : AttributableObject
    {
        /// Attribute data
        /// <summary>
        /// <p>Collection of values associated with the chart data.</p>
        /// <p>Objects used as key value have to override two methods of object: int GetHashCode()
        /// and bool Equals(object o)</p>
        /// </summary>
        protected IDictionary data = Hashtable.Synchronized(new Hashtable());
        
        /// Attribute SyncRoot
        /// <summary>
        /// <p>An object that can be used to synchronize access to data.</p>
        /// <p>Simply returns data.SyncRoot</p>
        /// <p>Some operations (enumerating through a collection for example) are intrinsically not
        /// a thread-safe procedure. Even when a collection is synchronized, other threads could still
        /// modify the collection. To guarantee thread safety during operation execution,
        /// you should lock the collection during the entire enumeration.</p>
        /// <p>Lock this variable to prevents any access to this data collection from other threads.</p>
        /// </summary>
        public object SyncRoot 
        {
            get 
            {
                return data.SyncRoot;
            }
        }
        
        /// Constructor ChartData
        /// <summary>
        /// <p>Constructs a new ChartData with given label.</p>
        /// <p>Simply uses base(label)</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='label'>label to associate with this ChartData</param>
        protected ChartData(string label): base(label) 
        {
        }
        
        /// Constructor ChartData
        /// <summary>
        /// <p>Constructs a new ChartData with given label and data.</p>
        /// <p>This constructor uses base(label) to set label attribute. After it sets this.data
        /// to synchronized version of new Hashtable(data)</p>
        /// <p>To do this operation thread safe method should lock axes array using
        /// data.SyncRoot</p> 
        /// </summary>
        /// <exception>ArgumentNullException if any parameter is null</exception>
        /// <param name='label'>label to associate with this ChartData</param>
        /// <param name='data'>data to associate with this ChartData</param>
        protected  ChartData(string label, IDictionary data) : base(label)
        {
            if (data == null)
            {
                throw new ArgumentNullException("data", "data cannot be null");
            }
            
            lock (data.SyncRoot)
            {
                // checks data consistency
                foreach (DictionaryEntry dictionaryEntry in data) 
                {
                    if (!(dictionaryEntry.Value is INumeric)) 
                    {
                        throw new ArgumentException("data", "Collection has an invalid object type within. (" 
                            + dictionaryEntry.Value.GetType().ToString() + ")");
                    }
                    if (dictionaryEntry.Value == null) 
                    {
                        throw new ArgumentException("data", "Collection has a null object within.");
                    }
                }
                this.data = new Hashtable(data);
            }
        }
        
        /// Operation GetValue
        /// <summary>
        /// <p>Returns INumeric object from data collection to associate with specified key. 
        /// If key is not found returns null.</p>
        /// </summary>
        /// <exception>ArgumentNullException if key is null</exception>
        /// <param name='key'>key to associate with the INumeric object</param>
        /// <returns> INumeric object from data collection to associate with specified key</returns>
        public INumeric GetValue(object key) 
        {
            if (key == null)
            {
                throw new ArgumentNullException("key", "Key cannot be null");
            }
            return (INumeric) data[key];
        }
        
        /// Operation SetValue
        /// <summary>
        /// <p>Sets the INumeric value associated with the specified key. If the specified key
        /// is not found creates a new element using the specified key and value.</p>
        /// </summary>
        /// <exception>ArgumentNullException if any parameter is null</exception>
        /// <param name='key'>key associate to specified INumeric value</param>
        /// <param name='dataValue'>new INumeric value</param>
        /// <returns>void</returns>
        public void SetValue(object key, INumeric dataValue) 
        {
            if (key == null)
            {
                throw new ArgumentNullException("key", "Key cannot be null");
            }
            if (dataValue == null)
            {
                throw new ArgumentNullException("dataValue", "dataValue cannot be null");
            }
            data[key] = dataValue;
        }
    }
}
