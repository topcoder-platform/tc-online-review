// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using TopCoder.Report.Chart.Elements;

namespace TopCoder.Report.Chart 
{
    /// <summary>
    /// <p>Represents column chart.
    /// A chart in which data values are represented by vertical columns.
    /// Histograms are a specific class of column chart used in
    /// statistical work.</p>
    /// <p>The column chart can have several data series.
    /// It has two axes. Horizontal axis is catergory axis. Vertical axis
    /// is value axis.</p>
    /// <p>Every data point is rendered as rectange. Its heigh corresponds
    /// to data value.
    /// Its color is defined by series.Color (this behavior can be overriden)</p>
    /// <p>Column can start from not zero point. Use ChartData attribute to
    /// model this behavior.</p>
    /// <p>The category can have one or more value depended on column chart
    /// kind.
    /// Use appropriate ChartData class to model it.</p>
    /// </summary>
    
    public class ColumnChart : Axial2DChart 
    {
        /// Constructor ColumnChart
        /// <summary>
        /// <p>Constructs column chart with given label and axis specified
        /// in second and third parameters.</p>
        /// <p>Simply uses base constructor</p>
        /// </summary>
        /// <exception>ArgumentNullException if any parameter is null</exception>
        /// <param name='label'>label to associate with chart</param>
        /// <param name='categoryAxis'>category axis</param>
        /// <param name='valueAxis'>value axis</param>
        public ColumnChart(string label, Axis categoryAxis, Axis valueAxis) : base(label, categoryAxis, valueAxis) 
        {
        }
    }
    
}
