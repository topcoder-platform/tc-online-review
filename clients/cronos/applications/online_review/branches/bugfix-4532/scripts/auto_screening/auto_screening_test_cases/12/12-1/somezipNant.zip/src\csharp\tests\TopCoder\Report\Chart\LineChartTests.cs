// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;
using NUnit.Framework;
using System.Collections;
using TopCoder.Report.Chart.Elements;

namespace TopCoder.Report.Chart {
    /// <summary>
    /// This test class will test LineChart Class.
    /// </summary>
    [TestFixture]
    public class LineChartTests
    {
        /// <summary>
        /// Axis used for tests
        /// </summary>
        Axis axis1;

        /// <summary>
        /// Axis used for tests
        /// </summary>
        Axis axis2;
        
        /// <summary>
        /// LineChart used for tests
        /// </summary>
        LineChart lineChart;
        
        /// <summary>
        /// Attributes setup for common tests.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            axis1 = new Axis("axis1");
            axis1.MinimumValue = 1;
            axis1.MaximumValue = 10;
            
            axis2 = new Axis("axis2");
            axis2.MinimumValue = 2;
            axis2.MaximumValue = 20;
            
            lineChart = new LineChart("lineChart1", axis1, axis2);
        }
        
        /// <summary>
        /// Tests null constructor 1
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorNullParamTest1()
        {
            new LineChart(null, axis1, axis2);
        }
        
        /// <summary>
        /// Tests null constructor 2
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorNullParamTest2()
        {
            new LineChart("lineChart1", null, axis2);
        }
        
        /// <summary>
        /// Tests null constructor 3
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorNullParamTest3()
        {
            new LineChart("lineChart1", axis1, null);
        }
        
        /// <summary>
        /// Tests same axes in constructor
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void ConstructorSameAxesTest()
        {
            new LineChart("lineChart1", axis1, axis1);
        }
    }
}
