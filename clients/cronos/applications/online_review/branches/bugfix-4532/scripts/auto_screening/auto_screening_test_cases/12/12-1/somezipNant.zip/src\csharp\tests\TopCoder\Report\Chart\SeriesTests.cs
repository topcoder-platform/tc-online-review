// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;
using NUnit.Framework;
using System.Drawing;
using System.Collections;

namespace TopCoder.Report.Chart.Elements {
    /// <summary>
    /// This test class will test Series Class.
    /// </summary>
    [TestFixture]
    public class SeriesTests
    {
        /// <summary>
        /// Series used for tests
        /// </summary>
        private Series series;
        
        /// <summary>
        /// Attributes setup for common tests.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            series = new Series("series1");
            series.Add((new SingleValue("singleValue1", new Numeric(1))));
            series.Add((new SingleValue("singleValue2", new Numeric(2))));
            series.Add((new SingleValue("singleValue3", new Numeric(3))));
        }
        
        /// <summary>
        /// Tests null constructor 1
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullConstructorTest()
        {
            new Series(null);
        }
        
        /// <summary>
        /// Tests null constructor 2
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullConstructorTest2()
        {
            new Series("series1", null);
        }
        
        /// <summary>
        /// Tests null constructor 3
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorWithChartDataCollectionTest()
        {
            ChartData[] chartDataCollection = new ChartData[2];
            chartDataCollection[0] = new SingleValue("singleValue1", new Numeric(1));
            chartDataCollection[0] = new SingleValue("singleValue2", new Numeric(1));
            Series series2 = new Series("series1", chartDataCollection);
            Assert.AreEqual(2, series2.Count);
        }
        
        /// <summary>
        /// Tests null add
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullAddTest()
        {
            series.Add(null);
        }
        
        /// <summary>
        /// Tests clearing
        /// </summary>
        [Test]
        public void ClearTest()
        {
            series.Clear();
            Assert.AreEqual(0, series.Count);
        }
        
        /// <summary>
        /// Tests contains
        /// </summary>
        [Test]
        public void ContainsTest()
        {
            ChartData chartData = new SingleValue("singleValue5", new Numeric(5));
            series.Add(chartData);
            Assert.AreEqual(true, series.Contains(chartData));
            chartData = new SingleValue("singleValue6", new Numeric(6));
            Assert.AreEqual(false, series.Contains(chartData));
        }
        
        /// <summary>
        /// Tests equality
        /// </summary>
        [Test]
        public void EqualsTest()
        {
            Series series2 = new Series("series1");
            SingleValue singleValue1 = new SingleValue("singleValue1", new Numeric(1));
            series2.Add(singleValue1);
            
            Assert.AreEqual(false, series.Equals(series2));
        }
        
        /// <summary>
        /// Tests enumerator
        /// </summary>
        [Test]
        public void GetEnumeratorTest()
        {
            IEnumerator dataEnum = series.GetEnumerator();
            Assert.AreEqual(true, dataEnum.MoveNext());
        }
        
        /// <summary>
        /// Tests Hash Code
        /// </summary>
        [Test]
        public void GetHashCodeTest()
        {
            Assert.AreEqual(true, series.GetHashCode() != 0);
        }
        
        /// <summary>
        /// Tests getting index
        /// </summary>
        [Test]
        public void GetIndexTest()
        {
            Assert.AreEqual(0, series.GetIndex("singleValue1"));
        }
        
        /// <summary>
        /// Tests getting value
        /// </summary>
        [Test]
        public void GetValueTest()
        {
            Assert.AreEqual(1, series.GetValue(0).GetValue("singleValue1").ToDouble());
        }
        
        /// <summary>
        /// Tests getting value by key
        /// </summary>
        [Test]
        public void GetValueByKeyTest()
        {
            Assert.AreEqual(2, ((Numeric)series.GetValuesByKey("singleValue2")[0]).ToDouble());
        }
        
        /// <summary>
        /// Tests index of
        /// </summary>
        [Test]
        public void IndexOfTest()
        {
            ChartData chartData = new SingleValue("singleValue5", new Numeric(5));
            series.Add(chartData);
            Assert.AreEqual(3, series.IndexOf(chartData));
            chartData = new SingleValue("singleValue6", new Numeric(6));
            Assert.AreEqual(-1, series.IndexOf(chartData));
        }
        
        /// <summary>
        /// Tests last index of
        /// </summary>
        [Test]
        public void LastIndexOfTest()
        {
            ChartData chartData = new SingleValue("singleValue1", new Numeric(1));
            series.Add(chartData);
            Assert.AreEqual(3, series.LastIndexOf(chartData));
        }
        
        /// <summary>
        /// Tests insert
        /// </summary>
        [Test]
        public void InsertTest()
        {
            ChartData chartData = new SingleValue("singleValue6", new Numeric(6));
            series.Insert(2,chartData);
            Assert.AreEqual(2, series.IndexOf(chartData));
        }
        
        /// <summary>
        /// Tests insert range
        /// </summary>
        [Test]
        public void InsertRangeTest()
        {
            ArrayList chartDataArray = new ArrayList();
            ChartData chartData1 = new SingleValue("singleValue6", new Numeric(6));
            ChartData chartData2 = new SingleValue("singleValue7", new Numeric(7));
            chartDataArray.Add(chartData1);
            chartDataArray.Add(chartData2);
            series.InsertRange(1,chartDataArray);
            Assert.AreEqual(1, series.IndexOf(chartData1));
            Assert.AreEqual(2, series.IndexOf(chartData2));
        }
        
        /// <summary>
        /// Tests remove
        /// </summary>
        [Test]
        public void RemoveTest()
        {
            ChartData chartData = new SingleValue("singleValue5", new Numeric(5));
            series.Add(chartData);
            Assert.AreEqual(true, series.Contains(chartData));
            series.Remove(chartData);
            Assert.AreEqual(false, series.Contains(chartData));
        }
        
        /// <summary>
        /// Tests remove at
        /// </summary>
        [Test]
        public void RemoveAtTest()
        {
            ChartData chartData = new SingleValue("singleValue5", new Numeric(5));
            series.Add(chartData);
            Assert.AreEqual(true, series.Contains(chartData));
            series.RemoveAt(series.IndexOf(chartData));
            Assert.AreEqual(false, series.Contains(chartData));
        }
        
        /// <summary>
        /// Tests remove range
        /// </summary>
        [Test]
        public void RemoveRangeTest()
        {
            ChartData chartData1 = new SingleValue("singleValue5", new Numeric(5));
            ChartData chartData2 = new SingleValue("singleValue6", new Numeric(6));
            series.Add(chartData1);
            series.Add(chartData2);
            Assert.AreEqual(true, series.Contains(chartData1));
            Assert.AreEqual(true, series.Contains(chartData2));
            series.RemoveRange(series.IndexOf(chartData1),2);
            Assert.AreEqual(false, series.Contains(chartData1));
            Assert.AreEqual(false, series.Contains(chartData2));
        }
        
        /// <summary>
        /// Tests setting value
        /// </summary>
        [Test]
        public void SetValueTest()
        {
            ChartData chartData1 = new SingleValue("singleValue5", new Numeric(5));
            series.SetValue(0,chartData1);
            Assert.AreEqual(0, series.IndexOf(chartData1));
        }
        
        /// <summary>
        /// Tests count property
        /// </summary>
        [Test]
        public void CountPropertyTest()
        {
            Assert.AreEqual(3, series.Count);
        }
        
        /// <summary>
        /// Tests icon property
        /// </summary>
        [Test]
        public void IconPropertyTest()
        {
            series.Icon = "AnIcon";
            Assert.AreEqual("AnIcon", (string) series.Icon);
        }
        
        /// <summary>
        /// Tests legend item property
        /// </summary>
        [Test]
        public void LegendItemPropertyTest()
        {
            Assert.AreEqual("series1", series.LegendItem.Label);
        }
        
        /// <summary>
        /// Tests maximum value property
        /// </summary>
        [Test]
        public void MaximumValuePropertyTest()
        {
            Assert.AreEqual(3, series.MaximumValue);
        }
        
        /// <summary>
        /// Tests minimum value property
        /// </summary>
        [Test]
        public void MinimumValuePropertyTest()
        {
            Assert.AreEqual(1, series.MinimumValue);
        }
        
        /// <summary>
        /// Tests SyncRoot property
        /// </summary>
        [Test]
        public void SyncRootPropertyTest()
        {
            Assert.AreEqual(true, series.SyncRoot != null);
        }
    }
}
