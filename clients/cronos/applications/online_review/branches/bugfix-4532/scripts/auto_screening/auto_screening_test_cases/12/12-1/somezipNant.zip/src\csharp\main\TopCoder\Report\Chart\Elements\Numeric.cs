// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

namespace TopCoder.Report.Chart.Elements 
{
    
    ///  <summary>
    ///  <p>Implementation of INumeric interface for objects to have
    /// implicit or explicit conversion to double type.</p>
    ///  </summary>
    public class Numeric : INumeric 
    {
        /// Attribute data
        /// <summary>
        /// <p>Numeric value of object. Must be not null.</p>
        /// </summary>
        private double data;
        
        /// Attribute Value
        /// <summary>
        /// <p>Property for data variable. To do this operation thread
        /// safe all getting and setting operation should lock this variable
        /// using dataLock object</p>
        /// </summary>
        public double Value
        {
            get 
            {
                lock (dataLock) 
                {
                    return data;
                }
            }
            set 
            {
                lock (dataLock) 
                {
                    data = value;
                }
            }
        }
        
        /// Attribute dataLock
        /// <summary>
        /// <p>object to lock data variable while reading or writing</p>
        /// </summary>
        private readonly object dataLock = new object();
        
        /// Constructor Numeric
        /// <summary>
        /// <p>Constructs Numeric with given value.</p>
        /// </summary>
        /// <param name='data'>value of object</param>
        public Numeric(double data) 
        {
            Value = data;
        }
        
        /// Operation ToDouble
        /// <summary>
        /// <p>Returns this.Value</p>
        /// </summary>
        /// <returns>data</returns>
        public double ToDouble()
        {
            return this.Value;
        }
    }
    
}
