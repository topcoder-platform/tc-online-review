// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;
using NUnit.Framework;
using System.Drawing;
using System.Collections;

namespace TopCoder.Report.Chart.Elements {
    /// <summary>
    /// This test class will test LegendItem Class.
    /// </summary>
    [TestFixture]
    public class LegendItemTests
    {
        /// <summary>
        /// LegendItem used for tests
        /// </summary>
        private LegendItem legendItem;
        
        /// <summary>
        /// Series used for tests
        /// </summary>
        private Series series;
        
        /// <summary>
        /// Attributes setup for common tests.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            series = new Series("series1");
            series.Add((new SingleValue("singleValue1", new Numeric(1))));
            series.Add((new SingleValue("singleValue2", new Numeric(2))));
            series.Add((new SingleValue("singleValue3", new Numeric(3))));
            legendItem = new LegendItem(series);
        }
        
        /// <summary>
        /// Tests null constructor
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullConstructorTest()
        {
            new LegendItem(null);
        }
        
        /// <summary>
        /// Tests null label setting
        /// </summary>
        [Test]
        public void NullLabelSetTest()
        {
            legendItem.Label = null;
        }
        
        /// <summary>
        /// Tests null icon setting
        /// </summary>
        [Test]
        public void NullIconSetTest()
        {
            legendItem.Icon = null;
        }
        
        /// <summary>
        /// Tests null annotation setting
        /// </summary>
        [Test]
        public void NullAnnotationSetTest()
        {
            legendItem.Annotation = null;
        }
        
        /// <summary>
        /// Tests label get and set
        /// </summary>
        [Test]
        public void LabelGetSetTest()
        {
            Assert.AreEqual("series1", legendItem.Label);
            legendItem.Label = "changedLabel";
            Assert.AreEqual("changedLabel", legendItem.Label);
        }
        
        /// <summary>
        /// Tests icon get and set
        /// </summary>
        [Test]
        public void IconGetSetTest()
        {
            Assert.AreEqual(null, legendItem.Icon);
            legendItem.Icon = "changedIcon";
            Assert.AreEqual("changedIcon", legendItem.Icon);
        }
        
        /// <summary>
        /// Tests series get and set
        /// </summary>
        [Test]
        public void SeriesGetSetTest()
        {
            Assert.AreEqual(3, legendItem.Series.Count);
        }
        
        /// <summary>
        /// Tests color get and set
        /// </summary>
        [Test]
        public void ColorGetSetTest()
        {
            Assert.AreEqual(Color.Empty, legendItem.Color);
            legendItem.Color = Color.AliceBlue;
            Assert.AreEqual(Color.AliceBlue, legendItem.Color);
        }
        
        /// <summary>
        /// Tests annotation get and set
        /// </summary>
        [Test]
        public void AnnotationGetSetTest()
        {
            Assert.AreEqual(null, legendItem.Annotation);
            legendItem.Annotation = "ChangedAnnotation";
            Assert.AreEqual("ChangedAnnotation", legendItem.Annotation);
        }
        
        /// <summary>
        /// Tests indexer
        /// </summary>
        [Test]
        public void IndexerTest()
        {
            legendItem["1"] = "one";
            legendItem["2"] = "two";
            
            Assert.AreEqual("one", legendItem["1"]);
            Assert.AreEqual("two", legendItem["2"]);
        }
        
        /// <summary>
        /// Tests null key indexer
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullIndexerKeyTest()
        {
            legendItem[null] = "one";
        }
        
        /// <summary>
        /// Tests null value indexer
        /// </summary>
        [Test]
        public void NullIndexerValueTest()
        {
            legendItem["3"] = null;
        }
        
        /// <summary>
        /// Tests clearing attributes
        /// </summary>
        [Test]
        public void ClearAttributesTest()
        {
            legendItem.Color = Color.AliceBlue;
            legendItem.Icon = "changedIcon";
            legendItem.Annotation = "ChangedAnnotation";
            legendItem["1"] = "one";
            legendItem["2"] = "two";
            
            legendItem.ClearAttributes();
            
            Assert.AreEqual("series1", legendItem.Label);
            Assert.AreEqual(Color.Empty , legendItem.Color);
            Assert.AreEqual(null, legendItem.Annotation);
            Assert.AreEqual(null, legendItem.Icon);
            Assert.AreEqual(null, legendItem["1"]);
            Assert.AreEqual(null, legendItem["2"]);
        }
    }
}
