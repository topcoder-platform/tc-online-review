// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;
using NUnit.Framework;
using System.Collections;

namespace TopCoder.Report.Chart.Elements {
    /// <summary>
    /// This test class will test MultiValue Class.
    /// </summary>
    [TestFixture]
    public class MultiValueTests
    {
        /// <summary>
        /// MultiValue used for tests
        /// </summary>
        MultiValue multiValue;

        /// <summary>
        /// Hashtable used for tests
        /// </summary>
        Hashtable hashtable;

        /// <summary>
        /// Attributes setup for common tests.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            hashtable = new Hashtable();
            hashtable.Add("point1",new Numeric(1));
            hashtable.Add("point2",new Numeric(2));
            hashtable.Add("point3",new Numeric(3));
            multiValue = new MultiValue("label1", hashtable);
        }
        
        /// <summary>
        /// Tests null constructor 1
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorNullParamTest1()
        {
            new MultiValue(null);
        }
        
        /// <summary>
        /// Tests null constructor 2
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorNullParamTest2()
        {
            new MultiValue("label2",null);
        }
        
        /// <summary>
        /// Tests adding null value 1
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void AddValueNullParamTest1()
        {
            multiValue.AddValue(null,new Numeric(4));
        }
        
        /// <summary>
        /// Tests adding null value 2
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void AddValueNullParamTest2()
        {
            multiValue.AddValue("point4",null);
        }
        
        /// <summary>
        /// Tests adding existing key
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void AddValueExistingKeyTest()
        {
            multiValue.AddValue("point4",new Numeric(4));
            multiValue.AddValue("point4",new Numeric(4.5));
        }
        
        /// <summary>
        /// Tests removing value
        /// </summary>
        [Test]
        public void AddValueRemoveValueTest()
        {
            MultiValue multiValue2 = new MultiValue("label2");
            multiValue2.AddValue("point4", new Numeric(4));
            IDictionaryEnumerator dataEnum = multiValue2.GetEnumerator();
            Assert.AreEqual(true, dataEnum.MoveNext(), "Collection should have one item");
            multiValue2.RemoveValue("point4");
            dataEnum = multiValue2.GetEnumerator();
            Assert.AreEqual(false, dataEnum.MoveNext(), "Collection should be empty");
        }
        
        /// <summary>
        /// Tests enumerator
        /// </summary>
        [Test]
        public void GetEnumeratorTest()
        {
            IDictionaryEnumerator dataEnum = multiValue.GetEnumerator();
            while (dataEnum.MoveNext()) 
            {
                if (dataEnum.Key.ToString()  == "point1") 
                {
                    Assert.AreEqual(1, ((INumeric)dataEnum.Value).ToDouble());
                }
                if (dataEnum.Key.ToString()  == "point2") 
                {
                    Assert.AreEqual(2, ((INumeric)dataEnum.Value).ToDouble());
                }
                if (dataEnum.Key.ToString()  == "point3") 
                {
                    Assert.AreEqual(3, ((INumeric)dataEnum.Value).ToDouble());
                }
            }
        }
        
    }
}
