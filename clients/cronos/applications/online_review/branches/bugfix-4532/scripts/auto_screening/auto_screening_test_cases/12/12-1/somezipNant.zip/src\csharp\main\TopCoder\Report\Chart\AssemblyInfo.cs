// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Chart Data Structure")]
[assembly: AssemblyDescription("Provides a foundation for holding necessary information about variety of charts.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("http://www.topcoder.com")]
[assembly: AssemblyProduct("TopCoder .NET Software Catalog")]
[assembly: AssemblyCopyright("Copyright � 2005, TopCoder, Inc. All rights reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0")]

// This will not compile with Visual Studio.  If you want to build a signed
// executable use the NAnt build file.  To build under Visual Studio just
// exclude this file from the build.
[assembly: AssemblyDelaySign(false)]
//[assembly: AssemblyKeyFile(@"..\tcs\bin\TopCoder.snk")]
[assembly: AssemblyKeyName("")]
