// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;
using NUnit.Framework;
using System.Drawing;
using System.Collections;

namespace TopCoder.Report.Chart.Elements {
    /// <summary>
    /// This test class will test Legend Class.
    /// </summary>
    [TestFixture]
    public class LegendTests
    {
        /// <summary>
        /// Legend used for tests
        /// </summary>
        private Legend legend;
        
        /// <summary>
        /// Chart used for tests
        /// </summary>
        private Chart chart;
        
        /// <summary>
        /// Series used for tests
        /// </summary>
        private Series series;
        
        /// <summary>
        /// Attributes setup for common tests.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            series = new Series("series1");
            series.LegendItem.Label = "legendItem1";
            chart = new PieChart("chart1", series);
            legend = new Legend(chart);
        }
        
        /// <summary>
        /// Tests null constructor
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullConstructorTest()
        {
            new Legend(null);
        }
        
        /// <summary>
        /// Tests null label set
        /// </summary>
        [Test]
        public void NullLabelSetTest()
        {
            legend.Label = null;
        }
        
        /// <summary>
        /// Tests label set and get
        /// </summary>
        [Test]
        public void LabelSetGetTest()
        {
            legend.Label = "label1";
            Assert.AreEqual("label1", legend.Label);
        }
        
        /// <summary>
        /// Tests color set and get
        /// </summary>
        [Test]
        public void ColorSetGetTest()
        {
            legend.Color = Color.Beige;
            Assert.AreEqual(Color.Beige, legend.Color);
        }
        
        /// <summary>
        /// Tests null color get
        /// </summary>
        [Test]
        public void ColorGetNullTest()
        {
            Assert.AreEqual(Color.Empty, legend.Color);
        }
        
        /// <summary>
        /// Tests null annotation set
        /// </summary>
        [Test]
        public void NullAnnotationSetTest()
        {
            legend.Annotation = null;
        }
        
        /// <summary>
        /// Tests annotation set and get
        /// </summary>
        [Test]
        public void AnnotationSetGetTest()
        {
            legend.Annotation = "annotation1";
            Assert.AreEqual("annotation1", legend.Annotation);
        }
        
        /// <summary>
        /// Tests null annotation get
        /// </summary>
        [Test]
        public void AnnotationGetNullTest()
        {
            Assert.AreEqual(null, legend.Annotation);
        }
        
        /// <summary>
        /// Tests indexer
        /// </summary>
        [Test]
        public void IndexerTest()
        {
            legend["1"] = "one";
            legend["2"] = "t-o";
            legend["2"] = "two";
            
            Assert.AreEqual("one", legend["1"]);
            Assert.AreEqual("two", legend["2"]);
        }
        
        /// <summary>
        /// Tests clearing attributes
        /// </summary>
        [Test]
        public void ClearAttributesTest()
        {
            legend.Label = "label1";
            legend.Color = Color.Beige;
            legend.Annotation = "annotation1";
            Assert.AreEqual("label1", legend.Label);
            Assert.AreEqual(Color.Beige, legend.Color);
            Assert.AreEqual("annotation1", legend.Annotation);
            legend.ClearAttributes();
            Assert.AreEqual("label1", legend.Label);
            Assert.AreEqual(Color.Empty , legend.Color);
            Assert.AreEqual(null, legend.Annotation);
        }
        
        /// <summary>
        /// Tests count property
        /// </summary>
        [Test]
        public void ItemCountPropertyTest()
        {
            Assert.AreEqual(1, legend.ItemCount);
        }
        
        /// <summary>
        /// Tests chart property
        /// </summary>
        [Test]
        public void ChartPropertyTest()
        {
            Assert.AreEqual("chart1", legend.Chart.Label);
        }
        
        /// <summary>
        /// Tests getting legend item
        /// </summary>
        [Test]
        public void GetLegendItemTest()
        {
            Assert.AreEqual("legendItem1", legend.GetLegendItem(0).Label);
        }
    }
}
