// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

namespace TopCoder.Report.Chart.Elements 
{
    /// <summary>
    /// <p>Every data point is a pair (label, value). Value to be
    /// represented as chart element has to be numeric
    /// measuring. This interface defines a contract for object used as
    /// value of data point.</p>
    /// </summary>
    public interface INumeric 
    {
        /// Operation ToDouble
        /// <summary>
        /// <p>Converts object to double numeric type.</p>
        /// </summary>
        /// <returns>double numeric value</returns>
        double ToDouble();
    }
}
