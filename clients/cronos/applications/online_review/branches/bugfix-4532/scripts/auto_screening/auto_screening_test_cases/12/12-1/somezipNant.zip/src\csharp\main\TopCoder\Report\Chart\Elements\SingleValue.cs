// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System.Drawing;

namespace TopCoder.Report.Chart.Elements 
{
    
    ///  <summary>
    ///  <p>A ChartData that may contain only one value associated with
    /// it. Such objects could be used in one-axial charts, for example,
    /// histogram chart.</p>
    ///  <p>Data collection for this class contains only one value. Its
    /// key is label.</p>
    ///  </summary>
    public class SingleValue : ChartData 
    {
        
        /// Attribute Data
        /// <summary>
        /// <p>Property for value to associate with the object.</p>
        /// <p>Getter method simply returns data[Label]. If key is not
        /// found method returns null.</p>
        /// <p>Setter method sets data[Label] to given value. If key is
        /// not found method creates element with label variable as key and
        /// specified value.</p>
        /// </summary>
        public INumeric Data
        {
            get 
            {
                return GetValue(Label);
            }
            set 
            {
                SetValue(Label,value);
            }
        }
        
        /// Constructor SingleValue
        /// <summary>
        /// <p>Constructs a new SingleValue with given label.</p>
        /// <p>Simply uses base(label)</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='label'>label to associate with this object</param>
        public SingleValue(string label) : base(label) 
        {
            // base class will handle a null label
        }
        
        /// Constructor SingleValue
        /// <summary>
        /// <p>Constructs a new SingleValue with given label and value</p>
        /// <p>This constructor simply uses base(label). After this, it adds
        /// element with given value and label as key to data collection.</p>
        /// </summary>
        /// <exception>ArgumentNullException if any parameter is null</exception>
        /// <param name='label'>label to associate with this object</param>
        /// <param name='data'>value to associate with this object</param>
        public SingleValue(string label, INumeric data) : base(label) 
        {
            SetValue(Label,data);
        }
        
        /// Constructor SingleValue
        /// <summary>
        /// <p>Constructs a new SingleValue with given label, value and
        /// color attribute</p>
        /// <p>This constructor simply uses base(label). After this, it adds
        /// element with given value and label as key to data collection and
        /// sets color attribute using Color property of AttributableObject
        /// class.</p>
        /// </summary>
        /// <exception>ArgumentNullException if label or data are null</exception>
        /// <param name='label'>label to associate with this object</param>
        /// <param name='data'>value to associate with this object</param>
        /// <param name='color'>color to associate with this object</param>
        public SingleValue(string label, INumeric data, Color color) : base(label) 
        {
            SetValue(Label,data);
            Color = color;
        }
    }
    
}
