// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System.Collections;
using System.Drawing;
using System;

namespace TopCoder.Report.Chart.Elements 
{
    /// <summary>
    /// <p>Abstract class representing an object and its associated attributes. Implements methods manipulating an
    /// object's attributes as getter and setter indexer of object. Provides a set of properties representing
    /// label, color and annotation attributes that are common to all subclasses of this class.</p>
    /// </summary>
    public abstract class AttributableObject
    {
        /// Attribute attributes
        /// <summary>
        /// <p>Hashtable to store attributes collection of object.</p>
        /// <p>Objects used as key value for attribute have to override two methods of object: int GetHashCode()
        /// and bool Equals(object o)</p>
        /// </summary>
        protected IDictionary attributes = Hashtable.Synchronized(new Hashtable());
        
        /// Attribute label
        /// <summary>
        /// <p>Property for the attributte Label.</p>
        /// <p>This attribute represent label to associate with chart element. Every element of chart must have
        /// not null Label</p>
        /// <p>Getter method just returns this["label"].</p>
        /// <p>Setter method just does this["label"] = value If key is not found method creates element
        /// with key "label" and specified value.</p>
        /// <exception>ArgumentNullException if value is null</exception>
        /// </summary>
        public virtual string Label 
        {
            get 
            {
                // if label attribute is null or not a string, it returns null.
                return this["label"] == null || !(this["label"] is string) ? null : this["label"].ToString();
            }
            set 
            {
                if (value == null)
                {
                    throw new ArgumentNullException("value", "Label cannot be null");
                }
                this["label"] = value;
            }
        }
        
        
        /// Attribute Color
        /// <summary>
        /// <p>Property for the attributte Color.</p>
        /// <p>This optional attribute represents a color of the chart element.</p>
        /// <p>Getter method just returns this["color"]. If key is not found method returns Color.Empty.</p>
        /// <p>Setter method just does this["color"] = value If key is not found method creates
        /// element with key "color" and specified value.</p>
        /// </summary>
        public virtual Color Color 
        {
            get 
            {
                // if Color attribute is null or not a Color, it returns Color.Empty.
                return this["color"] == null || !(this["color"] is Color) ? Color.Empty : ((Color)this["color"]);
            }
            set 
            {
                // Improved performance: Avoiding the enlargement of the collection if the value 
                // is Color.Empty. (it is its default)
                if (value == Color.Empty) 
                {
                    attributes.Remove("color");
                } 
                else
                {
                    this["color"] = value;
                }
            }
        }
        
        /// Attribute Annotation
        /// <summary>
        /// <p>Property for the attributte Annotation.</p>
        /// <p>This optional attribute represents an annotation to associate with the chart element.</p>
        /// <p>Getter method just returns this["annotation"]. If key is not found method returns null.</p>
        /// <p>Setter method just does this["annotation"] = value If key is not found method creates
        /// element with key "color" and specified value.</p>
        /// </summary>
        public virtual string Annotation 
        {
            get 
            {
                return this["Annotation"] == null || !(this["Annotation"] is string) 
                    ? null : this["Annotation"].ToString();
            }
            set 
            {
                // Improved performance: Avoiding the enlargement of the collection if 
                // the value is null. (it is its default)
                if (value == null) 
                {
                    attributes.Remove("Annotation");
                } 
                else
                {
                    this["Annotation"] = value;
                }
            }
        }
        
        /// Constructor AttributableObject
        /// <summary>
        /// <p>Empty constructor of class. It does nothing.</p>
        /// </summary>
        protected  AttributableObject() 
        {
            // just an empty constructor
        }
        
        /// Constructor AttributableObject
        /// <summary>
        /// <p>Constructor of class with given label. Adds attribute holding the label to list of attributes.</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='label'>label to associate with this object</param>
        protected  AttributableObject(string label) 
        {
            // Label property will handle the null value.
            Label=label;
        }
        
        /// Operation this
        /// <summary>
        /// <p>Getter indexer of class. Returns attribute object to associate with specified
        /// key. If key is not found returns null.</p>
        /// <p>Overridden by Legend and LegendItem classes to realize two layer getter.</p>
        /// </summary>
        /// <exception>ArgumentNullException if key is null</exception>
        /// <param name='key'>attribute key</param>
        /// <returns>attribute object to associate with specified key</returns>
        public virtual object this[object key]
        {
            get
            {
                if (key == null)
                {
                    throw new ArgumentNullException("key", "key cannot be null");
                }
                return attributes[key];
            }
            set
            {
                if (key == null)
                {
                    throw new ArgumentNullException("key", "key cannot be null");
                }
                // Avoiding the enlargement of the collection if the value is null. (it is its default)
                if (value == null) 
                {
                    attributes.Remove(key);
                } 
                else 
                {
                    attributes[key] = value;
                }
            }
        }
        
        /// Operation ClearAttributes
        /// <summary>
        /// <p>Clears all the attribute information defined except attribute Label. This method saves attribute
        /// Label value, calls attributes.Clear() method and restores previous value of attribute Label.</p>
        /// <p>Overridden by Legend and LegendItem classes to restore default attribute values.</p>
        /// </summary>
        public virtual void ClearAttributes() 
        {
            string label = Label;
            attributes.Clear();
            this["label"] = label;
        }
        
        /// Operation GetAttributeEnumerator
        /// <summary>
        /// <p>Returns attribute collection enumerator.</p>
        /// <p>Simply calls attributes.GetEnumerator().</p>
        /// </summary>
        /// <returns>attribute enumerator</returns>
        public IDictionaryEnumerator GetAttributeEnumerator() 
        {
            return attributes.GetEnumerator();
        }
    }
}
