// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;
using NUnit.Framework;
using System.Collections;

namespace TopCoder.Report.Chart.Elements {
    /// <summary>
    /// This test class will test SingleValue Class.
    /// </summary>
    [TestFixture]
    public class SingleValueTests
    {
        /// <summary>
        /// SingleValue used for tests
        /// </summary>
        SingleValue singleValue;

        /// <summary>
        /// Attributes setup for common tests.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            singleValue = new SingleValue("label1");
        }
        
        /// <summary>
        /// Tests null constructor 1
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorNullParamTest1()
        {
            new SingleValue(null);
        }
        
        /// <summary>
        /// Tests null constructor 2
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorNullParamTest2()
        {
            new SingleValue("label2",null);
        }
        
        /// <summary>
        /// Tests data property
        /// </summary>
        [Test]
        public void DataPropertyTest()
        {
            singleValue.Data = new Numeric(1);
            Assert.AreEqual(1, singleValue.Data.ToDouble());
        }
        
        /// <summary>
        /// Tests changing data property
        /// </summary>
        [Test]
        public void ChangeDataPropertyTest()
        {
            singleValue.Data = new Numeric(1);
            singleValue.Data = new Numeric(2);
            Assert.AreEqual(2, singleValue.Data.ToDouble());
        }
    }
}
