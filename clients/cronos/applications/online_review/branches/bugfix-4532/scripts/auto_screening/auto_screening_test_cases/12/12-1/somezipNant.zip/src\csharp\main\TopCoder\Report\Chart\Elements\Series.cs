// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System.Collections;
using System;

namespace TopCoder.Report.Chart.Elements 
{
    
    /// <summary>
    /// <p>Series class representing a series of values with unique
    /// label and legend icon to associate with it.</p>
    /// <p>Concrete chart contain one or more series of values.</p>
    /// <p>Every Series contains some ChartData objects.</p>
    /// </summary>
    public class Series : AttributableObject 
    {
        /// Attribute data
        /// <summary>
        /// <p>A list of values that this series consists of. Each element
        /// is a ChartData object representing the actual value.</p>
        /// </summary>
        private ArrayList data = ArrayList.Synchronized(new ArrayList());
         
        /// Attribute legendItem
        /// <summary>
        /// <p>Legend item to associate with this Series. It is created by
        /// class constructor.</p>
        /// </summary>
        private LegendItem legendItem;
        
        /// Attribute LegendItem
        /// <summary>
        /// <p>
        /// Returns legend item to associate with this series. Get property
        /// for legendItem variable.
        /// </p>
        /// </summary>
        public LegendItem LegendItem 
        {
            get 
            {
                return legendItem;
            }
        }
        
        /// Attribute Count
        /// <summary>
        /// <p>Gets the number of data points within this Series.</p>
        /// <p>Simply uses data.Count property.</p>
        /// </summary>
        public int Count 
        {
            get 
            {
                return data.Count;
            }
        }
        
        /// Attribute MinimumValue
        /// <summary>
        /// <p>Gets the minimum value among the values of ChartData
        /// objects belonging to this Series. This value has sense
        /// only for Series contained only SingleValue objects.</p>
        /// <p>Method compares values using its numeric values returned
        /// by ToDouble method. If no values were added to this Series
        /// returns null.</p>
        /// <p>To do this operation thread safe method should lock data
        /// array using data.SyncRoot</p>
        /// </summary>
        public object MinimumValue 
        {
            get 
            {
                try 
                {
                    lock (data.SyncRoot) 
                    {
                        // just seeking for the minimum value and keeping it
                        bool firstValue = true;
                        double lowestValue = 0;
                        foreach(SingleValue singleValue in data) 
                        {
                            if (firstValue) 
                            {
                                lowestValue = singleValue.Data.ToDouble();
                                firstValue = false;
                            } 
                            else 
                            {
                                double Value = singleValue.Data.ToDouble();
                                if (lowestValue > Value) 
                                {
                                    lowestValue = Value;
                                }
                            }
                        }
                        if (!firstValue) 
                        {
                            return lowestValue;
                        }
                    }
                } 
                catch 
                {
                    // Something in data is not SingleValue
                    throw new NotSupportedException("MinimumValue is only for SingleValue collection");
                }
                return null;
            }
        }
        
        /// Attribute MaximumValue
        /// <summary>
        /// <p>Gets the maximum value among the values of ChartData
        /// objects belonging to this Series. This value has sense
        /// only for Series contained only SingleValue objects.</p>
        /// <p>Method compares values using its numeric measuring returned
        /// by ToDouble method. If no values were added to this Series
        /// returns null.</p>
        /// <p>To do this operation thread safe method should lock data
        /// array using data.SyncRoot</p>
        /// </summary>
        public object MaximumValue 
        {
            get
            {
                try 
                {
                    lock (data.SyncRoot) 
                    {
                        // just seeking for the maximum value and keeping it
                        bool firstValue = true;
                        double greatestValue = 0;
                        foreach(SingleValue singleValue in data) 
                        {
                            if (firstValue) 
                            {
                                greatestValue = singleValue.Data.ToDouble();
                                firstValue = false;
                            } 
                            else 
                            {
                                double Value = singleValue.Data.ToDouble();
                                if (greatestValue < Value) 
                                {
                                    greatestValue = Value;
                                }
                            }
                        }
                        if (!firstValue) 
                        {
                            return greatestValue;
                        }
                    }
                } 
                catch 
                {
                    // Something in data is not SingleValue
                    throw new NotSupportedException("MinimumValue is only for SingleValue collection");
                }
                return null;
            }
        }
        
        /// Attribute Icon
        /// <summary>
        /// <p>Property for the attributte Icon.</p>
        /// <p>Getter method just returns this["icon"]. If key
        /// is not found method returns null.</p>
        /// <p>Setter method just does this["icon"] = value If
        /// key is not found method creates element with key
        /// "icon" and specified value.</p>
        /// </summary>
        public object Icon 
        {
            get 
            {
                return this["icon"];
            }
            set 
            {
                // Avoiding the enlargement of the collection if the value is null. (it is its default)
                if (value == null)
                {
                    attributes.Remove("icon");
                } 
                else
                {
                    this["icon"] = value;
                }
            }
        }
        
        /// Attribute SyncRoot
        /// <summary>
        /// <p>An object that can be used to synchronize access to data.</p>
        /// <p>Simply returns data.SyncRoot</p>
        /// <p>Some operations (enumerating through a collection for example)
        /// are intrinsically not a thread-safe procedure. Even when a collection is
        /// synchronized, other threads could still modify the collection. To
        /// guarantee thread safety during operation execution, you should lock the
        /// collection during the entire enumeration.</p>
        /// <p>Lock this variable to prevents any access to this series data
        /// collection from other threads.</p>
        /// </summary>
        public object SyncRoot 
        {
            get 
            {
                return data.SyncRoot;
            }
        }
        
        /// Constructor Series
        /// <summary>
        /// <p>Constructs a new Series with given label.</p>
        /// <p>Uses base(label) constructor. </p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='label'>label to associate with this Series</param>
        public Series(string label) : base(label) 
        {
            // base class will handle null args.
            legendItem = new LegendItem(this);
        }
        
        /// Constructor Series
        /// <summary>
        /// <p>Constructs a new Series with given label and data.</p>
        /// <p>Uses base(label). Sets this.data to new ArrayList(data)</p>
        /// <p>To do this operation thread safe method should lock axes array using
        /// data.SyncRoot</p> 
        /// </summary>
        /// <exception>ArgumentNullException if any parameter is null</exception>
        /// <param name='label'>label to associate with this Series</param>
        /// <param name='data'>data to associate with this Series</param>
        public Series(string label, ChartData[] data) : base(label) {
            if (data == null)
            {
                throw new ArgumentNullException("data", "data cannot be null");
            }
            // base class will handle null args.
            
            // checking data consistency
            lock (data.SyncRoot)
            {
                foreach (ChartData chartData in data) 
                {
                    if (chartData == null) 
                    {
                        throw new ArgumentNullException("data", "data collection has a null object within");
                    }
                }
                
                this.data = new ArrayList(data);
            }
            legendItem = new LegendItem(this);
        }
        
        /// Operation GetIndex
        /// <summary>
        /// <p>Method iterates through collection of elements of Series.
        /// It returns the first element with specified label. If element is
        /// not found returns -1.</p>
        /// <p>To do this operation thread safe method should lock data
        /// array using data.SyncRoot</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='label'>element label</param>
        /// <returns>first element with given label</returns>
        public int GetIndex(string label) 
        {
            if (label == null)
            {
                throw new ArgumentNullException("label", "label cannot be null");
            }
            
            lock (data.SyncRoot)
            {
                IEnumerator dataEnum = data.GetEnumerator();
                for (int i=0; dataEnum.MoveNext(); i++) 
                {
                    if (((ChartData)dataEnum.Current).Label == label) 
                    {
                        return i;
                    }
                }
            }
            return -1;
        }
        
        /// Operation GetValue
        /// <summary>
        /// <p>Returns data[index] element.</p>
        /// </summary>
        /// <exception>ArgumentOutOfRangeException if index is not in
        /// range [0; data.Count-1]</exception>
        /// <param name='index'>element index</param>
        /// <returns>element of data collection with given index</returns>
        public ChartData GetValue(int index) 
        {
            if (index < 0 || index >= data.Count)
            {
                throw new ArgumentOutOfRangeException("index", "index must be between 0 and " 
                    + (data.Count - 1).ToString());
            }
            return (ChartData) data[index];
        }
        
        /// Operation SetValue
        /// <summary>
        /// <p>Sets element with given index to specified value.</p>
        /// </summary>
        /// <exception>ArgumentNullException if element is null</exception>
        /// <exception>ArgumentOutOfRangeException if index is not in range
        ///  [0; data.Count-1]</exception>
        /// <param name='index'>element index</param>
        /// <param name='element'>new element value</param>
        /// <returns>void</returns>
        public void SetValue(int index, ChartData element) 
        {
            if (element == null)
            {
                throw new ArgumentNullException("element", "element cannot be null");
            }
            if (index < 0 || index >= data.Count)
            {
                throw new ArgumentOutOfRangeException("index", "index must be between 0 and " 
                    + (data.Count - 1).ToString());
            }
            data[index] = element;
        }
        
        /// Operation Contains
        /// <summary>
        /// <p>Determines whether an element is in the
        /// data collection.</p>
        /// <p>Simply uses data.Contains(element)</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='element'>ChartData object to locate in Series</param>
        /// <returns>true if data collection contains this element</returns>
        public bool Contains(ChartData element) 
        {
            if (element == null)
            {
                throw new ArgumentNullException("element", "element cannot be null");
            }
            return data.Contains(element);
        }
        
        /// Operation IndexOf
        /// <summary>
        /// Searches for the specified ChartData object
        /// and returns the zero-based index of the first occurrence within
        /// the entire Series. If it is not found returns -1.
        /// <p>Simply uses data.IndexOf(element)</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='element'>ChartData object to locate in Series</param>
        /// <returns>zero-based index of the first occurrence if found, otherwise -1</returns>
        public int IndexOf(ChartData element) 
        {
            if (element == null)
            {
                throw new ArgumentNullException("element", "element cannot be null");
            }
            return data.IndexOf(element);
        }
        
        /// Operation LastIndexOf
        /// <summary>
        /// <p>Searches for the specified ChartData object and returns the
        /// zero-based index of the last occurrence within the entire Series.
        ///  If it is not found returns -1.</p>
        /// <p>Simply uses data.LastIndexOf(element)</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='element'>ChartData object to locate in Series</param>
        /// <returns>zero-based index of the last occurrence if found, otherwise -1</returns>
        public int LastIndexOf(ChartData element) 
        {
            if (element == null)
            {
                throw new ArgumentNullException("element", "element cannot be null");
            }
            return data.LastIndexOf(element);
        }
        
        /// Operation Add
        /// <summary>
        /// <p>Adds an object to the end of the Series.</p>
        /// <p>Simply uses data.Add(element)</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='element'>ChartData object to be added</param>
        /// <returns>void</returns>
        public void Add(ChartData element) 
        {
            if (element == null)
            {
                throw new ArgumentNullException("element", "element cannot be null");
            }
            data.Add(element);
        }
        
        /// Operation Insert
        /// <summary>
        /// Inserts an element into the Series at the
        /// specified index. If index is Series.Count then element added to
        /// Series.
        /// Simple uses data.Insert(index,element)
        /// </summary>
        /// <exception>ArgumentNullException if element is null</exception>
        /// <exception>ArgumentOutOfRangeException if index is not in range
        ///  [0; data.Count]</exception>
        /// <param name='index'>element index</param>
        /// <param name='element'>ChartData object to be inserted</param>
        /// <returns>void</returns>
        public void Insert(int index, ChartData element) 
        {
            if (index < 0 || index > data.Count)
            {
                throw new ArgumentOutOfRangeException("index", "index must be between 0 and " 
                    + data.Count.ToString());
            }
            if (element == null)
            {
                throw new ArgumentNullException("element", "element cannot be null");
            }
            data.Insert(index, element);
        }
        
        /// Operation InsertRange
        /// <summary>
        /// <p>Inserts the elements of a collection
        /// into the Series at the specified index. If
        /// index is Series.Count then elements of collection added to
        /// Series.</p>
        /// <p>Simply uses data.InsertRange(index, collection)</p>
        /// <p>To do this operation thread safe method should lock collection using
        /// collection.SyncRoot</p>
        /// </summary>
        /// <exception>ArgumentNullException if collection is null</exception>
        /// <exception>ArgumentOutOfRangeException if index is not in
        /// range [0; data.Count]</exception>
        /// <param name='index'>element index</param>
        /// <param name='collection'>element collection to be added</param>
        /// <returns>void</returns>
        public void InsertRange(int index, ICollection collection) 
        {
            if (index < 0 || index > data.Count)
            {
                throw new ArgumentOutOfRangeException("index", "index must be between 0 and " 
                    + data.Count.ToString());
            }
            if (collection == null)
            {
                throw new ArgumentNullException("collection", "collection cannot be null");
            }
            
            // checking collection consistency
            lock (collection.SyncRoot) 
            {
                foreach (Object o in collection) 
                {
                    if (!(o is ChartData)) 
                    {
                        throw new ArgumentException("collection", "Collection has an invalid object type within. (" 
                            + o.GetType().ToString() + ")");
                    }
                    if (o == null) 
                    {
                        throw new ArgumentNullException("collection", "Collection has a null object within.");
                    }
                }
            }
            data.InsertRange(index, collection);
        }
        
        /// Operation Remove
        /// <summary>
        /// Removes the first occurrence of a specific
        /// object from the Series.
        /// <p>Simply uses data.Remove(element)</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='element'>ChartData object to be removed</param>
        /// <returns>void</returns>
        public void Remove(ChartData element) 
        {
            if (element == null)
            {
                throw new ArgumentNullException("element", "element cannot be null");
            }
            data.Remove(element);
        }
        
        /// Operation RemoveAt
        /// <summary>
        /// Removes the element at the specified index
        /// of the Series
        /// <p>Simply uses data.RemoveAt(element)</p>
        /// </summary>
        /// <exception>ArgumentOutOfRangeException if index is not in range
        /// [0; data.Count-1]</exception>
        /// <param name='index'>element index</param>
        /// <returns>void</returns>
        public void RemoveAt(int index) 
        {
            if (index < 0 || index >= data.Count)
            {
                throw new ArgumentOutOfRangeException("index", "index must be between 0 and " 
                    + (data.Count - 1).ToString());
            }
            data.RemoveAt(index);
        }
        
        /// Operation RemoveRange
        /// <summary>
        /// <p>Removes a range of elements from
        /// theSeries.</p>
        /// </summary>
        /// <exception>ArgumentOutOfRangeException if index is not in
        /// range [0; data.Count-1]</exception>
        /// <exception>ArgumentException if index and count do not denote
        /// a valid range of elements</exception>
        /// <param name='index'>the index of first element to be
        /// removed</param>
        /// <param name='count'>the number of elements to be removed</param>
        /// <returns>void</returns>
        public void RemoveRange(int index, int count) 
        {
            if (index < 0 || index >= data.Count)
            {
                throw new ArgumentOutOfRangeException("index", "index must be between 0 and " 
                    + (data.Count - 1).ToString());
            }
            if (index + count > data.Count)
            {
                throw new ArgumentOutOfRangeException("index, count", "Invalid range of elements");
            }
            data.RemoveRange(index, count);
        }
        
        /// Operation Clear
        /// <summary>
        /// Removes all elements from the Series
        /// </summary>
        /// <returns>void</returns>
        public void Clear() 
        {
            data.Clear();
        }
        
        /// Operation GetEnumerator
        /// <summary>
        /// <p>Returns an enumerator that can iterate through the Series
        /// elements.</p>
        /// <p>Simply uses data.GetEnumerator() method</p>
        /// </summary>
        /// <returns>Series elements enumerator</returns>
        public IEnumerator GetEnumerator() 
        {
            return data.GetEnumerator();
        }
        
        /// Operation GetValuesByKey
        /// <summary>
        /// <p>Returns array of INumeric values from this Series for given
        /// key.</p>
        /// <p>Method enumerates all elements current series. If current
        /// element has value with given key it adds to result array.</p>
        /// <p>To do this operation thread safe method should lock data
        /// array using data.SyncRoot</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='key'>key value</param>
        /// <returns>array of values from this Series for given key</returns>
        public ArrayList GetValuesByKey(object key) 
        {
            // Should return INumeric array with hashtable values
            // corresponding to given hashtable key.
            
            if (key == null)
            {
                throw new ArgumentNullException("key", "key cannot be null");
            }
            
            ArrayList valuesArray = new ArrayList();
            lock (data.SyncRoot) 
            {
                foreach(ChartData chartData in data) 
                {
                    if (chartData.GetValue(key) != null) 
                    {
                        valuesArray.Add(chartData.GetValue(key));
                    }
                }
            }
            return valuesArray;
        }
        
        /// Operation Equals
        /// <summary>
        /// <p>Overridden method of object object. Determines whether the
        /// specified object is equal to the current series object.</p>
        /// <p>Series objects with the same data collection are equal,
        /// otherwise they are not.</p>
        /// </summary>
        /// <param name='o'>object to compare with current series object</param>
        /// <returns>true if the specified Object is equal to the this
        /// series object; otherwise, false.</returns>
        public override bool Equals(object o) 
        {
            try 
            {
                if (!(data.Equals(((Series)o).data))) 
                {
                    return false;
                }
                return true;
            } 
            catch 
            {
                return false;
            }
        }
        
        /// Operation GetHashCode
        /// <summary>
        /// <p>Overridden method of object object. Returns
        /// a hash code for the current Series.</p>
        /// <p>Hashcode of Series object is equal of hashcode of its label.</p>
        /// </summary>
        /// <returns>A hash code for the current Series object</returns>
        public override int GetHashCode()
        {
            return Label.GetHashCode();
        }
    }
    
}
