// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;
using NUnit.Framework;
using System.Collections;
using TopCoder.Report.Chart.Elements;

namespace TopCoder.Report.Chart {
    /// <summary>
    /// This test class will test PieChart Class.
    /// </summary>
    [TestFixture]
    public class PieChartTests
    {
        /// <summary>
        /// Series used for tests
        /// </summary>
        Series series;
        
        /// <summary>
        /// PieChart used for tests
        /// </summary>
        PieChart pieChart;
        
        /// <summary>
        /// Attributes setup for common tests.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            series = new Series("series1");
            series.Add((new SingleValue("singleValue1", new Numeric(1))));
            series.Add((new SingleValue("singleValue2", new Numeric(2))));
            series.Add((new SingleValue("singleValue3", new Numeric(3))));
            pieChart = new PieChart("PieChart1",series);
        }
        
        /// <summary>
        /// Tests null constructor 1
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorNullParamTest1()
        {
            new PieChart(null, series);
        }
        
        /// <summary>
        /// Tests null constructor 2
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorNullParamTest2()
        {
            new PieChart("PieChart", null);
        }
        
        /// <summary>
        /// Tests series property
        /// </summary>
        [Test]
        public void SeriesPropertyTest()
        {
            Assert.AreEqual(1, pieChart.Series.GetValue(0).GetValue("singleValue1").ToDouble());
        }
    }
}
