// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;
using NUnit.Framework;
using System.Collections;

namespace TopCoder.Report.Chart.Elements {
    /// <summary>
    /// This test class will test Axis Class.
    /// </summary>
    [TestFixture]
    public class AxisTests
    {
        /// <summary>
        /// axis used for tests
        /// </summary>
        Axis axis;

        /// <summary>
        /// Attributes setup for common tests.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            axis = new Axis("axis1");
            axis.MinimumValue = 1;
            axis.MaximumValue = 10;
        }
        
        /// <summary>
        /// Tests Null constructor
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorNullParamTest()
        {
            new Axis(null);
        }
        
        /// <summary>
        /// Tests minimum and maximun properties
        /// </summary>
        [Test]
        public void MinimumMaximumPropertiesTest()
        {
            Assert.AreEqual(1, axis.MinimumValue);
            Assert.AreEqual(10, axis.MaximumValue);
        }
        
        /// <summary>
        /// Tests changing minimum and maximum properties
        /// </summary>
        [Test]
        public void MinimumMaximumPropertiesChangeTest()
        {
            axis.MinimumValue = 2;
            axis.MaximumValue = 20;
            Assert.AreEqual(2, axis.MinimumValue);
            Assert.AreEqual(20, axis.MaximumValue);
        }
        
        /// <summary>
        /// Tests invalid minimum and maximum properties
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void MinimumMaximumPropertiesInvalidTest()
        {
            axis.MinimumValue = 20;
            axis.MaximumValue = 2;
        }
        
        /// <summary>
        /// Tests equal axes
        /// </summary>
        [Test]
        public void AxisEqualsTest()
        {
            Axis axis2 = new Axis("axis1");
            Axis axis3 = new Axis("axis3");
            Assert.IsTrue(axis.Equals(axis2));
            Assert.IsFalse(axis.Equals(axis3));
            Assert.IsFalse(axis.Equals(null), "comparition with null must return false");
            Assert.IsFalse(axis.Equals(new object()), "Different object types must return false");
        }

        /// <summary>
        /// Tests axis HashCode
        /// </summary>
        [Test]
        public void AxisGetHashCodeTest()
        {
            Assert.IsTrue(axis.GetHashCode() > 0);
        }
    }
}
