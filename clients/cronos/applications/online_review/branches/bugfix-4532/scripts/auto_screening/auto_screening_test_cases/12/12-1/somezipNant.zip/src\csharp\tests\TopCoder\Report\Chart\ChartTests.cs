// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;
using NUnit.Framework;
using System.Collections;
using TopCoder.Report.Chart.Elements;

namespace TopCoder.Report.Chart {
    /// <summary>
    /// This test class will test Chart Class.
    /// </summary>
    [TestFixture]
    public class ChartTests
    {
        #region "class MockChart"
        
        /// <summary>
        /// This class inherits from Chart.
        /// </summary>
        private class MockChart: Chart
        {
            /// <summary>
            /// Create a MockChart, calling the base constructor.
            /// </summary>
            /// <param name="label">label for the chart</param>
            public MockChart(string label) : base (label)
            {
            }
        }
        #endregion
        
        /// <summary>
        /// Series used for tests
        /// </summary>
        private Series series1;

        /// <summary>
        /// Series used for tests
        /// </summary>
        private Series series2;
        
        /// <summary>
        /// MockChart used for tests
        /// </summary>
        MockChart mockChart;
        
        /// <summary>
        /// Attributes setup for common tests.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            mockChart = new MockChart("chart1");
            series1 = new Series("series1");
            series1.Add((new SingleValue("singleValue1", new Numeric(1))));
            series1.Add((new SingleValue("singleValue2", new Numeric(2))));
            series1.Add((new SingleValue("singleValue3", new Numeric(3))));
            series2 = new Series("series2");
            series2.Add((new SingleValue("singleValue4", new Numeric(4))));
            series2.Add((new SingleValue("singleValue5", new Numeric(5))));
            series2.Add((new SingleValue("singleValue6", new Numeric(6))));
            mockChart.AddSeries(series1);
            mockChart.AddSeries(series2);
        }
        
        /// <summary>
        /// Tests null constructor 1
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ConstructorNullParamTest()
        {
            new MockChart(null);
        }
        
        /// <summary>
        /// Tests null series adding
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void AddNullSeriesTest()
        {
            mockChart.AddSeries(null);
        }
        
        /// <summary>
        /// Tests fixing size
        /// </summary>
        [Test]
        [ExpectedException(typeof(NotSupportedException))]
        public void FixSizeTest()
        {
            mockChart.FixSize();
            mockChart.AddSeries(new Series("series1"));
        }
        
        /// <summary>
        /// Tests getting index
        /// </summary>
        [Test]
        public void GetIndexTest()
        {
            Assert.AreEqual(1, mockChart.GetIndex("series2"));
        }
        
        /// <summary>
        /// Tests getting series
        /// </summary>
        [Test]
        public void GetSeriesTest()
        {
            Assert.AreEqual("series1", mockChart.GetSeries(0).Label);
        }
        
        /// <summary>
        /// Tests removing series
        /// </summary>
        [Test]
        public void RemoveSeriesTest()
        {
            mockChart.RemoveSeries(series2);
            Assert.AreEqual(1, mockChart.SeriesCount);
        }
        
        /// <summary>
        /// Tests removing series at
        /// </summary>
        [Test]
        public void RemoveSeriesAtTest()
        {
            mockChart.RemoveSeriesAt(0);
            Assert.AreEqual(1, mockChart.SeriesCount);
        }
        
        /// <summary>
        /// Tests legend property
        /// </summary>
        [Test]
        public void LegendPropertyTest()
        {
            Assert.AreEqual("chart1", mockChart.Legend.Label);
        }
        
        /// <summary>
        /// Tests series count property
        /// </summary>
        [Test]
        public void SeriesCountPropertyTest()
        {
            Assert.AreEqual(2, mockChart.SeriesCount);
        }
        
        /// <summary>
        /// Tests enumerator
        /// </summary>
        [Test]
        public void GetEnumeratorTest()
        {
            IEnumerator dataEnum = mockChart.GetEnumerator();
            Assert.AreEqual(true, dataEnum.MoveNext());
        }
        
        /// <summary>
        /// Tests SyncRoot property
        /// </summary>
        [Test]
        public void SyncRootPropertyTest()
        {
            Assert.AreEqual(true, mockChart.SyncRoot != null);
        }
    }
}
