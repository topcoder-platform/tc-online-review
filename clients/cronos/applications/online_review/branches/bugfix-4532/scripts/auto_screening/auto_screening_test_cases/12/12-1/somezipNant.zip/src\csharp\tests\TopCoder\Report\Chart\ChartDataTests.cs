// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System;
using NUnit.Framework;
using System.Collections;

namespace TopCoder.Report.Chart.Elements {
    /// <summary>
    /// This test class will test ChartData Class.
    /// </summary>
    [TestFixture]
    public class ChartDataTests
    {
        
        #region "class MockChartData"
        
        /// <summary>
        /// This class inherits from ChartData.
        /// </summary>
        private class MockChartData: ChartData
        {
            /// <summary>
            /// Create a MockChartData, calling the base constructor. 
            /// </summary>
            /// <param name="label">label for the chart</param>
            public MockChartData(string label): base(label) {
            }
            
            /// <summary>
            /// Create a MockChartData, calling the base constructor. 
            /// </summary>
            /// <param name="label">label for the chart</param>
            /// <param name="data">data for the chart</param>
            public MockChartData(string label, IDictionary data) : base(label, data){
            }
        }
        #endregion
        
        
        /// <summary>
        /// MockChartData used for tests
        /// </summary>
        private MockChartData mockChartData ;
        
        /// <summary>
        /// Hashtable used for tests
        /// </summary>
        private Hashtable hashtable;
        
        /// <summary>
        /// Attributes setup for common tests.
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            hashtable = new Hashtable();
            hashtable.Add("point1",new Numeric(1));
            hashtable.Add("point2",new Numeric(2));
            hashtable.Add("point3",new Numeric(3));
            mockChartData = new MockChartData("Data1", hashtable);
        }
        
        /// <summary>
        /// Tests Null constructor - label
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullLabelConstructorTest()
        {
            new MockChartData(null,new Hashtable());
        }
        
        /// <summary>
        /// Tests Null constructor - data
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void NullDataConstructorTest()
        {
            new MockChartData("Data1",null);
        }
        
        /// <summary>
        /// Tests invalid data
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentException))]
        public void InvalidDataConstructorTest()
        {
            hashtable.Add("point4",4);
            new MockChartData("Data1", hashtable);
        }
        
        /// <summary>
        /// Tests label set in constructor 1
        /// </summary>
        [Test]
        public void LabelSetInConstructor1Test()
        {
            MockChartData mockChartData2 = new MockChartData("Data1") ;
            Assert.AreEqual("Data1", mockChartData2.Label);
        }
        
        /// <summary>
        /// Tests label set in constructor 2
        /// </summary>
        [Test]
        public void LabelSetInConstructor2Test()
        {
            Assert.AreEqual("Data1", mockChartData.Label);
        }
        
        /// <summary>
        /// Tests data set in constructor
        /// </summary>
        [Test]
        public void DataSetInConstructorTest()
        {
            Assert.AreEqual(1, mockChartData.GetValue("point1").ToDouble());
            Assert.AreEqual(2, mockChartData.GetValue("point2").ToDouble());
            Assert.AreEqual(3, mockChartData.GetValue("point3").ToDouble());
        }
        
        /// <summary>
        /// Tests setValue with null key
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SetValueNullKeyTest()
        {
            mockChartData.SetValue(null, new Numeric(1));
        }
        
        /// <summary>
        /// Tests setValue with null value
        /// </summary>
        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SetValueNullValueTest()
        {
            mockChartData.SetValue("point4", null);
        }
        
        /// <summary>
        /// Tests set and get Value
        /// </summary>
        [Test]
        public void SetValueGetValueTest()
        {
            mockChartData.SetValue("point4", new Numeric(4));
            Assert.AreEqual(4, mockChartData.GetValue("point4").ToDouble());
        }
        
        /// <summary>
        /// Tests getValue that does not exists
        /// </summary>
        [Test]
        public void GetValueDontExistsTest()
        {
            Assert.AreEqual(null, mockChartData.GetValue("point5"));
        }
        
    }
}
