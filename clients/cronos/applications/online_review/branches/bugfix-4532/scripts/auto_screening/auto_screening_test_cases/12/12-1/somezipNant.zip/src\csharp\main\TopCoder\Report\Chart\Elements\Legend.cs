// Copyright (c)2005, TopCoder, Inc. All rights reserved
// @author TCSDEVELOPER
// @version 1.0

using System.Drawing;
using System.Collections;
using System;

namespace TopCoder.Report.Chart.Elements 
{
    /// <summary>
    /// <p>Returns the number of items in legend items collection</p>
    /// <p>Simply uses chart.Series.Count property</p>
    /// </summary>
    public class Legend : AttributableObject 
    {
        /// Attribute chart
        /// <summary>
        /// <p>Reference to instance of chart contained this object.</p>
        /// </summary>
        private Chart chart = null;
        
        /// Attribute Chart
        /// <summary>
        /// <p>Returns reference to chart associated with the legend.</p>
        /// <p>Simply uses chart value</p>
        /// </summary>
        public Chart Chart 
        {
            get 
            {
                return chart;
            }
        }
        
        /// Attribute Label
        /// <summary>
        /// <p>Overridden property for attribute Label.</p>
        /// <p>Getter method gets base.Label. If it is not null the method
        /// returns it, otherwise - chart.Label.</p>
        /// <p>Setter method just does this["label"] = value.</p>
        /// <p>As LegendItem instance has default value for label it can
        /// set label attribute to null.</p>
        /// </summary>
        public override string Label 
        {
            get 
            {
                return base.Label != null ? base.Label : chart.Label;
            }
            set 
            {
                // Avoiding the enlargement of the collection if the value is null. (it is its default)
                if (value == null) 
                {
                    attributes.Remove("label");
                } 
                else 
                {
                    this["label"] = value;
                }
            }
            
        }
        
        /// Attribute Color
        /// <summary>
        /// <p>Overridden property for attribute Color.</p>
        /// <p>Getter method gets base.Color. If it is not null the method
        /// returns it, otherwise - chart.Color.</p>
        /// <p>Setter method just does base.Color = value.</p>
        /// </summary>
        public override Color Color 
        {
            get 
            {
                return base.Color != Color.Empty ? base.Color : chart.Color;
            }
            set 
            {
                base.Color = value;
            }
        }
        
        /// Attribute Annotation
        /// <summary>
        /// <p>Overridden property for attribute Annotation.</p>
        /// <p>Getter method gets base.Annotation. If it is not null the
        /// method returns it, otherwise - chart.Annotation.</p>
        /// <p>Setter method just does base.Annotation = value.</p>
        /// </summary>
        public override string Annotation 
        {
            get 
            {
                return base.Annotation != null ? base.Annotation : chart.Annotation;
            }
            set 
            {
                base.Annotation = value;
            }
        }
        
        /// Attribute ItemCount
        /// <summary>
        /// <p>Returns the number of items in legend items collection</p>
        /// <p>Uses chart.SeriesCount property</p>
        /// </summary>
        public int ItemCount 
        {
            get 
            {
                return (chart.SeriesCount);
            }
        }
        
        /// Constructor Legend
        /// <summary>
        /// <p>Constructs Legend object. Sets chart variable to parameter.</p>
        /// </summary>
        /// <exception>ArgumentNullException if parameter is null</exception>
        /// <param name='container'>reference to container object</param>
        public Legend(Chart container) 
        {
            if (container == null)
            {
                throw new ArgumentNullException("container", "container cannot be null");
            }
            chart = container;
        }
        
        /// Operation this
        /// <summary>
        /// <p>Overridden getter indexer of class.</p>
        /// <p>Returns value of attribute with specified key. If key is not
        /// found returns appropriate attribute value of Chart object.</p>
        /// <p>Overridden setter indexer of class. Sets the attribute
        /// associated with the specified key. If the specified key is not
        /// found creates a new element using the specified key and value.</p>
        /// </summary>
        /// <exception>ArgumentNullException if key is null</exception>
        /// <param name='key'>attribute key</param>
        /// <returns>value of attribute with given key</returns>
        public override object this[object key]
        {
            get
            {
                if (key == null)
                {
                    throw new ArgumentNullException("key", "key cannot be null");
                }
                return base[key] != null ? base[key] : chart[key];
            }
            set
            {
                if (key == null)
                {
                    throw new ArgumentNullException("key", "key cannot be null");
                }
                base[key] = value;
            }
        }
        
        
        // Operation ClearAttributes
        /// <summary>
        /// <p>Resets the entire legend and all LegendItem objects for
        /// each series by eliminating all attribute information -
        /// thus providing the default information.</p>
        /// </summary>
        /// <returns>void</returns>
        public override void ClearAttributes() 
        {
            base.ClearAttributes();
            
            for (int i = 0; i < this.ItemCount; i++) 
            {
                GetLegendItem(i).ClearAttributes();
            }
        }
        
        /// Operation GetLegendItem
        /// <summary>
        /// <p> Returns legend item for Series with given index. This method
        /// can be used to iterate through legend item collection. </p>
        /// <p> Simply returns chart.GetSeries(index).LegendItem </p>
        /// </summary>
        /// <exception>ArgumentOutOfRangeException if index is out range
        /// [0; ItemCount-1] </exception>
        /// <param name='index'>series index</param>
        /// <returns>legend item for series with given index</returns>
        public LegendItem GetLegendItem(int index) 
        {
            // chart.GetSeries() handles invalid index
            return chart.GetSeries(index).LegendItem;
        }
    }
    
}
