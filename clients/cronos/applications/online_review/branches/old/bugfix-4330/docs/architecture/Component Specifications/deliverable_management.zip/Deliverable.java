package com.topcoder.management.deliverable;

import java.util.Date;
import java.io.Serializable;

public class Deliverable implements Serializable {
	public String getName() {
		return null;
	}
	public long getProject() {
		return 0;
	}
	public long getPhase() {
		return 0;
	}
	public long getResource() {
		return 0;
	}
	public Long getSubmission() {
		return null;
	}
	public boolean isRequired() {
		return false;
	}
	public void setCompletionDate(Date completionDate) {
	}
	public Date getCompletionDate() {
		return null;
	}
}
