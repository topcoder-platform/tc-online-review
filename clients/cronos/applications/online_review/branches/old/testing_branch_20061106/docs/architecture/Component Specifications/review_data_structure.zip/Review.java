package com.topcoder.management.review.data;

import java.io.Serializable;
import java.util.Date;


public class Review implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setAuthor(long author) {
	}
	public long getAuthor() {
		return 0;
	}
	public void setSubmission(long submission) {
	}
	public long getSubmission() {
		return 0;
	}
	public void setScorecard(long scorecard) {
	}
	public long getScorecard() {
		return 0;
	}
	public void setCommitted(boolean committed) {
	}
	public boolean isCommitted() {
		return false;
	}
	public void setScore(Float score) {
	}
	public Float getScore() {
		return null;
	}
	public void addItem(Item item) {
	}
	public void removeItem(Item item) {
	}
	public Item[] getAllItems() {
		return null;
	}
	public void addComment(Comment comment) {
	}
	public void removeComment(Comment comment) {
	}
	public Comment[] getAllComments() {
		return null;
	}
	public void setCreationUser(String creationUser) {
	}
	public String getCreationUser() {
		return null;
	}
	public void setCreationTimestamp(Date creationTimestamp) {
	}
	public Date getCreationTimestamp() {
		return null;
	}
	public void setModificationUser(String modificationUser) {
	}
	public String getModificationUser() {
		return null;
	}
	public void setModificationTimestamp(Date modificationTimestamp) {
	}
	public Date getModificationTimestamp() {
		return null;
	}
}
