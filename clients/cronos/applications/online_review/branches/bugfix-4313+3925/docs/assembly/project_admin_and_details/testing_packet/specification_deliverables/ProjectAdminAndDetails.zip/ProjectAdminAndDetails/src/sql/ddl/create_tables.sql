-- Tables required by the Authorization component

CREATE TABLE principal(
           principal_id integer NOT NULL, 
           principal_name varchar(255),
           PRIMARY KEY (principal_id));

revoke all on "informix".principal from "public";
grant select on "informix".principal to "public" as "informix";
grant update on "informix".principal to "public" as "informix";
grant insert on "informix".principal to "public" as "informix";
grant delete on "informix".principal to "public" as "informix";
grant index on "informix".principal to "public" as "informix";

CREATE TABLE role(
           role_id integer NOT NULL,
           role_name varchar(255),
           PRIMARY KEY (role_id));

revoke all on "informix".role from "public";
grant select on "informix".role to "public" as "informix";
grant update on "informix".role to "public" as "informix";
grant insert on "informix".role to "public" as "informix";
grant delete on "informix".role to "public" as "informix";
grant index on "informix".role to "public" as "informix";

CREATE TABLE principal_role(
           principal_id integer NOT NULL,
           role_id integer NOT NULL,
           PRIMARY KEY (principal_id, role_id), 
           FOREIGN KEY (principal_id) REFERENCES principal(principal_id), 
           FOREIGN KEY (role_id) REFERENCES role(role_id));

revoke all on "informix".principal_role from "public";
grant select on "informix".principal_role to "public" as "informix";
grant update on "informix".principal_role to "public" as "informix";
grant insert on "informix".principal_role to "public" as "informix";
grant delete on "informix".principal_role to "public" as "informix";
grant index on "informix".principal_role to "public" as "informix";

CREATE TABLE action(
           action_id integer NOT NULL, 
           class_name varchar(255) NOT NULL, 
           action_name varchar(255),
           PRIMARY KEY (action_id));

revoke all on "informix".action from "public";
grant select on "informix".action to "public" as "informix";
grant update on "informix".action to "public" as "informix";
grant insert on "informix".action to "public" as "informix";
grant delete on "informix".action to "public" as "informix";
grant index on "informix".action to "public" as "informix";

CREATE TABLE action_context(
           action_context_id integer NOT NULL PRIMARY KEY,
           action_context_name varchar(255),
           action_context_parent_id integer REFERENCES action_context(action_context_id),
           class_name varchar(255) NOT NULL);

revoke all on "informix".action_context from "public";
grant select on "informix".action_context to "public" as "informix";
grant update on "informix".action_context to "public" as "informix";
grant insert on "informix".action_context to "public" as "informix";
grant delete on "informix".action_context to "public" as "informix";
grant index on "informix".action_context to "public" as "informix";

CREATE TABLE role_action_context_permission(
           role_id integer NOT NULL,
           action_id integer NOT NULL,
           action_context_id integer NOT NULL,
           permission integer NOT NULL,
           PRIMARY KEY (role_id, action_id, action_context_id),
           FOREIGN KEY (role_id) REFERENCES role(role_id),
           FOREIGN KEY (action_id) REFERENCES action(action_id),
           FOREIGN KEY (action_context_id) REFERENCES action_context(action_context_id));

revoke all on "informix".role_action_context_permission from "public";
grant select on "informix".role_action_context_permission to "public" as "informix";
grant update on "informix".role_action_context_permission to "public" as "informix";
grant insert on "informix".role_action_context_permission to "public" as "informix";
grant delete on "informix".role_action_context_permission to "public" as "informix";
grant index on "informix".role_action_context_permission to "public" as "informix";

CREATE TABLE principal_action_context_permission(
           principal_id integer NOT NULL,
           action_id integer NOT NULL,
           action_context_id integer NOT NULL,
           permission integer NOT NULL,
           PRIMARY KEY (principal_id, action_id, action_context_id),
           FOREIGN KEY (principal_id) REFERENCES principal(principal_id),
           FOREIGN KEY (action_id) REFERENCES action(action_id),
           FOREIGN KEY (action_context_id) REFERENCES action_context(action_context_id));

revoke all on "informix".principal_action_context_permission from "public";
grant select on "informix".principal_action_context_permission to "public" as "informix";
grant update on "informix".principal_action_context_permission to "public" as "informix";
grant insert on "informix".principal_action_context_permission to "public" as "informix";
grant delete on "informix".principal_action_context_permission to "public" as "informix";
grant index on "informix".principal_action_context_permission to "public" as "informix";


-- create table for IDGenerator 3.0
CREATE TABLE id_sequences (
	name VARCHAR(255) NOT NULL,
	PRIMARY KEY (name),
	next_block_start integer NOT NULL,
	block_size INT NOT NULL,
	exhausted int not null
);

revoke all on "informix".id_sequences from "public";
grant select on "informix".id_sequences to "public" as "informix";
grant update on "informix".id_sequences to "public" as "informix";
grant insert on "informix".id_sequences to "public" as "informix";
grant delete on "informix".id_sequences to "public" as "informix";
grant index on "informix".id_sequences to "public" as "informix";

-- this is the required row for Time Tracker User component.
INSERT INTO id_sequences (name, next_block_start, block_size, exhausted)
VALUES ('TimeTrackerUser', 1, 20, 0);
INSERT INTO id_sequences (name, next_block_start, block_size, exhausted)
VALUES ('com.cronos.timetracker.entry.time.TimeEntry', 1, 20, 0);


-- Internal table for storing imported users

CREATE TABLE Users (
       UsersID              integer NOT NULL,
       Name                 varchar(64) NOT NULL,
       CreationDate         datetime year to second,	  	-- NOT NULL flag is removed, because this field is out of scope for this component
       CreationUser         varchar(64),	  	-- NOT NULL flag is removed, because this field is out of scope for this component
       ModificationDate     datetime year to second,	  	-- NOT NULL flag is removed, because this field is out of scope for this component
       ModificationUser     varchar(64),	  	-- NOT NULL flag is removed, because this field is out of scope for this component
       UserStore            varchar(255) NOT NULL, -- field added by designer to store link to original user store
       PRIMARY KEY (UsersID)
);

revoke all on "informix".Users from "public";
grant select on "informix".users to "public" as "informix";
grant update on "informix".users to "public" as "informix";
grant insert on "informix".users to "public" as "informix";
grant delete on "informix".users to "public" as "informix";
grant index on "informix".users to "public" as "informix";

-- Default supported table for storing user profiles

CREATE TABLE DefaultUsers (
       DefaultUsersID       integer NOT NULL,
       UserName             varchar(64) NOT NULL,
       Password             varchar(64) NOT NULL,
       FirstName            varchar(64),
       LastName             varchar(64),
       Phone                varchar(20),
       Email                varchar(64),
       CreationDate         datetime year to second NOT NULL,
       CreationUser         varchar(64) NOT NULL,
       ModificationDate     datetime year to second NOT NULL,
       ModificationUser     varchar(64) NOT NULL,
       PRIMARY KEY (DefaultUsersID)
);

revoke all on "informix".DefaultUsers from "public";
grant select on "informix".Defaultusers to "public" as "informix";
grant update on "informix".Defaultusers to "public" as "informix";
grant insert on "informix".Defaultusers to "public" as "informix";
grant delete on "informix".Defaultusers to "public" as "informix";
grant index on "informix".Defaultusers to "public" as "informix";

-- Table for storing reject reasons

CREATE TABLE reject_reason (
       reject_reason_id          integer NOT NULL,
       description          varchar(255) NOT NULL,
       creation_date         datetime year to second NOT NULL,
       creation_user         varchar(64) NOT NULL,
       modification_date     datetime year to second NOT NULL,
       modification_user     varchar(64) NOT NULL,
       PRIMARY KEY (reject_reason_id)
);

revoke all on "informix".reject_reason from "public";
grant select on "informix".reject_reason to "public" as "informix";
grant update on "informix".reject_reason to "public" as "informix";
grant insert on "informix".reject_reason to "public" as "informix";
grant delete on "informix".reject_reason to "public" as "informix";
grant index on "informix".reject_reason to "public" as "informix";

-- Represents the many-to-many relationship between clients and projects

CREATE TABLE ClientProjects (
       ClientsID            integer NOT NULL,
       ProjectsID           integer NOT NULL,
       CreationDate         datetime year to second NOT NULL,
       CreationUser         varchar(64) NOT NULL,
       ModificationDate     datetime year to second NOT NULL,
       ModificationUser     varchar(64) NOT NULL,
       PRIMARY KEY (ClientsID, ProjectsID)
);

revoke all on "informix".ClientProjects from "public";
grant select on "informix".ClientProjects to "public" as "informix";
grant update on "informix".ClientProjects to "public" as "informix";
grant insert on "informix".ClientProjects to "public" as "informix";
grant delete on "informix".ClientProjects to "public" as "informix";
grant index on "informix".ClientProjects to "public" as "informix";

-- Table for storing clients

CREATE TABLE Clients (
       ClientsID            integer NOT NULL,
       Name                 varchar(64) NOT NULL,
       CreationDate         datetime year to second NOT NULL,
       Creationuser         varchar(64) NOT NULL,
       ModificationDate     datetime year to second NOT NULL,
       ModificationUser     varchar(64) NOT NULL,
       PRIMARY KEY (ClientsID)
);

revoke all on "informix".Clients from "public";
grant select on "informix".Clients to "public" as "informix";
grant update on "informix".Clients to "public" as "informix";
grant insert on "informix".Clients to "public" as "informix";
grant delete on "informix".Clients to "public" as "informix";
grant index on "informix".Clients to "public" as "informix";

-- Represents the many-to-many relationship between Projects and expense entries

CREATE TABLE ProjectExpenses (
       ProjectsID           integer NOT NULL,
       ExpenseEntriesID     integer NOT NULL,
       CreationDate         datetime year to second NOT NULL,
       CreationUser         varchar(64) NOT NULL,
       ModificationDate     datetime year to second NOT NULL,
       ModificationUser     varchar(64) NOT NULL,
       PRIMARY KEY (ProjectsID, ExpenseEntriesID)
);

revoke all on "informix".ProjectExpenses  from "public";
grant select on "informix".ProjectExpenses  to "public" as "informix";
grant update on "informix".ProjectExpenses  to "public" as "informix";
grant insert on "informix".ProjectExpenses  to "public" as "informix";
grant delete on "informix".ProjectExpenses  to "public" as "informix";
grant index on "informix".ProjectExpenses  to "public" as "informix";

-- Represents the many-to-many relationship between projects and users

CREATE TABLE ProjectManagers (
       ProjectsID           integer NOT NULL,
       UsersID              integer NOT NULL,
       CreationDate         datetime year to second NOT NULL,
       CreationUser         varchar(64) NOT NULL,
       ModificationDate     datetime year to second NOT NULL,
       ModificationUser     varchar(64) NOT NULL,
       PRIMARY KEY (ProjectsID, UsersID)
);

revoke all on "informix".ProjectManagers   from "public";
grant select on "informix".ProjectManagers   to "public" as "informix";
grant update on "informix".ProjectManagers   to "public" as "informix";
grant insert on "informix".ProjectManagers   to "public" as "informix";
grant delete on "informix".ProjectManagers   to "public" as "informix";
grant index on "informix".ProjectManagers   to "public" as "informix";


-- Table for storing project information

CREATE TABLE Projects (
       ProjectsID           integer NOT NULL,
       Name                 varchar(64) NOT NULL,
       Description          varchar(64) NOT NULL,
       StartDate            datetime year to second NOT NULL,
       EndDate              datetime year to second NOT NULL,
       CreationDate         datetime year to second NOT NULL,
       CreationUser         varchar(64) NOT NULL,
       ModificationDate     datetime year to second NOT NULL,
       ModificationUser     varchar(64) NOT NULL,
       PRIMARY KEY (ProjectsID)
);

revoke all on "informix".Projects   from "public";
grant select on "informix".Projects   to "public" as "informix";
grant update on "informix".Projects   to "public" as "informix";
grant insert on "informix".Projects   to "public" as "informix";
grant delete on "informix".Projects   to "public" as "informix";
grant index on "informix".Projects   to "public" as "informix";


-- Represents the many-to-many relationship between projects and time entries

CREATE TABLE ProjectTimes (
       ProjectsID           integer NOT NULL,
       TimeEntriesID        integer NOT NULL,
       CreationDate         datetime year to second NOT NULL,
       CreationUser         varchar(64) NOT NULL,
       ModificationDate     datetime year to second NOT NULL,
       ModificationUser     varchar(64) NOT NULL,
       PRIMARY KEY (ProjectsID, TimeEntriesID)
);

revoke all on "informix".ProjectTimes    from "public";
grant select on "informix".ProjectTimes    to "public" as "informix";
grant update on "informix".ProjectTimes    to "public" as "informix";
grant insert on "informix".ProjectTimes    to "public" as "informix";
grant delete on "informix".ProjectTimes    to "public" as "informix";
grant index on "informix".ProjectTimes    to "public" as "informix";

-- Represents the many-to-many relationship between projects and project workers

CREATE TABLE ProjectWorkers (
       ProjectsID           integer NOT NULL,
       UsersID              integer NOT NULL,
       StartDate            datetime year to second NOT NULL,
       EndDate              datetime year to second NOT NULL,
       PayRate              money NOT NULL,
       CreationDate         datetime year to second NOT NULL,
       CreationUser         varchar(64) NOT NULL,
       ModificationDate     datetime year to second NOT NULL,
       ModificationUser     varchar(64) NOT NULL,
       PRIMARY KEY (ProjectsID, UsersID)
);

revoke all on "informix".ProjectWorkers   from "public";
grant select on "informix".ProjectWorkers   to "public" as "informix";
grant update on "informix".ProjectWorkers   to "public" as "informix";
grant insert on "informix".ProjectWorkers   to "public" as "informix";
grant delete on "informix".ProjectWorkers   to "public" as "informix";
grant index on "informix".ProjectWorkers   to "public" as "informix";

-- Table for storing task types

CREATE TABLE TaskTypes (
       TaskTypesID          integer NOT NULL,
       Description          varchar(64) NOT NULL,
       CreationDate         datetime year to second NOT NULL,
       CreationUser         varchar(64) NOT NULL,
       ModificationDate     datetime year to second NOT NULL,
       ModificationUser     varchar(64) NOT NULL,
       PRIMARY KEY (TaskTypesID)
);

revoke all on "informix".TaskTypes   from "public";
grant select on "informix".TaskTypes   to "public" as "informix";
grant update on "informix".TaskTypes   to "public" as "informix";
grant insert on "informix".TaskTypes   to "public" as "informix";
grant delete on "informix".TaskTypes   to "public" as "informix";
grant index on "informix".TaskTypes   to "public" as "informix";


-- Table for storing time entries

CREATE TABLE TimeEntries (
       TimeEntriesID        integer NOT NULL,
       TaskTypesID          integer NOT NULL,
       TimeStatusesID       integer NOT NULL,
       Description          varchar(64) NOT NULL,
       EntryDate            datetime year to second NOT NULL,
       Hours                float NOT NULL,
       Billable             smallint NOT NULL,
       CreationDate         datetime year to second NOT NULL,
       CreationUser         varchar(64) NOT NULL,
       ModificationDate     datetime year to second NOT NULL,
       ModificationUser     varchar(64) NOT NULL,
       PRIMARY KEY (TimeEntriesID)
);

revoke all on "informix".TimeEntries   from "public";
grant select on "informix".TimeEntries   to "public" as "informix";
grant update on "informix".TimeEntries   to "public" as "informix";
grant insert on "informix".TimeEntries   to "public" as "informix";
grant delete on "informix".TimeEntries   to "public" as "informix";
grant index on "informix".TimeEntries   to "public" as "informix";


-- Table for storing time statuses

CREATE TABLE TimeStatuses (
       TimeStatusesID       integer NOT NULL,
       Description          varchar(64) NOT NULL,
       CreationDate         datetime year to second NOT NULL,
       CreationUser         varchar(64) NOT NULL,
       ModificationDate     datetime year to second NOT NULL,
       ModificationUser     varchar(64) NOT NULL,
       PRIMARY KEY (TimeStatusesID)
);

revoke all on "informix".TimeStatuses   from "public";
grant select on "informix".TimeStatuses   to "public" as "informix";
grant update on "informix".TimeStatuses   to "public" as "informix";
grant insert on "informix".TimeStatuses   to "public" as "informix";
grant delete on "informix".TimeStatuses   to "public" as "informix";
grant index on "informix".TimeStatuses   to "public" as "informix";


-- Represents the many-to-many relationship between time entries and reject reasons

CREATE TABLE time_reject_reason (
       TimeEntriesID          integer NOT NULL,
       reject_reason_id          integer NOT NULL,
       creation_date         datetime year to second NOT NULL,
       creation_user         varchar(64) NOT NULL,
       modification_date     datetime year to second NOT NULL,
       modification_user     varchar(64) NOT NULL,
       PRIMARY KEY (TimeEntriesID, reject_reason_id)
);

revoke all on "informix".time_reject_reason   from "public";
grant select on "informix".time_reject_reason   to "public" as "informix";
grant update on "informix".time_reject_reason   to "public" as "informix";
grant insert on "informix".time_reject_reason   to "public" as "informix";
grant delete on "informix".time_reject_reason   to "public" as "informix";
grant index on "informix".time_reject_reason   to "public" as "informix";


-- Table for storing expense entries

CREATE TABLE ExpenseEntries (
       ExpenseEntriesID     integer NOT NULL,
       ExpenseTypesID       integer NOT NULL,
       ExpenseStatusesID    integer NOT NULL,
       Description          varchar(64) NOT NULL,
       EntryDate            datetime year to second NOT NULL,
       Amount               money NOT NULL,
       Billable             smallint NOT NULL,
       CreationDate         datetime year to second NOT NULL,
       CreationUser         varchar(64) NOT NULL,
       ModificationDate     datetime year to second NOT NULL,
       ModificationUser     varchar(64) NOT NULL,
       PRIMARY KEY (ExpenseEntriesID)
);

revoke all on "informix".ExpenseEntries  from "public";
grant select on "informix".ExpenseEntries  to "public" as "informix";
grant update on "informix".ExpenseEntries  to "public" as "informix";
grant insert on "informix".ExpenseEntries  to "public" as "informix";
grant delete on "informix".ExpenseEntries  to "public" as "informix";
grant index on "informix".ExpenseEntries  to "public" as "informix";


-- Table for storing expense statuses

CREATE TABLE ExpenseStatuses (
       ExpenseStatusesID    integer NOT NULL,
       Description          varchar(20) NOT NULL,
       CreationDate         datetime year to second NOT NULL,
       CreationUser         varchar(64) NOT NULL,
       ModificationDate     datetime year to second NOT NULL,
       ModificationUser     varchar(64) NOT NULL,
       PRIMARY KEY (ExpenseStatusesID)
);

revoke all on "informix".ExpenseStatuses  from "public";
grant select on "informix".ExpenseStatuses  to "public" as "informix";
grant update on "informix".ExpenseStatuses  to "public" as "informix";
grant insert on "informix".ExpenseStatuses  to "public" as "informix";
grant delete on "informix".ExpenseStatuses  to "public" as "informix";
grant index on "informix".ExpenseStatuses  to "public" as "informix";


-- Table for storing expense types

CREATE TABLE ExpenseTypes (
       ExpenseTypesID       integer NOT NULL,
       Description          varchar(64) NOT NULL,
       CreationDate         datetime year to second NOT NULL,
       CreationUser         varchar(64) NOT NULL,
       ModificationDate     datetime year to second NOT NULL,
       ModificationUser     varchar(64) NOT NULL,
       PRIMARY KEY (ExpenseTypesID)
);

revoke all on "informix".ExpenseTypes from "public";
grant select on "informix".ExpenseTypes to "public" as "informix";
grant update on "informix".ExpenseTypes to "public" as "informix";
grant insert on "informix".ExpenseTypes to "public" as "informix";
grant delete on "informix".ExpenseTypes to "public" as "informix";
grant index on "informix".ExpenseTypes to "public" as "informix";

-- Represents the many-to-many relationship between expense entries and reject reasons

CREATE TABLE exp_reject_reason (
       ExpenseEntriesID          integer NOT NULL,
       reject_reason_id          integer NOT NULL,
       creation_date         datetime year to second NOT NULL,
       creation_user         varchar(64) NOT NULL,
       modification_date     datetime year to second NOT NULL,
       modification_user     varchar(64) NOT NULL,
       PRIMARY KEY (ExpenseEntriesID, reject_reason_id)
);

revoke all on "informix".exp_reject_reason from "public";
grant select on "informix".exp_reject_reason to "public" as "informix";
grant update on "informix".exp_reject_reason to "public" as "informix";
grant insert on "informix".exp_reject_reason to "public" as "informix";
grant delete on "informix".exp_reject_reason to "public" as "informix";
grant index on "informix".exp_reject_reason to "public" as "informix";

ALTER TABLE ExpenseEntries
       ADD CONSTRAINT FOREIGN KEY (ExpenseStatusesID)
                             REFERENCES ExpenseStatuses;


ALTER TABLE ExpenseEntries
       ADD CONSTRAINT FOREIGN KEY (ExpenseTypesID)
                             REFERENCES ExpenseTypes;

ALTER TABLE exp_reject_reason
       ADD CONSTRAINT FOREIGN KEY (ExpenseEntriesID)
                             REFERENCES ExpenseEntries;

ALTER TABLE exp_reject_reason
       ADD CONSTRAINT FOREIGN KEY (reject_reason_id)
                             REFERENCES reject_reason;


ALTER TABLE TimeEntries
       ADD CONSTRAINT FOREIGN KEY (TimeStatusesID)
                             REFERENCES TimeStatuses;


ALTER TABLE TimeEntries
       ADD CONSTRAINT FOREIGN KEY (TaskTypesID)
                             REFERENCES TaskTypes;

ALTER TABLE time_reject_reason
       ADD CONSTRAINT FOREIGN KEY (TimeEntriesID)
                             REFERENCES TimeEntries;

ALTER TABLE time_reject_reason
       ADD CONSTRAINT FOREIGN KEY (reject_reason_id)
                             REFERENCES reject_reason;




ALTER TABLE ClientProjects
       ADD CONSTRAINT FOREIGN KEY (ProjectsID)
                             REFERENCES Projects;


ALTER TABLE ClientProjects
       ADD CONSTRAINT FOREIGN KEY (ClientsID)
                             REFERENCES Clients;


ALTER TABLE ProjectExpenses
       ADD CONSTRAINT FOREIGN KEY (ExpenseEntriesID)
                             REFERENCES ExpenseEntries;


ALTER TABLE ProjectExpenses
       ADD CONSTRAINT FOREIGN KEY (ProjectsID)
                             REFERENCES Projects;


ALTER TABLE ProjectManagers
       ADD CONSTRAINT FOREIGN KEY (UsersID)
                             REFERENCES Users;


ALTER TABLE ProjectManagers
       ADD CONSTRAINT FOREIGN KEY (ProjectsID)
                             REFERENCES Projects;


ALTER TABLE ProjectTimes
       ADD CONSTRAINT FOREIGN KEY (TimeEntriesID)
                             REFERENCES TimeEntries;


ALTER TABLE ProjectTimes
       ADD CONSTRAINT FOREIGN KEY (ProjectsID)
                             REFERENCES Projects;


ALTER TABLE ProjectWorkers
       ADD CONSTRAINT FOREIGN KEY (UsersID)
                             REFERENCES Users;


ALTER TABLE ProjectWorkers
       ADD CONSTRAINT FOREIGN KEY (ProjectsID)
                             REFERENCES Projects;

