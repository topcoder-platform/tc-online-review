INSERT INTO DefaultUsers(DefaultUsersID, UserName, Password, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1001, 'contractor', 'contractor', CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO DefaultUsers(DefaultUsersID, UserName, Password, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1002, 'employee', 'employee', CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO DefaultUsers(DefaultUsersID, UserName, Password, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1003, 'manager', 'manager', CURRENT, 'Tester', CURRENT, 'Tester');

INSERT INTO Users(UsersID, Name, UserStore, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1001, 'contractor', 'DbUS', CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO Users(UsersID, Name, UserStore, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1002, 'employee', 'DbUS', CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO Users(UsersID, Name, UserStore, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1003, 'manager', 'DbUS', CURRENT, 'Tester', CURRENT, 'Tester');

INSERT INTO principal(principal_id, principal_name) VALUES(1001, 'contractor');
INSERT INTO principal(principal_id, principal_name) VALUES(1002, 'employee');
INSERT INTO principal(principal_id, principal_name) VALUES(1003, 'manager');

INSERT INTO principal_role(principal_id, role_id) VALUES(1001, 6);
INSERT INTO principal_role(principal_id, role_id) VALUES(1002, 5);
INSERT INTO principal_role(principal_id, role_id) VALUES(1003, 7);



-- test clients

INSERT INTO Clients(ClientsID, Name, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1001, 'ACME', CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO Clients(ClientsID, Name, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1002, 'Excellentia', CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO Clients(ClientsID, Name, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1003, 'Frequentia', CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO Clients(ClientsID, Name, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1004, 'iento', CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO Clients(ClientsID, Name, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1005, 'Rapidence', CURRENT, 'Tester', CURRENT, 'Tester');

-- test projects

INSERT INTO Projects(ProjectsID, Name, Description, StartDate, EndDate, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1001, 'Self-Service Center', 'Description', CURRENT, CURRENT, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO Projects(ProjectsID, Name, Description, StartDate, EndDate, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1002, 'Notification Tag', 'Description', CURRENT, CURRENT, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO Projects(ProjectsID, Name, Description, StartDate, EndDate, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1003, 'Security Engine', 'Description', CURRENT, CURRENT, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO Projects(ProjectsID, Name, Description, StartDate, EndDate, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1004, 'Documentor', 'Description', CURRENT, CURRENT, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO Projects(ProjectsID, Name, Description, StartDate, EndDate, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1005, 'Email Engine', 'Description', CURRENT, CURRENT, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO Projects(ProjectsID, Name, Description, StartDate, EndDate, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1006, 'Title Log', 'Description', CURRENT, CURRENT, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO Projects(ProjectsID, Name, Description, StartDate, EndDate, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1007, 'Subset Logger', 'Description', CURRENT, CURRENT, CURRENT, 'Tester', CURRENT, 'Tester');

-- assign projects to clients
INSERT INTO ClientProjects(ClientsID, ProjectsID, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1001, 1001, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO ClientProjects(ClientsID, ProjectsID, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1001, 1002, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO ClientProjects(ClientsID, ProjectsID, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1002, 1003, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO ClientProjects(ClientsID, ProjectsID, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1003, 1004, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO ClientProjects(ClientsID, ProjectsID, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1003, 1005, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO ClientProjects(ClientsID, ProjectsID, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1004, 1006, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO ClientProjects(ClientsID, ProjectsID, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1005, 1007, CURRENT, 'Tester', CURRENT, 'Tester');

-- assign workers and managers to projects
-- assign contractor as worker to all 4 projects
INSERT INTO ProjectWorkers(ProjectsID, UsersID, StartDate, EndDate, PayRate, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1001, 1001, CURRENT, CURRENT, 30, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO ProjectWorkers(ProjectsID, UsersID, StartDate, EndDate, PayRate, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1002, 1001, CURRENT, CURRENT, 30, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO ProjectWorkers(ProjectsID, UsersID, StartDate, EndDate, PayRate, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1003, 1001, CURRENT, CURRENT, 30, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO ProjectWorkers(ProjectsID, UsersID, StartDate, EndDate, PayRate, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1004, 1001, CURRENT, CURRENT, 30, CURRENT, 'Tester', CURRENT, 'Tester');
-- assign employee as worker to all 4 projects
INSERT INTO ProjectWorkers(ProjectsID, UsersID, StartDate, EndDate, PayRate, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1001, 1002, CURRENT, CURRENT, 0, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO ProjectWorkers(ProjectsID, UsersID, StartDate, EndDate, PayRate, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1002, 1002, CURRENT, CURRENT, 0, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO ProjectWorkers(ProjectsID, UsersID, StartDate, EndDate, PayRate, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1003, 1002, CURRENT, CURRENT, 0, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO ProjectWorkers(ProjectsID, UsersID, StartDate, EndDate, PayRate, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1004, 1002, CURRENT, CURRENT, 0, CURRENT, 'Tester', CURRENT, 'Tester');
-- assign manager as manager to all 4 projects
INSERT INTO ProjectManagers(ProjectsID, UsersID, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1001, 1003, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO ProjectManagers(ProjectsID, UsersID, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1002, 1003, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO ProjectManagers(ProjectsID, UsersID, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1003, 1003, CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO ProjectManagers(ProjectsID, UsersID, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1004, 1003, CURRENT, 'Tester', CURRENT, 'Tester');

