package com.topcoder.management.resource;

import java.io.Serializable;

public class ResourceRole implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setName(String name) {
	}
	public String getName() {
		return null;
	}
	public void setPhaseType(long phaseType) {
	}
	public long getPhaseType() {
		return 0;
	}
}
