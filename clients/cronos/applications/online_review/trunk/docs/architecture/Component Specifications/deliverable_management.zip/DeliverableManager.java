package com.topcoder.management.deliverable;

import com.topcoder.search.builder.filter.Filter;

public interface DeliverableManager {
	Deliverable[] searchDeliverables(Filter filter, boolean complete);
}
