package com.topcoder.management.project;

import java.io.Serializable;

public class ProjectCategory implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setName(String name) {
	}
	public String getName() {
		return null;
	}
	public void setPropectType(ProjectType projectType) {
	}
	public ProjectType ProjectType() {
		return null;
	}
}
