CREATE TABLE project_category_lu (
  project_category_id           INTEGER                     NOT NULL,
  PRIMARY KEY(project_category_id)
);
CREATE TABLE scorecard_type_lu (
  scorecard_type_id             INTEGER                     NOT NULL,
  name                          VARCHAR(64)                 NOT NULL,
  description                   VARCHAR(255)                NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(scorecard_type_id)
);
CREATE TABLE scorecard_status_lu (
  scorecard_status_id           INTEGER                     NOT NULL,
  name                          VARCHAR(64)                 NOT NULL,
  description                   VARCHAR(255)                NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(scorecard_status_id)
);
CREATE TABLE scorecard (
  scorecard_id                  INTEGER                     NOT NULL,
  scorecard_status_id           INTEGER                     NOT NULL,
  scorecard_type_id             INTEGER                     NOT NULL,
  project_category_id           INTEGER                     NOT NULL,
  name                          VARCHAR(64)                 NOT NULL,
  version                       VARCHAR(16)                 NOT NULL,
  min_score                     FLOAT                       NOT NULL,
  max_score                     FLOAT                       NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(scorecard_id),
  FOREIGN KEY(scorecard_type_id)
    REFERENCES scorecard_type_lu(scorecard_type_id),
  FOREIGN KEY(project_category_id)
    REFERENCES project_category_lu(project_category_id),
  FOREIGN KEY(scorecard_status_id)
    REFERENCES scorecard_status_lu(scorecard_status_id)
);
CREATE TABLE scorecard_group (
  scorecard_group_id            INTEGER                     NOT NULL,
  scorecard_id                  INTEGER                     NOT NULL,
  name                          VARCHAR(64)                 NOT NULL,
  weight                        FLOAT                       NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(scorecard_group_id),
  FOREIGN KEY(scorecard_id)
    REFERENCES scorecard(scorecard_id)
);
CREATE TABLE scorecard_section (
  scorecard_section_id          INTEGER                     NOT NULL,
  scorecard_group_id            INTEGER                     NOT NULL,
  name                          VARCHAR(64)                 NOT NULL,
  weight                        FLOAT                       NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(scorecard_section_id),
  FOREIGN KEY(scorecard_group_id)
    REFERENCES scorecard_group(scorecard_group_id)
);
CREATE TABLE scorecard_question_type_lu (
  scorecard_question_type_id    INTEGER                     NOT NULL,
  name                          VARCHAR(64)                 NOT NULL,
  description                   VARCHAR(255)                NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(scorecard_question_type_id)
);
CREATE TABLE scorecard_question (
  scorecard_question_id         INTEGER                     NOT NULL,
  scorecard_question_type_id    INTEGER                     NOT NULL,
  scorecard_section_id          INTEGER                     NOT NULL,
  description                   LVARCHAR(4096)              NOT NULL,
  guideline                     LVARCHAR(4096),
  weight                        FLOAT                       NOT NULL,
  upload_document               BOOLEAN                     NOT NULL,
  upload_document_required      BOOLEAN                     NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(scorecard_question_id),
  FOREIGN KEY(scorecard_section_id)
    REFERENCES scorecard_section(scorecard_section_id),
  FOREIGN KEY(scorecard_question_type_id)
    REFERENCES scorecard_question_type_lu(scorecard_question_type_id)
);
CREATE TABLE project (
  project_id                    INTEGER                     NOT NULL,
  PRIMARY KEY(project_id)
);
CREATE TABLE project_scorecard (
  project_id                    INTEGER                     NOT NULL,
  scorecard_id                  INTEGER                     NOT NULL,
  PRIMARY KEY(project_id, scorecard_id),
  FOREIGN KEY(project_id)
    REFERENCES project(project_id),
  FOREIGN KEY(scorecard_id)
    REFERENCES scorecard(scorecard_id)
);

CREATE TABLE id_sequences (
  name                  VARCHAR(255)    NOT NULL,
  next_block_start      INTEGER         NOT NULL,
  block_size            INTEGER         NOT NULL,
  exhausted             INTEGER         NOT NULL,
  PRIMARY KEY (name)
);

INSERT INTO id_sequences(name, next_block_start, block_size, exhausted)
  VALUES('scorecard_id_seq', 1, 20, 0);
INSERT INTO id_sequences(name, next_block_start, block_size, exhausted)
  VALUES('scorecard_group_id_seq', 1, 20, 0);
INSERT INTO id_sequences(name, next_block_start, block_size, exhausted)
  VALUES('scorecard_section_id_seq', 1, 20, 0);
INSERT INTO id_sequences(name, next_block_start, block_size, exhausted)
  VALUES('scorecard_question_id_seq', 1, 20, 0);

INSERT INTO scorecard_status_lu(scorecard_status_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(1, 'Active', 'Active', 'System', CURRENT, 'System', CURRENT);
INSERT INTO scorecard_status_lu(scorecard_status_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(2, 'Inactive', 'Inactive', 'System', CURRENT, 'System', CURRENT);
INSERT INTO scorecard_status_lu(scorecard_status_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(3, 'Deleted', 'Deleted', 'System', CURRENT, 'System', CURRENT);