package com.topcoder.management.project;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

public class Project implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setProjectStatus(ProjectStatus projectStatus) {
	}
	public ProjectStatus getProjectStatus() {
		return null;
	}
	public void setProjectCategory(ProjectCategory projectCategory) {
	}
	public ProjectCategory getProjectCategory() {
		return null;
	}
	public void setScorecard(long assignment, Long scorecard) {
	}
	public Long getScorecard(long assignment) {
		return null;
	}
	public Map getAllScorecards() {
		return null;
	}
	public void setProperty(String name, Object value) {
	}
	public Object getProperty(String name) {
		return null;
	}
	public Map getAllProperties() {
		return null;
	}
	public void setCreationUser(String creationUser) {
	}
	public String getCreationUser() {
		return null;
	}
	public void setCreationTimestamp(Date creationTimestamp) {
	}
	public Date getCreationTimestamp() {
		return null;
	}
	public void setModificationUser(String modificationUser) {
	}
	public String getModificationUser() {
		return null;
	}
	public void setModificationTimestamp(Date modificationTimestamp) {
	}
	public Date getModificationTimestamp() {
		return null;
	}
}
