package com.topcoder.management.project;

import com.topcoder.search.builder.filter.Filter;

public interface ProjectManager {
	void createProject(Project project, String operator);
	void updateProject(Project project, String reason, String operator);
	Project getProject(long id);
	Project[] searchProjects(Filter filter);
	Project[] getUserProjects(long user);
	ProjectCategory[] getAllProjectCategories();
	ProjectStatus[] getAllProjectStatuses();
	ScorecardAssignment[] getAllScorecardAssignments();
}
