package com.topcoder.project.phases.template;

import java.util.Date;
import com.topcoder.project.phases.Project;

public interface PhaseTemplate {
	String[] getAllTemplateNames();
	Project applyTemplate(String template, Date startDate);
}
