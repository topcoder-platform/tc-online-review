package com.topcoder.management.review;

import java.io.Serializable;

public class Comment implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setAuthor(long author) {
	}
	public long getAuthor() {
		return 0;
	}
	public void setCommentType(CommentType commentType) {
	}
	public CommentType getCommentType() {
		return null;
	}
	public void setComment(String comment) {
	}
	public String getComment() {
		return null;
	}
	public void setExtraInfo(Object extraInfo) {
	}
	public Object getExtraInfo() {
		return null;
	}
}
