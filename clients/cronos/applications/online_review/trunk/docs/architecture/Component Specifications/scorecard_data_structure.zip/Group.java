package com.topcoder.management.scorecard.data;

import java.io.Serializable;

public class Group implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setName(String name) {
	}
	public String getName() {
		return null;
	}
	public void setWeight(float weight) {
	}
	public float getWeight() {
		return 0;
	}
	public void addSection(Section section) {
	}
	public void removeSection(Section section) {
	}
	public Section[] getAllSections() {
		return null;
	}
}
