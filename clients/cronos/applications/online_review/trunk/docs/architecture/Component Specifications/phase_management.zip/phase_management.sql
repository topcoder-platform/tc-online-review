CREATE TABLE project (
  project_id                    INTEGER                     NOT NULL,
  PRIMARY KEY(project_id)
);
CREATE TABLE phase_status_lu (
  phase_status_id               INTEGER                     NOT NULL,
  name                          VARCHAR(64)                 NOT NULL,
  description                   VARCHAR(255)                NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(phase_status_id)
);
CREATE TABLE phase_type_lu (
  phase_type_id                 INTEGER                     NOT NULL,
  name                          VARCHAR(64)                 NOT NULL,
  description                   VARCHAR(255)                NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(phase_type_id)
);
CREATE TABLE phase (
  phase_id                      INTEGER                     NOT NULL,
  project_id                    INTEGER                     NOT NULL,
  phase_type_id                 INTEGER                     NOT NULL,
  phase_status_id               INTEGER                     NOT NULL,
  fixed_start_time              DATETIME YEAR TO SECOND     NOT NULL,
  actual_start_time             DATETIME YEAR TO SECOND,
  actual_end_time               DATETIME YEAR TO SECOND,
  duration                      INTERVAL DAY TO SECOND      NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(phase_id),
  FOREIGN KEY(phase_type_id)
    REFERENCES phase_type_lu(phase_type_id),
  FOREIGN KEY(project_id)
    REFERENCES project(project_id),
  FOREIGN KEY(phase_status_id)
    REFERENCES phase_status_lu(phase_status_id)
);
CREATE TABLE phase_dependency (
  dependency_phase_id           INTEGER                     NOT NULL,
  dependent_phase_id            INTEGER                     NOT NULL,
  start_or_end                  BOOLEAN                     NOT NULL,
  before_or_after               BOOLEAN                     NOT NULL,
  lag_time                      INTERVAL DAY TO SECOND      NOT NULL,
  PRIMARY KEY(dependency_phase_id, dependent_phase_id),
  FOREIGN KEY(dependency_phase_id)
    REFERENCES phase(phase_id),
  FOREIGN KEY(dependent_phase_id)
    REFERENCES phase(phase_id)
);
CREATE TABLE phase_criteria_type_lu (
  phase_criteria_type_id        INTEGER                     NOT NULL,
  name                          VARCHAR(64)                 NOT NULL,
  description                   VARCHAR(255)                NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(phase_criteria_type_id)
);
CREATE TABLE phase_criteria (
  phase_id                      INTEGER                     NOT NULL,
  phase_criteria_type_id       INTEGER                     NOT NULL,
  parameter                     VARCHAR(255)                NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(phase_id, phase_criteria_type_id),
  FOREIGN KEY(phase_id)
    REFERENCES phase(phase_id),
  FOREIGN KEY(phase_criteria_type_id)
    REFERENCES phase_criteria_type_lu(phase_criteria_type_id)
);

CREATE TABLE id_sequences (
  name                  VARCHAR(255)    NOT NULL,
  next_block_start      INTEGER         NOT NULL,
  block_size            INTEGER         NOT NULL,
  exhausted             INTEGER         NOT NULL,
  PRIMARY KEY (name)
);

INSERT INTO id_sequences(name, next_block_start, block_size, exhausted)
  VALUES('phase_id_seq', 1, 20, 0);

INSERT INTO phase_status_lu(phase_status_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(1, 'Scheduled', 'Scheduled', 'System', CURRENT, 'System', CURRENT);
INSERT INTO phase_status_lu(phase_status_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(2, 'Open', 'Open', 'System', CURRENT, 'System', CURRENT);
INSERT INTO phase_status_lu(phase_status_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(3, 'Closed', 'Closed', 'System', CURRENT, 'System', CURRENT);