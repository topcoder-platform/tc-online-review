package com.topcoder.management.scorecard.data;

import java.io.Serializable;

public class Question implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setQuestionType(QuestionType questionType) {
	}
	public QuestionType getQuestionType() {
		return null;
	}
	public void setDescription(String description) {
	}
	public String getDescription() {
		return null;
	}
	public void setGuideline(String guideline) {
	}
	public String getGuideline() {
		return null;
	}
	public void setWeight(float weight) {
	}
	public float getWeight() {
		return 0;
	}
	public void setUploadDocument(boolean uploadDocument) {
	}
	public boolean isUploadDocument() {
		return false;
	}
	public void setUploadRequired(boolean uploadRequired) {
	}
	public boolean isUploadRequired() {
		return false;
	}
}
