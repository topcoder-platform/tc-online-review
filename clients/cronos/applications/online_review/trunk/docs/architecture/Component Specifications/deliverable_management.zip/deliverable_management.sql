CREATE TABLE resource (
  resource_id                   INTEGER                     NOT NULL,
  PRIMARY KEY(resource_id)
);
CREATE TABLE project (
  project_id                    INTEGER                     NOT NULL,
  PRIMARY KEY(project_id)
);
CREATE TABLE phase_type_lu (
  phase_type_id                 INTEGER                     NOT NULL,
  PRIMARY KEY(phase_type_id)
);
CREATE TABLE resource_role_lu (
  resource_role_id              INTEGER                     NOT NULL,
  PRIMARY KEY(resource_role_id)
);
CREATE TABLE upload_status_lu (
  upload_status_id              INTEGER                     NOT NULL,
  name                          VARCHAR(64)                 NOT NULL,
  description                   VARCHAR(255)                NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(upload_status_id)
);
CREATE TABLE upload (
  upload_id                     INTEGER                     NOT NULL,
  project_id                    INTEGER                     NOT NULL,
  resource_id                   INTEGER                     NOT NULL,
  upload_type_id                INTEGER                     NOT NULL,
  upload_status_id              INTEGER                     NOT NULL,
  parameter                     VARCHAR(255)                NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(upload_id),
  FOREIGN KEY(upload_type_id)
    REFERENCES upload_type_lu(upload_type_id),
  FOREIGN KEY(upload_status_id)
    REFERENCES upload_status_lu(upload_status_id),
  FOREIGN KEY(resource_id)
    REFERENCES resource(resource_id),
  FOREIGN KEY(project_id)
    REFERENCES project(project_id)
);
CREATE TABLE submission_status_lu (
  submission_status_id          INTEGER                     NOT NULL,
  name                          VARCHAR(64)                 NOT NULL,
  description                   VARCHAR(255)                NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(submission_status_id)
);
CREATE TABLE submission (
  submission_id                 INTEGER                     NOT NULL,
  upload_id                     INTEGER                     NOT NULL,
  submission_status_id          INTEGER                     NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(submission_id),
  FOREIGN KEY(submission_status_id)
    REFERENCES submission_status_lu(submission_status_id),
  FOREIGN KEY(upload_id)
    REFERENCES upload(upload_id)
);
CREATE TABLE deliverable_lu (
  deliverable_id                INTEGER                     NOT NULL,
  phase_type_id                 INTEGER                     NOT NULL,
  resource_role_id              INTEGER                     NOT NULL,
  name                          VARCHAR(64)                 NOT NULL,
  description                   VARCHAR(64)                 NOT NULL,
  per_submission                BOOLEAN                     NOT NULL,
  required                      BOOLEAN                     NOT NULL,
  creation_user                 VARCHAR(64)                 NOT NULL,
  creation_date                 DATETIME YEAR TO SECOND     NOT NULL,
  modification_user             VARCHAR(64)                 NOT NULL,
  modification_date             DATETIME YEAR TO SECOND     NOT NULL,
  PRIMARY KEY(deliverable_id),
  FOREIGN KEY(phase_type_id)
    REFERENCES phase_type_lu(phase_type_id),
  FOREIGN KEY(resource_role_id)
    REFERENCES resource_role_lu(resource_role_id)
);

CREATE TABLE id_sequences (
  name                  VARCHAR(255)    NOT NULL,
  next_block_start      INTEGER         NOT NULL,
  block_size            INTEGER         NOT NULL,
  exhausted             INTEGER         NOT NULL,
  PRIMARY KEY (name)
);

INSERT INTO id_sequences(name, next_block_start, block_size, exhausted)
  VALUES('upload_id_seq', 1, 20, 0);
INSERT INTO id_sequences(name, next_block_start, block_size, exhausted)
  VALUES('submission_id_seq', 1, 20, 0);

INSERT INTO upload_type_lu(upload_type_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(1, 'Submission', 'Submission', 'System', CURRENT, 'System', CURRENT);
INSERT INTO upload_type_lu(upload_type_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(2, 'Test Case', 'Test Case', 'System', CURRENT, 'System', CURRENT);
INSERT INTO upload_type_lu(upload_type_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(3, 'Final Fix', 'Final Fix', 'System', CURRENT, 'System', CURRENT);
INSERT INTO upload_type_lu(upload_type_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(4, 'Review Document', 'Review Document', 'System', CURRENT, 'System', CURRENT);

INSERT INTO upload_status_lu(upload_status_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(1, 'Active', 'Active', 'System', CURRENT, 'System', CURRENT);
INSERT INTO upload_status_lu(upload_status_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(2, 'Deleted', 'Deleted', 'System', CURRENT, 'System', CURRENT);

INSERT INTO submission_status_lu(submission_status_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(1, 'Active', 'Active', 'System', CURRENT, 'System', CURRENT);
INSERT INTO submission_status_lu(submission_status_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(2, 'Failed Automated Screening', 'Failed Automated Screening', 'System', CURRENT, 'System', CURRENT);
INSERT INTO submission_status_lu(submission_status_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(3, 'Failed Screening', 'Failed Screening', 'System', CURRENT, 'System', CURRENT);
INSERT INTO submission_status_lu(submission_status_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(4, 'Failed Review', 'Failed Review', 'System', CURRENT, 'System', CURRENT);
INSERT INTO submission_status_lu(submission_status_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(5, 'Completed Without Winning', 'Completed Without Winning', 'System', CURRENT, 'System', CURRENT);
INSERT INTO submission_status_lu(submission_status_id, name, description, creation_user, creation_date, modification_user, modification_date)
  VALUES(6, 'Deleted', 'Deleted', 'System', CURRENT, 'System', CURRENT);
