package com.topcoder.project.phases;

import java.util.Date;

public class Phase extends AttributableObject {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public Project getProject() {
		return null;
	}
	public void setPhaseType(PhaseType phaseType) {
	}
	public PhaseType getPhaseType() {
		return null;
	}
	public void setPhaseStatus(PhaseStatus phaseStatus) {
	}
	public PhaseStatus getPhaseStatus() {
		return null;
	} 
	public void setFixedStartDate(Date fixedStartDate) {
	}
	public Date getFixedStartDate() {
		return null;
	}
	public void setLength(int length) {
	}
	public int getLength() {
		return 0;
	}
	public void setActualStartDate(Date actualStartDate) {
	}
	public Date getActualStartDate() {
		return null;
	}
	public void setActualEndDate(Date actualEndDate) {
	}
	public Date getActualEndDate() {
		return null;
	}
	public void addDependency(Dependency dependency) {
	}
	public void removeDependency(Dependency dependency) {
	}
	public Dependency[] getAllDependencies() {
		return null;
	}
	public Date calcStartDate() {
		return null;
	}
	public Date calcEndDate() {
		return null;
	}
}
