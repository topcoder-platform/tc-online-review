package com.cronos.onlinereview.autoscreening.management;

import java.io.Serializable;

public class ScreeningResult implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setScreeningResponse(ScreeningResponse screeningResponse) {
	}
	public ScreeningResponse getScreeningResponse() {
		return null;
	}
	public void setDynamicText(String dynamicText) {
	}
	public String getDynamicText() {
		return null;
	}
}
