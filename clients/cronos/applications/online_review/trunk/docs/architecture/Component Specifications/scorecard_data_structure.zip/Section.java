package com.topcoder.management.scorecard.data;

import java.io.Serializable;

public class Section implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setName(String name) {
	}
	public String getName() {
		return null;
	}
	public void setWeight(float weight) {
	}
	public float getWeight() {
		return 0;
	}
	public void addQuestion(Question question) {
	}
	public void removeQuestion(Question question) {
	}
	public Question[] getAllQuestions() {
		return null;
	}
}
