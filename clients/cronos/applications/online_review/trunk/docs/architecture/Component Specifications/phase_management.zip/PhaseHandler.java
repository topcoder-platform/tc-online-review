package com.topcoder.management.phase;

import com.topcoder.project.phases.Phase;

public interface PhaseHandler {
	boolean canPerform(Phase phase);
	void perform(Phase phase, String operator);
}
