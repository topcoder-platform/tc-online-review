package com.topcoder.project.phases;

import java.util.Date;

public class Project extends AttributableObject {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void addPhase(Phase phase) {
	}
	public void removePhase(Phase phase) {
	}
	public Phase[] getAllPhases() {
		return null;
	}
	public void setStartDate(Date startDate) {
	}
	public Date getStartDate() {
		return null;
	}
}
