package com.topcoder.project.phases;

import java.io.Serializable;

public class Dependency implements Serializable {
	public void setDependency(Phase dependency) {
	}
	public Phase getDependency() {
		return null;
	}
	public void setDependent(Phase dependent) {
	}
	public Phase getDependent() {
		return null;
	}
	public void setStart(boolean start) {
	}
	public boolean isStart() {
		return false;
	}
	public void setBefore(boolean before) {
	}
	public boolean isBefore() {
		return false;
	}
	public void setLagTime(int lagTime) {
	}
	public int getLagTime() {
		return 0;
	}
}
