package com.topcoder.management.deliverable;

public interface DeliverableChecker {
	void check(Deliverable deliverable);
}
