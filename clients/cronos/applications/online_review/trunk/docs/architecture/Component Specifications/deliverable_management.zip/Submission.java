package com.topcoder.management.deliverable;

import java.io.Serializable;
import java.util.Date;

public class Submission implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setUpload(Upload upload) {
	}
	public Upload getUpload() {
		return null;
	}
	public void setSubmissionStatus(SubmissionStatus submissionStatus) {
	}
	public SubmissionStatus getSubmissionStatus() {
		return null;
	}
	public void setCreationUser(String creationUser) {
	}
	public String getCreationUser() {
		return null;
	}
	public void setCreationTimestamp(Date creationTimestamp) {
	}
	public Date getCreationTimestamp() {
		return null;
	}
	public void setModificationUser(String modificationUser) {
	}
	public String getModificationUser() {
		return null;
	}
	public void setModificationTimestamp(Date modificationTimestamp) {
	}
	public Date getModificationTimestamp() {
		return null;
	}
}
