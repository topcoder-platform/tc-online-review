package com.topcoder.project.phases;

import java.util.Map;
import java.io.Serializable;

public abstract class AttributableObject implements Serializable {
	public void setAttribute(Object key, Object value) {
	}
	public Object getAttribute(Object key) {
		return null;
	}
	public Map getAllAttributes() {
		return null;
	}
}
