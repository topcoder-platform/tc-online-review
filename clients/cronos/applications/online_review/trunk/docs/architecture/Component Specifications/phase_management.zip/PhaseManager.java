package com.topcoder.management.phase;

import com.topcoder.project.phases.Project;
import com.topcoder.project.phases.Phase;
import com.topcoder.project.phases.PhaseType;
import com.topcoder.project.phases.PhaseStatus;

public interface PhaseManager {
	void updatePhases(Project project, String operator);
	Project getPhases(long project);
	Project[] getPhases(long[] projects);
	PhaseType[] getAllPhaseTypes();
	PhaseStatus[] getAllPhaseStatuses();
	boolean canStart(Phase phase);
	void start(Phase phase, String operator);
	boolean canEnd(Phase phase);
	void end(Phase phase, String operator);
	boolean canCancel(Phase phase);
	void cancel(Phase phase, String operator);
}
