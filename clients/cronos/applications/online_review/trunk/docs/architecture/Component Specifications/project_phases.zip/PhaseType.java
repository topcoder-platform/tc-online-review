package com.topcoder.project.phases;

import java.io.Serializable;

public class PhaseType implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setName(String name) {
	}
	public String getName() {
		return null;
	}
}
