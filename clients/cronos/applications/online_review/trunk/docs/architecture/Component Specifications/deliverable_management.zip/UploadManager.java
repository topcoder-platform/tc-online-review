package com.topcoder.management.deliverable;

import com.topcoder.search.builder.filter.Filter;

public interface UploadManager {
	void createUpload(Upload upload, String operator);
	void updateUpload(Upload upload, String operator);
	Upload getUpload(long id);
	Upload[] searchUploads(Filter filter);
	UploadType[] getAllUploadTypes();
	UploadStatus[] getAllUploadStatuses();
	void createSubmission(Submission submission, String operator);
	void updateSubmission(Submission submission, String operator);
	Submission getSubmission(long id);
	Submission[] searchSubmissions(Filter filter);
	SubmissionStatus[] getAllSubmissionStatuses();
}
