package com.cronos.onlinereview.autoscreening.management;

import java.io.Serializable;

public class ResponseSeverity implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setName(String name) {
	}
	public String getName() {
		return null;
	}
}
