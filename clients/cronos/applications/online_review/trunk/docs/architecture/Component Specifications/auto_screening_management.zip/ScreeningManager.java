package com.cronos.onlinereview.autoscreening.management;

public interface ScreeningManager {
	void initiateScreening(long upload, String operator);
	ScreeningTask getScreeningDetails(long upload);
	ScreeningTask[] getScreeningTasks(long[] uploads);
}
