package com.cronos.onlinereview.autoscreening.management;

import java.io.Serializable;
import java.util.Date;

public class ScreeningTask implements Serializable {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setScreeningStatus(ScreeningStatus screeningStatus) {
	}
	public ScreeningStatus getScreeningStatus() {
		return null;
	}
	public void setUpload(long upload) {
	}
	public long getUpload() {
		return 0;
	}
	public void setScreener(long screener) {
	}
	public long getScreener() {
		return 0;
	}
	public void setStartTimestamp(Date startTimestamp) {
	}
	public Date getStartTimestamp() {
		return null;
	}
	public void addScreeningResult(ScreeningResult screeningResult) {
	}
	public void removeScreeningResult(ScreeningResult screeningResult) {
	}
	public ScreeningResult[] getAllScreeningResults() {
		return null;
	}
	public void setCreationUser(String creationUser) {
	}
	public String getCreationUser() {
		return null;
	}
	public void setCreationTimestamp(Date creationTimestamp) {
	}
	public Date getCreationTimestamp() {
		return null;
	}
	public void setModificationUser(String modificationUser) {
	}
	public String getModificationUser() {
		return null;
	}
	public void setModificationTimestamp(Date modificationTimestamp) {
	}
	public Date getModificationTimestamp() {
		return null;
	}
}
