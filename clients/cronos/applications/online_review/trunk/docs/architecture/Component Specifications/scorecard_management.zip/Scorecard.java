package com.topcoder.management.scorecard;

import java.io.Serializable;
import java.util.Date;

public class Scorecard {
	public void setId(long id) {
	}
	public long getId() {
		return 0;
	}
	public void setScorecardStatus(ScorecardStatus scorecardStatus) {
	}
	public ScorecardStatus getScorecardStatus() {
		return null;
	}
	public void setScorecardType(ScorecardType scorecardType) {
	}
	public ScorecardType getScorecardType() {
		return null;
	}
	public void setCategory(long category) {
	}
	public long getCategory() {
		return 0;
	}
	public void setName(String name) {
	}
	public String getName() {
		return null;
	}
	public void setVersion(String version) {
	}
	public String getVersion() {
		return null;
	}
	public void setMinScore(float minScore) {
	}
	public float getMinScore() {
		return 0;
	}
	public void setMaxScore(float maxScore) {
	}
	public float getMaxScore() {
		return 0;
	}
	public void addGroup(Group group) {
	}
	public void removeGroup(Group group) {
	}
	public Group[] getAllGroups() {
		return null;
	}
	public boolean isInUse() {
		return false;
	}
	public String getCreationUser() {
		return null;
	}
	public Date getCreationTimestamp() {
		return null;
	}
	public String getModificationUser() {
		return null;
	}
	public Date getModificationTimestamp() {
		return null;
	}
}
