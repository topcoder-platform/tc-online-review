-- Required roles for Time Tracker application
--insert into role (role_id, role_name) values (1, 'Super Administrator');   -- Deprecated
--insert into role (role_id, role_name) values (2, 'Human Resource');        -- Deprecated
--insert into role (role_id, role_name) values (3, 'Account Manager');       -- Deprecated
--insert into role (role_id, role_name) values (4, 'Project Manager');       -- Deprecated
insert into role (role_id, role_name) values (5, 'Employee');
insert into role (role_id, role_name) values (6, 'Contractor');
insert into role (role_id, role_name) values (7, 'Manager');
insert into role (role_id, role_name) values (8, 'Administrator');

-- Required actions for Time Tracker application
insert into action (action_id, class_name, action_name)
    values (1, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Login');
insert into action (action_id, class_name, action_name)
    values (2, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Enter Time');
insert into action (action_id, class_name, action_name)
    values (3, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Enter Expense');
insert into action (action_id, class_name, action_name)
    values (4, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Project Report');
insert into action (action_id, class_name, action_name)
    values (5, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Employee Report');
insert into action (action_id, class_name, action_name)
    values (6, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Personal Employee Report');
insert into action (action_id, class_name, action_name)
    values (7, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Client Report');
insert into action (action_id, class_name, action_name)
    values (8, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Approve Any Contractor Time');
insert into action (action_id, class_name, action_name)
    values (9, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Approve Managed Contractor Time');
insert into action (action_id, class_name, action_name)
    values (10, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Add Any Project');
insert into action (action_id, class_name, action_name)
    values (11, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Add Managed Project');
insert into action (action_id, class_name, action_name)
    values (12, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Edit Any Project');
insert into action (action_id, class_name, action_name)
    values (13, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Edit Managed Project');
insert into action (action_id, class_name, action_name)
    values (14, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Delete Any Project');
insert into action (action_id, class_name, action_name)
    values (15, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Delete Managed Project');
insert into action (action_id, class_name, action_name)
    values (16, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Add Client');
insert into action (action_id, class_name, action_name)
    values (17, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Edit Client');
insert into action (action_id, class_name, action_name)
    values (18, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Delete Client');
insert into action (action_id, class_name, action_name)
    values (19, 'com.topcoder.security.authorization.persistence.GeneralAction', 'Edit User');

-- Required action context for Time Tracker application
insert into action_context (action_context_id, class_name, action_context_name, action_context_parent_id)
    values (1, 'com.topcoder.security.authorization.persistence.GeneralActionContext', 'Time Tracker', 1);

-- Required action role context for Time Tracker application

-- For Employee role
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 1, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 2, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 3, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 4, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 5, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 6, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 7, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 8, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 9, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 10, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 11, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 12, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 13, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 14, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 15, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 16, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 17, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 18, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (5, 19, 1, 0);

-- For Contractor role
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 1, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 2, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 3, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 4, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 5, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 6, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 7, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 8, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 9, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 10, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 11, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 12, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 13, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 14, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 15, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 16, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 17, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 18, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (6, 19, 1, 0);

-- For Manager role
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 1, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 2, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 3, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 4, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 5, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 6, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 7, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 8, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 9, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 10, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 11, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 12, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 13, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 14, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 15, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 16, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 17, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 18, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (7, 19, 1, 1);

-- For Administrator role
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 1, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 2, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 3, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 4, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 5, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 6, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 7, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 8, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 9, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 10, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 11, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 12, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 13, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 14, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 15, 1, 0);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 16, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 17, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 18, 1, 1);
insert into role_action_context_permission (role_id, action_id, action_context_id, permission) values (8, 19, 1, 1);





-- The standard reject reasons

INSERT INTO reject_reason (reject_reason_id, description, creation_date, creation_user, modification_date, modification_user)
    VALUES (1, 'Work Incomplete', CURRENT, 'System', CURRENT, 'System');

INSERT INTO reject_reason (reject_reason_id, description, creation_date, creation_user, modification_date, modification_user)
    VALUES (2, 'Unapproved Hours', CURRENT, 'System', CURRENT, 'System');

INSERT INTO reject_reason (reject_reason_id, description, creation_date, creation_user, modification_date, modification_user)
    VALUES (3, 'Client Review', CURRENT, 'System', CURRENT, 'System');



-- The standard expense statuses

INSERT INTO ExpenseStatuses (ExpenseStatusesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1, 'Entered', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseStatuses (ExpenseStatusesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (2, 'Pending', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseStatuses (ExpenseStatusesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (3, 'Accepted', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseStatuses (ExpenseStatusesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (4, 'Rejected', CURRENT, 'System', CURRENT, 'System');



-- The standard expense types

INSERT INTO ExpenseTypes (ExpenseTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1, 'Air Transportation', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseTypes (ExpenseTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (2, 'Rail Transportation', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseTypes (ExpenseTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (3, 'Taxi', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseTypes (ExpenseTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (4, 'Parking', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseTypes (ExpenseTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (5, 'Auto Mileage', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseTypes (ExpenseTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (6, 'Lodging', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseTypes (ExpenseTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (7, 'Meals', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseTypes (ExpenseTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (8, 'Entertainment', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseTypes (ExpenseTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (9, 'Phone Calls', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseTypes (ExpenseTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (10, 'Monthly Cell Phone', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseTypes (ExpenseTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (11, 'Car Rental', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseTypes (ExpenseTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (12, 'Tolls', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseTypes (ExpenseTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (13, 'Office Supplies', CURRENT, 'System', CURRENT, 'System');

INSERT INTO ExpenseTypes (ExpenseTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (14, 'Other', CURRENT, 'System', CURRENT, 'System');



-- The standard task types

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1, 'Component Development', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (2, 'Component Design', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (3, 'Specification', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (4, 'Meeting', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (5, 'Pre-sales', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (6, 'Sales', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (7, 'Miscellaneous', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (8, 'Project Management', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (9, 'Information Architecture', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (10, 'Prototype Creation', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (11, 'Test Case Creation', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (12, 'Prototype Conversion', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (13, 'Sequence Diagram Implementation', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (14, 'Bug Fixes', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (15, 'Client Proposal Creation', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (16, 'Sales Call', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (17, 'New Client Research', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (18, 'Other', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (19, 'Travel', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (20, 'Holiday', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (21, 'Sick', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (22, 'Vacation', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (23, 'Application Assembly', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (24, 'Application Architecture', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (25, 'Certification', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (26, 'Deployment', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (27, 'Component Production', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (28, 'Time and Expenses', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (29, 'Internal Development', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (30, 'Reviewing', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TaskTypes (TaskTypesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (31, 'Training', CURRENT, 'System', CURRENT, 'System');


-- The standard time statuses

INSERT INTO TimeStatuses (TimeStatusesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (1, 'Entered', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TimeStatuses (TimeStatusesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (2, 'Pending', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TimeStatuses (TimeStatusesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (3, 'Accepted', CURRENT, 'System', CURRENT, 'System');

INSERT INTO TimeStatuses (TimeStatusesID, Description, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (4, 'Rejected', CURRENT, 'System', CURRENT, 'System');



INSERT INTO id_sequences (name,next_block_start,block_size,exhausted) VALUES 
 ('com.topcoder.security.authorization.Action',1,20,0);
INSERT INTO id_sequences (name,next_block_start,block_size,exhausted) VALUES 
 ('com.topcoder.security.authorization.ActionContext',1,20,0);
INSERT INTO id_sequences (name,next_block_start,block_size,exhausted) VALUES 
 ('com.topcoder.security.authorization.Principal',1,20,0);
INSERT INTO id_sequences (name,next_block_start,block_size,exhausted) VALUES 
 ('com.topcoder.security.authorization.SecurityRole',1,20,0);
INSERT INTO id_sequences (name,next_block_start,block_size,exhausted) VALUES 
 ('TimeTrackerID',60000001,20,0);
INSERT INTO id_sequences (name,next_block_start,block_size,exhausted) VALUES 
 ('TimeTrackerUser',50000001,20,0);
INSERT INTO id_sequences (name,next_block_start,block_size,exhausted) VALUES
 ('com.cronos.timetracker.entry.time.TimeEntry',1,20,0);

INSERT INTO DefaultUsers(DefaultUsersID, UserName, Password, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (9999999, 'admin', 'tc_super', CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO Users(UsersID, Name, UserStore, CreationDate, CreationUser, ModificationDate, ModificationUser)
    VALUES (9999999, 'admin', 'DbUS', CURRENT, 'Tester', CURRENT, 'Tester');
INSERT INTO principal(principal_id, principal_name) VALUES(9999999, 'admin');
INSERT INTO principal_role(principal_id, role_id) VALUES(9999999, 8);
