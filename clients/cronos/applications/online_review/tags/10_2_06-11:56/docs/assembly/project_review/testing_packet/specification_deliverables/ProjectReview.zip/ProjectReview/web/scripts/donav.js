function DoNav(theUrl)  
{    
document.location.href = theUrl;  
}  
