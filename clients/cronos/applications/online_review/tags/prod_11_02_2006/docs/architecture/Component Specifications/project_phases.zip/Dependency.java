package com.topcoder.project.phases;

import java.io.Serializable;

public class Dependency implements Serializable {
	public void setDependency(Phase dependency) {
	}
	public Phase getDependency() {
		return null;
	}
	public void setDependent(Phase dependent) {
	}
	public Phase getDependent() {
		return null;
	}
	public void setDependencyStart(boolean dependencyStart) {
	}
	public boolean isDependencyStart() {
		return false;
	}
	public void setDependentStart(boolean dependentStart) {
	}
	public boolean isDependentStart() {
		return false;
	}
	public void setLagTime(long lagTime) {
	}
	public long getLagTime() {
		return 0;
	}
}
