<!--Preload Nav Bar Buttons

if (document.images) {

	siteAdminon = new Image();
	siteAdminon.src = "images/siteAdmin_hover.gif";

	siteAdminoff = new Image();
	siteAdminoff.src = "images/siteAdmin_off.gif";

	catalogAdminon = new Image();
	catalogAdminon.src = "images/catalogAdmin_hover.gif";

	catalogAdminoff = new Image();
	catalogAdminoff.src = "images/catalogAdmin_off.gif";

	categoryAdminon = new Image();
	categoryAdminon.src = "images/categoryAdmin_hover.gif";

	categoryAdminoff = new Image();
	categoryAdminoff.src = "images/categoryAdmin_off.gif";

	userAdminon = new Image();
	userAdminon.src = "images/userAdmin_hover.gif";

	userAdminoff = new Image();
	userAdminoff.src = "images/userAdmin_off.gif";

	listsAdminon = new Image();
	listsAdminon.src = "images/listAdmin_hover.gif";

	listsAdminoff = new Image();
	listsAdminoff.src = "images/listAdmin_off.gif";

	scorecardAdminon = new Image();
	scorecardAdminon.src = "images/scorecardAdmin_hover.gif";

	scorecardAdminoff = new Image();
	scorecardAdminoff.src = "images/scorecardAdmin_off.gif";
}

// -->